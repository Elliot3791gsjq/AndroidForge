#!/bin/bash
# Tests the TXT/DOCX document view (app/src/main/assets/doc/doc.js + doc.css) in headless Chromium:
# position restore, highlights, search marks, selection ranges, live style changes, RTL/LTR, taps, and the
# far jumps / relayout of a 20 000 block document. Needs python3 and playwright with a Chromium build.
# This runs the page on a desktop engine; it says nothing about the phone's WebView (see docs/KNOWN_LIMITATIONS.md).
set -e
HERE=$(cd "$(dirname "$0")" && pwd)
ROOT=$(cd "$HERE/../.." && pwd)
W=$(mktemp -d)
cp "$ROOT"/app/src/main/assets/doc/doc.js "$ROOT"/app/src/main/assets/doc/doc.css "$HERE"/*.py "$W"/
cd "$W"
python3 gen.py small mid
python3 t_small.py
python3 t_big.py mid 10000 15000
