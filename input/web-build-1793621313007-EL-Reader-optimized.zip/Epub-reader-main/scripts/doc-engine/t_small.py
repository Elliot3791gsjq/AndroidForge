import json, sys, http.server, threading, functools
from playwright.sync_api import sync_playwright
texts = json.load(open("small.json", encoding="utf-8"))
H = functools.partial(http.server.SimpleHTTPRequestHandler, directory=".")
class Q(http.server.ThreadingHTTPServer): pass
srv = Q(("127.0.0.1", 8765), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
STYLE = dict(fs=18, lh=1.6, para=0.6, mx=16, indent=0, fg="#222", bg="#fff", link="#1a5fd0", font="sans-serif", weight=400, align="doc", dir="auto", docFonts=False, docColors=True, dark=False)
fails = 0
def check(name, cond, extra=""):
    global fails
    print(("PASS " if cond else "FAIL ") + name, extra)
    if not cond: fails += 1
with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={"width": 390, "height": 844}, device_scale_factor=2)
    pg.add_init_script("""window.__calls=[];window.NR=new Proxy({}, {get:(t,k)=>(...a)=>{window.__calls.push([k,...a])}});""")
    pg.goto("http://127.0.0.1:8765/small.html")
    pg.evaluate("s=>DocApp.init({style:s, block:50, frac:0.3, highlights:[]})", STYLE)
    pg.wait_for_timeout(900)
    pos = pg.evaluate("DocApp.position()")
    check("restore block 50 frac .3", pos["i"] == 50 and abs(pos["f"] - 0.3) < 0.06, str(pos))
    # textContent of every block equals the text list
    bad = pg.evaluate("t=>{const bl=DocApp._blocks();let bad=[];for(let i=0;i<t.length;i++){if(bl[i].textContent!==t[i])bad.push(i)}return bad.slice(0,5)}", texts)
    check("block textContent == texts", bad == [], str(bad))
    # highlights
    hl = [dict(id=1, b=10, s=3, e=20, c="#ffeb3b", k="hl"), dict(id=2, b=5, s=0, e=len(texts[5]), c="#64b5f6", k="ul"), dict(id=3, b=15, s=12, e=40, c="#f48fb1", k="nt")]
    pg.evaluate("h=>DocApp.setHighlights(h)", hl)
    got = pg.evaluate("()=>[1,2,3].map(id=>Array.from(document.querySelectorAll('mark[data-h=\"'+id+'\"]')).map(m=>m.textContent).join(''))")
    check("highlight text 1", got[0] == texts[10][3:20], repr(got[0]))
    check("highlight text 2 (whole block)", got[1] == texts[5], "")
    check("highlight text 3 across <b>/<span>", got[2] == texts[15][12:40], repr(got[2]))
    bad = pg.evaluate("t=>{const bl=DocApp._blocks();let bad=[];for(let i=0;i<t.length;i++){if(bl[i].textContent!==t[i])bad.push(i)}return bad.slice(0,5)}", texts)
    check("textContent unchanged after marking", bad == [], str(bad))
    pg.evaluate("DocApp.setHighlights([])")
    n = pg.evaluate("document.querySelectorAll('mark').length")
    check("highlights cleared", n == 0, str(n))
    # search
    hits = [[20, 5, 9], [20, 30, 36], [21, 0, 4]]
    pg.evaluate("h=>DocApp.setSearch(h,1)", hits)
    got = pg.evaluate("()=>[0,1,2].map(k=>Array.from(document.querySelectorAll('mark.sr[data-k=\"'+k+'\"]')).map(m=>m.textContent).join(''))")
    check("search marks", got == [texts[20][5:9], texts[20][30:36], texts[21][0:4]], str(got))
    on = pg.evaluate("document.querySelectorAll('mark.sr.on').length")
    check("active hit marked", on >= 1, str(on))
    pg.evaluate("DocApp.clearSearch()")
    check("search cleared", pg.evaluate("document.querySelectorAll('mark').length") == 0)
    # selection across two blocks
    pg.evaluate("""()=>{const bl=DocApp._blocks();const r=document.createRange();
      r.setStart(bl[30].firstChild,4); const last=bl[32]; const w=document.createTreeWalker(last,NodeFilter.SHOW_TEXT);let n,l;while(n=w.nextNode())l=n; r.setEnd(l,7);
      const s=getSelection();s.removeAllRanges();s.addRange(r);}""")
    pay = pg.evaluate("DocApp.selection()")
    exp = [dict(b=30, s=4, e=len(texts[30])), dict(b=31, s=0, e=len(texts[31]))]
    r32 = pay["ranges"][-1]
    # end offset inside block 32 is 7 counted from the last text node start, so just check structure
    check("selection ranges blocks 30..32", [x["b"] for x in pay["ranges"]] == [30, 31, 32] and pay["ranges"][0]["s"] == 4 and pay["ranges"][1]["e"] == len(texts[31]), str(pay["ranges"]))
    # triple-click style: range ends at start of the next block
    pg.evaluate("""()=>{const bl=DocApp._blocks();const r=document.createRange();r.setStart(bl[40],0);r.setEnd(bl[41],0);const s=getSelection();s.removeAllRanges();s.addRange(r);}""")
    pay = pg.evaluate("DocApp.selection()")
    check("block-start end excluded", [x["b"] for x in pay["ranges"]] == [40], str(pay["ranges"]))
    pg.evaluate("DocApp.clearSelection()")
    # style change keeps position
    pg.evaluate("DocApp.scrollToBlock(120,0.5,0)"); pg.wait_for_timeout(800)
    before = pg.evaluate("DocApp.position()")
    st = dict(STYLE); st["fs"] = 26; st["lh"] = 1.9
    pg.evaluate("s=>DocApp.setStyle(s)", st); pg.wait_for_timeout(900)
    after = pg.evaluate("DocApp.position()")
    check("style change keeps place", after["i"] == before["i"] and abs(after["f"] - before["f"]) < 0.12, f"{before} -> {after}")
    # directions: RTL block right aligned, forced LTR left aligned
    geo = pg.evaluate("""()=>{const bl=DocApp._blocks();const rtl=bl[0], ltr=bl[1];
       const rr=document.createRange();rr.selectNodeContents(rtl);const lr=document.createRange();lr.selectNodeContents(ltr);
       const a=rr.getClientRects()[0], c=lr.getClientRects()[0]; return {rtlRight: a.right, rtlLeft:a.left, ltrLeft:c.left, w: innerWidth}}""")
    check("rtl para hugs right edge", geo["rtlRight"] > geo["w"] - 40, str(geo))
    check("ltr para hugs left edge", geo["ltrLeft"] < 40, str(geo))
    st["dir"] = "ltr"; pg.evaluate("s=>DocApp.setStyle(s)", st); pg.wait_for_timeout(300)
    left = pg.evaluate("""()=>{const r=document.createRange();r.selectNodeContents(DocApp._blocks()[3]);return r.getClientRects()[0].left}""")
    check("forced LTR moves persian to left", left < 40, str(left))
    # position reports + ready call
    calls = pg.evaluate("window.__calls.map(c=>c[0])")
    check("onReady and onPosition fired", "onReady" in calls and "onPosition" in calls, str(set(calls)))
    # tap
    pg.mouse.click(200, 400); pg.wait_for_timeout(100)
    calls = pg.evaluate("window.__calls.filter(c=>c[0]=='onTap')")
    check("tap reported with fractions", len(calls) == 1 and 0.4 < calls[0][1] < 0.6, str(calls))
    b.close()
print("FAILS", fails)
sys.exit(1 if fails else 0)
