import json, sys, http.server, threading, functools, time
from playwright.sync_api import sync_playwright
H = functools.partial(http.server.SimpleHTTPRequestHandler, directory=".")
class Q(http.server.ThreadingHTTPServer): pass
class H2(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
srv = Q(("127.0.0.1", 8766), H2); threading.Thread(target=srv.serve_forever, daemon=True).start()
STYLE = dict(fs=18, lh=1.6, para=0.6, mx=16, indent=0, fg="#222", bg="#fff", link="#1a5fd0", font="sans-serif", weight=400, align="doc", dir="auto", docFonts=False, docColors=True, dark=False)
with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={"width": 390, "height": 844}, device_scale_factor=2)
    pg.add_init_script("""window.__calls=[];window.NR=new Proxy({}, {get:(t,k)=>(...a)=>{window.__calls.push([k,...a])}});""")
    t=time.time(); pg.goto("http://127.0.0.1:8766/"+sys.argv[1]+".html", timeout=120000); print("load", round(time.time()-t,1),"s")
    t=time.time(); pg.evaluate("s=>DocApp.init({style:s, block:%d, frac:0.4, highlights:[]})" % int(sys.argv[2]), STYLE); print("init", round(time.time()-t,1),"s")
    pg.wait_for_timeout(2500)
    print("pos after restore:", pg.evaluate("DocApp.position()"))
    for target in (int(sys.argv[2])+9000, 3, int(sys.argv[3]), int(sys.argv[2])//2):
        t=time.time(); pg.evaluate("i=>DocApp.scrollToBlock(i,0,0)", target); pg.wait_for_timeout(1500)
        print("target",target,"->",pg.evaluate("DocApp.position()"), round(time.time()-t,1))
    t=time.time(); pg.evaluate("DocApp.setSearch([[70000,1,5],[70001,2,6]],0)"); print("setSearch", round(time.time()-t,2))
    t=time.time(); pg.evaluate("s=>{s.fs=24;DocApp.setStyle(s)}", STYLE); pg.wait_for_timeout(1500); print("style change", round(time.time()-t,1), pg.evaluate("DocApp.position()"))
    print("jsheap MB", round(pg.evaluate("performance.memory ? performance.memory.usedJSHeapSize/1e6 : -1")))
    b.close()
