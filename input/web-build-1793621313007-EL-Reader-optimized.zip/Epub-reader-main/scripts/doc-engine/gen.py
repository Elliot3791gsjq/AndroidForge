"""Generates test documents for the document view: blocks exactly as the app writes them (data-i, dir, inline formatting)."""
import html, random, sys
random.seed(7)
FA = "این یک پاراگراف آزمایشی فارسی است که برای بررسی چینش راست‌به‌چپ و برش خطوط نوشته شده و باید چندین خط را پر کند تا ارتفاع بلوک‌ها متفاوت باشد."
EN = "This is an English paragraph used to check wrapping and measuring across different line counts in the document view of the reader application."
def blocks(n, rich=False):
    out=[]
    for i in range(n):
        base = FA if i%3==0 else EN
        t = (base+" ")*(1+i%4) + f"[{i}]"
        d = "rtl" if i%3==0 else "ltr"
        if rich and i%5==0:
            # inline formatting must not change textContent
            a,b = t[:10], t[10:25]
            c = t[25:]
            inner = f"{html.escape(a)}<b>{html.escape(b)}</b><span class=\"dc\" style=\"color:#c00\">{html.escape(c)}</span>"
        else:
            inner = html.escape(t)
        out.append((t, f'<p class="b" dir="{d}" data-i="{i}">{inner}</p>'))
    return out
def page(n, rich=False):
    bl = blocks(n, rich)
    body = "".join(h for _,h in bl)
    return ('<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
            '<link rel="stylesheet" href="doc.css"></head><body><main id="doc">'+body+'</main><script src="doc.js"></script></body></html>'), [t for t,_ in bl]
if __name__=="__main__":
    import json
    sizes = {"small": (300, True), "mid": (20000, False), "big": (60000, False)}
    for name in sys.argv[1:] or ["small"]:
        n, rich = sizes[name]
        h, t = page(n, rich)
        open(name + ".html", "w", encoding="utf-8").write(h)
        json.dump(t, open(name + ".json", "w", encoding="utf-8"), ensure_ascii=False)
