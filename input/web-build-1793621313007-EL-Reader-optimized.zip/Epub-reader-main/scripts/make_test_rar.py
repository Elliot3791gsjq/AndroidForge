#!/usr/bin/env python3
"""Writes tiny RAR 4.x archives (stored / "store" method, so no RAR compressor is needed) that hold real PNG pages.

Used by the CBR unit tests: app/src/test/resources/comics/stored.rar (non-solid) and solid.rar (solid flags set).
Header layout: RAR 1.5-4.x format (marker block, main header, file headers, end block); header CRC is the low 16 bits
of zlib.crc32 over the header bytes after the CRC field. Run: python3 scripts/make_test_rar.py
"""
import pathlib
import struct
import zlib

OUT = pathlib.Path(__file__).resolve().parent.parent / "app/src/test/resources/comics"


def png(w, h, rgb):
    raw = b"".join(b"\x00" + bytes(rgb) * w for _ in range(h))

    def chunk(t, d):
        c = struct.pack(">I", len(d)) + t + d
        return c + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)

    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0)) + chunk(b"IDAT", zlib.compress(raw)) + chunk(b"IEND", b"")


def head(body_after_crc):
    return struct.pack("<H", zlib.crc32(body_after_crc) & 0xFFFF) + body_after_crc


def main_header(solid):
    flags = 0x0008 if solid else 0
    body = struct.pack("<BHH", 0x73, flags, 13) + b"\x00\x00" + b"\x00\x00\x00\x00"
    return head(body)


def file_header(name, data, solid_flag):
    nm = name.encode("utf-8")
    flags = 0x8000 | (0x0010 if solid_flag else 0)
    size = 32 + len(nm)
    body = struct.pack("<BHH", 0x74, flags, size)
    body += struct.pack("<IIB", len(data), len(data), 2)            # pack size, unpacked size, host OS (Win32)
    body += struct.pack("<IIBBHI", zlib.crc32(data) & 0xFFFFFFFF, 0, 20, 0x30, len(nm), 0x20)
    body += nm
    return head(body) + data


def archive(entries, solid):
    out = b"Rar!\x1a\x07\x00" + main_header(solid)
    for i, (name, data) in enumerate(entries):
        out += file_header(name, data, solid and i > 0)
    out += bytes([0xC4, 0x3D, 0x7B, 0x00, 0x40, 0x07, 0x00])         # end-of-archive block
    return out


ENTRIES = [
    ("Chapter 1/page2.png", png(8, 12, (200, 30, 30))),
    ("Chapter 1/page10.png", png(8, 12, (30, 200, 30))),
    ("notes.txt", b"not a page"),
    ("Chapter 1/page1.png", png(8, 12, (30, 30, 200))),
    ("Thumbs.db", b"junk"),
    ("Chapter 2/page1.png", png(12, 8, (200, 200, 30))),
    (".hidden.png", png(2, 2, (0, 0, 0))),
    ("ComicInfo.xml", b"<?xml version=\"1.0\"?><ComicInfo><Title>Test &amp; Co</Title><Writer>Ann</Writer><Manga>YesAndRightToLeft</Manga></ComicInfo>"),
]

if __name__ == "__main__":
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "stored.rar").write_bytes(archive(ENTRIES, solid=False))
    (OUT / "solid.rar").write_bytes(archive(ENTRIES, solid=True))
    print("wrote", OUT)
