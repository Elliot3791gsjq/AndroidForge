#!/usr/bin/env python3
"""Emulator UI walkthrough of EL Reader.

Runs inside android-emulator-runner. Every step logs what is on screen and saves a screenshot to shots/ (uploaded by
the workflow so a human can look at them). Hard checks (CHECK PASS / FAIL) cover the features of the current
release: update over an old build (Room migration), "+" menu, in-app file browser import (book + folder), categories,
custom cover, chapter buttons, Images panel, background image behind the text (verified by sampling screenshot
pixels), reading stats, Persian UI, and frame timing (gfxinfo) of the animated library.
Usage: ui_test.py <new.apk> [old.apk]
"""
import os
import re
import struct
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
import zipfile
import zlib

PKG = "com.novelreader.app.debug"
MAIN = PKG + "/com.novelreader.app.MainActivity"
NEW_APK = sys.argv[1]
OLD_APK = sys.argv[2] if len(sys.argv) > 2 and os.path.exists(sys.argv[2]) else None
SHOTS = "shots"
os.makedirs(SHOTS, exist_ok=True)
REPORT = []
CHECKS = []


def log(msg):
    print(msg, flush=True)
    REPORT.append(msg)


def adb(*args, timeout=90):
    try:
        r = subprocess.run(["adb", *args], capture_output=True, text=True, timeout=timeout)
        return (r.stdout or "") + (r.stderr or "")
    except subprocess.TimeoutExpired:
        return "TIMEOUT"


def check(name, ok, detail=""):
    CHECKS.append((name, bool(ok)))
    log(("CHECK PASS " if ok else "CHECK FAIL ") + name + (" - " + detail if detail else ""))
    if not ok:
        print("::error::UI check failed: " + name + (" - " + detail if detail else ""), flush=True)


# --------------------------------------------------------------------------------------------- screen helpers
class Node:
    def __init__(self, e):
        self.text = e.get("text") or ""
        self.desc = e.get("content-desc") or ""
        self.clickable = e.get("clickable") == "true"
        b = e.get("bounds") or "[0,0][0,0]"
        nums = [int(x) for x in b.replace("][", ",").strip("[]").split(",")]
        self.x1, self.y1, self.x2, self.y2 = nums
        self.cx, self.cy = (self.x1 + self.x2) // 2, (self.y1 + self.y2) // 2

    @property
    def label(self):
        return self.text or self.desc


def _raw_dump():
    for _ in range(4):
        adb("shell", "uiautomator", "dump", "/sdcard/ui.xml")
        out = adb("exec-out", "cat", "/sdcard/ui.xml")
        i = out.find("<?xml")
        if i >= 0:
            try:
                root = ET.fromstring(out[i:])
                return [Node(e) for e in root.iter("node")]
            except ET.ParseError:
                pass
        time.sleep(1)
    return []


def dump():
    """UI hierarchy; a system 'isn't responding' dialog (slow CI emulator) is answered with Wait first."""
    nodes = _raw_dump()
    for _ in range(4):
        if not any("isn't responding" in n.text or "isn’t responding" in n.text or "keeps stopping" in n.text for n in nodes):
            break
        wait = next((n for n in nodes if n.text.strip().lower() == "wait"), None)
        log("  (system dialog on screen: %s)" % " | ".join(n.text for n in nodes if n.text)[:120])
        if wait is not None:
            adb("shell", "input", "tap", str(wait.cx), str(wait.cy))
        else:
            adb("shell", "input", "keyevent", "KEYCODE_BACK")
        time.sleep(3)
        nodes = _raw_dump()
    return nodes


def labels(nodes=None):
    nodes = nodes if nodes is not None else dump()
    seen = []
    for n in nodes:
        if n.label and n.label not in seen:
            seen.append(n.label)
    return seen


def find(nodes, label, exact=False):
    low = label.lower()
    best = None
    for n in nodes:
        for t in (n.text, n.desc):
            if not t:
                continue
            tl = t.lower()
            if tl == low:
                return n
            if not exact and low in tl and best is None:
                best = n
    return best


def wait_for(label, timeout=12, exact=False):
    end = time.time() + timeout
    while time.time() < end:
        n = find(dump(), label, exact)
        if n:
            return n
        time.sleep(1)
    return None


def tap(n):
    adb("shell", "input", "tap", str(n.cx), str(n.cy))


def tap_label(label, timeout=8, exact=False):
    n = wait_for(label, timeout, exact)
    if n:
        tap(n)
        time.sleep(1.2)
        return True
    log("  (not found: %s)" % label)
    return False


def back():
    adb("shell", "input", "keyevent", "KEYCODE_BACK")
    time.sleep(1.2)


def swipe_up(frac=0.55):
    adb("shell", "input", "swipe", "540", "1700", "540", str(int(1700 - 2340 * frac)), "350")
    time.sleep(1)


def swipe_down(frac=0.55):
    adb("shell", "input", "swipe", "540", "500", "540", str(int(500 + 2340 * frac)), "300")
    time.sleep(1)


def scroll_to(label, tries=7, y_from=1900, y_to=1000, exact=False):
    """Swipes up (inside the bottom sheet / list) until a label is on screen."""
    for _ in range(tries):
        n = find(dump(), label, exact)
        if n and 150 < n.cy < 2250:
            return n
        adb("shell", "input", "swipe", "540", str(y_from), "540", str(y_to), "350")
        time.sleep(0.8)
    return find(dump(), label, exact)


_shot_i = [0]
LAST_SHOT = [None]


def shot(name):
    _shot_i[0] += 1
    path = "%s/%02d_%s.png" % (SHOTS, _shot_i[0], name)
    with open(path, "wb") as f:
        subprocess.run(["adb", "exec-out", "screencap", "-p"], stdout=f, timeout=60)
    LAST_SHOT[0] = path
    log("SHOT %s" % path)
    return path


def crashed():
    """(did the APP crash, the first crash report of the app in full). Crashes of the test harness itself
    (uiautomator's 'FATAL EXCEPTION: UiAutomation') and of other processes are not the app's."""
    out = adb("logcat", "-d", "-b", "crash")
    pos = 0
    while True:
        i = out.find("FATAL EXCEPTION", pos)
        if i < 0:
            return False, out
        head = out[i:i + 400]
        if "Process: " + PKG in head:
            return True, out[max(0, out.rfind("\n", 0, i)):][:6000]
        pos = i + 10


def alive():
    return PKG in adb("shell", "ps", "-A") or bool(adb("shell", "pidof", PKG).strip())


def launch(extra=()):
    adb("shell", "am", "start", "-W", "-n", MAIN, *extra)
    time.sleep(5)


def stop():
    adb("shell", "am", "force-stop", PKG)
    time.sleep(1)


def screen(name, wait=1.0):
    time.sleep(wait)
    nodes = dump()
    log("SCREEN %s: %s" % (name, " | ".join(labels(nodes))[:700]))
    shot(name)
    return nodes


def type_text(s):
    adb("shell", "input", "text", s.replace(" ", "%s"))
    time.sleep(0.8)


# ---- frame timing (gfxinfo) ----
def gfx_reset():
    adb("shell", "dumpsys", "gfxinfo", PKG, "reset")


def gfx_report(tag):
    out = adb("shell", "dumpsys", "gfxinfo", PKG)
    pick = {}
    for key, pat in (("frames", r"Total frames rendered: (\d+)"), ("janky", r"Janky frames: (\d+) \(([\d.]+)%\)"),
                     ("p50", r"50th percentile: (\d+)ms"), ("p90", r"90th percentile: (\d+)ms"),
                     ("p95", r"95th percentile: (\d+)ms"), ("p99", r"99th percentile: (\d+)ms")):
        m = re.search(pat, out)
        if m:
            pick[key] = m.group(0)
    log("GFX %s: %s" % (tag, " ; ".join(pick.values()) or "n/a"))


# ---- pixel checks on screenshots (needs Pillow, installed by the workflow) ----
def region_mean(path, x1, y1, x2, y2):
    try:
        from PIL import Image
    except Exception:
        return None
    im = Image.open(path).convert("RGB")
    w, h = im.size
    box = (int(w * x1), int(h * y1), int(w * x2), int(h * y2))
    crop = im.crop(box).resize((8, 8))
    px = list(crop.getdata())
    return tuple(sum(p[i] for p in px) // len(px) for i in range(3))


# --------------------------------------------------------------------------------------------- test files
def png_raw(width, height, row_fn):
    rows = bytearray()
    for y in range(height):
        rows.append(0)
        rows.extend(row_fn(y))

    def chunk(tag, data):
        c = struct.pack(">I", len(data)) + tag + data
        return c + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)

    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)) +
            chunk(b"IDAT", zlib.compress(bytes(rows), 6)) + chunk(b"IEND", b""))


def png(width, height, c1, c2):
    cx, cy, r = width // 2, int(height * 0.42), width // 4

    def row(y):
        t = y / (height - 1)
        base = [int(c1[i] + (c2[i] - c1[i]) * t) for i in range(3)]
        out = bytearray()
        for x in range(width):
            d = (x - cx) ** 2 + (y - cy) ** 2
            if d < r * r:
                k = 0.55 + 0.45 * (1 - d / (r * r))
                out.extend(min(255, int(v * 0.35 + 255 * 0.65 * k)) for v in base)
            else:
                out.extend(base)
        return out

    return png_raw(width, height, row)


def gradient_png(width, height):
    """Left edge strong red, right edge strong blue: unmistakable against any reading theme."""
    def row(y):
        out = bytearray()
        for x in range(0, width, 1):
            t = x / (width - 1)
            out.extend((int(235 * (1 - t) + 20 * t), 25, int(20 * (1 - t) + 235 * t)))
        return out

    one = row(0)
    return png_raw(width, height, lambda y: one)


def make_epub(path, title, author, lang, paragraphs, c1, c2, rtl=False, images=False):
    ns = 'xmlns="http://www.w3.org/1999/xhtml"'
    dir_attr = ' dir="rtl"' if rtl else ""

    def chapter(i, head):
        body = "".join("<p>%s</p>" % p for p in paragraphs[i % len(paragraphs):] + paragraphs[: i % len(paragraphs)])
        pic = ""
        if images:
            pic = '<p><img src="pic%d.png" alt="Illustration %d" style="max-width:80%%"/></p>' % (i, i + 1)
        return ('<?xml version="1.0" encoding="utf-8"?><html %s xml:lang="%s"%s><head><title>%s</title>'
                '<link rel="stylesheet" href="style.css" type="text/css"/></head><body><h1>%s</h1>%s%s%s</body></html>'
                % (ns, lang, dir_attr, head, head, body, pic, body))

    heads = ["Chapter One", "Chapter Two", "Chapter Three"] if not rtl else ["فصل اول", "فصل دوم", "فصل سوم"]
    with zipfile.ZipFile(path, "w") as z:
        z.writestr(zipfile.ZipInfo("mimetype"), "application/epub+zip", compress_type=zipfile.ZIP_STORED)
        z.writestr("META-INF/container.xml",
                   '<?xml version="1.0"?><container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container">'
                   '<rootfiles><rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/>'
                   '</rootfiles></container>', compress_type=zipfile.ZIP_DEFLATED)
        items = "".join('<item id="c%d" href="c%d.xhtml" media-type="application/xhtml+xml"/>' % (i, i) for i in range(3))
        if images:
            items += "".join('<item id="p%d" href="pic%d.png" media-type="image/png"/>' % (i, i) for i in range(3))
        spine = "".join('<itemref idref="c%d"/>' % i for i in range(3))
        z.writestr("OEBPS/content.opf",
                   '<?xml version="1.0" encoding="utf-8"?><package xmlns="http://www.idpf.org/2007/opf" version="3.0" '
                   'unique-identifier="id"><metadata xmlns:dc="http://purl.org/dc/elements/1.1/">'
                   '<dc:identifier id="id">urn:uuid:%s</dc:identifier><dc:title>%s</dc:title><dc:creator>%s</dc:creator>'
                   '<dc:language>%s</dc:language><meta property="dcterms:modified">2026-01-01T00:00:00Z</meta></metadata>'
                   '<manifest><item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/>%s'
                   '<item id="css" href="style.css" media-type="text/css"/>'
                   '<item id="cover" href="cover.png" media-type="image/png" properties="cover-image"/></manifest>'
                   '<spine%s><itemref idref="nav" linear="no"/>%s</spine></package>'
                   % (abs(hash(title)) % 10 ** 12, title, author, lang, items, ' page-progression-direction="rtl"' if rtl else "", spine),
                   compress_type=zipfile.ZIP_DEFLATED)
        z.writestr("OEBPS/nav.xhtml",
                   '<?xml version="1.0" encoding="utf-8"?><html %s xmlns:epub="http://www.idpf.org/2007/ops"><head><title>Contents</title></head>'
                   '<body><nav epub:type="toc"><ol>%s</ol></nav></body></html>'
                   % (ns, "".join('<li><a href="c%d.xhtml">%s</a></li>' % (i, h) for i, h in enumerate(heads))),
                   compress_type=zipfile.ZIP_DEFLATED)
        z.writestr("OEBPS/style.css", "body{margin:1em} p{margin:0 0 .8em}", compress_type=zipfile.ZIP_DEFLATED)
        z.writestr("OEBPS/cover.png", png(300, 450, c1, c2), compress_type=zipfile.ZIP_STORED)
        if images:
            for i, col in enumerate(((220, 60, 40), (40, 160, 90), (50, 90, 210))):
                z.writestr("OEBPS/pic%d.png" % i, png(240, 160, col, (20, 20, 20)), compress_type=zipfile.ZIP_STORED)
        for i, h in enumerate(heads):
            z.writestr("OEBPS/c%d.xhtml" % i, chapter(i, h), compress_type=zipfile.ZIP_DEFLATED)


EN = [
    "The library was quiet in the way only old libraries are, a hush made of paper, dust and patient light.",
    "She ran a finger along the spines until one of them, unmarked, seemed to lean toward her hand.",
    "Inside, the first page held a single sentence: every story begins with someone deciding to look up.",
    "Outside the tall windows the rain wrote its own slow chapters on the glass, and nobody read them.",
    "He closed the book carefully, as one closes a door on a sleeping child, and went to find the others.",
    "By evening the lamps had come on one by one, each pooling amber over a table and a stranger's thoughts.",
]
FA = [
    "کتابخانه آرام بود، آرامشی که فقط در کتابخانه‌های قدیمی پیدا می‌شود؛ سکوتی از کاغذ و غبار و نوری صبور.",
    "انگشتش را روی عطف کتاب‌ها کشید تا اینکه یکی از آن‌ها، بی‌نام و نشان، به سوی دستش خم شد.",
    "در صفحهٔ اول فقط یک جمله بود: هر داستان از لحظه‌ای آغاز می‌شود که کسی تصمیم می‌گیرد سر بلند کند.",
    "بیرون از پنجره‌های بلند، باران فصل‌های آهستهٔ خودش را روی شیشه می‌نوشت و هیچ‌کس نمی‌خواندشان.",
    "کتاب را با احتیاط بست، مثل کسی که در اتاق کودکی خفته را می‌بندد، و رفت تا بقیه را پیدا کند.",
]


# --------------------------------------------------------------------------------------------- scenario steps
def import_via_view(filename):
    """Old builds: open the EPUB from outside the app, add it to the library from the reader."""
    adb("shell", "am", "start", "-W", "-a", "android.intent.action.VIEW", "-t", "application/epub+zip",
        "-d", "file:///sdcard/Download/" + filename, "-n", MAIN)
    time.sleep(9)
    nodes = dump()
    n = find(nodes, "Add to library")
    if n:
        tap(n)
        time.sleep(1.5)
    back()
    time.sleep(2)
    return n is not None


SEED_SQL = """
INSERT INTO books (title,author,fileName,filePath,coverPath,sizeBytes,sha256,addedAt,lastReadAt,progress,lastLocatorJson,inLibrary,readingMillis,charCount,wordCount) VALUES ('Seeded Old Book','Seed Author','seed.epub','books/seed.epub',NULL,1234,'seedsha256seedsha256',1700000000000,1700000100000,0.4,NULL,1,3600000,NULL,NULL);
INSERT INTO highlights (bookId,locatorJson,text,color,note,chapterTitle,createdAt,style) VALUES (1,'{"href":"c0.xhtml","type":"application/xhtml+xml","locations":{"progression":0.1,"totalProgression":0.4},"text":{"highlight":"seed highlight text"}}','seed highlight text',-256,'seed note',NULL,1700000200000,'HIGHLIGHT');
INSERT INTO bookmarks (bookId,locatorJson,title,note,chapterTitle,progress,createdAt) VALUES (1,'{"href":"c0.xhtml","type":"application/xhtml+xml","locations":{"progression":0.1,"totalProgression":0.4}}','Seed bookmark',NULL,NULL,0.4,1700000300000);
"""


def seed_old_database():
    """Writes a book, a highlight and a bookmark straight into the OLD build's database (run-as + sqlite3), so the
    Room migration is exercised with real rows. Returns True when the rows were written."""
    with open("seed.sql", "w") as f:
        f.write(SEED_SQL)
    adb("push", "seed.sql", "/data/local/tmp/seed.sql")
    adb("shell", "chmod", "644", "/data/local/tmp/seed.sql")
    out = adb("shell", "run-as", PKG, "sh", "-c",
              "'sqlite3 databases/novel_reader.db < /data/local/tmp/seed.sql; sqlite3 databases/novel_reader.db \"select count(*) from books;\"'")
    log("seed old database: " + out.strip()[:200])
    return out.strip().endswith("1")



def img_diff(path_a, path_b):
    """Mean absolute grey-level difference (0..255) between two screenshots; None without Pillow."""
    try:
        from PIL import Image, ImageChops
    except Exception:
        return None
    a = Image.open(path_a).convert("L").resize((270, 585))
    b = Image.open(path_b).convert("L").resize((270, 585))
    d = ImageChops.difference(a, b)
    px = list(d.getdata())
    return sum(px) / len(px)


def ink(path, x1, y1, x2, y2):
    """Fraction of pixels in the box that differ strongly from the box's typical (background) grey level."""
    try:
        from PIL import Image
    except Exception:
        return None
    im = Image.open(path).convert("L")
    w, h = im.size
    crop = im.crop((int(w * x1), int(h * y1), int(w * x2), int(h * y2)))
    px = sorted(crop.getdata())
    bg = px[len(px) // 2]
    dark = sum(1 for p in px if abs(p - bg) > 60)
    return dark / len(px)


def open_reader_menu_item(label):
    """Options (three dots) -> menu entry."""
    if not find(dump(), "Options", True):
        adb("shell", "input", "tap", "540", "1170")   # toggle the chrome
        time.sleep(1)
    if tap_label("Options", 4, exact=True):
        return tap_label(label, 3)
    return False


def set_flip_style(label):
    if open_reader_menu_item("Page Flip Settings"):
        screen("flip_dialog", 0.8)
        ok = tap_label(label, 3)
        time.sleep(0.8)
        screen("flip_dialog_after_pick", 0.5)
        tap_label("Close", 3) or back()
        time.sleep(0.8)
        return ok
    return False


def drag_screenshot(name, x1, x2, duration_ms, shot_after_s, y=1200):
    """Starts a slow swipe, takes a screenshot while the finger is still down, waits for the swipe to end."""
    p = subprocess.Popen(["adb", "shell", "input", "swipe", str(x1), str(y), str(x2), str(y), str(duration_ms)])
    time.sleep(shot_after_s)
    path = shot(name)
    p.wait(timeout=60)
    time.sleep(1.2)
    return path


def screen_density():
    out = adb("shell", "wm", "density")
    m = re.findall(r"(\d+)", out)
    return (int(m[-1]) if m else 440) / 160.0


def hex_on_screen(nodes):
    for n in nodes:
        t = n.text.strip()
        if re.fullmatch(r"#[0-9A-Fa-f]{6}", t):
            return t.upper()
    return None


def hex_close(a, b, tol=4):
    if not a or not b:
        return False
    ca = [int(a[i:i + 2], 16) for i in (1, 3, 5)]
    cb = [int(b[i:i + 2], 16) for i in (1, 3, 5)]
    return all(abs(x - y) <= tol for x, y in zip(ca, cb))


def hsv_hex(h, s, v):
    import colorsys
    r, g, b = colorsys.hsv_to_rgb((h % 360) / 360.0, s, v)
    return "#%02X%02X%02X" % (round(r * 255), round(g * 255), round(b * 255))


def hex_hsv(hx):
    import colorsys
    r, g, b = [int(hx[i:i + 2], 16) / 255.0 for i in (1, 3, 5)]
    h, s, v = colorsys.rgb_to_hsv(r, g, b)
    return h * 360, s, v


def slider_node(nodes, desc):
    return next((n for n in nodes if n.desc == desc and n.text == ""), None)


def slider_x(node, f, thumb_px):
    return int(node.x1 + thumb_px / 2 + f * (node.x2 - node.x1 - thumb_px))


def color_picker_checks():
    """Theme editor -> Accent: the round handle must sit under the finger and set exactly that value."""
    log("== Phase I2: colour picker in the theme editor")
    if not tap_label("New theme", 5):
        return
    time.sleep(1.5)
    screen("theme_editor", 1)
    if not tap_label("Accent", 4, exact=True):
        back()
        return
    nodes = screen("color_picker", 1.2)
    hue, sat, val = (slider_node(nodes, d) for d in ("Hue", "Saturation", "Brightness"))
    start_hex = hex_on_screen(nodes)
    log("picker start: hex=%s hue=%s sat=%s val=%s" % (start_hex, bool(hue), bool(sat), bool(val)))
    if not (hue and sat and val and start_hex):
        check("colour picker shows three sliders and the HEX value", False, " | ".join(labels(nodes))[:200])
        tap_label("Cancel", 3)
        back()
        return
    thumb = 28 * screen_density()
    y = hue.cy
    h0, s0, v0 = hex_hsv(start_hex)
    # touching the track at 50 % must give exactly the middle hue (handle under the finger, value set on touch-down)
    adb("shell", "input", "tap", str(slider_x(hue, 0.5, thumb)), str(y))
    time.sleep(0.8)
    got = hex_on_screen(dump())
    exp = hsv_hex(180.0, s0, v0)
    check("hue slider: a touch in the middle selects hue 180 exactly", hex_close(got, exp), "got %s expected %s" % (got, exp))
    adb("shell", "input", "tap", str(slider_x(hue, 0.25, thumb)), str(y))
    time.sleep(0.8)
    got = hex_on_screen(dump())
    exp = hsv_hex(90.0, s0, v0)
    check("hue slider: a touch at 25 % selects hue 90", hex_close(got, exp), "got %s expected %s" % (got, exp))
    screen("color_picker_hue_quarter", 0.3)
    # dragging: the value must follow the finger and end where the finger was lifted
    adb("shell", "input", "swipe", str(slider_x(hue, 0.2, thumb)), str(y), str(slider_x(hue, 0.8, thumb)), str(y), "700")
    time.sleep(0.8)
    got = hex_on_screen(dump())
    exp = hsv_hex(288.0, s0, v0)
    check("hue slider: dragging from 20 % to 80 % ends at hue 288", hex_close(got, exp), "got %s expected %s" % (got, exp))
    # the two ends of the brightness track are reachable (handle fully at the end = exactly 0 % / 100 %)
    nodes = dump()
    val = slider_node(nodes, "Brightness") or val
    adb("shell", "input", "tap", str(slider_x(val, 1.0, thumb)), str(val.cy))
    time.sleep(0.8)
    hi = hex_on_screen(dump())
    adb("shell", "input", "tap", str(slider_x(val, 0.0, thumb)), str(val.cy))
    time.sleep(0.8)
    lo = hex_on_screen(dump())
    log("brightness ends: 100%% -> %s, 0%% -> %s" % (hi, lo))
    check("brightness slider: touching the far right gives full brightness", bool(hi) and max(int(hi[i:i + 2], 16) for i in (1, 3, 5)) >= 250, str(hi))
    check("brightness slider: touching the far left gives black", lo == "#000000", str(lo))
    screen("color_picker_black", 0.3)
    tap_label("Cancel", 3)
    time.sleep(0.8)
    back()
    time.sleep(1)


def import_fonts_and_use():
    """Reader -> Fonts -> add two real TTF files -> choose one -> the book reloads with it, and it survives a restart."""
    log("== Phase F3: imported fonts")
    names = [x for x in adb("shell", "ls", "/system/fonts").split() if x.lower().endswith(".ttf")]
    pick = [n for n in ("DancingScript-Regular.ttf", "ComingSoon.ttf", "CutiveMono.ttf", "NotoSerif-Italic.ttf") if n in names] or \
           [n for n in names if "Regular" in n and "Noto" not in n][:2] or names[:2]
    pick = pick[:2]
    if len(pick) < 2:
        log("  (no system TTF files found to import)")
        return
    adb("shell", "mkdir", "-p", "/sdcard/Documents/Fonts")
    for i, n in enumerate(pick):
        adb("shell", "cp", "/system/fonts/" + n, "/sdcard/Documents/Fonts/testfont%d.ttf" % (i + 1))
    log("fonts to import: " + ", ".join(pick))
    if not find(dump(), "Fonts", True):
        adb("shell", "input", "tap", "540", "1170")
        time.sleep(1)
    before = shot("font_00_before")
    if not tap_label("Fonts", 4, exact=True):
        return
    nodes = screen("font_panel", 1.5)
    if scroll_to("Add fonts", 8):
        tap_label("Add fonts", 3)
        time.sleep(2)
        browse("Documents", "Fonts")
        nodes = screen("font_browser", 2)
        check("font browser lists the two font files", find(nodes, "testfont1.ttf") is not None and find(nodes, "testfont2.ttf") is not None,
              " | ".join(labels(nodes))[:240])
        tap_label("Select all", 3)
        tap_label("Add 2 font", 4)
        time.sleep(5)
        # back in the reader (panel may still be open): bring the Fonts panel up again
        nodes = dump()
        if find(nodes, "Your fonts") is None:
            if not find(nodes, "Fonts", True):
                adb("shell", "input", "tap", "540", "1170")
                time.sleep(1)
            tap_label("Fonts", 4, exact=True)
            time.sleep(1.5)
        scroll_to("Your fonts", 8)
        nodes = screen("font_rows", 1)
        check("imported fonts no longer say 'Close and reopen the book'", find(nodes, "reopen the book") is None, " | ".join(labels(nodes))[:300])
        check("imported fonts are listed", find(nodes, "has Latin letters") is not None or find(nodes, "TTF") is not None, " | ".join(labels(nodes))[:300])
        # choose the first font for Latin text -> the reader reloads once with it
        chip = find(nodes, "EN", True)
        if chip:
            tap(chip)
            time.sleep(9)
            nodes = dump()
            if not find(nodes, "Options", True):
                adb("shell", "input", "tap", "540", "1170")
                time.sleep(1)
            applied = shot("font_01_applied")
            d = img_diff(before, applied)
            log("font applied: screenshot difference vs before = %s" % d)
            if d is not None:
                check("choosing an imported font changes the page text", d > 1.0, "diff=%.2f" % d)
            # a full restart keeps the font
            stop()
            launch()
            if open_book("The Quiet Library"):
                time.sleep(3)
                if not find(dump(), "Options", True):
                    adb("shell", "input", "tap", "540", "1170")
                    time.sleep(1)
                again = shot("font_02_after_restart")
                d2 = img_diff(applied, again)
                d3 = img_diff(before, again)
                log("after restart: vs applied=%s vs before=%s" % (d2, d3))
                if d2 is not None:
                    check("the imported font is still used after the app was closed and reopened", d2 < 3.0 and d3 > 1.0,
                          "vs applied=%.2f vs before=%.2f" % (d2, d3))
                if tap_label("Fonts", 4, exact=True):
                    scroll_to("Your fonts", 8)
                    nodes = screen("font_rows_after_restart", 1)
                    check("after a restart the fonts still do not ask to reopen the book", find(nodes, "reopen the book") is None,
                          " | ".join(labels(nodes))[:300])
                    back()
        else:
            log("  (EN chip not found)")
    c, trace = crashed()
    check("no crash while importing and applying fonts", not c, trace[:1800] if c else "")


def open_menu_add():
    n = wait_for("Add book", 8)
    if n:
        tap(n)
        time.sleep(1.2)
        return True
    return False


def browse(*names):
    ok = True
    for nm in names:
        if not tap_label(nm, 6, exact=True):
            ok = False
    return ok


def reveal(label, exact=False):
    """Brings a library entry (title) on screen by scrolling the library; returns its node or None."""
    n = find(dump(), label, exact)
    if n and 300 < n.cy < 1950:
        return n
    for _ in range(8):
        adb("shell", "input", "swipe", "540", "1800", "540", "700", "350")
        time.sleep(0.9)
        n = find(dump(), label, exact)
        if n and 300 < n.cy < 1950:
            return n
    return None


def reveal_chip(label):
    """The category chips scroll sideways; slide the row until [label] shows (row sits near y=666)."""
    n = find(dump(), label)
    if n:
        return n
    for _ in range(4):
        adb("shell", "input", "swipe", "950", "666", "150", "666", "300")
        time.sleep(0.8)
        n = find(dump(), label)
        if n:
            return n
    return None


def tap_book(title):
    n = reveal(title)
    if n:
        tap(n)
        time.sleep(1.2)
        return True
    log("  (not found: %s)" % title)
    return False


def open_book(title):
    """Opens the book's detail page and starts reading. Retries: a tap can land during a transition on a slow emulator."""
    for attempt in range(3):
        if not tap_book(title):
            return False
        time.sleep(1)
        if tap_label("Continue reading", 4) or tap_label("Start reading", 3):
            time.sleep(7)
            return True
        log("  (no read button found, attempt %d)" % (attempt + 1))
        nodes = dump()
        if find(nodes, "Search the library") is None:   # not on the library list: step back to it first
            back()
            time.sleep(1.5)
    return False


def main():
    # ---------------------------------------------------------------- setup
    adb("wait-for-device")
    for _ in range(60):  # let the emulator finish booting before anything is measured
        if adb("shell", "getprop", "sys.boot_completed").strip() == "1":
            break
        time.sleep(3)
    time.sleep(25)
    adb("shell", "settings", "put", "secure", "anr_show_background", "0")
    adb("shell", "settings", "put", "global", "animator_duration_scale", "0")
    adb("shell", "settings", "put", "global", "transition_animation_scale", "0")
    adb("shell", "settings", "put", "global", "window_animation_scale", "0")
    make_epub("quiet.epub", "The Quiet Library", "A. Tester", "en", EN, (255, 90, 31), (40, 12, 8), images=True)
    make_epub("kitab.epub", "کتابخانهٔ آرام", "آزمایش‌کننده", "fa", FA, (40, 120, 200), (6, 14, 40), rtl=True)
    make_epub("folder1.epub", "Folder Book One", "F. Author", "en", EN, (30, 140, 90), (6, 30, 20))
    make_epub("folder2.epub", "Folder Book Two", "F. Author", "en", EN, (150, 60, 200), (24, 8, 36))
    make_epub("outside.epub", "Outside Book", "O. Author", "en", EN, (200, 160, 30), (40, 30, 6))
    with open("bg_test.png", "wb") as f:
        f.write(gradient_png(540, 1170))
    with open("cover_test.png", "wb") as f:
        f.write(png(300, 450, (20, 200, 220), (230, 30, 140)))
    adb("shell", "mkdir", "-p", "/sdcard/Documents/Books", "/sdcard/Pictures")
    adb("push", "quiet.epub", "/sdcard/Download/quiet.epub")
    adb("push", "kitab.epub", "/sdcard/Download/kitab.epub")
    adb("push", "folder1.epub", "/sdcard/Documents/Books/folder1.epub")
    adb("push", "folder2.epub", "/sdcard/Documents/Books/folder2.epub")
    adb("push", "outside.epub", "/sdcard/Documents/outside.epub")
    adb("push", "bg_test.png", "/sdcard/Pictures/bg_test.png")
    adb("push", "cover_test.png", "/sdcard/Pictures/cover_test.png")
    log("test files on the phone: " + " ; ".join(
        adb("shell", "ls", "-l", d).strip().replace("\n", " / ")[:300]
        for d in ("/sdcard/Download", "/sdcard/Documents", "/sdcard/Documents/Books")))

    # ---------------------------------------------------------------- phase A: old build, create real data
    old_added = False
    if OLD_APK:
        log("== Phase A: install OLD build and add a book")
        out = adb("install", "-r", OLD_APK)
        log("old install: " + out.strip()[-120:])
        adb("shell", "appops", "set", PKG, "MANAGE_EXTERNAL_STORAGE", "allow")
        launch()
        screen("old_build_library")
        stop()   # the old build has created its (version 2) database by now
        old_added = seed_old_database()
        log("old database seeded with a book, highlight and bookmark: %s" % old_added)
    else:
        log("== Phase A skipped (no old APK)")

    # ---------------------------------------------------------------- phase B: update to the new build
    log("== Phase B: install NEW build")
    out = adb("install", "-r", NEW_APK)
    log("new install: " + out.strip()[-160:])
    check("new APK installs over the old build", "Success" in out, out.strip()[-120:])
    adb("shell", "appops", "set", PKG, "MANAGE_EXTERNAL_STORAGE", "allow")
    adb("logcat", "-c")
    launch()
    nodes = screen("new_build_first_launch", 2)
    c, trace = crashed()
    check("no crash on first launch after update (Room migration)", not c and alive(), trace[:1800] if c else "")
    check("bottom navigation has 5 destinations (incl. Stats)",
          all(find(nodes, t) for t in ("Library", "Bookmarks", "Notes", "Stats", "Settings")), " | ".join(labels(nodes))[:200])
    if old_added:
        check("book stored by the old (v2) build survived the migration", find(nodes, "Seeded Old Book") is not None,
              " | ".join(labels(nodes))[:200])
        if tap_label("Bookmarks", 4, exact=True):
            nodes = screen("migrated_bookmarks", 1.5)
            check("bookmark stored by the old build survived the migration", find(nodes, "Seed bookmark") is not None,
                  " | ".join(labels(nodes))[:240])
        if tap_label("Notes", 4, exact=True):
            nodes = screen("migrated_notes", 1.5)
            check("highlight/note stored by the old build survived the migration",
                  find(nodes, "seed highlight") is not None or find(nodes, "seed note") is not None, " | ".join(labels(nodes))[:240])
        tap_label("Library", 4, exact=True)
    else:
        log("  (old database could not be seeded: migration with data not verified)")

    # ---------------------------------------------------------------- a file opened from outside lands in the library
    log("== Phase B2: open an EPUB from outside the app")
    adb("shell", "am", "start", "-W", "-a", "android.intent.action.VIEW", "-t", "application/epub+zip",
        "-d", "file:///sdcard/Documents/outside.epub", "-n", MAIN)
    # the import (copy, cover, metadata) is slower on a debug build: wait for the reader up to 40 s
    deadline = time.time() + 40
    while time.time() < deadline:
        time.sleep(2)
        probe = dump()
        if find(probe, "Appearance") is not None or find(probe, "Options") is not None:
            break
    nodes = screen("outside_open_reader", 1)
    check("EPUB opened from outside starts reading right away", find(nodes, "Options") is not None or find(nodes, "Outside Book") is not None
          or find(nodes, "Appearance") is not None, " | ".join(labels(nodes))[:240])
    back()
    time.sleep(2)
    nodes = screen("outside_open_library", 1.5)
    check("EPUB opened from outside appears in the library", find(nodes, "Outside Book") is not None, " | ".join(labels(nodes))[:240])
    c, trace = crashed()
    check("no crash while opening an external EPUB", not c, trace[:1800] if c else "")

    # ---------------------------------------------------------------- "+" menu and the in-app file browser
    log("== Phase C: + menu, file browser, folder import")
    if not find(nodes, "The Quiet Library"):
        # empty library: the empty state has its own two buttons; otherwise the header "+" button
        pass
    if open_menu_add():
        nodes = screen("plus_menu", 0.8)
        check("+ shows 'Add a folder' and 'Add a book'", find(nodes, "Add a folder") is not None and find(nodes, "Add a book") is not None,
              " | ".join(labels(nodes))[:200])
        if tap_label("Add a book", 4):
            nodes = screen("file_browser_books", 2)
            check("in-app file browser opens (not only the system 'Open from')",
                  find(nodes, "Internal storage") is not None or find(nodes, "Download") is not None, " | ".join(labels(nodes))[:240])
            browse("Download")
            nodes = screen("file_browser_download", 1.5)
            check("browser lists EPUB files of Download", find(nodes, "kitab.epub") is not None and find(nodes, "quiet.epub") is not None,
                  " | ".join(labels(nodes))[:240])
            if find(nodes, "Select all") is None:
                # the select-all entry lives in the overflow menu on some layouts
                tap_label("Other ways to pick", 2)
            tap_label("Select all", 3)
            nodes = screen("file_browser_selected", 1)
            check("select all marks every book", find(nodes, "2 selected") is not None or find(nodes, "Add 2 book") is not None,
                  " | ".join(labels(nodes))[:240])
            tap_label("Add 2 book", 4)
            time.sleep(6)
            nodes = screen("library_after_book_import", 2)
            check("both selected books were added (library grew from 2 to 4 books)", find(nodes, "4 books") is not None,
                  " | ".join(labels(nodes))[:240])
    else:
        log("  (could not find the + button)")

    if open_menu_add() and tap_label("Add a folder", 4):
        nodes = screen("file_browser_folder", 2)
        browse("Documents", "Books")
        nodes = screen("file_browser_folder_inside", 2.5)
        check("folder import detects the EPUBs inside the folder", find(nodes, "Add all 2") is not None or find(nodes, "2 EPUB") is not None,
              " | ".join(labels(nodes))[:240])
        tap_label("Add all 2", 4)
        time.sleep(6)
        nodes = screen("library_after_folder_import", 2)
        check("folder import added both books (library grew from 4 to 6 books)", find(nodes, "6 books") is not None,
              " | ".join(labels(nodes))[:240])

    # ---------------------------------------------------------------- categories
    log("== Phase D: categories")
    chip = reveal_chip("New category")
    if chip:
        tap(chip)
        time.sleep(1.2)
        nodes = screen("category_dialog", 1)
        field = find(nodes, "Category name")
        if field:
            tap(field)
            time.sleep(0.6)
        type_text("Classics")
        shot("category_typed")
        tap_label("Create", 4)
        time.sleep(1.5)
        nodes = screen("category_created", 1.5)
        check("a category can be created with a name", find(nodes, "Classics") is not None, " | ".join(labels(nodes))[:240])
        # when the app offers to choose books right away, tick the first one
        if find(nodes, "Choose books"):
            tap_label("Choose books", 3)
            screen("category_choose_books", 1)
            back()

    # ---------------------------------------------------------------- detail + custom cover
    log("== Phase E: detail, custom cover")
    for _ in range(3):
        if find(dump(), "All", True):
            break
        adb("shell", "input", "swipe", "150", "666", "950", "666", "300")
    tap_label("All", 3, exact=True)
    if tap_book("The Quiet Library"):
        nodes = screen("book_detail", 1.5)
        check("book detail opens", find(nodes, "Start reading") or find(nodes, "Continue reading"), " | ".join(labels(nodes))[:200])
        if scroll_to("Change cover", 4, 1700, 900):
            tap_label("Change cover", 3)
            nodes = screen("cover_source_sheet", 1)
            check("cover picker offers gallery, file manager and storage browser",
                  find(nodes, "Gallery") is not None and find(nodes, "Browse phone storage") is not None, " | ".join(labels(nodes))[:240])
            if tap_label("Browse phone storage", 3):
                browse("Pictures")
                time.sleep(1)
                screen("cover_browser_pictures", 1.5)
                tap_label("cover_test.png", 4)
                tap_label("Use this image", 4)
                time.sleep(3)
                screen("book_detail_new_cover", 1.5)
        back()
        time.sleep(1.5)
        screen("library_new_cover", 1.5)

    # ---------------------------------------------------------------- reader
    log("== Phase F: reader")
    gfx_reset()
    if open_book("The Quiet Library"):
        reader_start = time.time()
        nodes = screen("reader", 1)
        check("reader opens with the floating chrome", find(nodes, "Options") is not None and find(nodes, "Appearance") is not None,
              " | ".join(labels(nodes))[:200])
        c, trace = crashed()
        check("no crash while opening the reader", not c, trace[:1800] if c else "")
        check("progress bar has previous / next chapter buttons",
              find(nodes, "Previous chapter") is not None and find(nodes, "Next chapter") is not None, " | ".join(labels(nodes))[:240])
        if tap_label("Next chapter", 3):
            time.sleep(1.5)
            screen("reader_next_chapter", 1)
            tap_label("Previous chapter", 3)
            time.sleep(1.5)
            screen("reader_prev_chapter", 1)
        # Contents -> Images
        if tap_label("Contents", 4, exact=True):
            nodes = screen("contents_chapters", 1.2)
            if tap_label("Images", 3, exact=True):
                nodes = screen("contents_images", 2.5)
                check("Images panel lists the book's pictures",
                      find(nodes, "This book has no images") is None and find(nodes, "Illustration 1") is not None, " | ".join(labels(nodes))[:240])
                if tap_label("Illustration 2", 3):
                    time.sleep(4)
                    nodes = screen("reader_after_image_jump", 1)
                    check("tapping an image in the Images panel jumps to its chapter (Chapter Two)",
                          find(nodes, "Chapter Two") is not None, " | ".join(labels(nodes))[:240])
            # the panel closes by itself after a jump; only press Back when it is still open (Back would leave the reader)
            probe = dump()
            if find(probe, "Images", True) is not None or find(probe, "Chapters", True) is not None:
                back()
            time.sleep(1)

        # Background image behind the text
        theme_shot = None
        if tap_label("Appearance", 4):
            if tap_label("Colors", 4):
                theme_shot = shot("reader_colors_before_image")
                if scroll_to("Choose image", 8):
                    tap_label("Choose image", 3)
                    nodes = screen("bg_source_sheet", 1)
                    check("background picker offers gallery, file manager and storage browser",
                          find(nodes, "Gallery") is not None and find(nodes, "Browse phone storage") is not None, " | ".join(labels(nodes))[:240])
                    if tap_label("Browse phone storage", 3):
                        browse("Pictures")
                        time.sleep(1)
                        screen("bg_browser_pictures", 1.5)
                        tap_label("bg_test.png", 4)   # a single image is returned as soon as it is tapped
                        time.sleep(4)
                        screen("reader_colors_with_image", 1.5)
                        log("BgDiag: " + adb("logcat", "-d", "-s", "BgDiag:I").strip()[-2500:])
            back()
            time.sleep(2.5)
        path = shot("reader_with_background_image")
        left = region_mean(path, 0.00, 0.20, 0.03, 0.80)
        right = region_mean(path, 0.97, 0.20, 1.00, 0.80)
        log("background sample left=%s right=%s" % (left, right))
        if left is not None and right is not None:
            check("background image is visible behind the page (red edge on the left, blue on the right)",
                  left[0] > left[2] + 25 and right[2] > right[0] + 25, "left=%s right=%s" % (left, right))
        else:
            log("  (Pillow missing: pixel check skipped)")


        # ------------------------------------------------------------ page turn animation (finger-driven curl)
        log("== Phase F2: page turn animation and dual page")
        adb("logcat", "-c")
        # Animations are off for the rest of the walkthrough. Slow them down (x4) for this part and restart the app so
        # the fresh process really uses that scale; the reader reopens at the saved place.
        adb("shell", "settings", "put", "global", "animator_duration_scale", "4")
        stop()
        launch()
        reopened = open_book("The Quiet Library")
        log("reader reopened with slowed animations: %s" % reopened)
        if reopened and set_flip_style("Page curl (Apple"):
            time.sleep(1.5)
            flat = shot("turn_01_flat_page")
            # finger drag: two frames while the finger is still down, then let it go and wait for the completion
            p = subprocess.Popen(["adb", "shell", "input", "swipe", "950", "1200", "130", "1200", "5000"])
            time.sleep(1.7)
            mid1 = shot("turn_02_curl_drag_early")
            time.sleep(1.5)
            mid2 = shot("turn_03_curl_drag_later")
            p.wait(timeout=60)
            time.sleep(7.0)
            after = shot("turn_04_after_completed_drag")
            d_mid1, d_mid2, d_after = img_diff(flat, mid1), img_diff(flat, mid2), img_diff(flat, after)
            log("turn diffs: flat->mid1=%s flat->mid2=%s flat->after=%s mid1->mid2=%s" % (d_mid1, d_mid2, d_after, img_diff(mid1, mid2)))
            if d_mid1 is not None:
                check("curl is drawn while the finger drags (screen differs from the flat page)", d_mid1 > 1.5 and d_mid2 > 1.5,
                      "diff=%.2f / %.2f" % (d_mid1, d_mid2))
                check("the curl follows the finger (two moments of one drag differ)", (img_diff(mid1, mid2) or 0) > 1.0)
                check("a completed drag turned the page", d_after > 1.0, "diff=%.2f" % d_after)
            # a short, slow drag that is let go again must put the page back
            before_cancel = shot("turn_05_before_cancel")
            adb("shell", "input", "swipe", "900", "1200", "780", "1200", "700")
            time.sleep(4.0)
            after_cancel = shot("turn_06_after_cancelled_drag")
            d_cancel = img_diff(before_cancel, after_cancel)
            log("turn diff before/after cancelled drag = %s" % d_cancel)
            if d_cancel is not None:
                check("a short drag that is released again leaves the page where it was", d_cancel < 1.0, "diff=%.2f" % d_cancel)
            # tap on the right edge turns the page too (frame in the middle of the animation)
            adb("shell", "input", "tap", "1000", "1200")
            time.sleep(1.3)
            tap_mid = shot("turn_07_edge_tap_mid_animation")
            time.sleep(5.0)
            after_tap = shot("turn_08_after_edge_tap")
            d_tap = img_diff(after_cancel, after_tap)
            d_tap_mid = img_diff(after_cancel, tap_mid)
            log("turn diff after edge tap = %s, mid-animation frame vs start = %s, vs end = %s" % (d_tap, d_tap_mid, img_diff(tap_mid, after_tap)))
            if d_tap is not None:
                check("tapping the right edge turns the page", d_tap > 1.0, "diff=%.2f" % d_tap)
                check("the edge tap is animated (a frame in between differs from both ends)",
                      (d_tap_mid or 0) > 1.0 and (img_diff(tap_mid, after_tap) or 0) > 1.0)
            # the other styles: one frame in the middle of an edge-tap turn each
            for label, nm in (("Slide", "slide"), ("Swing open (horizontal)", "swing_h"), ("Fade In", "fade")):
                if set_flip_style(label):
                    time.sleep(1.2)
                    # go one page back first (animated too), so there is a next page to turn to
                    adb("shell", "input", "tap", "80", "1200")
                    time.sleep(6.0)
                    before_style = shot("turn_%s_0_before" % nm)
                    adb("shell", "input", "tap", "1000", "1200")
                    time.sleep(1.3)
                    mid_style = shot("turn_%s_1_mid" % nm)
                    time.sleep(5.0)
                    after_style = shot("turn_%s_2_after" % nm)
                    d1, d2 = img_diff(before_style, mid_style), img_diff(mid_style, after_style)
                    log("style %s: before->mid=%s mid->after=%s before->after=%s" % (label, d1, d2, img_diff(before_style, after_style)))
                    if d1 is not None:
                        check("'%s' animates (a frame in between differs from both ends)" % label, d1 > 1.0 and d2 > 1.0, "diff=%.2f / %.2f" % (d1, d2))
            log_out = adb("logcat", "-d", "-s", "PageTurn:I")
            log("PageTurn log: " + log_out.strip().replace("\n", " / ")[:1500])
            m = re.search(r"distinct sampled colours=(\d+)", log_out)
            check("page snapshot contains the page (not just a blank backdrop)", bool(m) and int(m.group(1)) >= 4,
                  m.group(0) if m else "no snapshot logged")
            c1, trace = crashed()
            check("no crash while turning pages", not c1, trace[:1800] if c1 else "")
            set_flip_style("None")
        else:
            log("  (page flip dialog not reachable)")
        adb("shell", "settings", "put", "global", "animator_duration_scale", "0")

        # ------------------------------------------------------------ dual page mode (landscape)
        if open_reader_menu_item("Dual-Page Mode"):
            time.sleep(1.5)
            adb("shell", "settings", "put", "system", "accelerometer_rotation", "0")
            adb("shell", "settings", "put", "system", "user_rotation", "1")
            time.sleep(9)
            path = shot("dual_page_landscape")
            left = ink(path, 0.12, 0.25, 0.46, 0.62)
            gutter = ink(path, 0.485, 0.25, 0.515, 0.62)
            right = ink(path, 0.54, 0.25, 0.88, 0.62)
            log("dual page ink: left=%s gutter=%s right=%s" % (left, gutter, right))
            if left is not None:
                check("dual page: text on both sides of an empty gutter in landscape",
                      left > 0.02 and right > 0.02 and gutter < min(left, right) * 0.4, "left=%.3f gutter=%.3f right=%.3f" % (left, gutter, right))
            c2, trace = crashed()
            check("no crash when dual page mode reopens the reader in landscape", not c2 and alive(), trace[:1800] if c2 else "")
            # back to portrait and switch it off again
            adb("shell", "settings", "put", "system", "user_rotation", "0")
            time.sleep(8)
            screen("dual_page_back_to_portrait", 1)
            if open_reader_menu_item("Dual-Page Mode"):
                time.sleep(6)
                screen("dual_page_off", 1)
        adb("shell", "settings", "put", "system", "accelerometer_rotation", "1")

        import_fonts_and_use()

        # stay in the reader long enough to record a whole minute of reading
        remaining = 70 - (time.time() - reader_start)
        if remaining > 0:
            time.sleep(remaining)
        back()
        time.sleep(2)
        screen("library_after_reading", 1)
    gfx_report("reader session")

    # ---------------------------------------------------------------- reading stats
    log("== Phase G: reading stats")
    if wait_for("Stats", 2, True) is None:
        back()          # still on the book detail screen: one more step back to the library
        time.sleep(1.5)
    if tap_label("Stats", 5, exact=True):
        nodes = screen("stats_week", 2)
        check("stats screen shows the header, period button and cards",
              find(nodes, "Reading stats") is not None and find(nodes, "This week") is not None and find(nodes, "Time spent reading") is not None,
              " | ".join(labels(nodes))[:300])
        check("stats show the tiles", all(find(nodes, t) for t in ("Books read from", "Books finished", "Day streak", "Sittings", "Pace")),
              " | ".join(labels(nodes))[:300])
        check("stats show the day-by-day chart and device note", find(nodes, "Day by day") is not None and find(nodes, "Counting this device only") is not None)
        joined = " | ".join(labels(nodes))
        m = re.search(r"TIME SPENT READING \| (?:(\d+) h )?(?:(\d+) min)?", joined)
        minutes = (int(m.group(1) or 0) * 60 + int(m.group(2) or 0)) if m else 0
        m2 = re.search(r"Sittings \| (\d+)", joined)
        sittings = int(m2.group(1)) if m2 else 0
        check("recorded reading appears (>= 1 min and >= 1 sitting)", minutes >= 1 and sittings >= 1,
              "minutes=%d sittings=%d | %s" % (minutes, sittings, joined[:240]))
        swipe_up(0.6)
        nodes = screen("stats_by_book", 1.2)
        check("By book lists the read book with sittings", find(nodes, "By book") is not None and find(nodes, "sitting") is not None
              and (find(nodes, "The Quiet Library") is not None or find(nodes, "Outside Book") is not None),
              " | ".join(labels(nodes))[:300])
        swipe_down(0.8)
        for period, expect in (("This month", "This month"), ("This year", "This year"), ("All time", "Across all time")):
            if tap_label("This week", 3) or tap_label("This month", 2) or tap_label("This year", 2) or tap_label("All time", 2):
                time.sleep(0.8)
                if tap_label(period, 3, exact=True):
                    nodes = screen("stats_" + period.lower().replace(" ", "_"), 1.5)
                    check("period switch to '%s' recomputes the stats" % period,
                          find(nodes, "Reading stats") is not None and find(nodes, expect) is not None, " | ".join(labels(nodes))[:240])
        tap_label("All time", 2)
        time.sleep(0.5)
        tap_label("This week", 2, exact=True)

    # ---------------------------------------------------------------- performance of the animated library
    log("== Phase H: frame timing with animations ON")
    adb("shell", "settings", "put", "global", "animator_duration_scale", "1")
    adb("shell", "settings", "put", "global", "transition_animation_scale", "1")
    adb("shell", "settings", "put", "global", "window_animation_scale", "1")
    stop()
    launch()
    tap_label("Library", 4, exact=True)
    time.sleep(1.5)
    gfx_reset()
    for _ in range(4):
        adb("shell", "input", "swipe", "540", "1800", "540", "500", "250")
        time.sleep(0.4)
        adb("shell", "input", "swipe", "540", "500", "540", "1800", "250")
        time.sleep(0.4)
    gfx_report("library scroll")
    gfx_reset()
    for nav in ("Settings", "Stats", "Notes", "Bookmarks", "Library"):
        n = find(dump(), nav, exact=True)
        if n:
            tap(n)
            time.sleep(0.9)
    gfx_report("tab switches")
    gfx_reset()
    if tap_book("The Quiet Library"):
        time.sleep(1.2)
        back()
        time.sleep(1.2)
    gfx_report("detail open/close (shared element)")
    c, trace = crashed()
    check("no crash with animations enabled", not c and alive(), trace[:1800] if c else "")

    # ---------------------------------------------------------------- settings + Persian
    log("== Phase I: settings, Persian")
    tap_label("Settings", 5, exact=True)
    nodes = screen("settings_top", 1.5)
    check("settings screen shows the theme presets", find(nodes, "Ocean") is not None, " | ".join(labels(nodes))[:250])
    color_picker_checks()
    swipe_up()
    screen("settings_scrolled", 1)
    swipe_up()
    screen("settings_bottom", 1)
    swipe_down(0.9)
    swipe_down(0.9)
    if tap_label("فارسی", 5, exact=True):
        time.sleep(3)
        nodes = screen("persian_settings", 1.5)
        check("Persian UI shows translated navigation", find(nodes, "کتابخانه") is not None and find(nodes, "تنظیمات") is not None,
              " | ".join(labels(nodes))[:250])
        if tap_label("آمار", 4, exact=True):
            nodes = screen("persian_stats", 2)
            check("Persian stats screen is translated", find(nodes, "آمار مطالعه") is not None and find(nodes, "این هفته") is not None,
                  " | ".join(labels(nodes))[:300])
        tap_label("کتابخانه", 4, exact=True)
        screen("persian_library", 1.5)

    # ---------------------------------------------------------------- launcher icon (informational screenshot)
    log("== launcher icon")
    adb("shell", "input", "keyevent", "KEYCODE_HOME")
    time.sleep(2.5)
    adb("shell", "input", "swipe", "540", "2000", "540", "500", "300")
    time.sleep(2.5)
    shot("launcher_app_drawer")

    # ---------------------------------------------------------------- wrap up
    with open("logcat.txt", "w") as f:
        f.write(adb("logcat", "-d", "-t", "5000"))
    with open("crash.txt", "w") as f:
        f.write(adb("logcat", "-d", "-b", "crash").strip() or "(no crash recorded)")
    fails = [n for n, ok in CHECKS if not ok]
    log("SUMMARY: %d checks, %d failed" % (len(CHECKS), len(fails)))
    for n, ok in CHECKS:
        log(("  PASS " if ok else "  FAIL ") + n)
    with open("ui-report.txt", "w") as f:
        f.write("\n".join(REPORT))
    print("::notice::UI test: %d checks, %d failed" % (len(CHECKS), len(fails)))
    sys.exit(1 if fails else 0)


try:
    main()
except SystemExit:
    raise
except Exception as ex:  # keep the artefacts even when the script itself breaks
    import traceback
    traceback.print_exc()
    with open("ui-report.txt", "w") as f:
        f.write("\n".join(REPORT) + "\nSCRIPT ERROR: %r" % ex)
    with open("logcat.txt", "w") as f:
        f.write(adb("logcat", "-d", "-t", "5000"))
    with open("crash.txt", "w") as f:
        f.write(adb("logcat", "-d", "-b", "crash").strip() or "(no crash recorded)")
    print("::error::ui_test.py crashed: %r" % ex)
    sys.exit(2)
