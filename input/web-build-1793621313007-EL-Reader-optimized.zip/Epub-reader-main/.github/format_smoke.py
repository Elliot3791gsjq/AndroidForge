#!/usr/bin/env python3
"""Emulator smoke test of the non-EPUB readers (TXT, DOCX, PDF, CBZ) and of corrupt files.

Runs inside android-emulator-runner. One real file of every format is made here, pushed to the phone and opened from
outside the app (VIEW intent, the same path as "Open with"). For each one the script checks that the right reader
opens, that nothing crashes, that the page really shows something (pixels of the screenshot), and drives the main
controls (chrome toggle, settings, search, bookmark, note, zoom, page turn, position restore). It is deliberately
small: it answers "does each new reader start and work on a real Android WebView / PdfRenderer", not "is everything
perfect". Every check is logged as CHECK PASS / CHECK FAIL / INFO; the script never stops at the first failure.
Usage: format_smoke.py <new.apk>
"""
import os
import re
import struct
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
import zipfile
import zlib

PKG = "com.novelreader.app.debug"
MAIN = PKG + "/com.novelreader.app.MainActivity"
APK = sys.argv[1]
SHOTS = "shots"
os.makedirs(SHOTS, exist_ok=True)
REPORT = []
CHECKS = []
_shot_i = [0]


def log(msg):
    print(msg, flush=True)
    REPORT.append(msg)


def adb(*args, timeout=90):
    try:
        r = subprocess.run(["adb", *args], capture_output=True, text=True, timeout=timeout)
        return (r.stdout or "") + (r.stderr or "")
    except subprocess.TimeoutExpired:
        return "TIMEOUT"


def check(name, ok, detail=""):
    CHECKS.append((name, bool(ok)))
    log(("CHECK PASS " if ok else "CHECK FAIL ") + name + (" - " + detail if detail else ""))
    if not ok:
        print("::error::smoke check failed: " + name + (" - " + detail if detail else ""), flush=True)


def info(name, detail=""):
    log("INFO " + name + (" - " + detail if detail else ""))


# ------------------------------------------------------------------------------------------------ UI helpers
class Node:
    def __init__(self, e):
        self.text = e.get("text") or ""
        self.desc = e.get("content-desc") or ""
        b = e.get("bounds") or "[0,0][0,0]"
        nums = [int(x) for x in b.replace("][", ",").strip("[]").split(",")]
        self.x1, self.y1, self.x2, self.y2 = nums
        self.cx, self.cy = (self.x1 + self.x2) // 2, (self.y1 + self.y2) // 2

    @property
    def label(self):
        return self.text or self.desc


def dump():
    for _ in range(4):
        adb("shell", "uiautomator", "dump", "/sdcard/ui.xml")
        out = adb("exec-out", "cat", "/sdcard/ui.xml")
        i = out.find("<?xml")
        if i >= 0:
            try:
                nodes = [Node(e) for e in ET.fromstring(out[i:]).iter("node")]
            except ET.ParseError:
                nodes = []
            if any("isn't responding" in n.text or "isn’t responding" in n.text for n in nodes):
                wait = next((n for n in nodes if n.text.strip().lower() == "wait"), None)
                if wait:
                    adb("shell", "input", "tap", str(wait.cx), str(wait.cy))
                time.sleep(3)
                continue
            return nodes
        time.sleep(1)
    return []


def labels(nodes):
    seen = []
    for n in nodes:
        if n.label and n.label not in seen:
            seen.append(n.label)
    return seen


def find(nodes, label, exact=False):
    low = label.lower()
    best = None
    for n in nodes:
        for t in (n.text, n.desc):
            if not t:
                continue
            tl = t.lower()
            if tl == low:
                return n
            if not exact and low in tl and best is None:
                best = n
    return best


def wait_for(label, timeout=10, exact=False):
    end = time.time() + timeout
    while time.time() < end:
        n = find(dump(), label, exact)
        if n:
            return n
        time.sleep(1)
    return None


def tap(n):
    adb("shell", "input", "tap", str(n.cx), str(n.cy))


def tap_xy(x, y):
    adb("shell", "input", "tap", str(x), str(y))


def tap_label(label, timeout=8, exact=False):
    n = wait_for(label, timeout, exact)
    if n:
        tap(n)
        time.sleep(1.2)
        return True
    log("  (not found: %s)" % label)
    return False


def back():
    adb("shell", "input", "keyevent", "KEYCODE_BACK")
    time.sleep(1.5)


def swipe(x1, y1, x2, y2, ms=350):
    adb("shell", "input", "swipe", str(x1), str(y1), str(x2), str(y2), str(ms))
    time.sleep(1.2)


def shot(name):
    _shot_i[0] += 1
    path = "%s/%02d_%s.png" % (SHOTS, _shot_i[0], name)
    with open(path, "wb") as f:
        subprocess.run(["adb", "exec-out", "screencap", "-p"], stdout=f, timeout=60)
    log("SHOT " + path)
    return path


def screen(name, wait=1.0):
    time.sleep(wait)
    nodes = dump()
    log("SCREEN %s: %s" % (name, " | ".join(labels(nodes))[:900]))
    return nodes, shot(name)


def crashed():
    out = adb("logcat", "-d", "-b", "crash")
    pos = 0
    while True:
        i = out.find("FATAL EXCEPTION", pos)
        if i < 0:
            return False, ""
        if "Process: " + PKG in out[i:i + 400]:
            return True, out[max(0, out.rfind("\n", 0, i)):][:5000]
        pos = i + 10


CRASH_LOG = []


def reset_crash_buffer(tag):
    """Keeps a crash of an earlier flow from being counted again in the next one: the trace is saved, then the buffer cleared."""
    c, trace = crashed()
    if c:
        CRASH_LOG.append("[before %s]\n%s" % (tag, trace))
        log("INFO crash of the previous flow kept in crash.txt")
    adb("logcat", "-b", "crash", "-c")


def alive():
    return bool(adb("shell", "pidof", PKG).strip())


def keyboard_shown():
    return "mInputShown=true" in adb("shell", "dumpsys", "input_method")


def hide_keyboard():
    if keyboard_shown():
        back()


def scroll_sheet_and_collect(rounds=10):
    """Scrolls a bottom sheet up step by step and returns every label seen on the way (the first screen included),
    because the accessibility tree only lists what is on screen. Stops when two scrolls bring nothing new."""
    seen = list(labels(dump()))
    quiet = 0
    for _ in range(rounds):
        adb("shell", "input", "swipe", "540", "1750", "540", "800", "300")
        time.sleep(0.8)
        fresh = [l for l in labels(dump()) if l not in seen]
        seen.extend(fresh)
        quiet = 0 if fresh else quiet + 1
        if quiet >= 2:
            break
    return seen


SHEET_ONLY = ("Text direction", "Text alignment", "Line spacing", "Side margins", "Text weight", "Encoding",
              "Lines and paragraphs", "Colours", "Text color")


def sheet_open():
    """The reading-settings sheet is up: any label that only exists inside it is on screen (the sheet's own title
    "Reading settings" is also the label of the top-bar button, so it cannot be used)."""
    nodes = dump()
    return any(find(nodes, t, exact=True) is not None for t in SHEET_ONLY)


def close_sheet():
    """Presses Back once, only if the sheet is really open (Back with no sheet would leave the reader)."""
    if sheet_open():
        back()
        time.sleep(1.5)
        return True
    return False


def wait_chrome(visible, timeout=8):
    """Waits until the reader's top bar is (not) on screen; also taps away the system's one-time full-screen notice."""
    end = time.time() + timeout
    while time.time() < end:
        nodes = dump()
        got = find(nodes, "Got it", exact=True)
        if got is not None and find(nodes, "Viewing full screen") is not None:
            tap(got)
            time.sleep(1.0)
            continue
        shown = find(nodes, "Search in the document") is not None
        if shown == visible:
            return True
        time.sleep(1)
    return False


def scroll_until(label, rounds=9, top=450, bottom=2150):
    """Scrolls the open bottom sheet until [label] is on screen (not at the very edge) and taps it. Returns the label tapped, "" if never seen."""
    for _ in range(rounds):
        n = find(dump(), label)
        if n is not None and top < n.cy < bottom:
            label = n.label
            tap(n)
            time.sleep(1.2)
            return label
        adb("shell", "input", "swipe", "540", "1500", "540", "900", "300")
        time.sleep(0.7)
    return ""


def resumed():
    out = adb("shell", "dumpsys", "activity", "activities")
    m = re.search(r"(?:topResumedActivity|ResumedActivity)[^\n]*?\s(\S+/\S+)", out)
    return m.group(1) if m else ""


def web_console():
    """JavaScript errors / console output of the page (WebView writes them to logcat)."""
    out = adb("logcat", "-d", "-s", "chromium:*")
    keep = [l for l in out.splitlines() if "CONSOLE" in l or "Uncaught" in l]
    return keep[-8:]


# ------------------------------------------------------------------------------------------------ pixels
def image(path):
    from PIL import Image
    return Image.open(path).convert("RGB")


def ink_ratio(path, box=(0.0, 0.12, 1.0, 0.88)):
    """Share of pixels that differ clearly from the most common colour in the box: text / pictures on a flat page."""
    im = image(path)
    w, h = im.size
    crop = im.crop((int(w * box[0]), int(h * box[1]), int(w * box[2]), int(h * box[3]))).resize((180, 300))
    px = list(crop.getdata())
    counts = {}
    for p in px:
        k = (p[0] // 16, p[1] // 16, p[2] // 16)
        counts[k] = counts.get(k, 0) + 1
    top = max(counts, key=counts.get)
    far = sum(1 for p in px if abs(p[0] // 16 - top[0]) + abs(p[1] // 16 - top[1]) + abs(p[2] // 16 - top[2]) > 2)
    return far / len(px)


def differs(a, b, box=(0.0, 0.1, 1.0, 0.9)):
    """Mean absolute difference of two screenshots in the box (0..255)."""
    from PIL import ImageChops
    ia, ib = image(a), image(b)
    w, h = ia.size
    bx = (int(w * box[0]), int(h * box[1]), int(w * box[2]), int(h * box[3]))
    d = ImageChops.difference(ia.crop(bx).resize((120, 200)), ib.crop(bx).resize((120, 200)))
    px = list(d.getdata())
    return sum(sum(p) for p in px) / (3.0 * len(px))


def count_color(path, pred):
    im = image(path).resize((270, 585))
    return sum(1 for p in im.getdata() if pred(p))


def dominant(path):
    im = image(path).resize((60, 120))
    counts = {}
    for p in im.getdata():
        k = (p[0] // 32, p[1] // 32, p[2] // 32)
        counts[k] = counts.get(k, 0) + 1
    k = max(counts, key=counts.get)
    return tuple(v * 32 + 16 for v in k)


# ------------------------------------------------------------------------------------------------ test files
def png_raw(width, height, row_fn):
    rows = bytearray()
    for y in range(height):
        rows.append(0)
        rows.extend(row_fn(y))

    def chunk(tag, data):
        c = struct.pack(">I", len(data)) + tag + data
        return c + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)

    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)) +
            chunk(b"IDAT", zlib.compress(bytes(rows), 6)) + chunk(b"IEND", b""))


def solid_png(width, height, rgb):
    row = bytes(rgb) * width
    return png_raw(width, height, lambda y: row)


EN_WORD = "lighthouse"


def make_txt_en(path):
    out = []
    for i in range(1, 421):
        if (i - 1) % 60 == 0:
            out.append("Chapter %d" % ((i - 1) // 60 + 1))
        out.append("The %s keeper climbed the stairs again, as he had every evening for thirty years, counting step %d in the "
                   "dark. The sea below was quiet, and the lamp turned slowly above him." % (EN_WORD, i))
    open(path, "w", encoding="utf-8").write("\n".join(out) + "\n")


FA_SENT = "او هر شب از پلکان فانوس بالا می‌رفت و پله‌ها را می‌شمرد. دریا آرام بود و چراغ بالای سرش آرام می‌چرخید."
FA_WORD = "فانوس"


def make_txt_fa(path):
    """Persian text in windows-1256 (the old code page): the app has to recognise it by itself."""
    out = []
    for i in range(1, 301):
        if (i - 1) % 50 == 0:
            out.append("فصل %d" % ((i - 1) // 50 + 1))
        out.append("%s پاراگراف شمارهٔ %d." % (FA_SENT, i))
    text = "\n".join(out) + "\n"
    text = text.replace("ی", "ي").replace("ک", "ك").replace("ۀ", "ه")
    open(path, "wb").write(text.encode("cp1256", errors="replace"))


W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
RNS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"


def esc(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def para(text, ppr="", rpr=""):
    return "<w:p>%s<w:r>%s<w:t xml:space=\"preserve\">%s</w:t></w:r></w:p>" % (
        "<w:pPr>%s</w:pPr>" % ppr if ppr else "", "<w:rPr>%s</w:rPr>" % rpr if rpr else "", esc(text))


def make_docx(path):
    body = []
    body.append(para("Smoke Document", "<w:pStyle w:val=\"Heading1\"/>"))
    body.append(para("This paragraph has bold text.", rpr="<w:b/>"))
    body.append(para("Red coloured words in an English paragraph.", rpr="<w:color w:val=\"FF0000\"/>"))
    body.append(para("این یک بند فارسی در سند ورد است و باید راست‌به‌چپ نمایش داده شود.", "<w:bidi/>"))
    body.append("<w:p><w:pPr><w:numPr><w:ilvl w:val=\"0\"/><w:numId w:val=\"1\"/></w:numPr></w:pPr><w:r><w:t>List item one</w:t></w:r></w:p>")
    body.append("<w:p><w:pPr><w:numPr><w:ilvl w:val=\"0\"/><w:numId w:val=\"1\"/></w:numPr></w:pPr><w:r><w:t>List item two</w:t></w:r></w:p>")
    body.append("<w:tbl><w:tr><w:tc><w:tcPr><w:shd w:val=\"clear\" w:fill=\"FFCC00\"/></w:tcPr>%s</w:tc><w:tc>%s</w:tc></w:tr></w:tbl>"
                % (para("Cell A"), para("Cell B")))
    body.append("<w:p><w:r><w:drawing><wp:inline xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\">"
                "<wp:extent cx=\"1905000\" cy=\"952500\"/><a:graphic xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\">"
                "<a:graphicData><pic:pic xmlns:pic=\"http://schemas.openxmlformats.org/drawingml/2006/picture\"><pic:blipFill>"
                "<a:blip r:embed=\"rIdImg\"/></pic:blipFill></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>")
    body.append(para("Second Heading", "<w:pStyle w:val=\"Heading1\"/>"))
    for i in range(1, 60):
        body.append(para("Body paragraph number %d of the smoke document, long enough to wrap onto a second line on a phone screen." % i))
    doc = ("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><w:document xmlns:w=\"%s\" xmlns:r=\"%s\"><w:body>%s</w:body></w:document>"
           % (W, RNS, "".join(body)))
    styles = ("<?xml version=\"1.0\"?><w:styles xmlns:w=\"%s\"><w:style w:type=\"paragraph\" w:styleId=\"Heading1\"><w:name w:val=\"heading 1\"/>"
              "<w:pPr><w:outlineLvl w:val=\"0\"/></w:pPr><w:rPr><w:b/><w:sz w:val=\"36\"/></w:rPr></w:style></w:styles>" % W)
    numbering = ("<?xml version=\"1.0\"?><w:numbering xmlns:w=\"%s\"><w:abstractNum w:abstractNumId=\"0\"><w:lvl w:ilvl=\"0\"><w:start w:val=\"1\"/>"
                 "<w:numFmt w:val=\"decimal\"/><w:lvlText w:val=\"%%1.\"/></w:lvl></w:abstractNum><w:num w:numId=\"1\"><w:abstractNumId w:val=\"0\"/></w:num></w:numbering>" % W)
    rels = ("<?xml version=\"1.0\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
            "<Relationship Id=\"rIdS\" Type=\"%s/styles\" Target=\"styles.xml\"/><Relationship Id=\"rIdN\" Type=\"%s/numbering\" Target=\"numbering.xml\"/>"
            "<Relationship Id=\"rIdImg\" Type=\"%s/image\" Target=\"media/image1.png\"/></Relationships>" % (RNS, RNS, RNS))
    root_rels = ("<?xml version=\"1.0\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
                 "<Relationship Id=\"rId1\" Type=\"%s/officeDocument\" Target=\"word/document.xml\"/></Relationships>" % RNS)
    ctypes = ("<?xml version=\"1.0\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">"
              "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>"
              "<Default Extension=\"xml\" ContentType=\"application/xml\"/><Default Extension=\"png\" ContentType=\"image/png\"/>"
              "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/></Types>")
    header = "<?xml version=\"1.0\"?><w:hdr xmlns:w=\"%s\"><w:p><w:r><w:t>Header text that is not shown</w:t></w:r></w:p></w:hdr>" % W
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", ctypes)
        z.writestr("_rels/.rels", root_rels)
        z.writestr("word/document.xml", doc)
        z.writestr("word/_rels/document.xml.rels", rels)
        z.writestr("word/styles.xml", styles)
        z.writestr("word/numbering.xml", numbering)
        z.writestr("word/header1.xml", header)
        z.writestr("word/media/image1.png", solid_png(120, 60, (0, 160, 40)))


def make_pdf(path, pages=3):
    objs = {}
    page_ids = [4 + 2 * i for i in range(pages)]
    objs[1] = "<< /Type /Catalog /Pages 2 0 R >>"
    objs[2] = "<< /Type /Pages /Kids [%s] /Count %d >>" % (" ".join("%d 0 R" % p for p in page_ids), pages)
    objs[3] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>"
    for i, pid in enumerate(page_ids):
        text = "BT /F1 40 Tf 60 700 Td (PDF page %d of %d) Tj 0 -60 Td /F1 22 Tf (lighthouse keeper smoke test) Tj ET" % (i + 1, pages)
        stream = text + "\n0.9 0.1 0.1 rg 60 400 200 120 re f"
        objs[pid] = ("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents %d 0 R "
                     "/Resources << /Font << /F1 3 0 R >> >> >>" % (pid + 1))
        objs[pid + 1] = "<< /Length %d >>\nstream\n%s\nendstream" % (len(stream), stream)
    out = bytearray(b"%PDF-1.4\n")
    offsets = {}
    for n in sorted(objs):
        offsets[n] = len(out)
        out += ("%d 0 obj\n%s\nendobj\n" % (n, objs[n])).encode("latin-1")
    xref = len(out)
    size = max(objs) + 1
    out += ("xref\n0 %d\n0000000000 65535 f \n" % size).encode()
    for n in range(1, size):
        out += ("%010d 00000 n \n" % offsets[n]).encode()
    out += ("trailer\n<< /Size %d /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n" % (size, xref)).encode()
    open(path, "wb").write(bytes(out))


COMIC_COLORS = [(210, 40, 40), (40, 170, 60), (40, 70, 210), (230, 200, 30)]


def make_cbz(path):
    with zipfile.ZipFile(path, "w", zipfile.ZIP_STORED) as z:
        for i, c in enumerate(COMIC_COLORS):
            z.writestr("page%02d.png" % (i + 1), solid_png(600, 900, c))


# ------------------------------------------------------------------------------------------------ flows
MIME = {
    "txt": "text/plain",
    "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "pdf": "application/pdf",
    "cbz": "application/vnd.comicbook+zip",
}


PRIVATE = "/data/user/0/%s/files/smoke/" % PKG


def put_private(local, name):
    """Copies a test file into the app's own files dir (run-as works for the debug build). The app can always read
    that, so the test does not depend on storage permissions of the emulator image."""
    with open(local, "rb") as f:
        r = subprocess.run(["adb", "exec-in", "run-as %s sh -c 'mkdir -p files/smoke && cat > files/smoke/%s'" % (PKG, name)],
                           stdin=f, capture_output=True, timeout=60)
    return r.returncode == 0


def open_file(filename, mime, wait=10):
    out = adb("shell", "am", "start", "-W", "-a", "android.intent.action.VIEW", "-t", mime,
              "-d", "file://" + PRIVATE + filename, "-n", MAIN)
    time.sleep(wait)
    keep = [l for l in adb("logcat", "-d", "-t", "400").splitlines()
            if re.search(r"novelreader|AndroidRuntime|chromium.*(CONSOLE|Uncaught)|MediaProvider|StrictMode", l)]
    for l in keep[-6:]:
        info("log after opening " + filename, l[-220:])


def reader_ok(tag, expect_activity):
    act = resumed()
    c, trace = crashed()
    check("%s: no crash on open" % tag, not c and alive(), trace[:1500])
    check("%s: the %s opens" % (tag, expect_activity), expect_activity in act, act)
    return act


def tap_center():
    tap_xy(540, 1300)
    time.sleep(1.0)


def flow_doc(tag, filename, fmt, expect_word=None, contents=False):
    log("== %s" % tag)
    open_file(filename, MIME[fmt], wait=12)
    if "DocReaderActivity" not in reader_ok(tag, "DocReaderActivity"):
        screen(tag + "_not_opened", 1.0)
        return False
    nodes, a = screen(tag + "_open", 1.5)
    ink = ink_ratio(a)
    check("%s: the page shows text (ink %.3f)" % (tag, ink), ink > 0.01)
    if expect_word:
        found = [l for l in labels(nodes) if expect_word in l]
        info("%s: page text readable through accessibility" % tag, "found" if found else "not exposed (inconclusive)")
        if found:
            check("%s: the text is decoded correctly (%s)" % (tag, expect_word), True)
    for l in web_console():
        info("page console", l[-200:])
    check("%s: top bar has search / marks / settings" % tag,
          all(find(nodes, t) for t in ("Search in the document", "Bookmarks and notes", "Reading settings")), " | ".join(labels(nodes))[:200])
    if contents:
        check("%s: contents button (headings found)" % tag, find(nodes, "Contents") is not None)

    # tap in the middle of the page -> chrome hides (JS tap -> bridge -> Compose), again -> shows
    tap_center()
    hidden = wait_chrome(False)
    check("%s: tapping the page hides the bars (JS bridge works)" % tag, hidden, " | ".join(labels(dump()))[:160])
    shot(tag + "_immersive")
    tap_center()
    check("%s: tapping again shows the bars" % tag, wait_chrome(True))
    time.sleep(1.0)

    # settings sheet. The page is photographed BEFORE the sheet opens and AFTER it closed (same bars on screen), so a
    # different picture can only come from the changed text size.
    page_before = shot(tag + "_page_before")
    if tap_label("Reading settings", 6):
        sn, _ = screen(tag + "_settings", 1.2)
        check("%s: settings sheet lists its own controls" % tag, find(sn, "Text size") is not None and find(sn, "Line spacing") is not None,
              " | ".join(labels(sn))[:240])
        plus = None
        for n in sn:
            if n.desc.lower() in ("increase", "increase text size") and n.cy < find(sn, "Line spacing").cy:
                plus = n
                break
        if plus:
            for _ in range(5):
                tap(plus)
                time.sleep(0.5)
        # the options further down the sheet (the accessibility tree only lists what is on screen, so scroll and collect)
        seen = scroll_sheet_and_collect()
        info("%s: all settings labels seen" % tag, " | ".join(seen)[:900])
        shot(tag + "_settings_bottom")
        if fmt == "txt":
            check("txt: encoding + paragraph options exist", "Encoding" in seen and "Lines and paragraphs" in seen, " | ".join(seen)[-300:])
            check("txt: encoding list offers Windows-1256 and UTF-8",
                  any(l.startswith("Windows-1256") for l in seen) and "UTF-8" in seen)
        else:
            check("docx: document fonts / colours switches exist", "Use the fonts of the document" in seen, " | ".join(seen)[:300])
            check("docx: alignment can follow the document / colours can be kept",
                  "As in the document" in seen and "Keep the colours of the document" in seen, " | ".join(seen)[:300])
        was_open = close_sheet()
        wait_chrome(True)
        time.sleep(1.5)
        after = shot(tag + "_bigger_text")
        in_reader = "DocReaderActivity" in resumed()
        check("%s: the settings sheet closes and the reader stays" % tag, was_open and in_reader, resumed())
        if plus:
            d = differs(page_before, after)
            check("%s: a bigger text size changes the page live (diff %.2f)" % (tag, d), in_reader and d > 1.0)
        else:
            info("%s: no + button for text size found" % tag, " | ".join(labels(sn))[:200])
    # bookmark
    if find(dump(), "Bookmarks and notes") is None:
        tap_center()
        wait_chrome(True)
    if tap_label("Bookmarks and notes", 6):
        if tap_label("Add bookmark", 6):
            time.sleep(1.5)
            bn = dump()
            check("%s: a bookmark is added and listed" % tag, find(bn, "Add bookmark") is not None and find(bn, "No bookmarks yet") is None,
                  " | ".join(labels(bn))[:200])
        back()
        time.sleep(1)
    else:
        check("%s: the bookmarks button is reachable" % tag, False, " | ".join(labels(dump()))[:200])
    c, trace = crashed()
    check("%s: still no crash after settings / bookmark" % tag, not c and alive(), trace[:1500])
    return True


def flow_txt_search_and_note():
    tag = "txt-en"
    log("== %s: search, selection, note, position" % tag)
    if not tap_label("Search in the document", 6):
        return
    field = wait_for("Find in this document", 5)
    if field:
        tap(field)
        time.sleep(0.8)
        adb("shell", "input", "text", EN_WORD)
        time.sleep(0.8)
        adb("shell", "input", "keyevent", "KEYCODE_ENTER")
        time.sleep(3)
        sn, _ = screen(tag + "_search", 1.0)
        m = [l for l in labels(sn) if re.search(r"\b\d+ of \d+\b", l)]
        check("txt-en: search finds the word (\"1 of N\")", bool(m), (m[0] if m else " | ".join(labels(sn))[:200]))
        if m:
            nums = re.findall(r"\d+", m[0])
            check("txt-en: all 420 occurrences are found", len(nums) >= 2 and int(nums[1]) == 420, m[0])
            n = find(sn, "Next match")
            if n:
                tap(n)
                time.sleep(1.5)
                shot(tag + "_next_hit")
        close = find(dump(), "Close search")
        if close:
            tap(close)
            time.sleep(1)
    # selection: long-press on text until the app's own bar (Copy / Note) shows
    sel = False
    hide_keyboard()
    first = True
    for y in (900, 1100, 1300, 700, 1500):
        for dx in (0, 3):                 # a still press, and one with a tiny move (both are long-presses for Android)
            adb("shell", "input", "swipe", "300", str(y), str(300 + dx), str(y), "1100")
            time.sleep(1.5)
            sn = dump()
            if first:
                shot(tag + "_longpress_try")
                first = False
            if find(sn, "Clear selection") is not None:
                sel = True
                break
        if sel:
            break
    check("txt-en: long-press selects text and shows the selection bar", sel, " | ".join(labels(sn))[:200])
    if sel:
        shot(tag + "_selection")
        if tap_label("Note", 4, exact=True):
            fld = wait_for("Write a note", 4)
            if fld:
                tap(fld)
                time.sleep(0.6)
                adb("shell", "input", "text", "smoke%snote")
                time.sleep(0.8)
                back()           # hides the keyboard
                time.sleep(0.8)
            if tap_label("Save", 4, exact=True):
                time.sleep(2)
                shot(tag + "_note_saved")
                if find(dump(), "Bookmarks and notes") is None:
                    tap_center()
                if tap_label("Bookmarks and notes", 5):
                    tap_label("Highlights and notes", 4)
                    nn = dump()
                    check("txt-en: the note appears in the notes list", find(nn, "smoke note") is not None or find(nn, "smoke") is not None,
                          " | ".join(labels(nn))[:240])
                    back()
                    time.sleep(1)
    # position: scroll far, leave, reopen -> same place
    for _ in range(6):
        swipe(540, 1800, 540, 500, 250)
    time.sleep(1.5)
    a = shot(tag + "_scrolled")
    back()
    time.sleep(2)
    open_file("smoke_en.txt", MIME["txt"], wait=10)
    time.sleep(2)
    b = shot(tag + "_reopened")
    d = differs(a, b)
    check("txt-en: reopening restores the reading position (diff %.2f)" % d, d < 6.0)


def flow_txt_encoding_override():
    """Opens the cp1256 Persian file, forces the wrong encoding (page must change), then back to automatic (page must
    return). This is the re-decode path of the encoding override. While the wrong one is forced, the "Automatic (...)"
    entry must still name what detection found (Windows-1256), not the forced encoding."""
    tag = "txt-fa-enc"
    log("== %s: encoding override" % tag)
    open_file("smoke_fa.txt", MIME["txt"], wait=10)
    if "DocReaderActivity" not in reader_ok(tag, "DocReaderActivity"):
        return
    wait_chrome(True)
    time.sleep(1.5)
    base = shot(tag + "_base")
    if not tap_label("Reading settings", 6):
        return
    if not scroll_until("Windows-1252"):
        info("%s: Windows-1252 option not found" % tag)
        return
    time.sleep(2.5)
    shot(tag + "_sheet_after_choice")
    was_open = close_sheet()
    wait_chrome(True)
    time.sleep(2)
    wrong = shot(tag + "_wrong")
    in_reader = "DocReaderActivity" in resumed()
    d = differs(base, wrong)
    check("txt-fa: forcing Windows-1252 changes the text (diff %.2f)" % d, was_open and in_reader and d > 1.0, resumed())
    if tap_label("Reading settings", 6):
        label = scroll_until("Automatic (")
        if label:
            check("txt-fa: the Automatic entry still names the detected encoding (%r)" % label, "1256" in label)
            time.sleep(2.5)
            close_sheet()
            wait_chrome(True)
            time.sleep(2)
            again = shot(tag + "_auto_again")
            d2 = differs(base, again)
            check("txt-fa: back to Automatic restores the text (diff %.2f)" % d2, "DocReaderActivity" in resumed() and d2 < 3.0)
        else:
            check("txt-fa: the Automatic entry is in the encoding list", False)
    c, trace = crashed()
    check("txt-fa: no crash while changing the encoding", not c and alive(), trace[:1500])


def flow_pdf():
    tag = "pdf"
    log("== pdf")
    open_file("smoke.pdf", MIME["pdf"], wait=10)
    if "PdfReaderActivity" not in reader_ok(tag, "PdfReaderActivity"):
        screen("pdf_not_opened", 1.0)
        return
    nodes, a = screen("pdf_open", 2.0)
    check("pdf: the page shows ink (text + red box)", ink_ratio(a) > 0.01, "%.3f" % ink_ratio(a))
    red = count_color(a, lambda p: p[0] > 170 and p[1] < 90 and p[2] < 90)
    check("pdf: the red rectangle of the page is drawn (%d px)" % red, red > 300)
    # double tap -> zoom
    adb("shell", "input", "tap", "540", "1000")
    adb("shell", "input", "tap", "540", "1000")
    time.sleep(2.5)
    z = shot("pdf_zoomed")
    check("pdf: double tap zooms (diff %.2f)" % differs(a, z), differs(a, z) > 2.0)
    # drag the zoomed page and lift the finger: this used to put a NaN into the zoom state and kill the app
    for _ in range(3):
        swipe(800, 1300, 300, 900, 300)
        swipe(300, 900, 800, 1400, 300)
    pz = shot("pdf_zoomed_panned")
    c, trace = crashed()
    check("pdf: dragging a zoomed page does not crash (the NaN regression)", not c and alive(), trace[:1500])
    check("pdf: the page is still drawn after dragging (ink %.3f)" % ink_ratio(pz), ink_ratio(pz) > 0.005)
    # settings sheet
    tap_xy(540, 1500)
    time.sleep(1)
    sn = dump()
    if find(sn, "Reading settings") is None and find(sn, "Settings") is None:
        tap_xy(540, 1500)
        sn = dump()
    info("pdf: controls on screen", " | ".join(labels(sn))[:400])
    c, trace = crashed()
    check("pdf: still no crash", not c and alive(), trace[:1500])
    # text search (Android 15+ only)
    sdk = adb("shell", "getprop", "ro.build.version.sdk").strip()
    if tap_label("Search in the document", 4):
        field = wait_for("Find in this PDF", 4)
        if field:
            tap(field)
            adb("shell", "input", "text", "lighthouse")
            adb("shell", "input", "keyevent", "KEYCODE_ENTER")
            time.sleep(5)
            sn, _ = screen("pdf_search", 1.0)
            m = [l for l in labels(sn) if re.search(r"\b\d+ of \d+\b", l)]
            info("pdf: text search on API %s" % sdk, m[0] if m else " | ".join(labels(sn))[:200])
    back()
    time.sleep(1)


def flow_cbz():
    tag = "cbz"
    log("== cbz")
    open_file("smoke.cbz", MIME["cbz"], wait=9)
    if "ComicReaderActivity" not in reader_ok(tag, "ComicReaderActivity"):
        screen("cbz_not_opened", 1.0)
        return
    nodes, a = screen("cbz_open", 1.5)
    d1 = dominant(a)
    check("cbz: first page (red) is shown %s" % (d1,), d1[0] > 150 and d1[1] < 120 and d1[2] < 120)
    swipe(900, 1200, 150, 1200, 250)
    time.sleep(1.5)
    b = shot("cbz_page2")
    d2 = dominant(b)
    check("cbz: swiping turns to page 2 (green) %s" % (d2,), d2[1] > 120 and d2[0] < 120)
    swipe(150, 1200, 900, 1200, 250)
    time.sleep(1.5)
    c = shot("cbz_back_to_page1")
    d3 = dominant(c)
    check("cbz: swiping back returns to page 1", d3[0] > 150 and d3[1] < 120)
    # zoom in by double tap, drag around, lift the finger (same NaN path as the PDF reader)
    adb("shell", "input", "tap", "540", "1200")
    adb("shell", "input", "tap", "540", "1200")
    time.sleep(2)
    for _ in range(3):
        swipe(800, 1300, 300, 900, 300)
        swipe(300, 900, 800, 1400, 300)
    shot("cbz_zoomed_panned")
    cz, tz = crashed()
    check("cbz: dragging a zoomed page does not crash", not cz and alive(), tz[:1500])
    cc, trace = crashed()
    check("cbz: still no crash", not cc and alive(), trace[:1500])


ERR_WORDS = re.compile(r"damaged|incomplete|not supported|not a valid|invalid|empty|cannot|can't|encrypted|too large|unsupported|password", re.I)


def flow_corrupt():
    log("== corrupt files")
    for name, mime in (("broken.pdf", MIME["pdf"]), ("broken.docx", MIME["docx"]), ("broken.cbz", MIME["cbz"]), ("empty.txt", MIME["txt"])):
        open_file(name, mime, wait=1)
        # the library shows its message in a snackbar for a few seconds: look for it right away, not after a long wait
        msg, nodes = [], []
        for _ in range(6):
            nodes = dump()
            msg = [l for l in labels(nodes) if ERR_WORDS.search(l) and len(l) < 200]
            if msg or "MainActivity" not in resumed():
                break
        time.sleep(1.0)
        c, trace = crashed()
        shot("corrupt_" + name.replace(".", "_"))
        check("%s: no crash" % name, not c and alive(), trace[:1500])
        act = resumed()
        if "MainActivity" in act:
            check("%s: the app says what is wrong (%s)" % (name, msg[0] if msg else "no message seen"), bool(msg))
        else:
            # a reader opened and must be showing its own error screen
            shown = [l for l in labels(nodes) if ERR_WORDS.search(l)]
            check("%s: the reader that opened shows an error (%s)" % (name, (shown or ["none"])[0]), bool(shown), act)
        info("%s: screen after opening" % name, act + " | " + " | ".join(labels(nodes))[:200])
        # leave whatever opened (an error screen or the library)
        if "MainActivity" not in act:
            back()
        time.sleep(1)


def main():
    adb("wait-for-device")
    for _ in range(60):
        if adb("shell", "getprop", "sys.boot_completed").strip() == "1":
            break
        time.sleep(3)
    time.sleep(40)
    adb("shell", "settings", "put", "secure", "anr_show_background", "0")
    adb("shell", "settings", "put", "global", "hide_error_dialogs", "1")
    for k in ("animator_duration_scale", "transition_animation_scale", "window_animation_scale"):
        adb("shell", "settings", "put", "global", k, "0")
    log("device API %s" % adb("shell", "getprop", "ro.build.version.sdk").strip())
    make_txt_en("smoke_en.txt")
    make_txt_fa("smoke_fa.txt")
    make_docx("smoke.docx")
    make_pdf("smoke.pdf")
    make_cbz("smoke.cbz")
    open("broken.pdf", "wb").write(b"this is not a pdf file at all " * 20)
    open("broken.docx", "wb").write(b"this is not a zip file at all " * 20)
    open("broken.cbz", "wb").write(b"PK\x03\x04 truncated garbage" * 10)
    open("empty.txt", "wb").write(b"")
    out = adb("install", "-r", APK)
    check("APK installs", "Success" in out, out.strip()[-120:])
    adb("shell", "appops", "set", PKG, "MANAGE_EXTERNAL_STORAGE", "allow")
    adb("shell", "am", "start", "-W", "-n", MAIN)
    time.sleep(4)
    for f in ("smoke_en.txt", "smoke_fa.txt", "smoke.docx", "smoke.pdf", "smoke.cbz", "broken.pdf", "broken.docx", "broken.cbz", "empty.txt"):
        check("test file %s is in the app's files dir" % f, put_private(f, f))
    adb("logcat", "-c")
    time.sleep(6)
    nodes, _ = screen("library_first", 1.0)
    c, trace = crashed()
    check("first launch: no crash", not c and alive(), trace[:1500])

    for label, fn in (
        ("txt-en", lambda: flow_doc("txt-en", "smoke_en.txt", "txt", contents=True) and flow_txt_search_and_note()),
        ("txt-fa", lambda: flow_doc("txt-fa", "smoke_fa.txt", "txt", expect_word=FA_WORD, contents=True)),
        ("txt-fa-encoding", flow_txt_encoding_override),
        ("docx", lambda: flow_doc("docx", "smoke.docx", "docx", contents=True)),
        ("pdf", flow_pdf),
        ("cbz", flow_cbz),
        ("corrupt", flow_corrupt),
    ):
        reset_crash_buffer(label)
        try:
            fn()
        except Exception as ex:
            import traceback
            traceback.print_exc()
            check("%s flow ran to the end (%r)" % (label, ex), False)
        # back to a known state
        for _ in range(3):
            if "MainActivity" in resumed():
                break
            back()
        adb("shell", "am", "start", "-n", MAIN)
        time.sleep(3)

    # library after all the opens: every readable file must be listed
    nodes, _ = screen("library_after", 1.5)
    info("library shows", " | ".join(labels(nodes))[:600])
    fails = [n for n, ok in CHECKS if not ok]
    log("SUMMARY: %d checks, %d failed" % (len(CHECKS), len(fails)))
    for f in fails:
        log("  FAILED: " + f)


try:
    main()
finally:
    with open("ui-report.txt", "w") as f:
        f.write("\n".join(REPORT))
    with open("logcat.txt", "w") as f:
        f.write(adb("logcat", "-d", "-t", "6000"))
    with open("crash.txt", "w") as f:
        f.write("\n\n".join(CRASH_LOG + [adb("logcat", "-d", "-b", "crash").strip()]).strip() or "(no crash recorded)")
