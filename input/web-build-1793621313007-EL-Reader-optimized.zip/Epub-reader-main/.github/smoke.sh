#!/bin/sh
P=com.novelreader.app.debug
fail() { echo "::error::$1"; tr '\n' '|' < "$2" | cut -c1-3500 | sed 's/^/::error::LOG /'; exit 1; }
adb install -r NovelReader-debug.apk > install.txt 2>&1 || fail "install failed" install.txt
cat install.txt
adb logcat -c
adb shell am start -W -n $P/com.novelreader.app.MainActivity > start.txt 2>&1
cat start.txt
sleep 15
adb logcat -d > logcat.txt
if grep -q "FATAL EXCEPTION" logcat.txt; then grep -A20 "FATAL EXCEPTION" logcat.txt | head -40 > f.txt; fail "crash on launch" f.txt; fi
adb shell pidof $P > pid.txt || { tail -60 logcat.txt > f.txt; fail "process not running" f.txt; }
echo SMOKE_OK
