package com.novelreader.app.formats

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FormatDetectorTest {

    private fun detect(name: String, bytes: ByteArray, mime: String? = null) =
        FormatDetector.detect(TestFiles.tempFile(name, bytes), name, mime)

    private fun found(f: BookFormat) = Detection.Found(f)

    private val page = TestFiles.png(4, 6, 10, 20, 30)

    @Test fun pdfByHeader() {
        assertEquals(found(BookFormat.PDF), detect("a.pdf", "%PDF-1.7\n%âãÏÓ\n1 0 obj".toByteArray(Charsets.ISO_8859_1)))
        // Content wins over a wrong extension.
        assertEquals(found(BookFormat.PDF), detect("book.epub", "%PDF-1.4 ...".toByteArray()))
        // Junk before the header is allowed within the first KB.
        assertEquals(found(BookFormat.PDF), detect("x.bin", ByteArray(200) { 0x20 } + "%PDF-1.5".toByteArray()))
    }

    @Test fun epubByContainer() {
        val z = TestFiles.zip(listOf("mimetype" to "application/epub+zip".toByteArray(), "META-INF/container.xml" to "<c/>".toByteArray()))
        assertEquals(found(BookFormat.EPUB), detect("a.epub", z))
        assertEquals(found(BookFormat.EPUB), detect("renamed.zip", z))
    }

    @Test fun epubWithOnlyMimetypeEntry() {
        val z = TestFiles.zip(listOf("mimetype" to "application/epub+zip".toByteArray(), "OEBPS/a.xhtml" to "<html/>".toByteArray()))
        assertEquals(found(BookFormat.EPUB), detect("a.epub", z))
    }

    @Test fun docxByDocumentXml() {
        val z = TestFiles.zip(listOf("[Content_Types].xml" to "<t/>".toByteArray(), "word/document.xml" to "<w/>".toByteArray()))
        assertEquals(found(BookFormat.DOCX), detect("a.docx", z))
        assertEquals(found(BookFormat.DOCX), detect("a.zip", z))
    }

    @Test fun otherOfficeFilesAreNotBooks() {
        val xlsx = TestFiles.zip(listOf("[Content_Types].xml" to "<t/>".toByteArray(), "xl/workbook.xml" to "<w/>".toByteArray()))
        assertEquals(Detection.Unknown, detect("a.xlsx", xlsx))
    }

    @Test fun cbzIsAZipOfImages() {
        val z = TestFiles.zip(listOf("1.png" to page, "2.png" to page))
        assertEquals(found(BookFormat.CBZ), detect("comic.cbz", z))
        // A ".cbr" that really is a ZIP opens as CBZ.
        assertEquals(found(BookFormat.CBZ), detect("comic.cbr", z))
    }

    @Test fun zipWithoutImagesIsUnknown() {
        val z = TestFiles.zip(listOf("readme.txt" to "hello".toByteArray()))
        assertEquals(Detection.Unknown, detect("a.cbz", z))
    }

    @Test fun macosJunkAloneIsNotAComic() {
        val z = TestFiles.zip(listOf("__MACOSX/._1.png" to page, ".hidden.jpg" to page))
        assertEquals(Detection.Unknown, detect("a.cbz", z))
    }

    @Test fun rarSignatureMeansCbr() {
        val rar4 = byteArrayOf(0x52, 0x61, 0x72, 0x21, 0x1A, 0x07, 0x00) + ByteArray(20)
        val rar5 = byteArrayOf(0x52, 0x61, 0x72, 0x21, 0x1A, 0x07, 0x01, 0x00) + ByteArray(20)
        assertEquals(found(BookFormat.CBR), detect("a.cbr", rar4))
        assertEquals(found(BookFormat.CBR), detect("a.cbz", rar5))   // a ".cbz" that really is RAR
    }

    @Test fun truncatedZipIsDamaged() {
        val z = TestFiles.zip(listOf("1.png" to page, "2.png" to page, "3.png" to page))
        val cut = z.copyOf(z.size / 2)
        assertEquals(Detection.Damaged(BookFormat.CBZ), detect("a.cbz", cut))
        assertEquals(Detection.Damaged(BookFormat.EPUB), detect("a.epub", cut))
    }

    @Test fun plainTextNeedsATextHint() {
        val text = "Hello world\nSecond line\n".toByteArray()
        assertEquals(found(BookFormat.TXT), detect("a.txt", text))
        assertEquals(found(BookFormat.TXT), detect("noext", text, mime = "text/plain"))
        assertEquals(Detection.Unknown, detect("a.dat", text))
    }

    @Test fun persianAndUtf16TextAreText() {
        assertEquals(found(BookFormat.TXT), detect("fa.txt", "سلام دنیا\nاین یک متن است".toByteArray(Charsets.UTF_8)))
        val utf16 = byteArrayOf(0xFF.toByte(), 0xFE.toByte()) + "Hello there, world".toByteArray(Charsets.UTF_16LE)
        assertEquals(found(BookFormat.TXT), detect("u16.txt", utf16))
        val noBom = "Hello there, this is utf-16 without a mark".toByteArray(Charsets.UTF_16LE)
        assertEquals(found(BookFormat.TXT), detect("u16b.txt", noBom))
        val cp1256 = "سلام دنیا".toByteArray(charset("windows-1256"))
        assertEquals(found(BookFormat.TXT), detect("old.txt", cp1256))
    }

    @Test fun binaryNamedTxtIsRejected() {
        val bin = ByteArray(2000) { (it * 31 % 251).toByte() }
        assertEquals(Detection.Unknown, detect("a.txt", bin))
    }

    @Test fun emptyAndOtherArchivesAreUnknown() {
        assertEquals(Detection.Unknown, detect("a.pdf", ByteArray(0)))
        assertEquals(Detection.Unknown, detect("a.7z", byteArrayOf(0x37, 0x7A, 0xBC.toByte(), 0xAF.toByte(), 0x27, 0x1C, 0, 4) + ByteArray(30)))
        assertEquals(Detection.Unknown, detect("a.gz", byteArrayOf(0x1F, 0x8B.toByte(), 8, 0, 0, 0, 0, 0, 0, 3)))
    }

    @Test fun extensionsAndMimeAreOnlyHints() {
        assertEquals(BookFormat.PDF, BookFormat.fromExtension("My Book.PDF"))
        assertEquals(BookFormat.CBR, BookFormat.fromExtension("x.cbr"))
        assertEquals(BookFormat.TXT, BookFormat.fromMime("text/plain"))
        assertTrue(BookFormat.allExtensions.containsAll(setOf("epub", "pdf", "txt", "docx", "cbz", "cbr")))
        assertEquals(BookFormat.EPUB, BookFormat.fromStored("garbage"))
    }
}
