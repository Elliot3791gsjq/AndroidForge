package com.novelreader.app.ui.formats

import androidx.compose.ui.geometry.Offset
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Regression tests for the "Cannot round NaN value" crash: a zoomed page dragged and released produced a NaN position. */
class ZoomStateTest {

    private fun state(): ZoomState = ZoomState(6f).apply {
        viewW = 1000f; viewH = 2000f; contentW = 1000f; contentH = 1400f
        reset(1f)
    }

    private fun ZoomState.assertFinite() {
        assertTrue("scale $scale", scale.isFinite())
        assertTrue("tx $tx", tx.isFinite())
        assertTrue("ty $ty", ty.isFinite())
    }

    @Test fun unspecifiedCentroidFromTheLiftingFingerKeepsStateFinite() {
        val z = state()
        z.transform(Offset(500f, 500f), Offset.Zero, 2.5f)
        z.assertFinite()
        val before = Triple(z.scale, z.tx, z.ty)
        // the event in which the last finger lifts: centroid is Unspecified, pan is zero
        val unused = z.transform(Offset.Unspecified, Offset.Zero, 1f)
        z.assertFinite()
        assertEquals(before.first, z.scale, 0f)
        assertEquals(before.second, z.tx, 0.001f)
        assertEquals(before.third, z.ty, 0.001f)
        assertEquals(0f, unused, 0.001f)
    }

    @Test fun unspecifiedCentroidWithPanStillMoves() {
        val z = state()
        z.transform(Offset(500f, 500f), Offset.Zero, 3f)
        val tx0 = z.tx
        z.transform(Offset.Unspecified, Offset(-40f, 0f), 1f)
        z.assertFinite()
        assertEquals(tx0 - 40f, z.tx, 0.001f)
    }

    @Test fun nonFiniteZoomAndPanAreIgnored() {
        val z = state()
        z.transform(Offset(500f, 500f), Offset.Zero, 2f)
        val before = Triple(z.scale, z.tx, z.ty)
        z.transform(Offset(500f, 500f), Offset(Float.NaN, Float.POSITIVE_INFINITY), Float.NaN)
        z.assertFinite()
        assertEquals(before.first, z.scale, 0f)
        assertEquals(before.second, z.tx, 0.001f)
        z.transform(Offset(500f, 500f), Offset.Zero, Float.POSITIVE_INFINITY)
        z.assertFinite()
        z.transform(Offset(500f, 500f), Offset.Zero, -3f)
        z.assertFinite()
        z.transform(Offset(500f, 500f), Offset.Zero, 0f)
        z.assertFinite()
    }

    @Test fun zoomKeepsThePointUnderTheCentroidFixed() {
        val z = state()
        val c = Offset(700f, 900f)
        // content point under the centroid before the zoom
        val cx = (c.x - z.tx) / z.scale
        val cy = (c.y - z.ty) / z.scale
        z.transform(c, Offset.Zero, 2f)
        assertEquals(2f, z.scale, 0.0001f)
        assertEquals(c.x, cx * z.scale + z.tx, 0.01f)
        // vertical: the content is centred while it fits, so only check it stays finite and inside the view
        z.assertFinite()
    }

    @Test fun scaleStaysWithinLimits() {
        val z = state()
        z.transform(Offset(500f, 500f), Offset.Zero, 100f)
        assertEquals(6f, z.scale, 0f)
        z.transform(Offset(500f, 500f), Offset.Zero, 0.0001f)
        assertEquals(1f, z.scale, 0f)
        z.assertFinite()
    }

    @Test fun panIsClampedToTheContentEdges() {
        val z = state()
        z.transform(Offset(0f, 0f), Offset.Zero, 2f)
        z.transform(Offset(500f, 500f), Offset(5000f, 5000f), 1f)
        assertTrue(z.tx <= 0f)
        assertTrue(z.tx >= z.viewW - z.contentW * z.scale - 0.001f)
        z.transform(Offset(500f, 500f), Offset(-9000f, -9000f), 1f)
        assertEquals(z.viewW - z.contentW * z.scale, z.tx, 0.001f)
        z.assertFinite()
    }

    @Test fun scrollToContentYIgnoresNonFiniteValues() {
        val z = state()
        z.transform(Offset(500f, 500f), Offset.Zero, 3f)
        val ty0 = z.ty
        z.scrollToContentY(Float.NaN)
        assertEquals(ty0, z.ty, 0f)
        z.scrollToContentY(Float.POSITIVE_INFINITY)
        assertEquals(ty0, z.ty, 0f)
        z.scrollToContentY(100f)
        z.assertFinite()
    }

    @Test fun stateWithoutAViewDoesNotProduceNaN() {
        val z = ZoomState(6f) // viewW = viewH = 0, never laid out
        z.transform(Offset.Unspecified, Offset(5f, 5f), 2f)
        z.assertFinite()
        z.reset(1f)
        z.assertFinite()
    }

    @Test fun placementWithNaNIsNotDrawable() {
        fun pl(left: Float = 0f, top: Float = 0f, ppp: Float = 1f, pw: Float = 612f, ph: Float = 792f) =
            PdfPlacement(page = 0, left = left, top = top, ppp = ppp, baseW = 600, pw = pw, ph = ph, rotation = 0)
        assertTrue(pl().isDrawable())
        assertFalse(pl(left = Float.NaN).isDrawable())
        assertFalse(pl(top = Float.POSITIVE_INFINITY).isDrawable())
        assertFalse(pl(ppp = Float.NaN).isDrawable())
        assertFalse(pl(ppp = 0f).isDrawable())
        assertFalse(pl(pw = 0f).isDrawable())
        assertFalse(pl(ph = Float.NaN).isDrawable())
        assertTrue(pl().isDrawable() && pl(left = -5000f, top = -9000f).isDrawable())
    }
}
