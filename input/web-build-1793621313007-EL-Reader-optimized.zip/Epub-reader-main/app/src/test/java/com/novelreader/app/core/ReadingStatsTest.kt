package com.novelreader.app.core

import java.time.DayOfWeek
import java.time.LocalDateTime
import java.time.ZoneId
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ReadingStatsTest {
    private val zone = ZoneId.of("UTC")
    private val min = 60_000L

    /** Thursday 22 Oct 2026, 12:00 UTC. The week (Sun-start) is 18..24 Oct. */
    private val now = at(2026, 10, 22, 12, 0)

    private fun at(y: Int, mo: Int, d: Int, h: Int, mi: Int): Long =
        LocalDateTime.of(y, mo, d, h, mi).atZone(zone).toInstant().toEpochMilli()

    private fun s(book: Long, start: Long, minutes: Long, from: Double = 0.0, to: Double = 0.0) =
        StatSession(book, start, minutes * min, from, to)

    private fun week(sessions: List<StatSession>, books: List<StatBook> = listOf(StatBook(1, 0), StatBook(2, 0))) =
        ReadingStats.compute(StatsPeriod.WEEK, sessions, books, now, zone, DayOfWeek.SUNDAY)

    @Test fun emptyDataIsAllZero() {
        val r = week(emptyList())
        assertEquals(0L, r.totalMillis)
        assertEquals(0, r.sittings)
        assertEquals(0, r.dayStreak)
        assertEquals(0, r.booksReadFrom)
        assertEquals(Trend.NONE, r.trend)
        assertNull(r.pacePercentPerHour)
        assertEquals(7, r.bars.size)
        assertTrue(r.bars.all { it.millis == 0L })
    }

    @Test fun weekTotalsAndBars() {
        val r = week(listOf(
            s(1, at(2026, 10, 19, 9, 0), 30),     // Monday
            s(2, at(2026, 10, 22, 20, 0), 15),    // Thursday (today)
            s(1, at(2026, 10, 12, 9, 0), 20),     // previous week
        ))
        assertEquals(45 * min, r.totalMillis)
        assertEquals(2, r.sittings)
        assertEquals(2, r.booksReadFrom)
        assertEquals(20 * min, r.previousMillis)
        assertEquals(Trend.MORE, r.trend)
        assertEquals(BarUnit.DAY, r.barUnit)
        assertEquals(30 * min, r.bars[1].millis)   // Mon
        assertEquals(15 * min, r.bars[4].millis)   // Thu
        assertTrue(r.bars[4].isCurrent)
        assertEquals(45 * min, r.bars.sumOf { it.millis })
    }

    @Test fun weekStartsOnTheChosenDay() {
        val sat = ReadingStats.compute(StatsPeriod.WEEK, emptyList(), emptyList(), now, zone, DayOfWeek.SATURDAY)
        assertEquals(at(2026, 10, 17, 0, 0), sat.rangeStart)   // Saturday 17 Oct
        val sun = week(emptyList())
        assertEquals(at(2026, 10, 18, 0, 0), sun.rangeStart)
    }

    @Test fun sittingAcrossMidnightIsSplitBetweenDays() {
        val r = week(listOf(s(1, at(2026, 10, 21, 23, 50), 20)))
        assertEquals(10 * min, r.bars[3].millis)   // Wed 21
        assertEquals(10 * min, r.bars[4].millis)   // Thu 22
        assertEquals(20 * min, r.totalMillis)
        assertEquals(2, r.dayStreak)
    }

    @Test fun sittingStraddlingTheStartOfTheWeekIsClipped() {
        // Saturday 17th 23:30 -> Sunday 18th 00:30: only the Sunday half is "this week".
        val r = week(listOf(s(1, at(2026, 10, 17, 23, 30), 60)))
        assertEquals(30 * min, r.totalMillis)
        assertEquals(30 * min, r.previousMillis)
        assertEquals(Trend.SAME, r.trend)
    }

    @Test fun trendLess() {
        val r = week(listOf(s(1, at(2026, 10, 19, 9, 0), 10), s(1, at(2026, 10, 13, 9, 0), 40)))
        assertEquals(Trend.LESS, r.trend)
    }

    @Test fun streakCountsConsecutiveDaysEndingTodayOrYesterday() {
        val endingToday = week(listOf(
            s(1, at(2026, 10, 20, 9, 0), 5), s(1, at(2026, 10, 21, 9, 0), 5), s(1, at(2026, 10, 22, 9, 0), 5),
        ))
        assertEquals(3, endingToday.dayStreak)
        val endingYesterday = week(listOf(s(1, at(2026, 10, 20, 9, 0), 5), s(1, at(2026, 10, 21, 9, 0), 5)))
        assertEquals(2, endingYesterday.dayStreak)
        val broken = week(listOf(s(1, at(2026, 10, 19, 9, 0), 5), s(1, at(2026, 10, 22, 9, 0), 5)))
        assertEquals(1, broken.dayStreak)
        val stale = week(listOf(s(1, at(2026, 10, 19, 9, 0), 5)))
        assertEquals(0, stale.dayStreak)
    }

    @Test fun streakNeverReachesBeforeThePeriod() {
        // Reading every day for a fortnight: the weekly tile is capped by the week, "all time" is not.
        val days = (9..22).map { s(1, at(2026, 10, it, 9, 0), 5) }
        assertEquals(5, week(days).dayStreak)   // Sun 18 .. Thu 22
        val all = ReadingStats.compute(StatsPeriod.ALL, days, listOf(StatBook(1, 0)), now, zone, DayOfWeek.SUNDAY)
        assertEquals(14, all.dayStreak)
    }

    @Test fun paceIsProgressPerHour() {
        val r = week(listOf(s(1, at(2026, 10, 20, 9, 0), 60, 0.10, 0.30)))
        assertEquals(20.0, r.pacePercentPerHour!!, 1e-9)
    }

    @Test fun paceIgnoresBackwardsMovesAndNeedsEnoughData() {
        val back = week(listOf(s(1, at(2026, 10, 20, 9, 0), 60, 0.50, 0.40)))
        assertEquals(0.0, back.pacePercentPerHour!!, 1e-9)
        val tiny = week(listOf(StatSession(1, at(2026, 10, 20, 9, 0), 30_000, 0.0, 0.01)))
        assertNull(tiny.pacePercentPerHour)
    }

    @Test fun paceIgnoresJumpsButKeepsRealReading() {
        // 60 min of real reading (+20 %) and a 2-minute sitting that jumped 66 % through the contents list.
        val real = s(1, at(2026, 10, 20, 9, 0), 60, 0.10, 0.30)
        val jump = StatSession(2, at(2026, 10, 21, 9, 0), 120_000, 0.0, 0.66)
        val r = week(listOf(real, jump))
        assertEquals(20.0, r.pacePercentPerHour!!, 1e-9)
        // The jump still counts as reading time and as a sitting.
        assertEquals(62 * 60_000L, r.totalMillis)
        assertEquals(2, r.sittings)
        // Only jumps in the period: no meaningful pace at all.
        assertNull(week(listOf(jump)).pacePercentPerHour)
    }

    @Test fun finishedBooksCountOnlyTheFinishingSittingInThePeriod() {
        val finishedNow = s(1, at(2026, 10, 21, 9, 0), 30, 0.90, 0.99)
        val finishedBefore = s(2, at(2026, 10, 5, 9, 0), 30, 0.90, 1.0)
        val rereadAtEnd = s(2, at(2026, 10, 21, 9, 0), 5, 0.99, 1.0)
        val neverStartedBelow = s(3, at(2026, 10, 21, 9, 0), 5, 0.99, 1.0)
        val r = week(listOf(finishedNow, finishedBefore, rereadAtEnd, neverStartedBelow), listOf(StatBook(1, 0), StatBook(2, 0), StatBook(3, 0)))
        assertEquals(1, r.booksFinished)
        val m = ReadingStats.compute(StatsPeriod.MONTH, listOf(finishedNow, finishedBefore, rereadAtEnd), emptyList(), now, zone, DayOfWeek.SUNDAY)
        assertEquals(2, m.booksFinished)   // both finishing sittings are in October
    }

    @Test fun monthHasOneBarPerDay() {
        val r = ReadingStats.compute(StatsPeriod.MONTH, listOf(s(1, at(2026, 10, 31, 22, 0), 30)), emptyList(), now, zone, DayOfWeek.SUNDAY)
        assertEquals(31, r.bars.size)
        assertEquals(30 * min, r.bars[30].millis)
        assertEquals(BarUnit.DAY, r.barUnit)
    }

    @Test fun yearHasTwelveMonthBars() {
        val r = ReadingStats.compute(
            StatsPeriod.YEAR,
            listOf(s(1, at(2026, 1, 15, 9, 0), 60), s(1, at(2026, 10, 2, 9, 0), 30), s(1, at(2025, 12, 31, 23, 0), 30)),
            emptyList(), now, zone, DayOfWeek.SUNDAY,
        )
        assertEquals(12, r.bars.size)
        assertEquals(BarUnit.MONTH, r.barUnit)
        assertEquals(60 * min, r.bars[0].millis)
        assertEquals(30 * min, r.bars[9].millis)
        assertEquals(90 * min, r.totalMillis)
        assertEquals(30 * min, r.previousMillis)
        assertTrue(r.bars[9].isCurrent)
    }

    @Test fun allTimeAddsReadingFromBeforeSittingsWereRecorded() {
        val r = ReadingStats.compute(
            StatsPeriod.ALL,
            listOf(s(1, at(2026, 10, 20, 9, 0), 30)),
            listOf(StatBook(1, 90 * min), StatBook(2, 60 * min)),
            now, zone, DayOfWeek.SUNDAY,
        )
        assertEquals(150 * min, r.totalMillis)            // 90 (book 1, 30 of it dated) + 60 (book 2, undated)
        assertEquals(1, r.sittings)
        assertEquals(2, r.booksReadFrom)
        assertNull(r.previousMillis)
        assertEquals(Trend.NONE, r.trend)
        assertEquals(90 * min, r.byBook.first { it.bookId == 1L }.millis)
        assertEquals(1, r.byBook.first { it.bookId == 1L }.sittings)
        assertEquals(0, r.byBook.first { it.bookId == 2L }.sittings)
        assertTrue(r.bars.size in 6..12)
    }

    @Test fun byBookIsSortedAndListsUnreadBooksToo() {
        val r = week(
            listOf(s(2, at(2026, 10, 20, 9, 0), 40), s(1, at(2026, 10, 21, 9, 0), 10), s(2, at(2026, 10, 22, 9, 0), 5)),
            listOf(StatBook(1, 0), StatBook(2, 0), StatBook(3, 0)),
        )
        assertEquals(listOf(2L, 1L, 3L), r.byBook.map { it.bookId })
        assertEquals(45 * min, r.byBook[0].millis)
        assertEquals(2, r.byBook[0].sittings)
        assertEquals(0L, r.byBook[2].millis)
        assertNotNull(r.byBook[2])
    }
}
