package com.novelreader.app.ui.design

import com.novelreader.app.core.ColorMath
import com.novelreader.app.data.CustomTheme
import com.novelreader.app.data.LegacyThemes
import com.novelreader.app.data.ReaderSettings
import com.novelreader.app.data.ReadingThemes
import com.novelreader.app.data.ThemeColors
import com.novelreader.app.data.ThemeMode
import com.novelreader.app.data.UiMode
import com.novelreader.app.data.effectiveBackground
import com.novelreader.app.data.effectiveText
import java.util.Random
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

private fun cr(a: Int, b: Int) = ColorMath.contrastRatio(a, b)

/** Every colour a screen can draw text or icons with must stay readable on every surface they sit on. */
private fun assertLegible(p: ArgbPalette, label: String, strict: Boolean) {
    val surfaces = listOf(p.bg, p.surface, p.surfaceHigh, p.surfaceHighest)
    val page = cr(p.text, p.bg)
    if (strict) {
        assertTrue("$label text/bg $page", page >= 7.0)
    } else {
        // Mid-tone pages cannot reach 7:1 (physical maximum ~4.6:1): they must still get the best available.
        assertTrue("$label text/bg $page", page >= minOf(7.0, ColorMath.maxAchievableContrast(p.bg)) - 0.01)
    }
    val floor = if (strict) 4.5 else 4.3
    surfaces.forEach { s ->
        assertTrue("$label text/${Integer.toHexString(s)} ${cr(p.text, s)}", cr(p.text, s) >= floor)
        assertTrue("$label muted/${Integer.toHexString(s)} ${cr(p.textMuted, s)}", cr(p.textMuted, s) >= floor)
        assertTrue("$label accentText/${Integer.toHexString(s)} ${cr(p.accentText, s)}", cr(p.accentText, s) >= floor)
    }
    assertTrue("$label muted/bg", cr(p.textMuted, p.bg) >= 4.5)
    assertTrue("$label accentText/bg", cr(p.accentText, p.bg) >= 4.5)
    assertTrue("$label accent fill/bg ${cr(p.accent, p.bg)}", cr(p.accent, p.bg) >= 3.0)
    assertTrue("$label onAccent/accent ${cr(p.onAccent, p.accent)}", cr(p.onAccent, p.accent) >= 4.5)
    assertTrue("$label onAccentSoft/accentSoft", cr(p.onAccentSoft, p.accentSoft) >= 4.5)
    assertTrue("$label danger/surfaceHigh", cr(p.danger, p.surfaceHigh) >= 4.5)
}

class PaletteFactoryTest {

    @Test fun everyPresetIsStrictlyLegibleInBothModes() {
        assertEquals(8, Presets.all.size)
        Presets.all.forEach { spec ->
            assertLegible(PaletteFactory.build(spec, dark = true), "${spec.id}-dark", strict = true)
            assertLegible(PaletteFactory.build(spec, dark = false), "${spec.id}-light", strict = true)
        }
    }

    @Test fun darkPresetsAreDarkAndLightPresetsAreLight() {
        Presets.all.forEach { spec ->
            assertTrue(spec.id, ColorMath.isDark(PaletteFactory.build(spec, true).bg))
            assertFalse(spec.id, ColorMath.isDark(PaletteFactory.build(spec, false).bg))
        }
    }

    @Test fun defaultThemeIsEmberOnDeepBlackWithOrangeAccent() {
        val p = PaletteFactory.resolve(ReaderSettings(), systemDark = false)
        assertTrue(p.dark)
        assertEquals(0xFF0B0908.toInt(), p.bg)
        assertEquals(0xFFFF5A1F.toInt(), p.accent)
    }

    @Test fun randomCustomColoursAreAlwaysLegible() {
        val rnd = Random(20261024)
        val specials = intArrayOf(
            0xFF000000.toInt(), 0xFFFFFFFF.toInt(), 0xFF777777.toInt(), 0xFF808080.toInt(), 0xFF767676.toInt(),
            0xFFFF0000.toInt(), 0xFF00FF00.toInt(), 0xFF0000FF.toInt(), 0xFF7F7F7F.toInt(), 0xFF757575.toInt(),
        )
        fun color() = rnd.nextInt() or (0xFF shl 24)
        repeat(6000) { i ->
            val bg = if (i % 10 == 0) specials[rnd.nextInt(specials.size)] else color()
            val accent = if (i % 7 == 0) specials[rnd.nextInt(specials.size)] else color()
            val text = if (rnd.nextBoolean()) color() else null
            val surface = if (rnd.nextBoolean()) color() else null
            val p = PaletteFactory.build(accent, bg, text, surface, dark = rnd.nextBoolean())
            assertLegible(p, "random#$i bg=${Integer.toHexString(bg)} accent=${Integer.toHexString(accent)}", strict = false)
        }
    }

    @Test fun worstCaseBackgroundsStillGetTheStrongestText() {
        // Black text on a mid-grey page and white text on it both reach ~4.6:1; the builder must reach that.
        listOf(0xFF777777.toInt(), 0xFF767676.toInt(), 0xFF7F7F7F.toInt()).forEach { bg ->
            val p = PaletteFactory.build(0xFFFF5A1F.toInt(), bg, null, null, dark = true)
            assertTrue(cr(p.text, p.bg) >= 4.5)
        }
    }

    @Test fun userSurfaceThatWouldHideTheTextIsPulledBack() {
        // Light surface + light text on a dark page: the surface must not swallow the text.
        val p = PaletteFactory.build(
            accent = 0xFFFF5A1F.toInt(), bg = 0xFF000000.toInt(), text = 0xFFFFFFFF.toInt(),
            surface = 0xFFFFFFFF.toInt(), dark = true,
        )
        assertTrue(cr(p.text, p.surface) >= 4.5)
        assertTrue(cr(p.text, p.surfaceHighest) >= 4.5)
    }

    @Test fun faintUserTextIsStrengthenedInsteadOfRejected() {
        val p = PaletteFactory.build(0xFFFF5A1F.toInt(), 0xFF101010.toInt(), 0xFF181818.toInt(), null, dark = true)
        assertTrue(cr(p.text, p.bg) >= 7.0)
    }

    @Test fun alreadyReadableColoursAreKeptAsChosen() {
        val p = PaletteFactory.build(0xFF4DA3FF.toInt(), 0xFF070B14.toInt(), 0xFFEAF1FF.toInt(), null, dark = true)
        assertEquals(0xFFEAF1FF.toInt(), p.text)
        assertEquals(0xFF070B14.toInt(), p.bg)
    }

    @Test fun surfaceLadderGetsLighterInDarkAndDarkerInLightMode() {
        val dark = PaletteFactory.build(Presets.byId(Presets.EMBER), true)
        assertTrue(ColorMath.luminance(dark.surface) > ColorMath.luminance(dark.bg))
        assertTrue(ColorMath.luminance(dark.surfaceHighest) >= ColorMath.luminance(dark.surface))
        val light = PaletteFactory.build(Presets.byId(Presets.EMBER), false)
        assertTrue(ColorMath.luminance(light.surface) <= ColorMath.luminance(light.bg))
        assertTrue(ColorMath.luminance(light.surfaceHighest) <= ColorMath.luminance(light.surface))
    }

    @Test fun uiModeResolvesAgainstTheSystem() {
        assertTrue(PaletteFactory.isDark(UiMode.DARK, systemDark = false))
        assertFalse(PaletteFactory.isDark(UiMode.LIGHT, systemDark = true))
        assertTrue(PaletteFactory.isDark(UiMode.SYSTEM, systemDark = true))
        assertFalse(PaletteFactory.isDark(UiMode.SYSTEM, systemDark = false))
    }

    @Test fun customThemeIsUsedWhenSelectedAndUnknownIdFallsBackToEmber() {
        val custom = CustomTheme(
            id = "c_test", name = "Mine", accent = 0xFF22CC88.toInt(),
            darkBg = 0xFF081410.toInt(), lightBg = 0xFFF2FBF6.toInt(),
        )
        val s = ReaderSettings(uiMode = UiMode.DARK, colorThemeId = "c_test", customThemes = listOf(custom))
        assertEquals(0xFF081410.toInt(), PaletteFactory.resolve(s, false).bg)
        assertEquals(0xFFF2FBF6.toInt(), PaletteFactory.resolve(s.copy(uiMode = UiMode.LIGHT), true).bg)
        val missing = s.copy(colorThemeId = "c_gone", customThemes = emptyList())
        assertEquals(PaletteFactory.build(Presets.byId(Presets.EMBER), true), PaletteFactory.resolve(missing, false))
    }

    @Test fun appThemeNeverDependsOnReadingPageColours() {
        val base = ReaderSettings(uiMode = UiMode.DARK, colorThemeId = Presets.OCEAN)
        val withPage = base.copy(backgroundColor = 0xFFFFFFFF.toInt(), textColor = 0xFF000000.toInt(), theme = ThemeMode.LIGHT)
        assertEquals(PaletteFactory.resolve(base, true), PaletteFactory.resolve(withPage, true))
    }

    @Test fun readingPageNeverDependsOnTheAppTheme() {
        val a = ReaderSettings(uiMode = UiMode.DARK, colorThemeId = Presets.EMBER, backgroundColor = 0xFFFAF1DC.toInt(), textColor = 0xFF2B2B2B.toInt())
        val b = a.copy(uiMode = UiMode.LIGHT, colorThemeId = Presets.VIOLET)
        assertEquals(a.effectiveBackground(), b.effectiveBackground())
        assertEquals(a.effectiveText(), b.effectiveText())
        assertEquals(0xFFFAF1DC.toInt(), b.effectiveBackground())
    }

    @Test fun readingPageDefaultsFollowBaseBrightness() {
        val dark = ReaderSettings(theme = ThemeMode.DARK)
        assertEquals(ThemeColors.DARK_BG, dark.effectiveBackground())
        assertEquals(ThemeColors.DARK_TEXT, dark.effectiveText())
        val light = ReaderSettings(theme = ThemeMode.LIGHT)
        assertEquals(ThemeColors.LIGHT_BG, light.effectiveBackground())
        assertEquals(ThemeColors.LIGHT_TEXT, light.effectiveText())
        // A dark custom page colour without an explicit text colour still gets light text.
        val customDarkPage = ReaderSettings(theme = ThemeMode.LIGHT, backgroundColor = 0xFF101820.toInt())
        assertEquals(ThemeColors.DARK_TEXT, customDarkPage.effectiveText())
    }

    @Test fun readingThemesAreLegibleAndDistinct() {
        assertEquals(7, ReadingThemes.all.size)
        assertEquals(ReadingThemes.all.size, ReadingThemes.all.map { it.id }.toSet().size)
        ReadingThemes.all.forEach { assertTrue(it.id, cr(it.text, it.background) >= 7.0) }
        assertTrue(ReadingThemes.all.any { it.isDark })
        assertTrue(ReadingThemes.all.any { !it.isDark })
    }
}

class CustomThemeJsonTest {
    @Test fun roundTripKeepsEverything() {
        val list = listOf(
            CustomTheme("c_a", "Sunrise", 0xFFFF8800.toInt(), 0xFF101010.toInt(), 0xFF202020.toInt(), 0xFFEEEEEE.toInt(), 0xFFFFFFF0.toInt(), null, null),
            CustomTheme("c_b", "ناب", 0xFF2244AA.toInt(), 0xFF000011.toInt(), null, null, 0xFFEEF2FF.toInt(), 0xFFE0E6FF.toInt(), 0xFF111133.toInt()),
        )
        assertEquals(list, CustomTheme.listFromJson(CustomTheme.listToJson(list)))
    }

    @Test fun brokenJsonGivesEmptyListNotACrash() {
        assertTrue(CustomTheme.listFromJson(null).isEmpty())
        assertTrue(CustomTheme.listFromJson("").isEmpty())
        assertTrue(CustomTheme.listFromJson("{not json").isEmpty())
    }

    @Test fun oneBadEntryDoesNotDropTheOthers() {
        val good = CustomTheme("c_ok", "Ok", 1, 2, null, null, 3, null, null)
        val json = "[{\"id\":\"x\"}," + CustomTheme.listToJson(listOf(good)).removePrefix("[").removeSuffix("]") + "]"
        assertEquals(listOf(good), CustomTheme.listFromJson(json))
    }

    @Test fun newIdsCarryThePrefix() {
        assertTrue(CustomTheme.newId().startsWith(CustomTheme.ID_PREFIX))
    }
}

class ColorMathContrastTest {
    @Test fun mixEndpointsAndMiddle() {
        assertEquals(0xFF000000.toInt(), ColorMath.mix(0xFF000000.toInt(), 0xFFFFFFFF.toInt(), 0f))
        assertEquals(0xFFFFFFFF.toInt(), ColorMath.mix(0xFF000000.toInt(), 0xFFFFFFFF.toInt(), 1f))
        assertEquals(0xFF808080.toInt(), ColorMath.mix(0xFF000000.toInt(), 0xFFFFFFFF.toInt(), 0.5f))
        assertEquals(0xFFFFFFFF.toInt(), ColorMath.mix(0xFF000000.toInt(), 0xFFFFFFFF.toInt(), 7f))
    }

    @Test fun ensureContrastKeepsGoodColoursAndFixesBadOnes() {
        val bg = 0xFF101010.toInt()
        assertEquals(0xFFEEEEEE.toInt(), ColorMath.ensureContrast(0xFFEEEEEE.toInt(), bg, 7.0))
        val fixed = ColorMath.ensureContrast(0xFF202020.toInt(), bg, 7.0)
        assertTrue(cr(fixed, bg) >= 7.0)
        val onLight = ColorMath.ensureContrast(0xFFF0F0F0.toInt(), 0xFFFFFFFF.toInt(), 7.0)
        assertTrue(cr(onLight, 0xFFFFFFFF.toInt()) >= 7.0)
    }

    @Test fun ensureContrastKeepsTheHueWhereItCan() {
        val orange = 0xFFFF5A1F.toInt()
        val onDark = ColorMath.ensureContrast(orange, 0xFF0B0908.toInt(), 3.0)
        assertEquals(orange, onDark)
        val pale = ColorMath.ensureContrast(0xFFFFD9C8.toInt(), 0xFFFBF6F2.toInt(), 4.5)
        val r = (pale shr 16) and 0xFF
        val b = pale and 0xFF
        assertTrue("warm tint kept: r=$r b=$b", r > b)
    }

    @Test fun maxAchievableContrastMatchesKnownPoints() {
        assertEquals(21.0, ColorMath.maxAchievableContrast(0xFF000000.toInt()), 0.01)
        assertEquals(21.0, ColorMath.maxAchievableContrast(0xFFFFFFFF.toInt()), 0.01)
        assertTrue(ColorMath.maxAchievableContrast(0xFF777777.toInt()) in 4.5..4.7)
    }

    @Test fun ensureOnAllReachesEveryBackground() {
        val bgs = intArrayOf(0xFF101010.toInt(), 0xFF303030.toInt(), 0xFF404040.toInt())
        val c = ColorMath.ensureContrastOnAll(0xFF505050.toInt(), 0xFFFFFFFF.toInt(), 4.5, *bgs)
        bgs.forEach { assertTrue(cr(c, it) >= 4.5) }
        // Impossible request: falls back to the target colour itself.
        assertEquals(
            0xFFFFFFFF.toInt(),
            ColorMath.ensureContrastOnAll(0xFF777777.toInt(), 0xFFFFFFFF.toInt(), 20.0, 0xFF777777.toInt()),
        )
    }

    @Test fun isDarkSplitsAtTheLuminanceMidpoint() {
        assertTrue(ColorMath.isDark(0xFF0B0908.toInt()))
        assertTrue(ColorMath.isDark(0xFF26303A.toInt()))
        assertFalse(ColorMath.isDark(0xFFF1E4C8.toInt()))
        assertFalse(ColorMath.isDark(0xFFFFFFFF.toInt()))
    }
}

class LegacyThemeMigrationTest {
    @Test fun oldIdsMapToTheNewPresets() {
        assertEquals(Presets.EMBER, LegacyThemes.newId(null))
        assertEquals(Presets.EMBER, LegacyThemes.newId("classic"))
        assertEquals(Presets.PAPER, LegacyThemes.newId("sepia"))
        assertEquals(Presets.CRIMSON, LegacyThemes.newId("rose"))
        assertEquals(Presets.MINIMAL, LegacyThemes.newId("mono"))
        assertEquals(Presets.OCEAN, LegacyThemes.newId("ocean"))
        assertEquals(Presets.FOREST, LegacyThemes.newId("forest"))
        assertEquals(Presets.VIOLET, LegacyThemes.newId("violet"))
        assertEquals("c_123", LegacyThemes.newId("c_123"))
    }

    @Test fun everyMigratedIdIsARealPreset() {
        listOf(null, "classic", "sepia", "ocean", "forest", "rose", "violet", "mono").forEach {
            assertTrue(it.toString(), Presets.isPreset(LegacyThemes.newId(it)))
        }
    }

    @Test fun oldPagePaletteIsKeptAsExplicitReadingColours() {
        assertNull(LegacyThemes.page("classic", true))
        assertNull(LegacyThemes.page(null, false))
        val dark = LegacyThemes.page("sepia", true)
        assertNotNull(dark)
        assertEquals(0xFF2B2118.toInt(), dark!!.first)
        val light = LegacyThemes.page("sepia", false)
        assertNotEquals(dark, light)
        assertEquals(0xFFF4ECD8.toInt(), light!!.first)
    }

    @Test fun migratedPagesAreReadable() {
        listOf("sepia", "ocean", "forest", "rose", "violet", "mono").forEach { id ->
            listOf(true, false).forEach { dark ->
                val (bg, text) = LegacyThemes.page(id, dark)!!
                assertTrue("$id dark=$dark", cr(text, bg) >= 7.0)
            }
        }
    }
}
