package com.novelreader.app.formats

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class FormatLocatorTest {
    @Test fun roundTrips() {
        assertEquals(FormatLocator.Pdf(12, 0.25, 90), FormatLocator.parse(FormatLocator.Pdf(12, 0.25, 90).toJson()))
        assertEquals(FormatLocator.Comic(7), FormatLocator.parse(FormatLocator.Comic(7).toJson()))
        assertEquals(FormatLocator.Doc(300, 0.5), FormatLocator.parse(FormatLocator.Doc(300, 0.5).toJson()))
    }

    @Test fun garbageIsIgnored() {
        assertNull(FormatLocator.parse(null))
        assertNull(FormatLocator.parse(""))
        assertNull(FormatLocator.parse("not json"))
        assertNull(FormatLocator.parse("{\"f\":\"unknown\"}"))
        assertNull(FormatLocator.parse("{\"f\":\"comic\"}"))
        // A Readium locator (EPUB) is not a format locator.
        assertNull(FormatLocator.parse("{\"href\":\"ch1.xhtml\",\"type\":\"text/html\"}"))
    }

    @Test fun valuesAreClamped() {
        assertEquals(FormatLocator.Comic(0), FormatLocator.parse("{\"f\":\"comic\",\"p\":-4}"))
        assertEquals(FormatLocator.Doc(3, 1.0), FormatLocator.parse("{\"f\":\"doc\",\"b\":3,\"y\":7.5}"))
        assertEquals(270, FormatLocator.normalizeRotation(-90))
        assertEquals(0, FormatLocator.normalizeRotation(360))
    }

    @Test fun highlightRanges() {
        val r = PdfHighlightRects(3, listOf(floatArrayOf(1f, 2f, 3f, 4f), floatArrayOf(5f, 6f, 7f, 8f)))
        val back = PdfHighlightRects.parse(r.toJson())!!
        assertEquals(3, back.page)
        assertEquals(2, back.rects.size)
        assertEquals(7f, back.rects[1][2], 0f)
        assertEquals(DocRange(4, 10, 25), DocRange.parse(DocRange(4, 10, 25).toJson()))
        assertNull(DocRange.parse("{\"f\":\"doc\"}"))
    }
}
