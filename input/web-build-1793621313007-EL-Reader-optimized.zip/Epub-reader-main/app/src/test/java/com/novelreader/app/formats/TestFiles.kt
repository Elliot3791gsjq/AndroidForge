package com.novelreader.app.formats

import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Builds small real files (ZIP containers, PNG pages...) for the format tests. */
object TestFiles {

    fun tempFile(name: String, bytes: ByteArray): File {
        val dir = java.nio.file.Files.createTempDirectory("elreader-test").toFile()
        dir.deleteOnExit()
        return File(dir, name).also { it.writeBytes(bytes); it.deleteOnExit() }
    }

    fun zip(entries: List<Pair<String, ByteArray>>): ByteArray {
        val bos = ByteArrayOutputStream()
        ZipOutputStream(bos).use { z ->
            for ((name, data) in entries) {
                z.putNextEntry(ZipEntry(name)); z.write(data); z.closeEntry()
            }
        }
        return bos.toByteArray()
    }

    /** A valid minimal PNG (solid colour), so the "pages" are real images. */
    fun png(w: Int, h: Int, r: Int, g: Int, b: Int): ByteArray {
        val raw = ByteArrayOutputStream()
        repeat(h) { raw.write(0); repeat(w) { raw.write(r); raw.write(g); raw.write(b) } }
        val deflated = java.util.zip.Deflater().let { d ->
            d.setInput(raw.toByteArray()); d.finish()
            val out = ByteArrayOutputStream(); val buf = ByteArray(1024)
            while (!d.finished()) { out.write(buf, 0, d.deflate(buf)) }
            d.end(); out.toByteArray()
        }
        val bos = ByteArrayOutputStream()
        bos.write(byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A))
        fun chunk(type: String, data: ByteArray) {
            val len = java.nio.ByteBuffer.allocate(4).putInt(data.size).array()
            bos.write(len)
            val td = type.toByteArray(Charsets.US_ASCII) + data
            bos.write(td)
            val crc = java.util.zip.CRC32().also { it.update(td) }.value
            bos.write(java.nio.ByteBuffer.allocate(4).putInt(crc.toInt()).array())
        }
        chunk("IHDR", java.nio.ByteBuffer.allocate(13).putInt(w).putInt(h).put(8).put(2).put(0).put(0).put(0).array())
        chunk("IDAT", deflated)
        chunk("IEND", ByteArray(0))
        return bos.toByteArray()
    }

    fun resource(path: String): ByteArray =
        (TestFiles::class.java.getResourceAsStream(path) ?: error("missing test resource $path")).use { it.readBytes() }
}

/** What a tiny solid-colour PNG (as built by [TestFiles.png] / make_test_rar.py) shows: size and its first pixel. */
data class PngInfo(val width: Int, val height: Int, val r: Int, val g: Int, val b: Int)

fun readPngInfo(bytes: ByteArray): PngInfo {
    val bb = java.nio.ByteBuffer.wrap(bytes)
    require(bytes.size > 33 && bytes[1] == 'P'.code.toByte()) { "not a PNG" }
    val w = bb.getInt(16)
    val h = bb.getInt(20)
    // Single IDAT chunk follows the 25-byte signature+IHDR block: length(4) "IDAT"(4) data.
    val len = bb.getInt(33)
    val idat = bytes.copyOfRange(41, 41 + len)
    val inf = java.util.zip.Inflater()
    inf.setInput(idat)
    val row = ByteArray(4)
    inf.inflate(row)
    inf.end()
    return PngInfo(w, h, row[1].toInt() and 0xFF, row[2].toInt() and 0xFF, row[3].toInt() and 0xFF)
}
