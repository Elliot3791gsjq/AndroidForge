package com.novelreader.app.formats

import com.novelreader.app.formats.pdf.PdfFit
import com.novelreader.app.formats.pdf.PdfGeometry
import com.novelreader.app.formats.pdf.PdfSize
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class PdfGeometryTest {
    private val eps = 0.001f

    @Test fun rotationNormalises() {
        assertEquals(0, PdfGeometry.normalizeRotation(0))
        assertEquals(270, PdfGeometry.normalizeRotation(-90))
        assertEquals(90, PdfGeometry.normalizeRotation(450))
        assertEquals(0, PdfGeometry.normalizeRotation(44))
    }

    @Test fun displaySizeSwapsForSideways() {
        assertEquals(PdfSize(600f, 800f), PdfGeometry.displaySize(600f, 800f, 0))
        assertEquals(PdfSize(800f, 600f), PdfGeometry.displaySize(600f, 800f, 90))
        assertEquals(PdfSize(600f, 800f), PdfGeometry.displaySize(600f, 800f, 180))
        assertEquals(PdfSize(800f, 600f), PdfGeometry.displaySize(600f, 800f, 270))
    }

    @Test fun pointRotationRoundTrips() {
        val w = 600f; val h = 800f
        for (rot in listOf(0, 90, 180, 270)) {
            val d = PdfGeometry.toDisplay(120f, 340f, w, h, rot)
            val back = PdfGeometry.toPage(d[0], d[1], w, h, rot)
            assertArrayEquals("rot $rot", floatArrayOf(120f, 340f), back, eps)
        }
    }

    @Test fun cornersLandOnTheRightCorners() {
        // Page 600 x 800; top-left corner (0,0) after turning 90 degrees clockwise is the TOP-RIGHT of the 800 x 600 view.
        assertArrayEquals(floatArrayOf(800f, 0f), PdfGeometry.toDisplay(0f, 0f, 600f, 800f, 90), eps)
        assertArrayEquals(floatArrayOf(600f, 800f), PdfGeometry.toDisplay(0f, 0f, 600f, 800f, 180), eps)
        assertArrayEquals(floatArrayOf(0f, 600f), PdfGeometry.toDisplay(0f, 0f, 600f, 800f, 270), eps)
    }

    @Test fun rectsStayNormalised() {
        val r = PdfGeometry.rectToDisplay(10f, 20f, 110f, 40f, 600f, 800f, 90)
        assertArrayEquals(floatArrayOf(760f, 10f, 780f, 110f), r, eps)
    }

    @Test fun renderMatrixMapsPagePointsToPixels() {
        // matrix applied to a page point must equal scale * display point - origin
        val w = 600f; val h = 800f
        for (rot in listOf(0, 90, 180, 270)) {
            val m = PdfGeometry.renderMatrix(rot, w, h, 2f, 30f, 50f)
            val px = 111f; val py = 222f
            val x = m[0] * px + m[1] * py + m[2]
            val y = m[3] * px + m[4] * py + m[5]
            val d = PdfGeometry.toDisplay(px, py, w, h, rot)
            assertEquals("x rot $rot", d[0] * 2f - 30f, x, eps)
            assertEquals("y rot $rot", d[1] * 2f - 50f, y, eps)
            assertEquals(1f, m[8], 0f)
        }
    }

    @Test fun fitScales() {
        // A4 portrait on a landscape-ish view
        assertEquals(2f, PdfGeometry.pxPerPoint(PdfFit.WIDTH, 1200f, 800f, 600f, 840f, 3f), eps)
        assertEquals(800f / 840f, PdfGeometry.pxPerPoint(PdfFit.PAGE, 1200f, 800f, 600f, 840f, 3f), eps)
        assertEquals(3f, PdfGeometry.pxPerPoint(PdfFit.ACTUAL, 1200f, 800f, 600f, 840f, 3f), eps)
        assertEquals(1f, PdfGeometry.pxPerPoint(PdfFit.WIDTH, 0f, 0f, 600f, 840f, 3f), eps)
    }

    @Test fun singleCellsFollowPages() {
        val cells = PdfGeometry.cells(3, dual = false, coverAlone = true, rtl = false) { PdfSize(600f, 800f) }
        assertEquals(3, cells.size)
        assertEquals(listOf(0), cells[0].pages.toList())
        assertEquals(600f, cells[0].ptsW, 0f)
        assertEquals(800f, cells[0].ptsH, 0f)
    }

    @Test fun dualCellsPairPagesAndCenterDifferentHeights() {
        val sizes = mapOf(0 to PdfSize(600f, 800f), 1 to PdfSize(600f, 800f), 2 to PdfSize(500f, 700f))
        val cells = PdfGeometry.cells(3, dual = true, coverAlone = true, rtl = false) { sizes[it]!! }
        assertEquals(listOf(listOf(0), listOf(1, 2)), cells.map { it.pages.toList() })
        val pair = cells[1]
        assertEquals(1100f, pair.ptsW, 0f)
        assertEquals(800f, pair.ptsH, 0f)
        assertArrayEquals(floatArrayOf(0f, 0f, 600f, 800f), pair.pageRects[0], 0f)
        assertArrayEquals(floatArrayOf(600f, 50f, 1100f, 750f), pair.pageRects[1], 0f)
    }

    @Test fun rtlPairPutsFirstPageOnTheRight() {
        val cells = PdfGeometry.cells(3, dual = true, coverAlone = true, rtl = true) { PdfSize(600f, 800f) }
        val pair = cells[1]
        assertEquals(listOf(1, 2), pair.pages.toList())
        assertArrayEquals(floatArrayOf(600f, 0f, 1200f, 800f), pair.pageRects[0], 0f)   // page 1 on the right
        assertArrayEquals(floatArrayOf(0f, 0f, 600f, 800f), pair.pageRects[1], 0f)
    }

    @Test fun landscapePageStaysAlone() {
        val cells = PdfGeometry.cells(4, dual = true, coverAlone = false, rtl = false) { if (it == 1) PdfSize(900f, 600f) else PdfSize(600f, 900f) }
        assertEquals(listOf(listOf(0), listOf(1), listOf(2, 3)), cells.map { it.pages.toList() })
    }

    @Test fun cellLookup() {
        val cells = PdfGeometry.cells(5, dual = true, coverAlone = true, rtl = false) { PdfSize(600f, 800f) }
        assertEquals(0, PdfGeometry.cellIndexOf(cells, 0))
        assertEquals(1, PdfGeometry.cellIndexOf(cells, 2))
        assertEquals(cells.lastIndex, PdfGeometry.cellIndexOf(cells, 99))
        assertEquals(0, PdfGeometry.cellIndexOf(emptyList(), 3))
    }

    @Test fun intersection() {
        assertArrayEquals(floatArrayOf(5f, 5f, 10f, 10f), PdfGeometry.intersect(floatArrayOf(0f, 0f, 10f, 10f), floatArrayOf(5f, 5f, 20f, 20f))!!, 0f)
        assertNull(PdfGeometry.intersect(floatArrayOf(0f, 0f, 10f, 10f), floatArrayOf(10f, 0f, 20f, 10f)))
    }
}
