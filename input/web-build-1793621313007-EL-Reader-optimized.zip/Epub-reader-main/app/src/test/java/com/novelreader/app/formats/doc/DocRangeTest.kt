package com.novelreader.app.formats.doc

import com.novelreader.app.formats.DocRange
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DocRangeTest {

    private val texts = listOf("first paragraph", "second one", "third")

    @Test fun jsonRoundTripSingleAndMultiBlock() {
        val a = DocRange(1, 2, 8)
        assertEquals(a, DocRange.parse(a.toJson()))
        assertTrue(!a.toJson().contains("b2"))
        val b = DocRange(0, 6, 3, 2)
        assertEquals(b, DocRange.parse(b.toJson()))
        assertTrue(b.toJson().contains("b2"))
    }

    @Test fun garbageIsIgnored() {
        assertNull(DocRange.parse(null))
        assertNull(DocRange.parse(""))
        assertNull(DocRange.parse("nope"))
        assertNull(DocRange.parse("{\"f\":\"pdfhl\",\"b\":1,\"s\":0,\"e\":2}"))
        assertNull(DocRange.parse("{\"f\":\"dochl\",\"b\":1}"))
        // A highlight made by the EPUB reader (Readium locator) is not a document range.
        assertNull(DocRange.parse("{\"href\":\"c1.xhtml\",\"type\":\"text/html\"}"))
    }

    @Test fun sliceOfOneBlock() {
        assertEquals("paragraph", DocRange(0, 6, 15).slice(texts))
    }

    @Test fun sliceAcrossBlocksJoinsWithALineBreak() {
        assertEquals("paragraph\nsecond one\nthi", DocRange(0, 6, 3, 2).slice(texts))
    }

    @Test fun sliceOutOfRangeIsNull() {
        assertNull(DocRange(5, 0, 1).slice(texts))
        assertNull(DocRange(0, 0, 99).slice(texts))
        assertNull(DocRange(0, 3, 1).slice(texts))
        assertNull(DocRange(2, 0, 1, 1).slice(texts))   // end before start
        assertNull(DocRange(0, 0, 1, 7).slice(texts))
    }

    @Test fun piecesOfASingleBlock() {
        val pc = DocRange(1, 2, 8).pieces { texts[it].length }
        assertEquals(1, pc.size)
        assertEquals(listOf(1, 2, 8), pc[0].toList())
    }

    @Test fun piecesOfAMultiBlockRange() {
        val pc = DocRange(0, 6, 3, 2).pieces { texts[it].length }.map { it.toList() }
        assertEquals(listOf(listOf(0, 6, 15), listOf(1, 0, 10), listOf(2, 0, 3)), pc)
    }

    @Test fun piecesStopAtAMissingBlock() {
        val pc = DocRange(1, 0, 4, 9).pieces { if (it < texts.size) texts[it].length else -1 }.map { it.toList() }
        assertEquals(listOf(listOf(1, 0, 10), listOf(2, 0, 5)), pc)
    }

    @Test fun emptyPiecesAreSkipped() {
        val pc = DocRange(0, 15, 0, 1).pieces { texts[it].length }.map { it.toList() }
        assertTrue(pc.none { it[2] <= it[1] })
    }
}
