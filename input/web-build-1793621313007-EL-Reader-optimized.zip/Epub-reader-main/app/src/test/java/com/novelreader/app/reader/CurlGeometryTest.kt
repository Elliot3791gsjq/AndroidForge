package com.novelreader.app.reader

import kotlin.math.PI
import kotlin.math.abs
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CurlGeometryTest {
    private val w = 1000f
    private val r = 85f

    @Test fun progressZeroIsExactlyTheFlatPage() {
        val plan = CurlGeometry.plan(CurlGeometry.edgeFor(0f, w), w, r)
        assertTrue(plan.isFlat)
        for (u in listOf(0f, 1f, 500f, 999f, 1000f)) {
            val m = CurlGeometry.map(u, plan)
            assertEquals(u, m.x, 0.001f)
            assertFalse(m.back)
        }
    }

    @Test fun smallLiftCurlsOnlyAThinStripAtTheFreeEdge() {
        val plan = CurlGeometry.plan(w - 20f, w, r)
        assertTrue(plan.fold > w - 20f)
        // The page up to the fold is untouched.
        assertEquals(400f, CurlGeometry.map(400f, plan).x, 0.001f)
    }

    @Test fun mappingIsContinuousEverywhere() {
        for (p in listOf(0.02f, 0.1f, 0.25f, 0.4f, 0.6f, 0.8f, 0.95f)) {
            val plan = CurlGeometry.plan(CurlGeometry.edgeFor(p, w), w, r)
            var prev = CurlGeometry.map(0f, plan).x
            var u = 1f
            while (u <= w) {
                val x = CurlGeometry.map(u, plan).x
                // a one-pixel step in the source never moves a column by more than one pixel on screen
                assertTrue("p=$p u=$u jump ${abs(x - prev)}", abs(x - prev) <= 1.0001f)
                prev = x
                u += 1f
            }
        }
    }

    @Test fun frontFaceMovesOutwardThenBackFaceReturns() {
        val plan = CurlGeometry.plan(CurlGeometry.edgeFor(0.5f, w), w, r)
        assertNotNull(plan.flippedStart)
        val startRoll = CurlGeometry.map(plan.fold, plan)
        val quarter = CurlGeometry.map(plan.fold + PI.toFloat() * r / 2f, plan)
        val top = CurlGeometry.map(plan.fold + PI.toFloat() * r, plan)
        assertFalse(startRoll.back)
        assertFalse(quarter.back.and(quarter.theta < PI.toFloat() / 2f - 0.01f))
        assertTrue(quarter.x > startRoll.x)          // front face bulges to the right
        assertEquals(plan.fold + r, quarter.x, 0.5f)  // rim of the roll
        assertEquals(plan.fold, top.x, 0.5f)          // back at the fold after half a turn
        assertTrue(top.back)
    }

    @Test fun freeEdgeEndsWhereTheEdgeWasHeld() {
        for (p in listOf(0.3f, 0.5f, 0.7f, 0.9f)) {
            val edge = CurlGeometry.edgeFor(p, w)
            val plan = CurlGeometry.plan(edge, w, r)
            if (plan.flippedStart != null) {
                assertEquals("p=$p", edge, CurlGeometry.map(w, plan).x, 0.5f)
            }
        }
    }

    @Test fun flippedPartIsMirrored() {
        val plan = CurlGeometry.plan(CurlGeometry.edgeFor(0.5f, w), w, r)
        val fs = plan.flippedStart!!
        val a = CurlGeometry.map(fs + 10f, plan)
        val b = CurlGeometry.map(fs + 20f, plan)
        assertTrue(a.back && b.back)
        assertTrue(b.x < a.x)   // further source columns land further towards the spine
    }

    @Test fun nothingIsLeftOnScreenAtTheEnd() {
        val plan = CurlGeometry.plan(CurlGeometry.edgeFor(1f, w), w, r)
        // even the rim of the roll is past the spine edge
        assertTrue("rim ${plan.rim}", plan.rim < 0f + 1f)
        for (u in listOf(0f, 250f, 500f, 750f, 1000f)) {
            assertTrue(CurlGeometry.map(u, plan).x <= 1f)
        }
    }

    @Test fun radiusRampsInSoTheFirstPixelsLookLikeAFlatFold() {
        val tiny = CurlGeometry.plan(w - 1f, w, r)
        assertTrue(tiny.radius < 0.01f * r)
        val full = CurlGeometry.plan(w - 200f, w, r)
        assertEquals(r, full.radius, 0.001f)
    }

    @Test fun darknessIsZeroFlatAndMaximumAtTheRim() {
        assertEquals(0f, CurlGeometry.darkness(0f), 1e-6f)
        assertEquals(1f, CurlGeometry.darkness(PI.toFloat() / 2f), 1e-6f)
        assertEquals(0f, CurlGeometry.darkness(PI.toFloat()), 1e-6f)
    }

    @Test fun dragProgressIsClamped() {
        assertEquals(0f, CurlGeometry.progressForDrag(-50f, w), 0f)
        assertEquals(1f, CurlGeometry.progressForDrag(5000f, w), 0f)
        assertEquals(0.5f, CurlGeometry.progressForDrag(1020f, w), 0.001f)
        assertEquals(0f, CurlGeometry.progressForDrag(10f, 0f), 0f)
    }

    @Test fun releaseDecision() {
        val dpi = 420f
        // slow, short drag -> cancel; long drag -> complete
        assertFalse(CurlGeometry.shouldComplete(100f, w, 0f, dpi))
        assertTrue(CurlGeometry.shouldComplete(400f, w, 0f, dpi))
        // a fast flick completes even a short drag, a fast flick back cancels even a long one
        assertTrue(CurlGeometry.shouldComplete(60f, w, 4000f, dpi))
        assertFalse(CurlGeometry.shouldComplete(600f, w, -4000f, dpi))
        // a flick without any movement towards the exit side does not turn the page
        assertFalse(CurlGeometry.shouldComplete(0f, w, 4000f, dpi))
    }

    @Test fun durationScalesWithSpeed() {
        assertEquals(760L, CurlGeometry.durationFor(1))
        assertEquals(166L, CurlGeometry.durationFor(10))
        assertEquals(CurlGeometry.durationFor(1), CurlGeometry.durationFor(-5))
        assertEquals(CurlGeometry.durationFor(10), CurlGeometry.durationFor(99))
        assertNull(CurlGeometry.plan(CurlGeometry.edgeFor(0.1f, w), w, r).flippedStart)
    }
}
