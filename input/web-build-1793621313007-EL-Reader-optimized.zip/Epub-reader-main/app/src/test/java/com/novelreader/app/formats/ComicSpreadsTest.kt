package com.novelreader.app.formats

import com.novelreader.app.formats.comic.ComicSpreads
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ComicSpreadsTest {
    private fun List<IntArray>.flat() = map { it.toList() }

    @Test fun singlePageLayoutIsOnePerSpread() {
        assertEquals(listOf(listOf(0), listOf(1), listOf(2)), ComicSpreads.build(3, false, true) { false }.flat())
        assertTrue(ComicSpreads.build(0, true, true) { false }.isEmpty())
    }

    @Test fun dualWithCoverAlone() {
        assertEquals(listOf(listOf(0), listOf(1, 2), listOf(3, 4), listOf(5)), ComicSpreads.build(6, true, true) { false }.flat())
    }

    @Test fun dualWithoutCoverAlone() {
        assertEquals(listOf(listOf(0, 1), listOf(2, 3), listOf(4)), ComicSpreads.build(5, true, false) { false }.flat())
    }

    @Test fun widePageStandsAloneAndRepairsFollowers() {
        // pages: 0 cover, 1 normal, 2 WIDE, 3, 4, 5
        val s = ComicSpreads.build(6, true, true) { it == 2 }
        assertEquals(listOf(listOf(0), listOf(1), listOf(2), listOf(3, 4), listOf(5)), s.flat())
    }

    @Test fun pageBeforeAWidePageIsNotPairedWithIt() {
        val s = ComicSpreads.build(4, true, false) { it == 1 }
        assertEquals(listOf(listOf(0), listOf(1), listOf(2, 3)), s.flat())
    }

    @Test fun everyPageAppearsExactlyOnceInOrder() {
        for (n in 1..40) for (cover in listOf(true, false)) {
            val s = ComicSpreads.build(n, true, cover) { it % 7 == 3 }
            assertEquals((0 until n).toList(), s.flatMap { it.toList() })
        }
    }

    @Test fun indexOfFindsTheSpread() {
        val s = ComicSpreads.build(6, true, true) { false }
        assertEquals(0, ComicSpreads.indexOf(s, 0))
        assertEquals(1, ComicSpreads.indexOf(s, 2))
        assertEquals(3, ComicSpreads.indexOf(s, 5))
        assertEquals(3, ComicSpreads.indexOf(s, 99))
        assertEquals(0, ComicSpreads.indexOf(s, -3))
        assertEquals(0, ComicSpreads.indexOf(emptyList(), 4))
    }

    @Test fun progressRunsFromZeroToOne() {
        assertEquals(0.0, ComicSpreads.progress(0, 10), 0.0)
        assertEquals(1.0, ComicSpreads.progress(9, 10), 0.0)
        assertEquals(1.0, ComicSpreads.progress(0, 1), 0.0)
        assertEquals(0.0, ComicSpreads.progress(0, 0), 0.0)
        assertEquals(1.0, ComicSpreads.progress(50, 10), 0.0)
    }
}
