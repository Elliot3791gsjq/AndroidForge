package com.novelreader.app.formats.doc

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TxtParserTest {

    private fun parse(text: String, mode: ParagraphMode = ParagraphMode.EVERY_LINE): Pair<DocParseResult, String> {
        val sb = StringBuilder()
        val r = TxtParser.parse(text, mode, "Title", sb)
        return r to sb.toString()
    }

    /** The block contract: element i of the markup has exactly the text texts[i]. */
    private fun assertContract(r: DocParseResult, html: String) {
        val re = Regex("<p class=\"b[^\"]*\" dir=\"(?:rtl|ltr)\" data-i=\"(\\d+)\">(.*?)</p>", RegexOption.DOT_MATCHES_ALL)
        val found = re.findAll(html).toList()
        assertEquals(r.texts.size, found.size)
        found.forEachIndexed { i, m ->
            assertEquals(i, m.groupValues[1].toInt())
            val text = m.groupValues[2].replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&")
            assertEquals(r.texts[i], text)
        }
    }

    @Test fun blocksMatchTexts() {
        val (r, html) = parse("first line\nsecond <b> & line\n\nthird")
        assertEquals(listOf("first line", "second <b> & line", "third"), r.texts)
        assertContract(r, html)
        assertFalse(html.contains("<b>"))
    }

    @Test fun markupIsEscaped() {
        val (_, html) = parse("</p><script>alert(1)</script> & \"quotes\"")
        assertFalse(html.contains("<script>"))
        assertTrue(html.contains("&lt;script&gt;"))
        assertTrue(html.contains("&amp;"))
    }

    @Test fun controlCharactersAreDropped() {
        val (r, html) = parse("a\u0000b\u0001c\td")
        assertEquals(listOf("abc\td"), r.texts)
        assertContract(r, html)
    }

    @Test fun everyBlockCarriesItsOwnDirection() {
        val (r, html) = parse("سلام دنیا\nHello world\n123 456")
        assertTrue(html.contains("dir=\"rtl\" data-i=\"0\""))
        assertTrue(html.contains("dir=\"ltr\" data-i=\"1\""))
        // Digits only: no strong letter, so the paragraph takes the direction of the document (2 of 3 strong... tie -> ltr).
        assertEquals(3, r.texts.size)
    }

    @Test fun documentDirectionFollowsTheMajority() {
        assertTrue(parse("سلام دنیا\nاین یک متن است\nHello").first.rtl)
        assertFalse(parse("Hello world\nThis is text\nسلام").first.rtl)
        // A paragraph without letters follows the document.
        val persianDoc = parse("سلام دنیا\nاین یک متن است\n۱۲۳").second
        assertTrue(persianDoc.contains("dir=\"rtl\" data-i=\"2\""))
    }

    @Test fun chaptersMakeAnOutline() {
        val text = "Chapter 1\nIt began.\nChapter 2: The Road\nIt went on.\nChapter III\nEnd."
        val (r, html) = parse(text)
        assertEquals(listOf("Chapter 1", "Chapter 2: The Road", "Chapter III"), r.outline.map { it.title })
        assertEquals(listOf(0, 2, 4), r.outline.map { it.block })
        assertTrue(html.contains("class=\"b ch\""))
        assertContract(r, html)
    }

    @Test fun persianAndCjkChapters() {
        val fa = parse("فصل ۱\nمتن اول\nفصل دوم\nمتن دوم\nمقدمه\nمتن").first
        assertEquals(listOf("فصل ۱", "فصل دوم", "مقدمه"), fa.outline.map { it.title })
        val zh = parse("第一章 开始\n内容\n第十二章 结束\n内容").first
        assertEquals(2, zh.outline.size)
    }

    @Test fun aSingleChapterLikeLineIsNotAnOutline() {
        // One "Chapter 3" in running text is more likely a coincidence than a table of contents.
        val r = parse("Some text.\nChapter 3\nMore text.").first
        assertTrue(r.outline.isEmpty())
    }

    @Test fun longLinesAreNeverHeadings() {
        val long = "Chapter 1 " + "x".repeat(200)
        val r = parse("$long\n$long\n$long").first
        assertTrue(r.outline.isEmpty())
    }

    @Test fun emptyTextHasNoBlocks() {
        val (r, html) = parse("  \n\n\t\n")
        assertTrue(r.texts.isEmpty())
        assertEquals("", html)
    }

    @Test fun titleIsPassedThrough() {
        assertEquals("Title", parse("x").first.title)
    }

    @Test fun hardWrappedFileInAutoMode() {
        val sb = StringBuilder()
        repeat(10) { p -> repeat(4) { l -> sb.append("Wrapped line ${l + 1} of block ${p + 1} that is about sixty characters.\n") }; sb.append("\n") }
        val (r, html) = parse(sb.toString(), ParagraphMode.AUTO)
        assertEquals(10, r.texts.size)
        assertContract(r, html)
    }

    @Test fun bigFileStaysLinear() {
        val line = "یک خط از یک رمان بلند که باید سریع پردازش شود. A line of a long novel.\n"
        val text = line.repeat(60_000)   // ~ 4 MB
        val sb = StringBuilder()
        val t0 = System.nanoTime()
        val r = TxtParser.parse(text, ParagraphMode.EVERY_LINE, null, sb)
        val ms = (System.nanoTime() - t0) / 1_000_000
        assertEquals(60_000, r.texts.size)
        assertTrue("took $ms ms", ms < 5000)
    }
}
