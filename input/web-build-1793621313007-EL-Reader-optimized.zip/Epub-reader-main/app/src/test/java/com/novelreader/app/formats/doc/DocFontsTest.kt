package com.novelreader.app.formats.doc

import com.novelreader.app.data.CustomFont
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DocFontsTest {

    private fun font(
        id: String = "ab12cd",
        ext: String = "ttf",
        family: String = "My Font",
        weight: Int = 400,
        italic: Boolean = false,
        vmin: Int? = null,
        vmax: Int? = null,
    ) = CustomFont(id, "My Font Regular", family, ext, weight, italic, vmin, vmax, true, true, 1000, "sha", "orig.ttf")

    @Test fun bundledFontsAreDeclaredFromAssets() {
        val css = DocFonts.css(emptyList())
        for ((family, file) in DocFonts.BUNDLED) {
            assertTrue(css.contains("font-family:\"$family\""))
            assertTrue(css.contains("url(\"/f/asset/$file\")"))
        }
        assertEquals(3, Regex("@font-face").findAll(css).count())
    }

    @Test fun anImportedFontIsDeclaredUnderItsIdAndItsRealName() {
        val css = DocFonts.css(listOf(font()))
        assertTrue(css.contains("font-family:\"NRFont_ab12cd\""))
        assertTrue(css.contains("font-family:\"My Font\""))      // so that a .docx asking for "My Font" finds it
        assertTrue(css.contains("url(\"/f/ab12cd.ttf\") format(\"truetype\")"))
    }

    @Test fun otfAndVariableAndItalic() {
        val css = DocFonts.css(listOf(font(ext = "otf", vmin = 200, vmax = 800, italic = true)))
        assertTrue(css.contains("format(\"opentype\")"))
        assertTrue(css.contains("font-weight:200 800"))
        assertTrue(css.contains("font-style:italic"))
    }

    @Test fun unsafeFontsAreLeftOut() {
        val bad = listOf(font(id = "../../etc"), font(id = "UPPER"), font(ext = "woff2"), font(ext = "html"))
        val css = DocFonts.css(bad)
        assertEquals(3, Regex("@font-face").findAll(css).count())   // only the bundled ones
        assertFalse(css.contains(".."))
    }

    @Test fun aFontNameCannotBreakOutOfTheCssString() {
        val css = DocFonts.css(listOf(font(family = "Evil\"};body{display:none}/*\n<script>")))
        assertFalse(css.contains("\"};body"))
        assertFalse(css.contains("<script>"))
        assertFalse(css.contains('\n'))
    }

    @Test fun aBlankFamilyNameIsSkippedButTheIdFamilyStays() {
        val css = DocFonts.css(listOf(font(family = "\"\"")))
        assertTrue(css.contains("NRFont_ab12cd"))
        assertFalse(css.contains("font-family:\"\""))
    }

    @Test fun customFamilyMatchesTheNavigatorFamilyName() {
        assertEquals("NRFont_ab12cd", DocFonts.customFamily(font()))
    }
}
