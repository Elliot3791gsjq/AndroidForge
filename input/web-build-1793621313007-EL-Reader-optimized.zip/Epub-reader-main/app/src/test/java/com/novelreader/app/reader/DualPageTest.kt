package com.novelreader.app.reader

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DualPageTest {
    @Test fun offStaysOffEverywhere() {
        for (landscape in listOf(true, false)) for (portraitToo in listOf(true, false)) for (scroll in listOf(true, false))
            assertFalse(DualPage.active(false, portraitToo, scroll, landscape))
    }

    @Test fun landscapeShowsTwoPages() {
        assertTrue(DualPage.active(true, false, false, true))
    }

    @Test fun portraitNeedsTheExtraSwitch() {
        assertFalse(DualPage.active(true, false, false, false))
        assertTrue(DualPage.active(true, true, false, false))
    }

    @Test fun scrollingNeverHasTwoPages() {
        assertFalse(DualPage.active(true, true, true, true))
        assertFalse(DualPage.active(true, false, true, true))
    }
}
