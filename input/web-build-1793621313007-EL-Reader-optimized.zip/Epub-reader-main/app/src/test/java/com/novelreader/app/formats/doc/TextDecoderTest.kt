package com.novelreader.app.formats.doc

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.nio.charset.Charset

/** Encoding detection on real-language samples, each encoded for real into the legacy code page. */
class TextDecoderTest {

    private val persian = "کتاب‌خوان الکترونیکی برای خواندن رمان‌های بلند ساخته شده است. هر شب پیش از خواب چند صفحه از کتاب مورد علاقه‌ام را می‌خوانم " +
        "و به دنیای شخصیت‌ها فکر می‌کنم. امروز هوا آفتابی بود و ما به همراه دوستان به پارک رفتیم و درباره‌ی آینده گفتگو کردیم. " +
        "باران دیشب تمام خیابان‌ها را شست و بوی خاک تازه در شهر پیچید. پدرم می‌گفت که زندگی مثل کتابی است که باید آرام و با دقت خوانده شود."

    private val russian = "Весь день шёл дождь, и мы остались дома. Я читал книгу о путешествиях по Сибири, а моя сестра готовила ужин на кухне. " +
        "Вечером к нам пришли соседи, и мы долго пили чай и разговаривали о жизни, о погоде и о том, что будет завтра. " +
        "Потом все вместе смотрели старый фильм, который помнили ещё с детства, и смеялись над знакомыми шутками."

    private val chineseSimplified = "今天天气很好，我和朋友们一起去公园玩。我们在湖边散步，看到了很多美丽的花和鸟。中午我们在一家小餐馆吃了饭，然后回家休息。" +
        "晚上我读了一本关于历史的书，觉得非常有意思。明天我还要去学校上课，所以早点睡觉。他说这个世界上没有什么事情是不可能的，只要你愿意去做。"

    private val chineseTraditional = "今天天氣很好，我和朋友們一起去公園玩。我們在湖邊散步，看到了很多美麗的花和鳥。中午我們在一家小餐館吃了飯，然後回家休息。" +
        "晚上我讀了一本關於歷史的書，覺得非常有意思。明天我還要去學校上課，所以早點睡覺。他說這個世界上沒有什麼事情是不可能的，只要你願意去做。"

    private val japanese = "今日は天気がとても良かったので、友達と一緒に公園へ行きました。湖のそばを歩いて、たくさんの美しい花や鳥を見ました。" +
        "昼には小さなレストランでご飯を食べて、それから家に帰って休みました。夜は歴史についての本を読んで、とても面白いと思いました。" +
        "明日は学校があるので、早く寝ることにします。彼はこの世界に不可能なことは何もないと言いました。"

    private val korean = "오늘은 날씨가 매우 좋아서 친구들과 함께 공원에 갔습니다. 호숫가를 걸으며 아름다운 꽃과 새를 많이 보았습니다. " +
        "점심에는 작은 식당에서 밥을 먹고 집에 돌아와 쉬었습니다. 저녁에는 역사에 관한 책을 읽었는데 아주 재미있었습니다. " +
        "내일은 학교에 가야 해서 일찍 자려고 합니다. 그는 이 세상에 불가능한 일은 없다고 말했습니다."

    private val western = "Le café de la rue Saint-Honoré était fermé, mais nous avons trouvé une petite boulangerie où l'on servait des croissants délicieux. " +
        "Ensuite, nous sommes allés à l'école où les élèves préparaient une fête pour l'été. Über die Brücke gingen wir zurück; " +
        "señor García dijo que mañana hará frío. “Quotes” and dashes – like these – are in this code page too."

    private fun enc(text: String, charset: String) = text.toByteArray(Charset.forName(charset))

    /** windows-1256 has the Arabic yeh and kaf only (the Persian forms are drawn from them by the font). */
    private val persian1256 = persian.replace('ی', 'ي').replace('ک', 'ك')

    @Test fun utf8WithoutMark() {
        val d = TextDecoder.decode(persian.toByteArray(Charsets.UTF_8))
        assertEquals(TextEncoding.UTF8, d.encoding)
        assertEquals(persian, d.text)
        assertFalse(d.hadBom)
    }

    @Test fun utf8WithMarkIsStripped() {
        val d = TextDecoder.decode(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()) + "سلام دنیا".toByteArray(Charsets.UTF_8))
        assertEquals(TextEncoding.UTF8, d.encoding)
        assertEquals("سلام دنیا", d.text)
        assertTrue(d.hadBom)
    }

    @Test fun utf16WithMarks() {
        val le = byteArrayOf(0xFF.toByte(), 0xFE.toByte()) + persian.toByteArray(Charsets.UTF_16LE)
        val be = byteArrayOf(0xFE.toByte(), 0xFF.toByte()) + persian.toByteArray(Charsets.UTF_16BE)
        TextDecoder.decode(le).let { assertEquals(TextEncoding.UTF16LE, it.encoding); assertEquals(persian, it.text) }
        TextDecoder.decode(be).let { assertEquals(TextEncoding.UTF16BE, it.encoding); assertEquals(persian, it.text) }
    }

    @Test fun utf16WithoutMarkIsRecognisedForLatinText() {
        val s = "Plain English text stored as UTF-16 without a byte order mark. ".repeat(4)
        TextDecoder.decode(s.toByteArray(Charsets.UTF_16LE)).let { assertEquals(TextEncoding.UTF16LE, it.encoding); assertEquals(s, it.text) }
        TextDecoder.decode(s.toByteArray(Charsets.UTF_16BE)).let { assertEquals(TextEncoding.UTF16BE, it.encoding); assertEquals(s, it.text) }
    }

    @Test fun persianWindows1256() {
        val d = TextDecoder.decode(enc(persian1256, "windows-1256"))
        assertEquals(TextEncoding.WIN1256, d.encoding)
        assertEquals(persian1256, d.text)
    }

    @Test fun russianWindows1251() {
        val d = TextDecoder.decode(enc(russian, "windows-1251"))
        assertEquals(TextEncoding.WIN1251, d.encoding)
        assertEquals(russian, d.text)
    }

    @Test fun chineseSimplifiedGb18030() {
        val d = TextDecoder.decode(enc(chineseSimplified, "GB18030"))
        assertEquals(TextEncoding.GB18030, d.encoding)
        assertEquals(chineseSimplified, d.text)
    }

    @Test fun chineseTraditionalBig5() {
        val d = TextDecoder.decode(enc(chineseTraditional, "Big5"))
        assertEquals(TextEncoding.BIG5, d.encoding)
        assertEquals(chineseTraditional, d.text)
    }

    @Test fun japaneseShiftJis() {
        val d = TextDecoder.decode(enc(japanese, "Shift_JIS"))
        assertEquals(TextEncoding.SJIS, d.encoding)
        assertEquals(japanese, d.text)
    }

    @Test fun koreanEucKr() {
        val d = TextDecoder.decode(enc(korean, "EUC-KR"))
        assertEquals(TextEncoding.EUCKR, d.encoding)
        assertEquals(korean, d.text)
    }

    @Test fun westernWindows1252() {
        val d = TextDecoder.decode(enc(western, "windows-1252"))
        assertEquals(TextEncoding.WIN1252, d.encoding)
        assertEquals(western, d.text)
    }

    @Test fun pureAsciiIsUtf8() {
        val d = TextDecoder.decode("Just ASCII, nothing else.\r\nSecond line.".toByteArray())
        assertEquals(TextEncoding.UTF8, d.encoding)
    }

    @Test fun emptyFile() {
        val d = TextDecoder.decode(ByteArray(0))
        assertEquals("", d.text)
        assertEquals(TextEncoding.UTF8, d.encoding)
    }

    @Test fun forcedChoiceStillReportsWhatAutomaticWouldPick() {
        val bytes = enc(russian, "windows-1251")
        val forced = TextDecoder.decode(bytes, TextEncoding.WIN1252)
        assertEquals(TextEncoding.WIN1252, forced.encoding)
        assertEquals(TextEncoding.WIN1251, forced.auto)
        assertEquals(TextEncoding.WIN1251, TextDecoder.detect(bytes))
        // without a manual choice both are the same
        val auto = TextDecoder.decode(bytes)
        assertEquals(auto.encoding, auto.auto)
        // UTF-8 file forced to a legacy page: automatic is still UTF-8
        val u = TextDecoder.decode("héllo wörld".toByteArray(Charsets.UTF_8), TextEncoding.WIN1252)
        assertEquals(TextEncoding.UTF8, u.auto)
    }

    @Test fun aManualChoiceAlwaysWins() {
        val bytes = enc(russian, "windows-1251")
        val forced = TextDecoder.decode(bytes, TextEncoding.WIN1251)
        assertEquals(russian, forced.text)
        // The wrong choice gives wrong letters, but it is what the reader asked for.
        val wrong = TextDecoder.decode(bytes, TextEncoding.WIN1252)
        assertEquals(TextEncoding.WIN1252, wrong.encoding)
        assertFalse(wrong.text == russian)
        // Valid UTF-8 can still be read as a legacy page when the reader insists.
        val asLatin = TextDecoder.decode("é".toByteArray(Charsets.UTF_8), TextEncoding.WIN1252)
        assertEquals("Ã©", asLatin.text)
    }

    @Test fun aByteOrderMarkBeatsAUnicodeChoiceOfAnotherForm() {
        val le = byteArrayOf(0xFF.toByte(), 0xFE.toByte()) + "abc".toByteArray(Charsets.UTF_16LE)
        val d = TextDecoder.decode(le, TextEncoding.UTF8)
        assertEquals(TextEncoding.UTF16LE, d.encoding)
        assertEquals("abc", d.text)
    }

    @Test fun aFileCutInTheMiddleOfACharacterIsStillUtf8() {
        val full = persian.toByteArray(Charsets.UTF_8)
        for (cut in 1..3) {
            val bytes = full.copyOf(full.size - cut)
            // Whatever the cut leaves, the text must not turn into legacy-code-page garbage.
            val d = TextDecoder.decode(bytes)
            assertEquals("cut $cut", TextEncoding.UTF8, d.encoding)
            assertTrue(d.text.startsWith("کتاب‌خوان الکترونیکی"))
        }
    }

    @Test fun invalidUtf8IsNotAccepted() {
        assertFalse(TextDecoder.isValidUtf8(byteArrayOf(0xC0.toByte(), 0x80.toByte())))          // overlong
        assertFalse(TextDecoder.isValidUtf8(byteArrayOf(0xED.toByte(), 0xA0.toByte(), 0x80.toByte()))) // surrogate
        assertFalse(TextDecoder.isValidUtf8(byteArrayOf(0xFF.toByte())))
        assertFalse(TextDecoder.isValidUtf8(byteArrayOf(0x61, 0xE9.toByte(), 0x62)))             // lone Latin-1 e-acute
        assertTrue(TextDecoder.isValidUtf8("añ漢😀".toByteArray(Charsets.UTF_8)))
    }

    @Test fun everyListedEncodingIsAvailableOnTheJvm() {
        TextEncoding.entries.forEach { assertTrue(it.name, it.available()) }
    }

    @Test fun threeMegabytesDecodeQuickly() {
        val big = (persian + "\n").repeat(3 * 1024 * 1024 / (persian.length * 2)).toByteArray(Charsets.UTF_8)
        val t0 = System.nanoTime()
        val d = TextDecoder.decode(big)
        val ms = (System.nanoTime() - t0) / 1_000_000
        assertEquals(TextEncoding.UTF8, d.encoding)
        assertTrue("took $ms ms", ms < 3000)
    }

    @Test fun legacyTextWithLongAsciiStretches() {
        // A Persian text where most bytes are ASCII (markup-like) must still be told from Western text by its letters.
        val s = "<p>" + persian1256.take(120) + "</p>\n" + "line one of english text that is long enough to dominate the ratio. ".repeat(6) + persian1256.take(160)
        assertEquals(TextEncoding.WIN1256, TextDecoder.decode(enc(s, "windows-1256")).encoding)
    }

    @Test fun paragraphsEveryLineDropsBlankLines() {
        val out = TextParagraphs.split("one\r\n\r\ntwo\rthree\n\n\nfour  \n", ParagraphMode.EVERY_LINE)
        assertEquals(listOf("one", "two", "three", "four"), out)
    }

    @Test fun paragraphsJoinWrappedLines() {
        val out = TextParagraphs.split("a b\nc d\n\ne\nf\n", ParagraphMode.JOIN_WRAPPED)
        assertEquals(listOf("a b c d", "e f"), out)
    }

    @Test fun autoJoinsHardWrappedText() {
        val sb = StringBuilder()
        repeat(12) { para ->
            repeat(5) { line -> sb.append("This is line ${line + 1} of paragraph ${para + 1}, wrapped at a fixed width.\n") }
            sb.append("\n")
        }
        val out = TextParagraphs.split(sb.toString(), ParagraphMode.AUTO)
        assertEquals(12, out.size)
        assertTrue(out[0].startsWith("This is line 1 of paragraph 1,") && out[0].contains("line 5 of paragraph 1"))
    }

    @Test fun autoKeepsOneLinePerParagraphForWebNovelText() {
        val sb = StringBuilder()
        repeat(30) { i -> sb.append("A long line that is one whole paragraph of the story number $i. ".repeat(6)).append("\n\n") }
        val out = TextParagraphs.split(sb.toString(), ParagraphMode.AUTO)
        assertEquals(30, out.size)
    }

    @Test fun autoDoesNotJoinShortTextOrPoetry() {
        assertFalse(TextParagraphs.looksHardWrapped("short\ntext\n"))
        val poem = (1..40).joinToString("\n") { "line $it of a poem" }   // no blank lines at all
        assertFalse(TextParagraphs.looksHardWrapped(poem))
    }

    @Test fun directionOfText() {
        assertTrue(TextDirection.looksRtl(persian))
        assertFalse(TextDirection.looksRtl(western))
        assertTrue(TextDirection.looksRtl("ab سلام دنیا من اینجا هستم"))
        assertFalse(TextDirection.looksRtl("12345 ... !!!"))
    }
}
