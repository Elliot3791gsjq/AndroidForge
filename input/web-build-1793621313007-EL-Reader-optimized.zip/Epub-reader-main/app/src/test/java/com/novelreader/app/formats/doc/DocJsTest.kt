package com.novelreader.app.formats.doc

import com.novelreader.app.formats.BookFormat
import com.novelreader.app.formats.DocAlign
import com.novelreader.app.formats.DocDirection
import com.novelreader.app.formats.DocFont
import com.novelreader.app.formats.DocRange
import com.novelreader.app.formats.DocSettings
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** The JSON the page script receives: settings, highlights and search hits. */
class DocJsTest {

    private fun style(s: DocSettings = DocSettings(), f: BookFormat = BookFormat.TXT, custom: String? = null) =
        DocJs.style(s, f, 0xFF112233.toInt(), 0xFFFFFFF0.toInt(), 0xFF0066CC.toInt(), false, custom)

    @Test fun colours() {
        assertEquals("#FF8800", DocJs.cssColor(0xFFFF8800.toInt()))
        assertEquals("#000001", DocJs.cssColor(0x00000001))     // alpha never leaks into the CSS colour
        val o = style()
        assertEquals("#112233", o.getString("fg"))
        assertEquals("#FFFFF0", o.getString("bg"))
        assertEquals("#0066CC", o.getString("link"))
    }

    @Test fun fontStacks() {
        assertEquals("sans-serif", DocJs.fontStack(DocSettings(font = DocFont.SYSTEM_SANS), null))
        assertEquals("serif", DocJs.fontStack(DocSettings(font = DocFont.SYSTEM_SERIF), null))
        assertEquals("monospace", DocJs.fontStack(DocSettings(font = DocFont.MONO), null))
        assertEquals("\"Vazirmatn\",sans-serif", DocJs.fontStack(DocSettings(font = DocFont.VAZIRMATN), null))
        assertEquals("\"Amiri\",serif", DocJs.fontStack(DocSettings(font = DocFont.AMIRI), null))
        assertEquals("\"Lora\",serif", DocJs.fontStack(DocSettings(font = DocFont.LORA), null))
        // An imported font wins over the built-in choice.
        assertEquals("\"NRFont_ab12\",sans-serif", DocJs.fontStack(DocSettings(font = DocFont.LORA), "NRFont_ab12"))
    }

    @Test fun numbersReachThePage() {
        val o = style(DocSettings(fontSize = 22, lineHeight = 1.8f, paragraphSpacing = 0.5f, marginDp = 24, weight = 500, indent = 1.5f))
        assertEquals(22, o.getInt("fs"))
        assertEquals(1.8, o.getDouble("lh"), 0.001)
        assertEquals(0.5, o.getDouble("para"), 0.001)
        assertEquals(24, o.getInt("mx"))
        assertEquals(500, o.getInt("weight"))
        assertEquals(1.5, o.getDouble("indent"), 0.001)
    }

    @Test fun indentIsForPlainTextOnly() {
        assertEquals(0.0, style(DocSettings(indent = 2f), BookFormat.DOCX).getDouble("indent"), 0.0)
    }

    @Test fun alignment() {
        assertEquals("doc", style(DocSettings(align = DocAlign.DOCUMENT), BookFormat.DOCX).getString("align"))
        // A text file has no alignment of its own to keep: "as in the document" falls back to the start side.
        assertEquals("start", style(DocSettings(align = DocAlign.DOCUMENT), BookFormat.TXT).getString("align"))
        assertEquals("justify", style(DocSettings(align = DocAlign.JUSTIFY)).getString("align"))
        assertEquals("center", style(DocSettings(align = DocAlign.CENTER)).getString("align"))
        assertEquals("start", style(DocSettings(align = DocAlign.START)).getString("align"))
    }

    @Test fun direction() {
        assertEquals("auto", style(DocSettings(direction = DocDirection.AUTO)).getString("dir"))
        assertEquals("ltr", style(DocSettings(direction = DocDirection.LTR)).getString("dir"))
        assertEquals("rtl", style(DocSettings(direction = DocDirection.RTL)).getString("dir"))
    }

    @Test fun documentOnlySwitches() {
        assertTrue(style(DocSettings(useDocFonts = true), BookFormat.DOCX).getBoolean("docFonts"))
        assertFalse(style(DocSettings(useDocFonts = false), BookFormat.DOCX).getBoolean("docFonts"))
        assertFalse(style(DocSettings(useDocFonts = true), BookFormat.TXT).getBoolean("docFonts"))
        assertTrue(style(DocSettings(keepDocColors = true), BookFormat.DOCX).getBoolean("docColors"))
        assertFalse(style(DocSettings(keepDocColors = false), BookFormat.DOCX).getBoolean("docColors"))
        assertTrue(style(DocSettings(keepDocColors = false), BookFormat.TXT).getBoolean("docColors"))
    }

    @Test fun darkFlagIsPassedThrough() {
        assertTrue(DocJs.style(DocSettings(), BookFormat.TXT, 0, 0, 0, true, null).getBoolean("dark"))
        assertFalse(style().getBoolean("dark"))
    }

    @Test fun highlightPiecesPerBlock() {
        val texts = listOf("first paragraph", "second one", "third")
        val arr = DocJs.highlights(
            listOf(
                DocJs.HighlightJs(7, DocRange(0, 6, 15), 0xFFFFEB3B.toInt(), "hl"),
                DocJs.HighlightJs(8, DocRange(1, 7, 3, 2), 0xFF81C784.toInt(), "ul"),
            ),
            texts,
        )
        // One piece for the first highlight, two for the second (block 1 from 7 to its end, block 2 up to 3).
        assertEquals(1 + 2, arr.length())
        val first = arr.getJSONObject(0)
        assertEquals(7L, first.getLong("id"))
        assertEquals(0, first.getInt("b")); assertEquals(6, first.getInt("s")); assertEquals(15, first.getInt("e"))
        assertEquals("#FFEB3B", first.getString("c")); assertEquals("hl", first.getString("k"))
        val second = arr.getJSONObject(1)
        assertEquals(8L, second.getLong("id")); assertEquals(1, second.getInt("b")); assertEquals(7, second.getInt("s")); assertEquals(10, second.getInt("e"))
        assertEquals("ul", second.getString("k"))
        val third = arr.getJSONObject(2)
        assertEquals(2, third.getInt("b")); assertEquals(0, third.getInt("s")); assertEquals(3, third.getInt("e"))
    }

    @Test fun noHighlightsIsAnEmptyArray() {
        assertEquals("[]", DocJs.highlights(emptyList(), listOf("a")).toString())
    }

    @Test fun hitsAreTriples() {
        val arr = DocJs.hits(listOf(DocHit(3, 4, 9, "snip"), DocHit(5, 0, 2, "x")))
        assertEquals("[[3,4,9],[5,0,2]]", arr.toString())
        assertEquals("[]", DocJs.hits(emptyList()).toString())
    }

    @Test fun theStyleObjectIsValidJavaScriptWhenInlined() {
        // The WebView evaluates "DocApp.setStyle(" + json + ")": the JSON must contain no raw line terminators.
        val json = style(DocSettings(font = DocFont.VAZIRMATN), custom = "NRFont_ab12").toString()
        assertFalse(json.contains('\n') || json.contains(' ') || json.contains(' '))
    }
}
