package com.novelreader.app.formats

import com.novelreader.app.formats.comic.ComicArchives
import com.novelreader.app.formats.comic.ComicPages
import com.novelreader.app.formats.comic.EmptyComicException
import com.novelreader.app.formats.comic.RarComicArchive
import com.novelreader.app.formats.comic.ZipComicArchive
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.io.File
import java.io.IOException

class ComicArchiveTest {

    private fun cacheDir(): File = java.nio.file.Files.createTempDirectory("elreader-cache").toFile().also { it.deleteOnExit() }

    private fun zipOf(vararg entries: Pair<String, ByteArray>) = TestFiles.tempFile("c.cbz", TestFiles.zip(entries.toList()))

    // ---- CBZ ---------------------------------------------------------------------------------------------

    @Test fun cbzPagesComeInNaturalOrder() {
        val red = TestFiles.png(4, 4, 255, 0, 0); val green = TestFiles.png(4, 4, 0, 255, 0); val blue = TestFiles.png(4, 4, 0, 0, 255)
        val f = zipOf("page10.png" to blue, "page2.png" to green, "page1.png" to red)   // stored out of order on purpose
        ZipComicArchive(f).use { a ->
            assertEquals(3, a.pageCount)
            assertEquals(listOf("page1.png", "page2.png", "page10.png"), (0 until 3).map { a.pageName(it) })
            assertEquals(255, readPngInfo(a.openPage(0).readBytes()).r)
            assertEquals(255, readPngInfo(a.openPage(1).readBytes()).g)
            assertEquals(255, readPngInfo(a.openPage(2).readBytes()).b)
            assertEquals(3, a.readyCount.value)
            assertTrue(a.isReady(2))
            assertFalse(a.isReady(3))
            assertNull(a.failure)
        }
    }

    @Test fun cbzFoldersJunkAndNonImagesAreSkipped() {
        val p = TestFiles.png(2, 2, 1, 2, 3)
        val f = zipOf(
            "Chapter 2/1.jpg" to p, "Chapter 1/10.png" to p, "Chapter 1/2.png" to p, "Chapter 1/1.webp" to p,
            "__MACOSX/Chapter 1/._1.png" to p, ".hidden.png" to p, "Thumbs.db" to "x".toByteArray(),
            "notes.txt" to "hi".toByteArray(), "cover.GIF" to p,
        )
        ZipComicArchive(f).use { a ->
            val names = (0 until a.pageCount).map { a.pageName(it) }
            assertEquals(listOf("Chapter 1/1.webp", "Chapter 1/2.png", "Chapter 1/10.png", "Chapter 2/1.jpg", "cover.GIF"), names)
        }
    }

    @Test fun traversalNamesNeverBecomePages() {
        val p = TestFiles.png(2, 2, 1, 2, 3)
        val f = zipOf("../evil.png" to p, "a/../../evil2.png" to p, "/abs.png" to p, "C:\\win.png" to p, "good.png" to p)
        ZipComicArchive(f).use { a ->
            assertEquals(listOf("good.png"), (0 until a.pageCount).map { a.pageName(it) })
        }
        assertFalse(ComicPages.isSafeName("../x.png"))
        assertFalse(ComicPages.isSafeName("a\\..\\..\\x.png"))
        assertFalse(ComicPages.isSafeName("/etc/passwd"))
        assertFalse(ComicPages.isSafeName("D:/x.png"))
        assertFalse(ComicPages.isSafeName("a\u0000.png"))
        assertTrue(ComicPages.isSafeName("Chapter 1/dots/1.png"))
        assertTrue(ComicPages.isSafeName("a..b/1.png"))
    }

    @Test fun comicInfoIsParsed() {
        val p = TestFiles.png(2, 2, 1, 2, 3)
        val xml = "<?xml version=\"1.0\"?><ComicInfo><Series>Great &amp; Co</Series><Number>3</Number><Writer>Ann &lt;A&gt;</Writer><Manga>YesAndRightToLeft</Manga></ComicInfo>"
        ZipComicArchive(zipOf("1.png" to p, "ComicInfo.xml" to xml.toByteArray())).use { a ->
            val info = a.info!!
            assertEquals(true, info.rightToLeft)
            assertEquals("Ann <A>", info.writer)
            assertEquals("Great & Co #3", info.displayTitle)
            assertEquals(1, a.pageCount)         // ComicInfo.xml is not a page
        }
        ZipComicArchive(zipOf("1.png" to p, "comicinfo.XML" to "<ComicInfo><Manga>No</Manga></ComicInfo>".toByteArray())).use { a ->
            assertEquals(false, a.info!!.rightToLeft)
        }
        ZipComicArchive(zipOf("1.png" to p, "ComicInfo.xml" to "garbage".toByteArray())).use { a -> assertNull(a.info) }
        ZipComicArchive(zipOf("1.png" to p)).use { a -> assertNull(a.info) }
    }

    @Test fun zipWithoutPagesIsEmpty() {
        try {
            ZipComicArchive(zipOf("readme.txt" to "hi".toByteArray())).close()
            fail("expected EmptyComicException")
        } catch (_: EmptyComicException) { }
    }

    @Test fun notAZipFailsCleanly() {
        try {
            ZipComicArchive(TestFiles.tempFile("x.cbz", ByteArray(500) { 7 })).close()
            fail("expected IOException")
        } catch (_: IOException) { }
    }

    @Test fun badPageIndexIsAnIoError() {
        ZipComicArchive(zipOf("1.png" to TestFiles.png(2, 2, 1, 1, 1))).use { a ->
            try { a.openPage(5); fail() } catch (_: IOException) { }
            try { a.openPage(-1); fail() } catch (_: IOException) { }
        }
    }

    @Test fun naturalOrderHandlesLeadingZerosAndCase() {
        val names = listOf("Page 10.png", "page 2.png", "Page 01.png", "page 1a.png")
        assertEquals(listOf("Page 01.png", "page 1a.png", "page 2.png", "Page 10.png"), names.sortedWith(ComicPages.order))
    }

    // ---- CBR (junrar, hand-built RAR4 fixtures) ---------------------------------------------------------------

    private fun resourceFile(name: String): File = TestFiles.tempFile(name, TestFiles.resource("/comics/$name"))

    private fun checkRarPages(a: RarComicArchive) {
        assertEquals(
            listOf("Chapter 1/page1.png", "Chapter 1/page2.png", "Chapter 1/page10.png", "Chapter 2/page1.png"),
            (0 until a.pageCount).map { a.pageName(it) },
        )
        val first = readPngInfo(a.openPage(0).readBytes())
        assertEquals(PngInfo(8, 12, 30, 30, 200), first)
        assertEquals(PngInfo(8, 12, 200, 30, 30), readPngInfo(a.openPage(1).readBytes()))
        assertEquals(PngInfo(8, 12, 30, 200, 30), readPngInfo(a.openPage(2).readBytes()))
        assertEquals(PngInfo(12, 8, 200, 200, 30), readPngInfo(a.openPage(3).readBytes()))
        assertEquals(4, a.readyCount.value)
        assertNull(a.failure)
        val info = a.info!!
        assertEquals("Test & Co", info.title)
        assertEquals("Ann", info.writer)
        assertEquals(true, info.rightToLeft)
    }

    @Test fun rarStoredArchiveOpens() {
        RarComicArchive(resourceFile("stored.rar"), cacheDir()).use { checkRarPages(it) }
    }

    @Test fun rarSolidArchiveOpensInAnyRequestOrder() {
        val a = RarComicArchive(resourceFile("solid.rar"), cacheDir())
        a.use {
            // Ask for the last page first: a solid archive must still deliver every page correctly.
            assertEquals(PngInfo(12, 8, 200, 200, 30), readPngInfo(it.openPage(3).readBytes()))
            checkRarPages(it)
        }
    }

    @Test fun rarPagesAreCachedUnderIndexNamesOnly() {
        val dir = cacheDir()
        RarComicArchive(resourceFile("stored.rar"), dir).use { a ->
            for (i in 0 until a.pageCount) a.openPage(i).close()
        }
        val names = dir.list().orEmpty().toSet()
        assertEquals(setOf("0.img", "1.img", "2.img", "3.img"), names)
    }

    @Test fun rarSecondOpenReusesUnpackedPages() {
        val dir = cacheDir()
        val f = resourceFile("stored.rar")
        RarComicArchive(f, dir).use { a -> for (i in 0 until a.pageCount) a.openPage(i).close() }
        RarComicArchive(f, dir).use { a ->
            assertEquals(4, a.readyCount.value)
            assertTrue(a.isReady(0) && a.isReady(3))
            assertEquals(PngInfo(8, 12, 30, 30, 200), readPngInfo(a.openPage(0).readBytes()))
        }
    }

    @Test fun truncatedRarFailsCleanlyOrDegrades() {
        val bytes = TestFiles.resource("/comics/stored.rar")
        val f = TestFiles.tempFile("t.cbr", bytes.copyOf(bytes.size / 3))
        try {
            RarComicArchive(f, cacheDir()).use { a ->
                // Whatever survived must still be readable or fail with IOException, never hang or crash.
                for (i in 0 until a.pageCount) try { a.openPage(i).close() } catch (_: IOException) { }
            }
        } catch (_: IOException) {
            // also acceptable: the archive is rejected up front
        } catch (_: EmptyComicException) { }
    }

    @Test fun notARarFailsCleanly() {
        try {
            RarComicArchive(TestFiles.tempFile("x.cbr", ByteArray(300) { 9 }), cacheDir()).close()
            fail("expected IOException")
        } catch (_: IOException) { }
    }

    @Test fun factoryPicksReaderByFormat() {
        val z = zipOf("1.png" to TestFiles.png(2, 2, 1, 1, 1))
        ComicArchives.open(z, BookFormat.CBZ, cacheDir()).use { assertEquals(BookFormat.CBZ, it.format) }
        ComicArchives.open(resourceFile("stored.rar"), BookFormat.CBR, cacheDir()).use { assertEquals(BookFormat.CBR, it.format) }
    }
}
