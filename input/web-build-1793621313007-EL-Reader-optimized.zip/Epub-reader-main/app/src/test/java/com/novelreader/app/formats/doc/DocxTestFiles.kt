package com.novelreader.app.formats.doc

import com.novelreader.app.formats.TestFiles
import org.kxml2.io.KXmlParser
import org.xmlpull.v1.XmlPullParser
import java.io.File

/** Builds small but real .docx files (a ZIP of XML parts) for the parser tests. */
object DocxTestFiles {

    const val W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
    private const val R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
    private const val REL = "http://schemas.openxmlformats.org/package/2006/relationships"

    /** The parser as the JVM tests use it: kxml2, namespace-aware (on the device the platform's own parser does this). */
    fun parser(): DocxParser = DocxParser {
        val p: XmlPullParser = KXmlParser()
        p.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, true)
        p
    }

    fun document(body: String, extraNs: String = ""): String =
        "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<w:document xmlns:w=\"$W\" xmlns:r=\"$R\" xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" " +
            "xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:pic=\"http://schemas.openxmlformats.org/drawingml/2006/picture\" " +
            "xmlns:m=\"http://schemas.openxmlformats.org/officeDocument/2006/math\" $extraNs><w:body>$body</w:body></w:document>"

    fun p(text: String, rpr: String = "", ppr: String = ""): String =
        "<w:p>" + (if (ppr.isNotEmpty()) "<w:pPr>$ppr</w:pPr>" else "") + run(text, rpr) + "</w:p>"

    fun run(text: String, rpr: String = ""): String =
        "<w:r>" + (if (rpr.isNotEmpty()) "<w:rPr>$rpr</w:rPr>" else "") + "<w:t xml:space=\"preserve\">${escape(text)}</w:t></w:r>"

    fun escape(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    /**
     * A .docx whose body is [body]. [extra] adds or replaces parts (name to bytes); [rels] are extra relationships
     * of the main part, as (id, type suffix, target, external).
     */
    fun docx(
        body: String,
        styles: String? = null,
        numbering: String? = null,
        rels: List<RelSpec> = emptyList(),
        extra: List<Pair<String, ByteArray>> = emptyList(),
        title: String? = null,
        name: String = "test.docx",
    ): File {
        val parts = ArrayList<Pair<String, ByteArray>>()
        parts += "[Content_Types].xml" to "<?xml version=\"1.0\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"/>".toByteArray()
        parts += "_rels/.rels" to ("<?xml version=\"1.0\"?><Relationships xmlns=\"$REL\"><Relationship Id=\"rId1\" " +
            "Type=\"$R/officeDocument\" Target=\"word/document.xml\"/></Relationships>").toByteArray()
        val relXml = StringBuilder("<?xml version=\"1.0\"?><Relationships xmlns=\"$REL\">")
        if (styles != null) relXml.append("<Relationship Id=\"rIdS\" Type=\"$R/styles\" Target=\"styles.xml\"/>")
        if (numbering != null) relXml.append("<Relationship Id=\"rIdN\" Type=\"$R/numbering\" Target=\"numbering.xml\"/>")
        for (r in rels) {
            relXml.append("<Relationship Id=\"${r.id}\" Type=\"$R/${r.type}\" Target=\"${escape(r.target)}\"")
            if (r.external) relXml.append(" TargetMode=\"External\"")
            relXml.append("/>")
        }
        relXml.append("</Relationships>")
        parts += "word/_rels/document.xml.rels" to relXml.toString().toByteArray()
        parts += "word/document.xml" to document(body).toByteArray()
        if (styles != null) parts += "word/styles.xml" to styles.toByteArray()
        if (numbering != null) parts += "word/numbering.xml" to numbering.toByteArray()
        if (title != null) {
            parts += "docProps/core.xml" to ("<?xml version=\"1.0\"?><cp:coreProperties xmlns:cp=\"http://schemas.openxmlformats.org/package/2006/metadata/core-properties\" " +
                "xmlns:dc=\"http://purl.org/dc/elements/1.1/\"><dc:title>${escape(title)}</dc:title></cp:coreProperties>").toByteArray()
        }
        parts += extra
        return TestFiles.tempFile(name, TestFiles.zip(parts))
    }

    class RelSpec(val id: String, val type: String, val target: String, val external: Boolean = false)

    fun styles(vararg styleXml: String, defaults: String = ""): String =
        "<?xml version=\"1.0\"?><w:styles xmlns:w=\"$W\">$defaults${styleXml.joinToString("")}</w:styles>"

    fun style(id: String, name: String, ppr: String = "", rpr: String = "", basedOn: String? = null, type: String = "paragraph"): String =
        "<w:style w:type=\"$type\" w:styleId=\"$id\"><w:name w:val=\"$name\"/>" +
            (if (basedOn != null) "<w:basedOn w:val=\"$basedOn\"/>" else "") +
            (if (ppr.isNotEmpty()) "<w:pPr>$ppr</w:pPr>" else "") + (if (rpr.isNotEmpty()) "<w:rPr>$rpr</w:rPr>" else "") + "</w:style>"
}
