package com.novelreader.app.formats.doc

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DocSearchTest {

    private fun starts(texts: List<String>, q: String) = DocSearch.search(texts, q).map { it.block to it.start }

    /** Every hit must point at the original characters (offsets are into the unfolded text). */
    private fun matched(texts: List<String>, q: String) = DocSearch.search(texts, q).map { texts[it.block].substring(it.start, it.end) }

    @Test fun caseInsensitiveWithOriginalOffsets() {
        val t = listOf("Hello World, hello world")
        assertEquals(listOf(0 to 6, 0 to 19), starts(t, "WORLD"))
        assertEquals(listOf("World", "world"), matched(t, "world"))
    }

    @Test fun persianVariantsMatch() {
        // Arabic yeh / kaf in the text, Persian ones in the query and the other way round.
        assertEquals(listOf("كتاب"), matched(listOf("این كتاب خوب است"), "کتاب"))
        assertEquals(listOf("دنيا"), matched(listOf("سلام دنيا"), "دنیا"))
        assertEquals(listOf("کتاب"), matched(listOf("این کتاب"), "كتاب"))
    }

    @Test fun digitsOfAllScriptsAreEqual() {
        val t = listOf("فصل ۱۲ و Chapter 12 و ١٢")
        assertEquals(3, DocSearch.search(t, "12").size)
        assertEquals(3, DocSearch.search(t, "۱۲").size)
    }

    @Test fun zeroWidthNonJoinerEqualsASpace() {
        assertEquals(1, DocSearch.search(listOf("او می‌خواند"), "می خواند").size)
        assertEquals(1, DocSearch.search(listOf("او می خواند"), "می‌خواند").size)
    }

    @Test fun diacriticsAndTatweelAreIgnored() {
        assertEquals(listOf("كِتَاب"), matched(listOf("هذا كِتَابٌ جيد"), "كتاب"))
        assertEquals(1, DocSearch.search(listOf("سلامــــ"), "سلام").size)
    }

    @Test fun offsetsStayCorrectAfterIgnoredCharacters() {
        // Tatweel and vowel marks are skipped while matching, but the hit still points at the original characters.
        val t = listOf("ـَكِتابٌ و کتاب")
        val hits = DocSearch.search(t, "کتاب")
        assertEquals(listOf(2 to 7, 11 to 15), hits.map { it.start to it.end })
        assertEquals(listOf("كِتاب", "کتاب"), hits.map { t[0].substring(it.start, it.end) })
    }

    @Test fun severalMatchesInOneBlockAndAcrossBlocks() {
        val t = listOf("aa aa", "no", "aa")
        assertEquals(listOf(0 to 0, 0 to 3, 2 to 0), starts(t, "aa"))
    }

    @Test fun aPhraseNeverSpansTwoBlocks() {
        assertTrue(DocSearch.search(listOf("end of one", "start of two"), "one start").isEmpty())
    }

    @Test fun emptyOrBlankQueryFindsNothing() {
        assertTrue(DocSearch.search(listOf("text"), "").isEmpty())
        assertTrue(DocSearch.search(listOf("text"), "   ").isEmpty())
    }

    @Test fun theLimitCapsTheResult() {
        val t = listOf("a ".repeat(5000))
        assertEquals(100, DocSearch.search(t, "a", limit = 100).size)
    }

    @Test fun snippetsCarryContext() {
        val text = "x".repeat(100) + " needle " + "y".repeat(100)
        val h = DocSearch.search(listOf(text), "needle").single()
        assertTrue(h.snippet.startsWith("…") && h.snippet.endsWith("…") && h.snippet.contains("needle"))
        assertEquals("short needle text", DocSearch.search(listOf("short needle text"), "needle").single().snippet)
    }

    @Test fun surrogatePairsAndPunctuationAreSafe() {
        assertEquals(1, DocSearch.search(listOf("emoji 😀 here (and) [there]"), "(and)").size)
        assertEquals(1, DocSearch.search(listOf("emoji 😀 here"), "😀").size)
    }

    @Test fun aLargeBookIsSearchedQuickly() {
        val t = List(60_000) { "پاراگراف شماره $it از یک کتاب بلند با کلمه‌های فارسی و English words." }
        val t0 = System.nanoTime()
        val n = DocSearch.search(t, "کتاب", limit = 100_000).size
        val ms = (System.nanoTime() - t0) / 1_000_000
        assertEquals(60_000, n)
        assertTrue("took $ms ms", ms < 6000)
    }
}
