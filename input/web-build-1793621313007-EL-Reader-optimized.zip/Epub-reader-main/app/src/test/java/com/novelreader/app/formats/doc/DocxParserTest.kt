package com.novelreader.app.formats.doc

import com.novelreader.app.formats.TestFiles
import com.novelreader.app.formats.doc.DocxTestFiles.RelSpec
import com.novelreader.app.formats.doc.DocxTestFiles.W
import com.novelreader.app.formats.doc.DocxTestFiles.p
import com.novelreader.app.formats.doc.DocxTestFiles.run
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.io.File

/** The .docx reader on real .docx packages (ZIP + XML parts) built in memory. */
class DocxParserTest {

    private class Parsed(val result: DocParseResult, val html: String)

    private fun parse(f: File): Parsed {
        val sb = StringBuilder()
        val r = DocxTestFiles.parser().parse(f, sb)
        return Parsed(r, sb.toString())
    }

    private fun parse(body: String, styles: String? = null, numbering: String? = null, rels: List<RelSpec> = emptyList(), extra: List<Pair<String, ByteArray>> = emptyList(), title: String? = null) =
        parse(DocxTestFiles.docx(body, styles, numbering, rels, extra, title))

    /** The block contract: element `data-i="n"` has exactly the text texts[n], and every index 0 until n is present. */
    private fun assertContract(x: Parsed) {
        val re = Regex("<(p|h[1-6]|li)\\b[^>]*data-i=\"(\\d+)\"[^>]*>(.*?)</\\1>", RegexOption.DOT_MATCHES_ALL)
        val found = re.findAll(x.html).toList()
        assertEquals("block count", x.result.texts.size, found.size)
        found.forEachIndexed { i, m ->
            assertEquals(i, m.groupValues[2].toInt())
            val text = m.groupValues[3].replace(Regex("<[^>]+>"), "").replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&amp;", "&")
            assertEquals("text of block $i", x.result.texts[i], text)
        }
    }

    private val png = TestFiles.png(4, 2, 255, 0, 0)

    private fun imageParagraph(rid: String, cx: Int = 1905000) =
        "<w:p><w:r><w:drawing><wp:inline><wp:extent cx=\"$cx\" cy=\"952500\"/><a:graphic><a:graphicData><pic:pic><pic:blipFill>" +
            "<a:blip r:embed=\"$rid\"/></pic:blipFill></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>"

    // ---- text, formatting, headings ----

    @Test fun plainParagraphsAndTitle() {
        val x = parse(p("First paragraph.") + p("Second <one> & more."), title = "My Title")
        assertEquals(listOf("First paragraph.", "Second <one> & more."), x.result.texts)
        assertEquals("My Title", x.result.title)
        assertFalse(x.html.contains("<one>"))
        assertContract(x)
    }

    @Test fun characterFormatting() {
        val x = parse(
            "<w:p>" + run("Bold ", "<w:b/>") + run("italic ", "<w:i/>") + run("under ", "<w:u w:val=\"single\"/>") +
                run("red ", "<w:color w:val=\"FF0000\"/>") + run("strike", "<w:strike/>") + "</w:p>",
        )
        assertTrue(x.html.contains("<b>Bold </b>"))
        assertTrue(x.html.contains("<i>italic </i>"))
        assertTrue(x.html.contains("<u>under </u>"))
        assertTrue(x.html.contains("color:#FF0000"))
        assertTrue(x.html.contains("<s>strike</s>"))
        assertEquals("Bold italic under red strike", x.result.texts.single())
        assertContract(x)
    }

    @Test fun turningAFormatOffWithValFalse() {
        val x = parse("<w:p>" + run("plain", "<w:b w:val=\"0\"/><w:i w:val=\"false\"/>") + "</w:p>")
        assertFalse(x.html.contains("<b>") || x.html.contains("<i>"))
    }

    @Test fun sizeHighlightFontSuperscriptTabAndBreak() {
        val x = parse(
            "<w:p><w:r><w:rPr><w:sz w:val=\"40\"/><w:highlight w:val=\"yellow\"/><w:rFonts w:ascii=\"Arial\"/></w:rPr><w:t>big</w:t></w:r>" +
                "<w:r><w:rPr><w:vertAlign w:val=\"superscript\"/></w:rPr><w:t>2</w:t></w:r>" +
                "<w:r><w:t>a</w:t><w:tab/><w:t>b</w:t><w:br/><w:t>c</w:t></w:r></w:p>",
            styles = DocxTestFiles.styles(defaults = "<w:docDefaults><w:rPrDefault><w:rPr><w:sz w:val=\"22\"/></w:rPr></w:rPrDefault></w:docDefaults>"),
        )
        assertTrue(x.html.contains("font-size:1.82em"))          // 20 pt on an 11 pt body
        assertTrue(x.html.contains("background:#FFFF00"))
        assertTrue(x.html.contains("Arial"))
        assertTrue(x.html.contains("<sup>2</sup>"))
        assertEquals("big2a\tb\nc", x.result.texts.single())     // tab and line break are real characters in the block text
        assertContract(x)
    }

    @Test fun headingsMakeTheOutline() {
        val styles = DocxTestFiles.styles(
            DocxTestFiles.style("Heading1", "heading 1", "<w:outlineLvl w:val=\"0\"/>", "<w:b/><w:sz w:val=\"32\"/>"),
            DocxTestFiles.style("Heading2", "heading 2", "<w:outlineLvl w:val=\"1\"/>", "<w:b/>", basedOn = "Heading1"),
        )
        val x = parse(
            p("Body") + p("Chapter One", ppr = "<w:pStyle w:val=\"Heading1\"/>") + p("text") + p("Section", ppr = "<w:pStyle w:val=\"Heading2\"/>"),
            styles = styles,
        )
        assertEquals(listOf("Chapter One", "Section"), x.result.outline.map { it.title })
        assertEquals(listOf(1, 2), x.result.outline.map { it.level })
        assertEquals(listOf(1, 3), x.result.outline.map { it.block })
        assertTrue(x.html.contains("<h1 class=\"b hd\""))
        assertTrue(x.html.contains("<h2 class=\"b hd\""))
        assertContract(x)
    }

    @Test fun styleInheritanceReachesTheText() {
        val styles = DocxTestFiles.styles(
            DocxTestFiles.style("Normal", "Normal"),
            DocxTestFiles.style("Quote", "Quote", "<w:ind w:left=\"864\"/>", "<w:i/><w:color w:val=\"404040\"/>", basedOn = "Normal"),
            DocxTestFiles.style("Strong", "Strong", rpr = "<w:b/>", type = "character"),
        )
        val x = parse(
            p("Quoted", ppr = "<w:pStyle w:val=\"Quote\"/>") +
                "<w:p><w:r><w:rPr><w:rStyle w:val=\"Strong\"/></w:rPr><w:t>strong run</w:t></w:r></w:p>",
            styles = styles,
        )
        assertTrue(x.html.contains("<i>Quoted</i>"))
        assertTrue(x.html.contains("color:#404040"))
        assertTrue(x.html.contains("margin-inline-start:min(43pt"))   // 864 twips = 43.2 pt
        assertTrue(x.html.contains("<b>strong run</b>"))
    }

    @Test fun paragraphAlignmentIndentAndSpacing() {
        val x = parse(
            p("Centered", ppr = "<w:jc w:val=\"center\"/>") +
                p("Indented", ppr = "<w:ind w:left=\"720\" w:firstLine=\"360\"/><w:spacing w:before=\"240\" w:after=\"120\"/>"),
        )
        assertTrue(x.html.contains("text-align:center"))
        assertTrue(x.html.contains("margin-inline-start:min(36pt"))
        assertTrue(x.html.contains("text-indent:18pt"))
        assertTrue(x.html.contains("margin-top:"))
        assertTrue(x.html.contains("margin-bottom:"))
    }

    // ---- Persian / English ----

    @Test fun persianParagraphsAreRtlAndTheDocumentToo() {
        val x = parse(p("این یک سند فارسی است", ppr = "<w:bidi/>") + p("و این هم بند دوم است") + p("English line"))
        assertTrue(x.html.contains("dir=\"rtl\" data-i=\"0\""))
        assertTrue(x.html.contains("dir=\"rtl\" data-i=\"1\""))
        assertTrue(x.html.contains("dir=\"ltr\" data-i=\"2\""))
        assertTrue(x.result.rtl)
        assertContract(x)
    }

    @Test fun englishDocumentIsLtr() {
        val x = parse(p("Hello") + p("World"))
        assertFalse(x.result.rtl)
    }

    // ---- lists ----

    private val numbering = "<w:numbering xmlns:w=\"$W\">" +
        "<w:abstractNum w:abstractNumId=\"0\">" +
        "<w:lvl w:ilvl=\"0\"><w:start w:val=\"1\"/><w:numFmt w:val=\"decimal\"/><w:lvlText w:val=\"%1.\"/></w:lvl>" +
        "<w:lvl w:ilvl=\"1\"><w:start w:val=\"1\"/><w:numFmt w:val=\"bullet\"/><w:lvlText w:val=\"•\"/></w:lvl></w:abstractNum>" +
        "<w:num w:numId=\"1\"><w:abstractNumId w:val=\"0\"/></w:num></w:numbering>"

    private fun item(text: String, level: Int, numId: Int = 1) =
        p(text, ppr = "<w:numPr><w:ilvl w:val=\"$level\"/><w:numId w:val=\"$numId\"/></w:numPr>")

    @Test fun numberedAndBulletedLists() {
        val x = parse(item("one", 0) + item("two", 0) + item("sub", 1) + item("three", 0), numbering = numbering)
        assertEquals(listOf("one", "two", "sub", "three"), x.result.texts)   // markers are drawn by CSS, not part of the text
        assertTrue(x.html.contains("data-m=\"1.\""))
        assertTrue(x.html.contains("data-m=\"2.\""))
        assertTrue(x.html.contains("data-m=\"•\""))
        assertTrue(x.html.contains("data-m=\"3.\""))   // the bullet level in between does not reset the first level
        assertContract(x)
    }

    // ---- tables ----

    @Test fun tablesWithSpans() {
        val body = "<w:tbl>" +
            "<w:tr><w:tc><w:tcPr><w:gridSpan w:val=\"2\"/></w:tcPr>" + p("wide") + "</w:tc></w:tr>" +
            "<w:tr><w:tc><w:tcPr><w:vMerge w:val=\"restart\"/></w:tcPr>" + p("a") + "</w:tc><w:tc>" + p("b") + "</w:tc></w:tr>" +
            "<w:tr><w:tc><w:tcPr><w:vMerge/></w:tcPr><w:p/></w:tc><w:tc>" + p("d") + "</w:tc></w:tr></w:tbl>" + p("after")
        val x = parse(body)
        assertEquals(listOf("wide", "a", "b", "d", "after"), x.result.texts)
        assertTrue(x.html.contains("<td colspan=\"2\">"))
        assertTrue(x.html.contains("<td rowspan=\"2\">"))
        assertContract(x)
    }

    @Test fun tableCellShadingKeepsItsColour() {
        val x = parse("<w:tbl><w:tr><w:tc><w:tcPr><w:shd w:val=\"clear\" w:fill=\"FFCC00\"/></w:tcPr>" + p("cell") + "</w:tc></w:tr></w:tbl>")
        assertTrue(x.html.contains("FFCC00"))
    }

    // ---- links ----

    @Test fun externalAndInternalLinks() {
        val body = "<w:p><w:r><w:t>See </w:t></w:r><w:hyperlink r:id=\"rIdL\"><w:r><w:t>the site</w:t></w:r></w:hyperlink>" +
            "<w:r><w:t> and </w:t></w:r><w:hyperlink w:anchor=\"mark\"><w:r><w:t>below</w:t></w:r></w:hyperlink></w:p>" +
            "<w:p><w:bookmarkStart w:id=\"0\" w:name=\"mark\"/><w:r><w:t>Target</w:t></w:r><w:bookmarkEnd w:id=\"0\"/></w:p>"
        val x = parse(body, rels = listOf(RelSpec("rIdL", "hyperlink", "https://example.com/?a=1&b=2", true)))
        assertTrue(x.html.contains("<a data-href=\"https://example.com/?a=1&amp;b=2\">the site</a>"))
        assertTrue(x.html.contains("<a data-a=\"mark\">below</a>"))
        assertEquals(1, x.result.anchors["mark"])
        assertContract(x)
    }

    @Test fun onlySafeLinkSchemesSurvive() {
        val rels = listOf(
            RelSpec("rA", "hyperlink", "javascript:alert(1)", true),
            RelSpec("rB", "hyperlink", "file:///data/data/com.novelreader.app/databases/x", true),
            RelSpec("rC", "hyperlink", "mailto:a@b.c", true),
            RelSpec("rD", "hyperlink", "content://com.android.contacts/contacts", true),
            RelSpec("rE", "hyperlink", "http://example.org", true),
        )
        val links = listOf("rA", "rB", "rC", "rD", "rE").joinToString("") { "<w:hyperlink r:id=\"$it\"><w:r><w:t>$it</w:t></w:r></w:hyperlink>" }
        val x = parse("<w:p>$links</w:p>", rels = rels)
        assertEquals(listOf("mailto:a@b.c", "http://example.org"), Regex("data-href=\"([^\"]*)\"").findAll(x.html).map { it.groupValues[1] }.toList())
        assertEquals("rArBrCrDrE", x.result.texts.single())   // the text of refused links stays
    }

    @Test fun hyperlinkFieldCodes() {
        val body = "<w:p><w:r><w:fldChar w:fldCharType=\"begin\"/></w:r><w:r><w:instrText xml:space=\"preserve\"> HYPERLINK \"https://example.com/x\" </w:instrText></w:r>" +
            "<w:r><w:fldChar w:fldCharType=\"separate\"/></w:r><w:r><w:t>field link</w:t></w:r><w:r><w:fldChar w:fldCharType=\"end\"/></w:r></w:p>"
        val x = parse(body)
        assertTrue(x.html.contains("<a data-href=\"https://example.com/x\">field link</a>"))
        assertEquals("field link", x.result.texts.single())
    }

    // ---- images ----

    @Test fun imagesAreServedFromThePackage() {
        val x = parse(
            p("before") + imageParagraph("rIdI") + p("after") + imageParagraph("rIdI") + imageParagraph("rIdJ"),
            rels = listOf(RelSpec("rIdI", "image", "media/image1.png"), RelSpec("rIdJ", "image", "media/photo.jpeg")),
            extra = listOf("word/media/image1.png" to png, "word/media/photo.jpeg" to ByteArray(20)),
        )
        assertEquals(listOf("word/media/image1.png" to "image/png", "word/media/photo.jpeg" to "image/jpeg"), x.result.images.map { it.entry to it.mime })
        assertEquals(3, Regex("<img src=\"/m/(\\d+)\"").findAll(x.html).count())
        assertEquals(listOf("0", "0", "1"), Regex("<img src=\"/m/(\\d+)\"").findAll(x.html).map { it.groupValues[1] }.toList())   // the same picture is stored once
        assertTrue(x.html.contains("width:200px"))   // 1905000 EMU = 200 px
        // An image paragraph is a block with no text, so the numbering of the blocks around it stays intact.
        assertEquals(listOf("before", "", "after", "", ""), x.result.texts)
        assertContract(x)
    }

    @Test fun unsupportedAndMissingImagesAreReported() {
        val x = parse(
            imageParagraph("rIdE") + imageParagraph("rIdM") + p("text"),
            rels = listOf(RelSpec("rIdE", "image", "media/image1.emf"), RelSpec("rIdM", "image", "media/gone.png")),
            extra = listOf("word/media/image1.emf" to ByteArray(10)),
        )
        assertTrue(x.result.images.isEmpty())
        assertFalse(x.html.contains("<img"))
        val w = x.result.warnings.single { it.kind == DocWarningKind.IMAGES_UNSUPPORTED }
        assertEquals(2, w.count)
    }

    // ---- what is not shown, reported honestly ----

    @Test fun unsupportedPartsAreReportedNotHidden() {
        val body = p("Body") +
            "<w:p><w:r><w:t>with note</w:t></w:r><w:r><w:footnoteReference w:id=\"2\"/></w:r></w:p>" +
            "<w:p><w:r><w:pict><v:shape xmlns:v=\"urn:schemas-microsoft-com:vml\"><v:textbox><w:txbxContent><w:p><w:r><w:t>in box</w:t></w:r></w:p></w:txbxContent></v:textbox></v:shape></w:pict></w:r></w:p>" +
            "<w:p><m:oMath><m:r><m:t>x+1</m:t></m:r></m:oMath></w:p>"
        val x = parse(
            body,
            extra = listOf(
                "word/header1.xml" to "<w:hdr xmlns:w=\"$W\"><w:p><w:r><w:t>Header text</w:t></w:r></w:p></w:hdr>".toByteArray(),
                "word/footer1.xml" to "<w:ftr xmlns:w=\"$W\"><w:p/></w:ftr>".toByteArray(),   // an empty footer is not worth a warning
            ),
        )
        val kinds = x.result.warnings.associate { it.kind to it.count }
        assertEquals(1, kinds[DocWarningKind.TEXT_BOXES])
        assertEquals(1, kinds[DocWarningKind.EQUATIONS])
        assertEquals(1, kinds[DocWarningKind.HEADERS_FOOTERS])
        assertEquals(1, kinds[DocWarningKind.FOOTNOTES])
        assertFalse(x.result.texts.any { it.contains("in box") })      // not shown, and said so
        assertTrue(x.result.texts.contains("x+1"))                      // equations are flattened to their text
        assertContract(x)
    }

    @Test fun aCleanDocumentHasNoWarnings() {
        assertTrue(parse(p("just text")).result.warnings.isEmpty())
    }

    // ---- review marks and content controls ----

    @Test fun trackedChangesShowTheAcceptedText() {
        val body = "<w:p><w:r><w:t xml:space=\"preserve\">Keep </w:t></w:r>" +
            "<w:ins w:id=\"1\" w:author=\"a\"><w:r><w:t>added </w:t></w:r></w:ins>" +
            "<w:del w:id=\"2\" w:author=\"a\"><w:r><w:delText>removed </w:delText></w:r></w:del>" +
            "<w:r><w:t>end</w:t></w:r></w:p>"
        val x = parse(body)
        assertEquals("Keep added end", x.result.texts.single())
        assertContract(x)
    }

    @Test fun contentControlsKeepTheirContent() {
        val body = "<w:sdt><w:sdtPr/><w:sdtContent>" + p("inside a control") + "</w:sdtContent></w:sdt>" +
            "<w:p><w:sdt><w:sdtContent><w:r><w:t>inline control</w:t></w:r></w:sdtContent></w:sdt></w:p>"
        val x = parse(body)
        assertEquals(listOf("inside a control", "inline control"), x.result.texts)
    }

    // ---- bad input ----

    private fun failure(f: File): DocxException.Reason {
        try { parse(f) } catch (e: DocxException) { return e.reason }
        fail("expected a DocxException")
        throw AssertionError()
    }

    @Test fun notAZipFile() {
        assertEquals(DocxException.Reason.NOT_DOCX, failure(TestFiles.tempFile("a.docx", "plain text, not a zip".toByteArray())))
    }

    @Test fun aZipWithoutADocument() {
        assertEquals(DocxException.Reason.NOT_DOCX, failure(TestFiles.tempFile("b.docx", TestFiles.zip(listOf("foo.txt" to "x".toByteArray())))))
    }

    @Test fun brokenXml() {
        val broken = TestFiles.tempFile("c.docx", TestFiles.zip(listOf("word/document.xml" to "<w:document xmlns:w=\"$W\"><w:body><w:p><w:r><w:t>x".toByteArray())))
        assertEquals(DocxException.Reason.CORRUPT, failure(broken))
    }

    @Test fun anEmptyBodyGivesAnEmptyResult() {
        val x = parse("")
        assertTrue(x.result.texts.isEmpty())
    }

    @Test fun aTruncatedZipIsRefusedNotCrashed() {
        val whole = TestFiles.zip(listOf("word/document.xml" to DocxTestFiles.document(p("hello")).toByteArray()))
        val cut = TestFiles.tempFile("d.docx", whole.copyOf(whole.size / 2))
        try { parse(cut); fail("a half zip must not parse") } catch (e: DocxException) { assertNotNull(e.reason) } catch (e: java.io.IOException) { }
    }

    @Test fun hostileTextCannotInjectMarkup() {
        val x = parse(p("<img src=x onerror=alert(1)>\"'</p><script>alert(2)</script>"))
        assertFalse(x.html.contains("<script"))
        assertFalse(x.html.contains("<img src=x"))
        assertContract(x)
    }

    @Test fun controlCharactersInTextAreRemoved() {
        val x = parse("<w:p><w:r><w:t>a&#1;b&#2;c</w:t></w:r></w:p>".let { it })
        // XML 1.0 forbids these characters, so the parser may refuse the file or drop them; it must never keep them.
        assertFalse(x.result.texts.any { t -> t.any { it.code < 0x20 && it != '\t' && it != '\n' } })
    }

    @Test fun aLargeDocumentParsesInReasonableTime() {
        val body = StringBuilder()
        repeat(20_000) { i -> body.append(p("Paragraph number $i with some words. این یک بند فارسی است.")) }
        val f = DocxTestFiles.docx(body.toString())
        val t0 = System.nanoTime()
        val x = parse(f)
        val ms = (System.nanoTime() - t0) / 1_000_000
        assertEquals(20_000, x.result.texts.size)
        assertTrue("took $ms ms", ms < 8000)
    }
}
