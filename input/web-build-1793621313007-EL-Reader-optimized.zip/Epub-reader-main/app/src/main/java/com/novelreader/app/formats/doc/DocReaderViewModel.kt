package com.novelreader.app.formats.doc

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.novelreader.app.data.AnnotationStyle
import com.novelreader.app.data.HighlightEntity
import com.novelreader.app.formats.BookFormat
import com.novelreader.app.formats.DocRange
import com.novelreader.app.formats.DocSettings
import com.novelreader.app.formats.DocSettingsRepository
import com.novelreader.app.formats.FormatLocator
import com.novelreader.app.formats.FormatReaderViewModel
import com.novelreader.app.formats.TextBookOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.IOException

enum class DocFailure { MISSING, CORRUPT, TOO_LARGE, EMPTY }

sealed interface DocLoadState {
    data object Loading : DocLoadState
    data class Failed(val reason: DocFailure) : DocLoadState
    class Ready(val page: DocPage, val title: String, val format: BookFormat) : DocLoadState {
        val blockCount: Int get() = page.result.texts.size
    }
}

/** Where to scroll the page: [block] and the fraction [frac] of it above the top edge; [offsetPx] keeps it below the top. */
data class DocJump(val block: Int, val frac: Double = 0.0, val offsetPx: Int = 0)

/** A text selection reported by the page: the text and the (block, start, end) pieces it covers. */
class DocSelection(val text: String, val ranges: List<IntArray>)

/** A saved highlight / underline / note, checked against the text it was made on. */
class DocHighlightItem(val entity: HighlightEntity, val range: DocRange, val valid: Boolean)

/** State of the TXT / DOCX reader: the loaded document, position, search, selection and annotations. */
class DocReaderViewModel(app: Application, bookId: Long, private val startLocator: String?) : FormatReaderViewModel(app, bookId) {

    private val _load = MutableStateFlow<DocLoadState>(DocLoadState.Loading)
    val load: StateFlow<DocLoadState> = _load.asStateFlow()

    private val _settings = MutableStateFlow<DocSettings?>(null)
    val settings: StateFlow<DocSettings?> = _settings.asStateFlow()
    private var repo: DocSettingsRepository? = null

    private val _options = MutableStateFlow(TextBookOptions())
    /** Encoding / paragraph options of this file (text files only). */
    val options: StateFlow<TextBookOptions> = _options.asStateFlow()

    private val _commands = MutableSharedFlow<DocJump>(extraBufferCapacity = 4)
    val commands: SharedFlow<DocJump> = _commands.asSharedFlow()

    private var block = 0
    private var frac = 0.0
    private var firstLoad = true
    private var loadJob: Job? = null
    private var currentPage: DocPage? = null

    private val _blockFlow = MutableStateFlow(0)
    /** Index of the block at the top of the screen (observable form of the reported position). */
    val blockFlow: StateFlow<Int> = _blockFlow.asStateFlow()

    /** The position the page starts at (the last reported one, so a recreated view comes back to the same place). */
    fun currentJump(): DocJump = DocJump(block, frac)

    val format: BookFormat? get() = (load.value as? DocLoadState.Ready)?.format

    init {
        viewModelScope.launch { start() }
    }

    private suspend fun start() {
        val b = graph.library.get(bookId)
        if (b == null) { _load.value = DocLoadState.Failed(DocFailure.MISSING); return }
        val fmt = BookFormat.fromStored(b.format)
        if (!fmt.isDocument) { _load.value = DocLoadState.Failed(DocFailure.CORRUPT); return }
        val r = graph.formatSettings.doc(fmt)
        repo = r
        viewModelScope.launch { r.flow.collect { _settings.value = it } }
        // A changed encoding / paragraph option re-reads the file; the first emission is the initial load.
        viewModelScope.launch {
            r.bookOptions(bookId).distinctUntilChanged().collect { opts ->
                _options.value = opts
                loadJob?.cancel()
                loadJob = viewModelScope.launch { loadDocument(b.title, fmt, opts) }
            }
        }
    }

    private suspend fun loadDocument(title: String, fmt: BookFormat, opts: TextBookOptions) {
        val b = graph.library.get(bookId) ?: run { _load.value = DocLoadState.Failed(DocFailure.MISSING); return }
        val file = graph.library.bookFile(b)
        if (!file.isFile) { _load.value = DocLoadState.Failed(DocFailure.MISSING); return }
        val keepProgress = if (firstLoad) -1.0 else progress
        val failure = withContext(Dispatchers.IO) {
            val body = File(getApplication<Application>().cacheDir, "doc/$bookId-${System.nanoTime()}.html")
            try {
                val page = DocLoader.load(file, fmt, body, opts, title)
                // Replace the previous page only now, so a failed re-read keeps showing the old one.
                val old = currentPage
                currentPage = page
                _load.value = DocLoadState.Ready(page, title, fmt)
                old?.close()
                null
            } catch (e: DocTooLargeException) {
                DocFailure.TOO_LARGE
            } catch (e: EmptyDocException) {
                DocFailure.EMPTY
            } catch (e: DocxException) {
                DocFailure.CORRUPT
            } catch (e: IOException) {
                DocFailure.CORRUPT
            } catch (e: org.xmlpull.v1.XmlPullParserException) {
                DocFailure.CORRUPT
            } catch (e: OutOfMemoryError) {
                DocFailure.TOO_LARGE
            }
        }
        if (failure != null) { if (currentPage == null) _load.value = DocLoadState.Failed(failure); return }
        val page = currentPage ?: return
        val count = page.result.texts.size
        if (firstLoad) {
            firstLoad = false
            val loc = startLocator ?: b.lastLocatorJson
            val doc = FormatLocator.parse(loc) as? FormatLocator.Doc
            val hl = DocRange.parse(loc)
            when {
                doc != null -> { block = doc.block.coerceIn(0, (count - 1).coerceAtLeast(0)); frac = doc.frac }
                hl != null && hl.block in 0 until count -> {
                    block = hl.block
                    val len = page.result.texts[hl.block].length.coerceAtLeast(1)
                    frac = (hl.start.toDouble() / len).coerceIn(0.0, 0.95)
                }
            }
        } else if (keepProgress >= 0) {
            // The block structure may have changed (paragraph option): keep the same place by progress.
            val pos = keepProgress * count
            block = pos.toInt().coerceIn(0, (count - 1).coerceAtLeast(0))
            frac = pos - block
        }
        _blockFlow.value = block
        clearSearch()
    }

    fun updateSettings(transform: (DocSettings) -> DocSettings) {
        val r = repo ?: return
        viewModelScope.launch { r.update(transform) }
    }

    fun updateOptions(transform: (TextBookOptions) -> TextBookOptions) {
        val r = repo ?: return
        viewModelScope.launch { r.updateBookOptions(bookId, transform) }
    }

    // ---- position ----

    /** The page reports the block at the top of the screen and how far into it the top edge is. */
    fun onViewport(b: Int, f: Double) {
        val n = (load.value as? DocLoadState.Ready)?.blockCount ?: return
        if (n <= 0) return
        block = b.coerceIn(0, n - 1)
        _blockFlow.value = block
        frac = f.coerceIn(0.0, 1.0)
        reportPosition((block + frac) / n, FormatLocator.Doc(block, frac).toJson())
    }

    fun goTo(b: Int, f: Double = 0.0, offsetPx: Int = 0) {
        val n = (load.value as? DocLoadState.Ready)?.blockCount ?: return
        _commands.tryEmit(DocJump(b.coerceIn(0, (n - 1).coerceAtLeast(0)), f, offsetPx))
    }

    fun goToProgress(p: Double) {
        val n = (load.value as? DocLoadState.Ready)?.blockCount ?: return
        val pos = p.coerceIn(0.0, 1.0) * n
        goTo(pos.toInt(), pos - pos.toInt())
    }

    /** Internal link target (DOCX bookmark). */
    fun goToAnchor(name: String) {
        val idx = (load.value as? DocLoadState.Ready)?.page?.result?.anchors?.get(name) ?: return
        goTo(idx, 0.0, offsetPx = 24)
    }

    val currentBlock: Int get() = block
    val blockProgress: Double
        get() {
            val n = (load.value as? DocLoadState.Ready)?.blockCount ?: return 0.0
            return if (n <= 0) 0.0 else ((block + frac) / n).coerceIn(0.0, 1.0)
        }

    /** The heading (or chapter) the reader is in at [b], or null. */
    fun chapterAt(b: Int): DocOutline? {
        val o = (load.value as? DocLoadState.Ready)?.page?.result?.outline ?: return null
        var found: DocOutline? = null
        for (e in o) { if (e.block <= b) found = e else break }
        return found
    }

    fun addBookmarkHere(fallbackLabel: String) {
        val label = chapterAt(block)?.title ?: fallbackLabel
        addBookmark(FormatLocator.Doc(block, frac).toJson(), null, label, blockProgress)
    }

    // ---- search ----

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()
    private val _hits = MutableStateFlow<List<DocHit>>(emptyList())
    val hits: StateFlow<List<DocHit>> = _hits.asStateFlow()
    private val _activeHit = MutableStateFlow(-1)
    val activeHit: StateFlow<Int> = _activeHit.asStateFlow()
    private val _searching = MutableStateFlow(false)
    val searching: StateFlow<Boolean> = _searching.asStateFlow()
    private var searchJob: Job? = null

    fun search(text: String) {
        searchJob?.cancel()
        val q = text.trim()
        _query.value = q
        _hits.value = emptyList()
        _activeHit.value = -1
        val ready = load.value as? DocLoadState.Ready ?: return
        if (q.isEmpty()) { _searching.value = false; return }
        _searching.value = true
        val from = block
        searchJob = viewModelScope.launch {
            val found = withContext(Dispatchers.Default) { DocSearch.search(ready.page.result.texts, q) }
            _hits.value = found
            _activeHit.value = if (found.isEmpty()) -1 else found.indexOfFirst { it.block >= from }.let { if (it < 0) 0 else it }
            _searching.value = false
        }
    }

    fun clearSearch() {
        searchJob?.cancel()
        _query.value = ""
        _hits.value = emptyList()
        _activeHit.value = -1
        _searching.value = false
    }

    fun stepHit(delta: Int) {
        val n = _hits.value.size
        if (n == 0) return
        _activeHit.value = ((_activeHit.value.coerceAtLeast(0) + delta) % n + n) % n
    }

    fun openHit(i: Int) { if (i in _hits.value.indices) _activeHit.value = i }

    // ---- selection ----

    private val _selection = MutableStateFlow<DocSelection?>(null)
    val selection: StateFlow<DocSelection?> = _selection.asStateFlow()
    private val _clearSelection = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val clearSelectionRequests: SharedFlow<Unit> = _clearSelection.asSharedFlow()

    /** From the page: the current selection as JSON, or "" when there is none. */
    fun onSelection(json: String) {
        if (json.isEmpty()) { _selection.value = null; return }
        _selection.value = try {
            val o = JSONObject(json)
            val arr = o.getJSONArray("ranges")
            val ranges = ArrayList<IntArray>(arr.length())
            for (i in 0 until arr.length()) {
                val r = arr.getJSONObject(i)
                ranges += intArrayOf(r.getInt("b"), r.getInt("s"), r.getInt("e"))
            }
            if (ranges.isEmpty()) null else DocSelection(o.optString("text"), ranges)
        } catch (_: Exception) {
            null
        }
    }

    fun clearSelection() {
        _selection.value = null
        _clearSelection.tryEmit(Unit)
    }

    // ---- highlights, underlines, notes ----

    private val allHighlights = graph.annotations.highlights(bookId)
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    /** Saved annotations, each checked against the current text (a re-read with other options can move paragraphs). */
    val highlights: StateFlow<List<DocHighlightItem>> = combine(allHighlights, _load) { list, state ->
        val texts = (state as? DocLoadState.Ready)?.page?.result?.texts
        list.mapNotNull { h ->
            val r = DocRange.parse(h.locatorJson) ?: return@mapNotNull null
            if (texts == null) return@mapNotNull DocHighlightItem(h, r, false)
            if (r.slice(texts) == h.text) DocHighlightItem(h, r, true) else relocate(h, r, texts)
        }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    /** A single-paragraph highlight whose place no longer fits is looked up again by its text (the nearest occurrence). */
    private fun relocate(h: HighlightEntity, old: DocRange, texts: List<String>): DocHighlightItem {
        if (h.text.isEmpty() || h.text.contains('\n') || old.endBlock != old.block) return DocHighlightItem(h, old, false)
        var best = -1
        var bestAt = 0
        for (i in texts.indices) {
            val at = texts[i].indexOf(h.text)
            if (at >= 0 && (best < 0 || Math.abs(i - old.block) < Math.abs(best - old.block))) { best = i; bestAt = at }
        }
        return if (best < 0) DocHighlightItem(h, old, false) else DocHighlightItem(h, DocRange(best, bestAt, bestAt + h.text.length), true)
    }

    fun annotateSelection(style: AnnotationStyle, color: Int, note: String?, fallbackLabel: String) {
        val sel = _selection.value ?: return
        val ready = load.value as? DocLoadState.Ready ?: return
        val texts = ready.page.result.texts
        val first = sel.ranges.first()
        val last = sel.ranges.last()
        val range = DocRange(first[0], first[1], last[2], last[0])
        val text = range.slice(texts) ?: return
        val label = chapterAt(first[0])?.title ?: fallbackLabel
        viewModelScope.launch { graph.annotations.addHighlight(bookId, range.toJson(), text, color, label, style, note) }
        clearSelection()
    }

    fun updateHighlight(h: HighlightEntity) { viewModelScope.launch { graph.annotations.updateHighlight(h) } }
    fun deleteHighlight(id: Long) { viewModelScope.launch { graph.annotations.deleteHighlight(id) } }

    private val _editing = MutableStateFlow<Long?>(null)
    /** Id of the annotation whose edit dialog is open. */
    val editing: StateFlow<Long?> = _editing.asStateFlow()
    fun editHighlight(id: Long?) { _editing.value = id }

    override fun onCleared() {
        super.onCleared()
        searchJob?.cancel()
        currentPage?.close()
        currentPage = null
    }

    companion object {
        fun factory(app: Application, bookId: Long, startLocator: String?) = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T = DocReaderViewModel(app, bookId, startLocator) as T
        }
    }
}
