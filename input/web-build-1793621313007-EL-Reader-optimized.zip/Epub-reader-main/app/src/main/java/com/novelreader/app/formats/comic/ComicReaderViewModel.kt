package com.novelreader.app.formats.comic

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.novelreader.app.data.BookEntity
import com.novelreader.app.formats.BookFormat
import com.novelreader.app.formats.ComicDirection
import com.novelreader.app.formats.ComicSettings
import com.novelreader.app.formats.FormatLocator
import com.novelreader.app.formats.FormatReaderViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException

enum class ComicFailure { MISSING, EMPTY, ENCRYPTED, NO_SPACE, CORRUPT }

sealed interface ComicLoad {
    data object Loading : ComicLoad
    data class Failed(val reason: ComicFailure) : ComicLoad
    data class Ready(val title: String, val pageCount: Int) : ComicLoad
}

/** State of the CBZ / CBR reader: the open archive, the page cache, the current page and the commands from the UI. */
class ComicReaderViewModel(app: Application, bookId: Long, private val startLocator: String?) : FormatReaderViewModel(app, bookId) {

    private val _load = MutableStateFlow<ComicLoad>(ComicLoad.Loading)
    val load: StateFlow<ComicLoad> = _load.asStateFlow()

    private val _settings = MutableStateFlow<ComicSettings?>(null)
    val settings: StateFlow<ComicSettings?> = _settings.asStateFlow()

    private var settingsRepo: com.novelreader.app.formats.ComicSettingsRepository? = null

    var archive: ComicArchive? = null
        private set
    var cache: ComicPageCache? = null
        private set

    private val _page = MutableStateFlow(0)
    /** Zero-based page the reader is showing. */
    val page: StateFlow<Int> = _page.asStateFlow()

    private val _pageCount = MutableStateFlow(0)
    val pageCount: StateFlow<Int> = _pageCount.asStateFlow()

    private val _ready = MutableStateFlow(0)
    /** Pages that are unpacked and readable (a CBR becomes readable page by page). */
    val readyCount: StateFlow<Int> = _ready.asStateFlow()

    private val _boundsVersion = MutableStateFlow(0)
    /** Ticks whenever more page sizes are known (two-page spreads depend on which pages are landscape). */
    val boundsVersion: StateFlow<Int> = _boundsVersion.asStateFlow()

    private val _commands = MutableSharedFlow<Int>(extraBufferCapacity = 4)
    /** "Show this page" requests for the UI (go to page, bookmark, thumbnail, slider). */
    val commands: SharedFlow<Int> = _commands.asSharedFlow()

    /** ComicInfo.xml says manga (right-to-left), left-to-right, or nothing. */
    var rtlFromFile: Boolean? = null
        private set

    init {
        viewModelScope.launch { open() }
    }

    private suspend fun open() {
        val b = graph.library.get(bookId)
        if (b == null) { _load.value = ComicLoad.Failed(ComicFailure.MISSING); return }
        val file = graph.library.bookFile(b)
        if (!file.isFile) { _load.value = ComicLoad.Failed(ComicFailure.MISSING); return }
        val format = BookFormat.fromStored(b.format)
        val repo = graph.formatSettings.comic(format)
        settingsRepo = repo
        viewModelScope.launch { repo.flow.collect { _settings.value = it } }

        val cacheRoot = File(getApplication<Application>().cacheDir, "comics")
        val dir = File(cacheRoot, b.sha256.take(32))
        val result = withContext(Dispatchers.IO) {
            trimCaches(cacheRoot, keep = dir, keepCount = 2)
            try {
                ComicArchives.open(file, format, dir)
            } catch (e: EmptyComicException) { ComicFailure.EMPTY }
            catch (e: EncryptedComicException) { ComicFailure.ENCRYPTED }
            catch (e: NoSpaceComicException) { ComicFailure.NO_SPACE }
            catch (e: IOException) { ComicFailure.CORRUPT }
            catch (e: Exception) { ComicFailure.CORRUPT }
        }
        val opened = result as? ComicArchive
        if (opened == null) { _load.value = ComicLoad.Failed(result as ComicFailure); return }
        archive = opened
        cache = ComicPageCache(opened, viewModelScope)
        rtlFromFile = opened.info?.rightToLeft
        _pageCount.value = opened.pageCount
        val start = ((FormatLocator.parse(startLocator ?: b.lastLocatorJson)) as? FormatLocator.Comic)?.page ?: 0
        _page.value = start.coerceIn(0, opened.pageCount - 1)
        _load.value = ComicLoad.Ready(opened.info?.displayTitle ?: b.title, opened.pageCount)

        viewModelScope.launch { opened.readyCount.collect { _ready.value = it } }
        viewModelScope.launch { scanBounds(opened) }
    }

    /** Reads the pixel size of every readable page in the background (cheap: headers only). */
    private suspend fun scanBounds(a: ComicArchive) {
        val c = cache ?: return
        val scanned = BooleanArray(a.pageCount)
        var sinceTick = 0
        a.readyCount.collect { _ ->
            for (i in 0 until a.pageCount) {
                if (scanned[i] || !a.isReady(i)) continue
                c.sizeOf(i)
                scanned[i] = true
                if (++sinceTick >= 64) { sinceTick = 0; _boundsVersion.value++ }
            }
            if (sinceTick > 0) { sinceTick = 0; _boundsVersion.value++ }
        }
    }

    private fun trimCaches(root: File, keep: File, keepCount: Int) {
        val others = root.listFiles { f -> f.isDirectory && f.name != keep.name }?.sortedByDescending { it.lastModified() } ?: return
        // Import leftovers and old books: everything beyond the newest (keepCount - 1) other folders goes.
        others.drop(keepCount - 1).forEach { it.deleteRecursively() }
        keep.mkdirs()
        keep.setLastModified(System.currentTimeMillis())
    }

    /** Effective direction after applying the file's own hint. */
    fun resolveDirection(s: ComicSettings): ComicDirection = when (s.direction) {
        ComicDirection.AUTO -> if (rtlFromFile == true) ComicDirection.RTL else ComicDirection.LTR
        else -> s.direction
    }

    fun updateSettings(transform: (ComicSettings) -> ComicSettings) {
        val repo = settingsRepo ?: return
        viewModelScope.launch { repo.update(transform) }
    }

    fun onPageShown(page: Int) {
        val n = _pageCount.value
        if (n <= 0) return
        val p = page.coerceIn(0, n - 1)
        _page.value = p
        reportPosition(ComicSpreads.progress(p, n), FormatLocator.Comic(p).toJson())
    }

    fun goTo(page: Int) {
        val n = _pageCount.value
        if (n <= 0) return
        _commands.tryEmit(page.coerceIn(0, n - 1))
    }

    fun addBookmarkHere(label: String) {
        val p = _page.value
        addBookmark(FormatLocator.Comic(p).toJson(), null, label, ComicSpreads.progress(p, _pageCount.value))
    }

    fun historyLabel(template: (Int) -> String): String = template(_page.value + 1)

    override fun onCleared() {
        super.onCleared()
        cache?.clear()
        archive?.close()
    }

    companion object {
        fun factory(app: Application, bookId: Long, startLocator: String?) = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T = ComicReaderViewModel(app, bookId, startLocator) as T
        }
    }
}
