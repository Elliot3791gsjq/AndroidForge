package com.novelreader.app.formats.doc

/** Turns decoded plain text into the document model and HTML (pure JVM, unit-tested). */
object TxtParser {

    /** Longest chapter title line that is still taken for a heading. */
    private const val MAX_TITLE = 80

    private const val NUM_EN = "(?:[0-9]+|[ivxlcdm]+|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty|first|second|third|fourth|fifth)"
    private const val NUM_FA = "(?:[0-9۰-۹٠-٩]+|اول|دوم|سوم|چهارم|پنجم|ششم|هفتم|هشتم|نهم|دهم|یازدهم|دوازدهم|سیزدهم|چهاردهم|پانزدهم|شانزدهم|هفدهم|هجدهم|نوزدهم|بیستم|یک|دو|سه|چهار|پنج|شش|هفت|هشت|نه|ده)"

    /** A title line: "Chapter 3", "Part II: ...", "فصل ۲", "第十二章 ...", "제 3 장", or a lone "Prologue" / "مقدمه". */
    private val CHAPTER = Regex(
        "^(?:" +
            "(?:chapter|part|book|volume|act|section)\\s*$NUM_EN(?:[\\s.:\\-–—].{0,60})?" +
            "|(?:prologue|epilogue|interlude|preface|foreword|afterword)(?:[\\s.:\\-–—].{0,50})?" +
            "|(?:فصل|بخش|قسمت|بخشِ)\\s*$NUM_FA(?:[\\s.:\\-–—].{0,60})?" +
            "|(?:مقدمه|پیشگفتار|پایان|پرولوگ|اپیلوگ|سخن آغازین)" +
            "|第\\s*[0-9零一二三四五六七八九十百千两〇]+\\s*[章节節回卷话話集部篇].{0,60}" +
            "|제\\s*\\d+\\s*[장화권부].{0,60}" +
            ")$",
        RegexOption.IGNORE_CASE,
    )

    /**
     * Paragraphs in, markup out. The default direction of the document is the majority direction of the first
     * paragraphs; every block also carries its own direction (first strong letter).
     */
    fun parse(text: String, mode: ParagraphMode, title: String?, out: Appendable): DocParseResult {
        val texts = ArrayList<String>()
        TextParagraphs.split(text, mode) { p -> texts += DocHtml.sanitize(p) }
        // Default direction: majority over a sample of paragraphs.
        var rtlVotes = 0
        var ltrVotes = 0
        for (i in 0 until minOf(texts.size, 200)) {
            val t = texts[i]
            if (t.length < 3) continue
            var has = false
            var j = 0
            while (j < t.length && !has) {
                val cp = t.codePointAt(j); j += Character.charCount(cp)
                when (Character.getDirectionality(cp)) {
                    Character.DIRECTIONALITY_LEFT_TO_RIGHT -> { ltrVotes++; has = true }
                    Character.DIRECTIONALITY_RIGHT_TO_LEFT, Character.DIRECTIONALITY_RIGHT_TO_LEFT_ARABIC -> { rtlVotes++; has = true }
                    else -> {}
                }
            }
        }
        val docRtl = rtlVotes > ltrVotes

        // Chapter headings; one or two matches are more likely a coincidence than a table of contents.
        val isChapter = BooleanArray(texts.size) { i -> val t = texts[i]; t.length <= MAX_TITLE && CHAPTER.matches(t.trim()) }
        val useChapters = isChapter.count { it } >= 2
        val outline = ArrayList<DocOutline>()
        for (i in texts.indices) {
            val t = texts[i]
            val rtl = DocHtml.directionOf(t, docRtl)
            val chapter = useChapters && isChapter[i]
            if (chapter) outline += DocOutline(t.trim(), 1, i)
            out.append("<p class=\"b").append(if (chapter) " ch" else "").append("\" dir=\"").append(if (rtl) "rtl" else "ltr")
                .append("\" data-i=\"").append(i.toString()).append("\">")
            DocHtml.escape(t, out)
            out.append("</p>")
        }
        return DocParseResult(texts, outline, emptyList(), emptyMap(), title, docRtl, emptyList())
    }
}
