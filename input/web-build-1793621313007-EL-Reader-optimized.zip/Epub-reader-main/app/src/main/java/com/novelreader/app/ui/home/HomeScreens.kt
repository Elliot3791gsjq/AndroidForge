@file:OptIn(androidx.compose.animation.ExperimentalSharedTransitionApi::class)

package com.novelreader.app.ui.home

import android.text.format.DateUtils
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.SharedTransitionLayout
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.novelreader.app.R
import com.novelreader.app.data.CustomTheme
import com.novelreader.app.data.GlobalBookmark
import com.novelreader.app.data.GlobalNote
import com.novelreader.app.ui.AppIcons
import com.novelreader.app.ui.design.AppBackdrop
import com.novelreader.app.ui.design.AppCard
import com.novelreader.app.ui.design.AppShapes
import com.novelreader.app.ui.design.EmptyState
import com.novelreader.app.ui.design.FloatingNavBar
import com.novelreader.app.ui.design.MutedText
import com.novelreader.app.ui.design.NavItem
import com.novelreader.app.ui.design.ScreenHeader
import com.novelreader.app.ui.design.Space
import com.novelreader.app.ui.design.bottomClearance
import com.novelreader.app.ui.design.motion
import com.novelreader.app.ui.design.palette
import com.novelreader.app.ui.library.LibraryScreen
import com.novelreader.app.ui.library.LibraryViewModel
import com.novelreader.app.ui.library.SOURCE_GRID
import com.novelreader.app.ui.stats.StatsScreen

enum class HomeScreen { LIBRARY, BOOKMARKS, NOTES, STATS, SETTINGS }

/** One destination of the root navigation: a tab, or a book's detail page opened from the library. */
private data class Route(val screen: HomeScreen, val detailId: Long? = null, val source: String = SOURCE_GRID)

/** What the theme editor was opened for: a new theme (null) or an existing custom theme. */
private class ThemeEditorRequest(val theme: CustomTheme?)

/**
 * Root of the library activity: floating bottom navigation (Library / Bookmarks / Notes / Settings), animated
 * tab transitions, and a book-detail page whose cover is a shared element with the library card.
 */
@Composable
fun AppRoot(
    vm: LibraryViewModel,
    onOpenBook: (Long) -> Unit,
    onOpenAt: (Long, String) -> Unit,
    onPickBooks: () -> Unit,
    onPickFolder: () -> Unit,
    snackbar: SnackbarHostState,
) {
    var screen by rememberSaveable { mutableStateOf(HomeScreen.LIBRARY) }
    var detailId by rememberSaveable { mutableStateOf<Long?>(null) }
    var detailSource by rememberSaveable { mutableStateOf(SOURCE_GRID) }
    var editor by remember { mutableStateOf<ThemeEditorRequest?>(null) }
    val route = Route(screen, detailId, detailSource)
    val mo = motion
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    val p = palette

    BackHandler(enabled = editor != null) { editor = null }
    BackHandler(enabled = editor == null && detailId != null) { detailId = null }
    BackHandler(enabled = editor == null && detailId == null && screen != HomeScreen.LIBRARY) { screen = HomeScreen.LIBRARY }

    val navItems = listOf(
        NavItem(stringResource(R.string.nav_library), AppIcons.MenuBook),
        NavItem(stringResource(R.string.nav_bookmarks), AppIcons.Bookmark),
        NavItem(stringResource(R.string.nav_notes), AppIcons.Notes),
        NavItem(stringResource(R.string.nav_stats), AppIcons.BarChart),
        NavItem(stringResource(R.string.nav_settings), AppIcons.Tune),
    )

    SharedTransitionLayout {
        CompositionLocalProvider(LocalSharedTransitionScope provides this) {
            AppBackdrop {
                AnimatedContent(
                    targetState = route,
                    transitionSpec = {
                        val toDetail = targetState.detailId != null
                        val fromDetail = initialState.detailId != null
                        when {
                            toDetail && !fromDetail ->
                                (fadeIn(mo.medium()) + slideInVertically(mo.medium()) { it / 14 }) togetherWith fadeOut(mo.fast())
                            !toDetail && fromDetail ->
                                fadeIn(mo.medium()) togetherWith (fadeOut(mo.fast()) + slideOutVertically(mo.fast()) { it / 14 })
                            else -> {
                                val forward = targetState.screen.ordinal > initialState.screen.ordinal
                                val dir = (if (forward) 1 else -1) * (if (rtl) -1 else 1)
                                (fadeIn(mo.medium()) + slideInHorizontally(mo.medium()) { dir * it / 10 }) togetherWith
                                    (fadeOut(mo.fast()) + slideOutHorizontally(mo.fast()) { -dir * it / 10 })
                            }
                        }
                    },
                    label = "route",
                ) { r ->
                    CompositionLocalProvider(LocalContentVisibilityScope provides this) {
                        if (r.detailId != null) {
                            BookDetailScreen(
                                vm = vm, bookId = r.detailId, source = r.source,
                                onBack = { detailId = null },
                                onRead = { onOpenBook(it) },
                            )
                        } else when (r.screen) {
                            HomeScreen.LIBRARY -> LibraryScreen(
                                vm = vm, onOpenBook = onOpenBook,
                                onOpenDetail = { id, src -> detailSource = src; detailId = id },
                                onPickBooks = onPickBooks,
                                onPickFolder = onPickFolder,
                            )
                            HomeScreen.BOOKMARKS -> BookmarksScreen(vm, onOpenAt)
                            HomeScreen.NOTES -> NotesScreen(vm, onOpenAt)
                            HomeScreen.STATS -> StatsScreen(vm, onOpenDetail = { id -> detailSource = SOURCE_GRID; detailId = id })
                            HomeScreen.SETTINGS -> SettingsScreen(vm, onEditTheme = { editor = ThemeEditorRequest(it) })
                        }
                    }
                }

                AnimatedVisibility(
                    visible = detailId == null && editor == null,
                    modifier = Modifier.align(Alignment.BottomCenter),
                    enter = fadeIn(mo.medium()) + slideInVertically(mo.medium()) { it },
                    exit = fadeOut(mo.fast()) + slideOutVertically(mo.fast()) { it },
                ) {
                    FloatingNavBar(
                        items = navItems,
                        selectedIndex = screen.ordinal,
                        onSelect = { screen = HomeScreen.entries[it] },
                        modifier = Modifier.navigationBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp),
                    )
                }

                SnackbarHost(
                    snackbar,
                    Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 92.dp, start = 16.dp, end = 16.dp),
                ) { data ->
                    Snackbar(
                        data,
                        containerColor = p.surfaceHighest,
                        contentColor = p.text,
                        actionColor = p.accentText,
                        shape = AppShapes.card,
                    )
                }
            }

            AnimatedContent(
                targetState = editor,
                transitionSpec = {
                    (fadeIn(mo.medium()) + slideInVertically(mo.medium()) { it / 8 }) togetherWith
                        (fadeOut(mo.fast()) + slideOutVertically(mo.fast()) { it / 8 })
                },
                label = "themeEditor",
            ) { req ->
                if (req != null) {
                    ThemeEditorScreen(vm = vm, initial = req.theme, onClose = { editor = null })
                } else {
                    Box(Modifier.fillMaxSize().then(Modifier))
                }
            }
        }
    }
}

private fun relative(ms: Long): String =
    DateUtils.getRelativeTimeSpanString(ms, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS).toString()

// -------------------------------------------------------------------------------------------------
// Bookmarks of every book
// -------------------------------------------------------------------------------------------------

@Composable
fun BookmarksScreen(vm: LibraryViewModel, onOpenAt: (Long, String) -> Unit) {
    val list by vm.allBookmarks.collectAsState()
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(stringResource(R.string.nav_bookmarks), subtitle = if (list.isEmpty()) null else com.novelreader.app.ui.Localized.number(list.size))
        if (list.isEmpty()) {
            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                EmptyState(AppIcons.BookmarkOutline, stringResource(R.string.nav_bookmarks), stringResource(R.string.bookmarks_all_empty))
            }
        } else LazyColumn(
            contentPadding = PaddingValues(start = Space.gutter, end = Space.gutter, top = Space.s, bottom = bottomClearance()),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            items(list, key = { it.id }) { b -> BookmarkRow(b) { onOpenAt(b.bookId, b.locatorJson) } }
        }
    }
}

@Composable
private fun BookmarkRow(b: GlobalBookmark, onClick: () -> Unit) {
    val p = palette
    AppCard(Modifier.fillMaxWidth(), onClick = onClick) {
        Row(Modifier.padding(Space.l), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(40.dp).clip(CircleShape).background(p.accentSoft), contentAlignment = Alignment.Center) {
                androidx.compose.material3.Icon(AppIcons.Bookmark, null, tint = p.onAccentSoft, modifier = Modifier.size(20.dp))
            }
            Column(Modifier.weight(1f).padding(horizontal = Space.m)) {
                Text(b.title ?: b.chapterTitle ?: b.bookTitle, style = MaterialTheme.typography.titleSmall, color = p.text, maxLines = 2, overflow = TextOverflow.Ellipsis)
                MutedText(stringResource(R.string.in_book, b.bookTitle), maxLines = 1)
                b.note?.takeIf { it.isNotBlank() }?.let {
                    Text(it, style = MaterialTheme.typography.bodySmall, color = p.text, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
                }
                Text(relative(b.createdAt), style = MaterialTheme.typography.labelSmall, color = p.textMuted, modifier = Modifier.padding(top = 4.dp))
            }
        }
    }
}

// -------------------------------------------------------------------------------------------------
// Notes of every book
// -------------------------------------------------------------------------------------------------

@Composable
fun NotesScreen(vm: LibraryViewModel, onOpenAt: (Long, String) -> Unit) {
    val list by vm.allNotes.collectAsState()
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(stringResource(R.string.nav_notes), subtitle = if (list.isEmpty()) null else com.novelreader.app.ui.Localized.number(list.size))
        if (list.isEmpty()) {
            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                EmptyState(AppIcons.Notes, stringResource(R.string.nav_notes), stringResource(R.string.notes_all_empty))
            }
        } else LazyColumn(
            contentPadding = PaddingValues(start = Space.gutter, end = Space.gutter, top = Space.s, bottom = bottomClearance()),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            items(list, key = { it.id }) { n -> NoteRow(n) { onOpenAt(n.bookId, n.locatorJson) } }
        }
    }
}

@Composable
private fun NoteRow(n: GlobalNote, onClick: () -> Unit) {
    val p = palette
    AppCard(Modifier.fillMaxWidth(), onClick = onClick) {
        Column(Modifier.padding(Space.l), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).clip(CircleShape).background(Color(n.color)))
                Text(
                    stringResource(R.string.in_book, n.bookTitle),
                    style = MaterialTheme.typography.labelMedium, color = p.textMuted,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(start = 8.dp),
                )
            }
            Text(n.note.orEmpty(), style = MaterialTheme.typography.bodyLarge, color = p.text)
            Row(Modifier.fillMaxWidth().clip(AppShapes.chip).background(p.surfaceHigh).padding(10.dp)) {
                Box(Modifier.size(width = 3.dp, height = 18.dp).clip(CircleShape).background(Color(n.color)))
                Text(
                    "“${n.text}”", style = MaterialTheme.typography.bodySmall, color = p.textMuted,
                    maxLines = 3, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(start = 10.dp),
                )
            }
            Text(relative(n.createdAt), style = MaterialTheme.typography.labelSmall, color = p.textMuted)
        }
    }
}
