package com.novelreader.app.reader

import android.content.Context
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.ViewConfiguration
import android.widget.FrameLayout
import kotlin.math.abs

/**
 * Touch front-end of the reading page. Two optional jobs, both leaving taps, long presses and text selection
 * (including dragging the selection handles, see [selectionActive]) to the page:
 *
 *  - "Top to Bottom (Separate Pages)": while [separatePages] is on, a vertical swipe is taken over and turned into
 *    exactly one page forward/backward instead of letting the page scroll freely.
 *  - Page-turn animation: while [horizontalDragEnabled] is on, a horizontal drag is taken over and reported to
 *    [dragListener], which lets the finger drive the turning page (curl, slide...). The page itself never sees it.
 */
class VerticalSwipeLayout(context: Context) : FrameLayout(context) {
    var separatePages = false
    var selectionActive = false
    var onSwipe: (forward: Boolean) -> Unit = {}

    /** Receives a horizontal drag that the page turner accepted. */
    interface DragListener {
        /**
         * The drag began towards the left ([towardsLeft]) or right; ([downX], [downY]) is where the finger first touched.
         * Return false to leave the gesture to the page.
         */
        fun onStart(towardsLeft: Boolean, downX: Float, downY: Float): Boolean
        /** [dragPx] = how far the finger has moved towards the exit side since the drag was recognised (>= 0). */
        fun onMove(dragPx: Float, x: Float, y: Float)
        /** Finger lifted ([cancelled] = system cancelled the gesture). [velocity] in px/s towards the exit side. */
        fun onEnd(dragPx: Float, velocity: Float, cancelled: Boolean)
    }

    var horizontalDragEnabled = false
    var dragListener: DragListener? = null

    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private val threshold = 48 * resources.displayMetrics.density
    private var downX = 0f
    private var downY = 0f
    private var taken = false
    private var dragging = false
    private var dragLeft = true
    private var tracker: VelocityTracker? = null

    private fun dragPx(x: Float): Float {
        val moved = if (dragLeft) downX - x else x - downX
        return (moved - slop).coerceAtLeast(0f)
    }

    private fun resetTracker() {
        tracker?.recycle()
        tracker = null
    }

    /**
     * The page WebView / pager ask their parents not to intercept as soon as a horizontal gesture starts (so the
     * engine can page by itself). Honouring that would make a finger drag skip [onInterceptTouchEvent] entirely, and
     * the page-turn animation could never follow the finger. The request is therefore ignored: this layout keeps
     * deciding, per move, whether a drag is its own.
     */
    override fun requestDisallowInterceptTouchEvent(disallowIntercept: Boolean) {
        if (!horizontalDragEnabled && !separatePages) super.requestDisallowInterceptTouchEvent(disallowIntercept)
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.x; downY = ev.y; taken = false; dragging = false
                resetTracker()
                tracker = VelocityTracker.obtain().also { it.addMovement(ev) }
            }
            MotionEvent.ACTION_MOVE -> {
                tracker?.addMovement(ev)
                if (selectionActive) return false
                val dx = ev.x - downX
                val dy = ev.y - downY
                if (horizontalDragEnabled && ev.pointerCount == 1 && !dragging &&
                    abs(dx) > slop && abs(dx) > abs(dy) * 1.3f
                ) {
                    dragLeft = dx < 0
                    if (dragListener?.onStart(dragLeft, downX, downY) == true) {
                        dragging = true
                        return true
                    }
                }
                if (separatePages && abs(dy) > slop && abs(dy) > abs(dx) * 1.5f) { taken = true; return true }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> resetTracker()
        }
        return false
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (dragging) {
            tracker?.addMovement(ev)
            when (ev.actionMasked) {
                MotionEvent.ACTION_MOVE -> dragListener?.onMove(dragPx(ev.x), ev.x, ev.y)
                MotionEvent.ACTION_UP -> {
                    val t = tracker
                    t?.computeCurrentVelocity(1000)
                    val vx = t?.xVelocity ?: 0f
                    dragging = false
                    dragListener?.onEnd(dragPx(ev.x), if (dragLeft) -vx else vx, false)
                    resetTracker()
                }
                MotionEvent.ACTION_CANCEL -> {
                    dragging = false
                    dragListener?.onEnd(dragPx(ev.x), 0f, true)
                    resetTracker()
                }
            }
            return true
        }
        if (!taken) return super.onTouchEvent(ev)
        if (ev.actionMasked == MotionEvent.ACTION_UP) {
            val dy = ev.y - downY
            if (abs(dy) >= threshold) onSwipe(dy < 0)
            taken = false
        } else if (ev.actionMasked == MotionEvent.ACTION_CANCEL) {
            taken = false
        }
        return true
    }
}
