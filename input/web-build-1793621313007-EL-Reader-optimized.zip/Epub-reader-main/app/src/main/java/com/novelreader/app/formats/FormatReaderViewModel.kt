package com.novelreader.app.formats

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.novelreader.app.data.BookEntity
import com.novelreader.app.data.BookmarkEntity
import com.novelreader.app.graph
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * What every non-EPUB reader (PDF, comics, TXT/DOCX) shares: the book row, the debounced saving of the reading
 * position (so it survives the app being killed), foreground reading time / sittings for the stats screen,
 * bookmarks and the "bars visible" flag. Format-specific view-models extend it.
 */
@OptIn(FlowPreview::class, ExperimentalCoroutinesApi::class)
abstract class FormatReaderViewModel(app: Application, protected val bookId: Long) : AndroidViewModel(app) {

    protected val graph = app.graph

    private val _book = MutableStateFlow<BookEntity?>(null)
    val book: StateFlow<BookEntity?> = _book.asStateFlow()

    private val _chrome = MutableStateFlow(true)
    val chromeVisible: StateFlow<Boolean> = _chrome.asStateFlow()
    fun setChromeVisible(v: Boolean) { _chrome.value = v }
    fun toggleChrome() { _chrome.value = !_chrome.value }

    val bookmarks: StateFlow<List<BookmarkEntity>> = graph.annotations.bookmarks(bookId)
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // ---- position ----
    private var latestProgress = 0.0
    private var latestLocator: String? = null
    private var dirty = false
    private val saveTrigger = MutableSharedFlow<Unit>(extraBufferCapacity = 1, onBufferOverflow = BufferOverflow.DROP_OLDEST)

    /** Progress of the whole book 0..1, as last reported by the reader. */
    val progress: Double get() = latestProgress

    init {
        viewModelScope.launch {
            _book.value = graph.library.get(bookId)
        }
        viewModelScope.launch {
            saveTrigger.debounce(SAVE_DEBOUNCE_MS).collect { flushPosition() }
        }
    }

    /** The reader reports where it is; saved a moment later (and at once when the reader stops). */
    fun reportPosition(progress: Double, locatorJson: String) {
        latestProgress = progress.coerceIn(0.0, 1.0)
        latestLocator = locatorJson
        dirty = true
        if (sessionStartedAt > 0L && sessionStartProgress < 0) sessionStartProgress = latestProgress
        saveTrigger.tryEmit(Unit)
    }

    /** Writes the newest position now (own scope: the view-model may be cleared right after onStop). */
    fun flushPosition() {
        val loc = latestLocator ?: return
        if (!dirty) return
        dirty = false
        val p = latestProgress
        val id = bookId
        val annotations = graph.annotations
        CoroutineScope(Dispatchers.IO).launch { annotations.savePosition(id, p, loc) }
    }

    // ---- reading time ----
    private var sessionStartedAt = 0L
    private var sessionStartProgress = -1.0

    fun onForeground() {
        sessionStartedAt = System.currentTimeMillis()
        sessionStartProgress = if (latestLocator != null) latestProgress else -1.0
    }

    /** [historyLabel] names where the reader stopped ("Page 12"); it becomes one entry of the book's history trail. */
    fun onBackground(historyLabel: String? = null) {
        flushPosition()
        val started = sessionStartedAt
        if (started <= 0L) return
        sessionStartedAt = 0L
        val delta = System.currentTimeMillis() - started
        val library = graph.library
        val annotations = graph.annotations
        val id = bookId
        val end = latestProgress
        val start = if (sessionStartProgress < 0) end else sessionStartProgress
        val loc = latestLocator
        CoroutineScope(Dispatchers.IO).launch {
            // A single stretch over 6 hours is almost certainly a forgotten open screen: not counted.
            if (delta in 1_000..MAX_SESSION_MS) {
                library.addReadingTime(id, delta)
                library.recordSession(id, started, delta, start, end)
            }
            if (historyLabel != null && loc != null) annotations.addHistory(id, loc, historyLabel, end)
        }
    }

    // ---- bookmarks ----
    fun addBookmark(locatorJson: String, title: String?, chapterTitle: String?, progress: Double) {
        viewModelScope.launch { graph.annotations.addBookmark(bookId, locatorJson, title, chapterTitle, progress) }
    }

    fun updateBookmark(b: BookmarkEntity) { viewModelScope.launch { graph.annotations.updateBookmark(b) } }
    fun deleteBookmark(id: Long) { viewModelScope.launch { graph.annotations.deleteBookmark(id) } }

    override fun onCleared() {
        flushPosition()
        super.onCleared()
    }

    companion object {
        const val SAVE_DEBOUNCE_MS = 1_200L
        const val MAX_SESSION_MS = 6L * 60 * 60 * 1000
    }
}
