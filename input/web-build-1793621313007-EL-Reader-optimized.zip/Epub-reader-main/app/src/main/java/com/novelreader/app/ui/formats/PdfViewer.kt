package com.novelreader.app.ui.formats

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.novelreader.app.data.AnnotationStyle
import com.novelreader.app.formats.PdfSettings
import com.novelreader.app.formats.pdf.PdfCell
import com.novelreader.app.formats.pdf.PdfFit
import com.novelreader.app.formats.pdf.PdfGeometry
import com.novelreader.app.formats.pdf.PdfHighlightItem
import com.novelreader.app.formats.pdf.PdfReaderViewModel
import com.novelreader.app.formats.pdf.PdfTextSelection
import com.novelreader.app.ui.design.palette
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/*
 * The PDF viewer. A page is always drawn twice: a "base" picture (whole page, rendered once at the on-screen size and
 * cached) that is scaled by the GPU while the user pinches, and - once the zoom settles - a "detail" picture of just
 * the visible part rendered at the real zoomed resolution, so text stays sharp at any zoom without huge bitmaps.
 */

/** Where one page is on the screen right now (all values in screen pixels). */
class PdfPlacement(
    val page: Int,
    val left: Float,
    val top: Float,
    /** Screen pixels per displayed PDF point. */
    val ppp: Float,
    /** Width in pixels of the base picture (which was rendered for zoom 1). */
    val baseW: Int,
    val pw: Float,
    val ph: Float,
    val rotation: Int,
) {
    private val disp = PdfGeometry.displaySize(pw, ph, rotation)
    val dispW: Float get() = disp.w
    val dispH: Float get() = disp.h
    val width: Float get() = disp.w * ppp
    val height: Float get() = disp.h * ppp

    /** Position and scale are real numbers and the page has an area, so it can be drawn (a NaN must never reach `roundToInt`). */
    fun isDrawable(): Boolean =
        left.isFinite() && top.isFinite() && ppp.isFinite() && ppp > 0f && disp.w.isFinite() && disp.w > 0f && disp.h.isFinite() && disp.h > 0f
}

/** A screen point resolved to a page and a page-space (unrotated points) position. */
class PageHit(val placement: PdfPlacement, val px: Float, val py: Float)

internal fun hitPage(list: List<PdfPlacement>, x: Float, y: Float): PageHit? {
    val pl = list.firstOrNull { x >= it.left && x <= it.left + it.width && y >= it.top && y <= it.top + it.height } ?: return null
    val pt = PdfGeometry.toPage((x - pl.left) / pl.ppp, (y - pl.top) / pl.ppp, pl.pw, pl.ph, pl.rotation)
    return PageHit(pl, pt[0], pt[1])
}

internal fun highlightAt(items: List<PdfHighlightItem>, hit: PageHit): PdfHighlightItem? =
    items.firstOrNull { h -> h.page == hit.placement.page && h.rects.any { r -> hit.px >= r[0] - 2f && hit.px <= r[2] + 2f && hit.py >= r[1] - 2f && hit.py <= r[3] + 2f } }

private val InvertFilter = ColorFilter.colorMatrix(
    ColorMatrix(
        floatArrayOf(
            -1f, 0f, 0f, 0f, 255f,
            0f, -1f, 0f, 0f, 255f,
            0f, 0f, -1f, 0f, 255f,
            0f, 0f, 0f, 1f, 0f,
        )
    )
)

/** The crisp picture of the visible part of a page (display points), valid for one zoom level. */
private class DetailTile(val image: ImageBitmap, val l: Float, val t: Float, val r: Float, val b: Float, val ppp: Float) {
    fun covers(vl: Float, vt: Float, vr: Float, vb: Float) = vl >= l - 0.5f && vt >= t - 0.5f && vr <= r + 0.5f && vb <= b + 0.5f
}

private const val MAX_TILE_PIXELS = 3_600_000L
private const val MAX_PX_PER_POINT = 12f

// ================================================================================================================
// Base picture of one page
// ================================================================================================================

@Composable
private fun PdfBasePage(vm: PdfReaderViewModel, page: Int, rotation: Int, widthPx: Int, invert: Boolean, modifier: Modifier) {
    val cache = vm.cache
    var bmp by remember(page, rotation, widthPx) { mutableStateOf(cache?.peek(page, rotation, widthPx)) }
    LaunchedEffect(page, rotation, widthPx) {
        if (bmp == null && widthPx > 0) cache?.get(page, rotation, widthPx)?.let { bmp = it }
    }
    Box(modifier.background(if (invert) Color.Black else Color.White)) {
        val b = bmp
        if (b != null) {
            val img = remember(b) { b.asImageBitmap() }
            Image(img, contentDescription = null, contentScale = ContentScale.FillBounds, modifier = Modifier.fillMaxSize(), colorFilter = if (invert) InvertFilter else null)
        }
    }
}

/** The pages of one cell laid out at [ppp] pixels per point inside a box of the cell's size. */
@Composable
private fun PdfCellPages(vm: PdfReaderViewModel, cell: PdfCell, ppp: Float, rotation: Int, invert: Boolean) {
    val density = LocalDensity.current
    cell.pages.forEachIndexed { i, page ->
        val r = cell.pageRects[i]
        val w = ((r[2] - r[0]) * ppp).roundToInt().coerceAtLeast(1)
        val h = ((r[3] - r[1]) * ppp).roundToInt().coerceAtLeast(1)
        PdfBasePage(
            vm, page, rotation, w, invert,
            Modifier
                .offset { IntOffset((r[0] * ppp).roundToInt(), (r[1] * ppp).roundToInt()) }
                .requiredSize(with(density) { w.toDp() }, with(density) { h.toDp() }),
        )
    }
}

// ================================================================================================================
// Overlay: crisp detail, highlights, search matches, selection
// ================================================================================================================

@OptIn(FlowPreview::class)
@Composable
private fun PdfOverlay(
    vm: PdfReaderViewModel,
    rotation: Int,
    invert: Boolean,
    viewW: Int,
    viewH: Int,
    placements: () -> List<PdfPlacement>,
    modifier: Modifier = Modifier,
) {
    val engine = vm.engine ?: return
    val tiles = remember { mutableStateMapOf<Int, DetailTile>() }
    val highlights by vm.highlights.collectAsState()
    val hits by vm.hits.collectAsState()
    val activeIdx by vm.activeHit.collectAsState()
    val selection by vm.selection.collectAsState()
    val hitsByPage = remember(hits) { hits.groupBy { it.page } }
    val activeHit = hits.getOrNull(activeIdx)
    val highlightsByPage = remember(highlights) { highlights.groupBy { it.page } }
    val selColor = palette.accent
    val dens = LocalDensity.current

    LaunchedEffect(rotation, viewW, viewH) { tiles.clear() }

    // Re-render the visible part of every zoomed page once the gesture has settled.
    LaunchedEffect(rotation, viewW, viewH) {
        snapshotFlow { placements() }.debounce(140).collectLatest { list ->
            val wanted = HashSet<Int>()
            for (pl in list) {
                if (!pl.isDrawable()) continue
                val baseP = pl.baseW / pl.dispW
                if (pl.ppp < baseP * 1.12f || pl.ppp > MAX_PX_PER_POINT * 1.5f) continue
                val visL = max(pl.left, 0f); val visT = max(pl.top, 0f)
                val visR = min(pl.left + pl.width, viewW.toFloat()); val visB = min(pl.top + pl.height, viewH.toFloat())
                if (visR <= visL || visB <= visT) continue
                wanted += pl.page
                val vl = (visL - pl.left) / pl.ppp; val vt = (visT - pl.top) / pl.ppp
                val vr = (visR - pl.left) / pl.ppp; val vb = (visB - pl.top) / pl.ppp
                val have = tiles[pl.page]
                if (have != null && have.covers(vl, vt, vr, vb) && pl.ppp <= have.ppp * 1.12f && pl.ppp >= have.ppp / 1.6f) continue
                // Render the visible part plus a margin, so small pans stay sharp without another render.
                var margin = 0.25f
                var l = 0f; var t = 0f; var r = 0f; var b = 0f
                while (true) {
                    l = max(pl.left, visL - margin * viewW); t = max(pl.top, visT - margin * viewH)
                    r = min(pl.left + pl.width, visR + margin * viewW); b = min(pl.top + pl.height, visB + margin * viewH)
                    if ((ceil(r - l).toLong() * ceil(b - t).toLong()) <= MAX_TILE_PIXELS || margin <= 0f) break
                    margin = max(0f, margin - 0.1f)
                }
                val w = ceil(r - l).toInt(); val h = ceil(b - t).toInt()
                if (w.toLong() * h > MAX_TILE_PIXELS || w <= 0 || h <= 0) continue
                val ox = (l - pl.left).roundToInt(); val oy = (t - pl.top).roundToInt()
                val bmp = engine.renderRegion(pl.page, rotation, pl.ppp, ox, oy, w, h) ?: continue
                tiles[pl.page] = DetailTile(bmp.asImageBitmap(), ox / pl.ppp, oy / pl.ppp, (ox + w) / pl.ppp, (oy + h) / pl.ppp, pl.ppp)
            }
            tiles.keys.toList().forEach { if (it !in wanted) tiles.remove(it) }
        }
    }

    Box(modifier.fillMaxSize()) {
        Canvas(Modifier.fillMaxSize()) {
            val list = placements()
            for (pl in list) {
                if (!pl.isDrawable()) continue
                val tile = tiles[pl.page]
                if (tile != null) {
                    drawImage(
                        tile.image,
                        dstOffset = IntOffset((pl.left + tile.l * pl.ppp).roundToInt(), (pl.top + tile.t * pl.ppp).roundToInt()),
                        dstSize = IntSize(((tile.r - tile.l) * pl.ppp).roundToInt().coerceAtLeast(1), ((tile.b - tile.t) * pl.ppp).roundToInt().coerceAtLeast(1)),
                        colorFilter = if (invert) InvertFilter else null,
                    )
                }
            }
            for (pl in list) {
                if (!pl.isDrawable()) continue
                fun rect(r: FloatArray): androidx.compose.ui.geometry.Rect {
                    val d = PdfGeometry.rectToDisplay(r[0], r[1], r[2], r[3], pl.pw, pl.ph, pl.rotation)
                    return androidx.compose.ui.geometry.Rect(pl.left + d[0] * pl.ppp, pl.top + d[1] * pl.ppp, pl.left + d[2] * pl.ppp, pl.top + d[3] * pl.ppp)
                }
                highlightsByPage[pl.page]?.forEach { h ->
                    val c = Color(h.entity.color)
                    h.rects.forEach { rr ->
                        val rc = rect(rr)
                        when (h.entity.style) {
                            AnnotationStyle.UNDERLINE.name ->
                                drawLine(c, Offset(rc.left, rc.bottom - 1f), Offset(rc.right, rc.bottom - 1f), strokeWidth = 2.5f * dens.density)
                            AnnotationStyle.STRIKE.name ->
                                drawLine(c, Offset(rc.left, rc.center.y), Offset(rc.right, rc.center.y), strokeWidth = 2f * dens.density)
                            AnnotationStyle.NOTE.name -> {
                                drawRect(c.copy(alpha = 0.16f), rc.topLeft, rc.size)
                                drawLine(
                                    c, Offset(rc.left, rc.bottom - 1f), Offset(rc.right, rc.bottom - 1f), strokeWidth = 2.5f * dens.density,
                                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f * dens.density, 4f * dens.density)),
                                )
                            }
                            else -> drawRect(c.copy(alpha = 0.38f), rc.topLeft, rc.size)
                        }
                    }
                }
                hitsByPage[pl.page]?.forEach { hit ->
                    val active = hit === activeHit
                    hit.rects.forEach { rr ->
                        val rc = rect(rr)
                        drawRect(if (active) Color(0xFFFF9800).copy(alpha = 0.55f) else Color(0xFFFFEB3B).copy(alpha = 0.45f), rc.topLeft, rc.size)
                        if (active) drawRoundRect(Color(0xFFE65100), rc.topLeft, rc.size, CornerRadius(3f * dens.density), Stroke(1.5f * dens.density))
                    }
                }
                val sel = selection
                if (sel != null && sel.page == pl.page) {
                    sel.rects.forEach { rr -> val rc = rect(rr); drawRect(selColor.copy(alpha = 0.32f), rc.topLeft, rc.size) }
                }
            }
        }

        val sel = selection
        if (sel != null) {
            SelectionHandle(true, vm, sel, rotation, placements)
            SelectionHandle(false, vm, sel, rotation, placements)
        }
    }
}

/** A draggable handle at one end of the selected text. */
@Composable
private fun SelectionHandle(start: Boolean, vm: PdfReaderViewModel, sel: PdfTextSelection, rotation: Int, placements: () -> List<PdfPlacement>) {
    val density = LocalDensity.current
    val r = with(density) { 14.dp.toPx() }
    var drag by remember(sel.page, start) { mutableStateOf<Offset?>(null) }

    fun tip(): Offset? {
        val pl = placements().firstOrNull { it.page == sel.page } ?: return null
        val ends = vm.selectionEnds() ?: return null
        val p = if (start) ends.first else ends.second
        val d = PdfGeometry.toDisplay(p[0], p[1], pl.pw, pl.ph, pl.rotation)
        return Offset(pl.left + d[0] * pl.ppp, pl.top + d[1] * pl.ppp)
    }

    Box(
        Modifier
            .offset {
                val t = drag ?: tip()
                if (t == null) IntOffset(-10_000, -10_000) else IntOffset((t.x - r).roundToInt(), t.y.roundToInt())
            }
            .size(28.dp)
            .clip(CircleShape)
            .background(palette.accent)
            .pointerInput(sel.page, start) {
                detectDragGestures(
                    onDragStart = { drag = tip() },
                    onDrag = { change, amount ->
                        change.consume()
                        val now = (drag ?: tip() ?: return@detectDragGestures) + amount
                        drag = now
                        val pl = placements().firstOrNull { it.page == sel.page } ?: return@detectDragGestures
                        val pt = PdfGeometry.toPage((now.x - pl.left) / pl.ppp, (now.y - pl.top) / pl.ppp, pl.pw, pl.ph, pl.rotation)
                        vm.moveSelectionHandle(start, pt[0], pt[1])
                    },
                    onDragEnd = { drag = null },
                    onDragCancel = { drag = null },
                )
            },
    )
}

// ================================================================================================================
// Shared tap handling
// ================================================================================================================

/** What a tap or long press on the page area should do; the screen decides about chrome and dialogs. */
class PdfTapActions(
    val onToggleChrome: () -> Unit,
    val onOpenHighlight: (PdfHighlightItem) -> Unit,
)

private suspend fun androidx.compose.ui.input.pointer.PointerInputScope.pdfTapGestures(
    onLongPress: (Offset) -> Unit,
    onTap: (Offset) -> Unit,
) {
    detectTapGestures(onLongPress = onLongPress, onTap = onTap)
}

// ================================================================================================================
// Paged viewer (one page or spread per screen)
// ================================================================================================================

@Composable
fun PdfPagedViewer(
    vm: PdfReaderViewModel,
    s: PdfSettings,
    cells: List<PdfCell>,
    rtl: Boolean,
    rotation: Int,
    invert: Boolean,
    viewW: Int,
    viewH: Int,
    actualPpp: Float,
    actions: PdfTapActions,
    layoutKey: Int,
) {
    val cellsState = rememberUpdatedState(cells)
    val scope = rememberCoroutineScope()
    val start = vm.startJump
    val yRequests = remember { mutableStateMapOf<Int, Float>().also { if (start.y > 0f) it[PdfGeometry.cellIndexOf(cells, start.page)] = start.y } }
    val panning = remember { mutableStateMapOf<Int, Boolean>() }

    CompositionLocalProvider(LocalLayoutDirection provides if (rtl) LayoutDirection.Rtl else LayoutDirection.Ltr) {
        val pagerState = rememberPagerState(initialPage = PdfGeometry.cellIndexOf(cells, start.page)) { cells.size.coerceAtLeast(1) }

        // Re-align only when the structure of the layout changed (not on every newly read page size).
        LaunchedEffect(layoutKey) {
            val target = PdfGeometry.cellIndexOf(cellsState.value, vm.page.value)
            if (pagerState.currentPage != target) pagerState.scrollToPage(target)
        }
        LaunchedEffect(Unit) {
            vm.commands.collect { j ->
                val idx = PdfGeometry.cellIndexOf(cellsState.value, j.page)
                if (j.y > 0f) yRequests[idx] = j.y else yRequests.remove(idx)
                if (idx == pagerState.currentPage) { /* same screen: the cell applies the offset */ }
                else if (abs(idx - pagerState.currentPage) <= 1) pagerState.animateScrollToPage(idx)
                else pagerState.scrollToPage(idx)
            }
        }

        HorizontalPager(
            state = pagerState,
            modifier = Modifier.fillMaxSize(),
            userScrollEnabled = panning[pagerState.currentPage] != true,
            beyondViewportPageCount = 1,
            key = { cells.getOrNull(it)?.pages?.firstOrNull() ?: it },
        ) { idx ->
            val cell = cells.getOrNull(idx) ?: return@HorizontalPager
            PdfPagedCell(
                vm = vm, cell = cell, s = s, rtl = rtl, rotation = rotation, invert = invert,
                viewW = viewW, viewH = viewH, actualPpp = actualPpp, actions = actions,
                isCurrent = pagerState.settledPage == idx,
                yRequest = yRequests[idx],
                onYHandled = { yRequests.remove(idx) },
                onPanX = { p -> if (p) panning[idx] = true else panning.remove(idx) },
                onTurn = { forward ->
                    val to = if (forward) idx + 1 else idx - 1
                    if (to in 0 until cellsState.value.size) scope.launch { pagerState.animateScrollToPage(to) }
                },
            )
        }
    }
}

@OptIn(FlowPreview::class)
@Composable
private fun PdfPagedCell(
    vm: PdfReaderViewModel,
    cell: PdfCell,
    s: PdfSettings,
    rtl: Boolean,
    rotation: Int,
    invert: Boolean,
    viewW: Int,
    viewH: Int,
    actualPpp: Float,
    actions: PdfTapActions,
    isCurrent: Boolean,
    yRequest: Float?,
    onYHandled: () -> Unit,
    onPanX: (Boolean) -> Unit,
    onTurn: (forward: Boolean) -> Unit,
) {
    val vw = viewW.toFloat()
    val vh = viewH.toFloat()
    val fitPpp = PdfGeometry.pxPerPoint(s.fit, vw, vh, cell.ptsW, cell.ptsH, actualPpp)
    val pagePpp = PdfGeometry.pxPerPoint(PdfFit.PAGE, vw, vh, cell.ptsW, cell.ptsH, actualPpp)
    val cw = cell.ptsW * fitPpp
    val ch = cell.ptsH * fitPpp
    val zoom = remember(cell.pages.first(), cw, ch, vw, vh) {
        ZoomState(max(2f, MAX_PX_PER_POINT / fitPpp.coerceAtLeast(0.01f)).coerceAtMost(12f)).also {
            it.viewW = vw; it.viewH = vh; it.contentW = cw; it.contentH = ch
            it.minScale = min(1f, pagePpp / fitPpp)
            it.reset(1f)
        }
    }
    val scope = rememberCoroutineScope()
    var pendingToggle by remember { mutableStateOf<Job?>(null) }
    var lastCenterTap by remember { mutableStateOf(0L) }
    val highlights by vm.highlights.collectAsState()
    val selection by vm.selection.collectAsState()
    val engine = vm.engine

    LaunchedEffect(yRequest, zoom) {
        if (yRequest != null) { zoom.scrollToContentY(yRequest * ch); onYHandled() }
    }
    LaunchedEffect(zoom) { snapshotFlow { zoom.panX }.collect { onPanX(it) } }
    DisposableEffect(zoom) { onDispose { onPanX(false) } }
    LaunchedEffect(zoom, isCurrent, ch) {
        if (!isCurrent) return@LaunchedEffect
        snapshotFlow { if (ch > 0f) (zoom.topContentY() / ch) else 0f }.debounce(350).collect { vm.onViewport(cell.pages[0], it) }
    }

    val placements = {
        cell.pages.mapIndexed { i, page ->
            val r = cell.pageRects[i]
            val size = engine?.sizeOrGuess(page) ?: com.novelreader.app.formats.pdf.PdfSize(612f, 792f)
            PdfPlacement(
                page = page,
                left = zoom.tx + r[0] * fitPpp * zoom.scale,
                top = zoom.ty + r[1] * fitPpp * zoom.scale,
                ppp = fitPpp * zoom.scale,
                baseW = ((r[2] - r[0]) * fitPpp).roundToInt(),
                pw = size.w, ph = size.h, rotation = rotation,
            )
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(zoom) { pagedZoomGestures(zoom) { dir -> onTurn(if (rtl) dir < 0 else dir > 0) } }
            .pointerInput(s.tapToTurn, rtl, zoom, highlights, selection) {
                pdfTapGestures(
                    onLongPress = { off ->
                        val hit = hitPage(placements(), off.x, off.y)
                        if (hit != null) vm.selectWordAt(hit.placement.page, hit.px, hit.py)
                    },
                    onTap = { offset ->
                        val hit = hitPage(placements(), offset.x, offset.y)
                        val hl = hit?.let { highlightAt(highlights, it) }
                        val zone = tapZone(offset.x, size.width.toFloat())
                        when {
                            selection != null -> vm.clearSelection()
                            hl != null -> actions.onOpenHighlight(hl)
                            zone != TapZone.CENTER && s.tapToTurn -> {
                                val forward = if (rtl) zone == TapZone.START else zone == TapZone.END
                                onTurn(forward)
                            }
                            else -> {
                                val now = System.currentTimeMillis()
                                if (now - lastCenterTap < 300L) {
                                    pendingToggle?.cancel()
                                    lastCenterTap = 0L
                                    scope.launch { if (zoom.zoomed) zoom.animateTo(1f, offset) else zoom.animateTo(2.5f, offset) }
                                } else {
                                    lastCenterTap = now
                                    pendingToggle = scope.launch { delay(300); actions.onToggleChrome() }
                                }
                            }
                        }
                    },
                )
            },
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .layout { measurable, c ->
                    val p = measurable.measure(Constraints.fixed(cw.roundToInt().coerceAtLeast(1), ch.roundToInt().coerceAtLeast(1)))
                    layout(c.maxWidth, c.maxHeight) { p.place(0, 0) }
                }
                .graphicsLayer {
                    transformOrigin = TransformOrigin(0f, 0f)
                    scaleX = zoom.scale; scaleY = zoom.scale
                    translationX = zoom.tx; translationY = zoom.ty
                },
        ) {
            PdfCellPages(vm, cell, fitPpp, rotation, invert)
        }
        PdfOverlay(vm, rotation, invert, viewW, viewH, placements)
    }
}

// ================================================================================================================
// Continuous vertical viewer
// ================================================================================================================

@OptIn(FlowPreview::class)
@Composable
fun PdfScrollViewer(
    vm: PdfReaderViewModel,
    s: PdfSettings,
    cells: List<PdfCell>,
    rotation: Int,
    invert: Boolean,
    viewW: Int,
    viewH: Int,
    actualPpp: Float,
    actions: PdfTapActions,
) {
    val vw = viewW.toFloat()
    val vh = viewH.toFloat()
    val cellsState = rememberUpdatedState(cells)
    // "Actual size" in scrolling mode is the width-fitted layout, zoomed in to the real size.
    val layoutFit = if (s.fit == PdfFit.ACTUAL) PdfFit.WIDTH else s.fit
    fun pppOf(c: PdfCell) = PdfGeometry.pxPerPoint(layoutFit, vw, vh, c.ptsW, c.ptsH, actualPpp)

    val start = vm.startJump
    val startIdx = PdfGeometry.cellIndexOf(cells, start.page)
    val listState = rememberLazyListState(
        initialFirstVisibleItemIndex = startIdx,
        initialFirstVisibleItemScrollOffset = cells.getOrNull(startIdx)?.let { (start.y * it.ptsH * pppOf(it)).roundToInt() } ?: 0,
    )
    val zoom = remember(vw, vh) { ZoomState(8f).also { it.viewW = vw; it.viewH = vh } }
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    var pendingToggle by remember { mutableStateOf<Job?>(null) }
    var lastTap by remember { mutableStateOf(0L) }
    val highlights by vm.highlights.collectAsState()
    val selection by vm.selection.collectAsState()
    val engine = vm.engine

    val firstPpp = cells.firstOrNull()?.let { pppOf(it) } ?: 1f
    LaunchedEffect(zoom, s.fit, firstPpp) {
        zoom.reset(if (s.fit == PdfFit.ACTUAL && firstPpp > 0f) (actualPpp / firstPpp).coerceIn(1f, zoom.maxScale) else 1f)
    }

    LaunchedEffect(listState) {
        snapshotFlow { listState.firstVisibleItemIndex to listState.firstVisibleItemScrollOffset }.debounce(350).collect { (i, off) ->
            val list = cellsState.value
            val cell = list.getOrNull(i) ?: return@collect
            val chpx = (cell.ptsH * pppOf(cell)).coerceAtLeast(1f)
            if (off > chpx * 0.6f && i + 1 < list.size) vm.onViewport(list[i + 1].pages[0], 0f) else vm.onViewport(cell.pages[0], off / chpx)
        }
    }
    LaunchedEffect(Unit) {
        vm.commands.collect { j ->
            val list = cellsState.value
            val idx = PdfGeometry.cellIndexOf(list, j.page)
            val cell = list.getOrNull(idx) ?: return@collect
            listState.scrollToItem(idx, (j.y * cell.ptsH * pppOf(cell)).roundToInt())
        }
    }

    val placements = {
        val list = cellsState.value
        listState.layoutInfo.visibleItemsInfo.flatMap { item ->
            val cell = list.getOrNull(item.index)
            if (cell == null) emptyList() else {
                val ppp = pppOf(cell)
                val xOff = (vw - cell.ptsW * ppp) / 2f
                cell.pages.mapIndexed { i, page ->
                    val r = cell.pageRects[i]
                    val size = engine?.sizeOrGuess(page) ?: com.novelreader.app.formats.pdf.PdfSize(612f, 792f)
                    PdfPlacement(
                        page = page,
                        left = zoom.tx + (xOff + r[0] * ppp) * zoom.scale,
                        top = zoom.ty + (item.offset + r[1] * ppp) * zoom.scale,
                        ppp = ppp * zoom.scale,
                        baseW = ((r[2] - r[0]) * ppp).roundToInt(),
                        pw = size.w, ph = size.h, rotation = rotation,
                    )
                }
            }
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(zoom) { scrollZoomGestures(zoom) }
            .pointerInput(zoom, highlights, selection) {
                pdfTapGestures(
                    onLongPress = { off ->
                        val hit = hitPage(placements(), off.x, off.y)
                        if (hit != null) vm.selectWordAt(hit.placement.page, hit.px, hit.py)
                    },
                    onTap = { offset ->
                        val hit = hitPage(placements(), offset.x, offset.y)
                        val hl = hit?.let { highlightAt(highlights, it) }
                        when {
                            selection != null -> vm.clearSelection()
                            hl != null -> actions.onOpenHighlight(hl)
                            else -> {
                                val now = System.currentTimeMillis()
                                if (now - lastTap < 300L) {
                                    pendingToggle?.cancel(); lastTap = 0L
                                    scope.launch { if (zoom.zoomed) zoom.animateTo(1f, offset) else zoom.animateTo(2f, offset) }
                                } else {
                                    lastTap = now
                                    pendingToggle = scope.launch { delay(300); actions.onToggleChrome() }
                                }
                            }
                        }
                    },
                )
            },
    ) {
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    transformOrigin = TransformOrigin(0f, 0f)
                    scaleX = zoom.scale; scaleY = zoom.scale
                    translationX = zoom.tx; translationY = zoom.ty
                },
            verticalArrangement = Arrangement.spacedBy(s.pageGapDp.dp),
        ) {
            items(cells.size, key = { cells[it].pages[0] }) { idx ->
                val cell = cells[idx]
                val ppp = pppOf(cell)
                val cwPx = (cell.ptsW * ppp).roundToInt().coerceAtLeast(1)
                val chPx = (cell.ptsH * ppp).roundToInt().coerceAtLeast(1)
                Box(Modifier.fillMaxWidth().height(with(density) { chPx.toDp() }), contentAlignment = Alignment.TopCenter) {
                    Box(Modifier.requiredSize(with(density) { cwPx.toDp() }, with(density) { chPx.toDp() })) {
                        PdfCellPages(vm, cell, ppp, rotation, invert)
                    }
                }
            }
        }
        PdfOverlay(vm, rotation, invert, viewW, viewH, placements)
    }
}
