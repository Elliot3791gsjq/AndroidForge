package com.novelreader.app.formats.comic

/**
 * Groups comic pages into what the reader shows at once. Pure logic (unit-tested).
 *  - single page layout: one page per spread;
 *  - two-page layout: pages are paired (1+2, 3+4, ...); with [coverAlone] page 1 stands alone so the spreads line up
 *    with the printed book, and a double-wide (landscape) page is always shown alone, re-pairing what follows it.
 */
object ComicSpreads {

    fun build(pageCount: Int, dual: Boolean, coverAlone: Boolean, isWide: (Int) -> Boolean): List<IntArray> {
        if (pageCount <= 0) return emptyList()
        if (!dual) return List(pageCount) { intArrayOf(it) }
        val out = ArrayList<IntArray>(pageCount / 2 + 1)
        var i = 0
        while (i < pageCount) {
            when {
                i == 0 && coverAlone -> { out += intArrayOf(0); i++ }
                isWide(i) -> { out += intArrayOf(i); i++ }
                i + 1 < pageCount && !isWide(i + 1) -> { out += intArrayOf(i, i + 1); i += 2 }
                else -> { out += intArrayOf(i); i++ }
            }
        }
        return out
    }

    /** Index of the spread that contains [page] (the last spread when the page is past the end). */
    fun indexOf(spreads: List<IntArray>, page: Int): Int {
        if (spreads.isEmpty()) return 0
        val i = spreads.indexOfFirst { page in it }
        return if (i >= 0) i else if (page < 0) 0 else spreads.lastIndex
    }

    /** Whole-book progress 0..1 for a zero-based page: first page 0, last page exactly 1. */
    fun progress(page: Int, pageCount: Int): Double =
        if (pageCount <= 1) (if (pageCount == 1) 1.0 else 0.0) else (page.coerceIn(0, pageCount - 1).toDouble() / (pageCount - 1))
}
