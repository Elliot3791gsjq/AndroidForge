package com.novelreader.app.ui.formats

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.novelreader.app.R
import com.novelreader.app.data.BookmarkEntity
import com.novelreader.app.ui.AppIcons
import com.novelreader.app.ui.Localized
import com.novelreader.app.ui.design.AccentButton
import com.novelreader.app.ui.design.AppDialog
import com.novelreader.app.ui.design.AppSheet
import com.novelreader.app.ui.design.AppSlider
import com.novelreader.app.ui.design.AppSwitch
import com.novelreader.app.ui.design.AppTextField
import com.novelreader.app.ui.design.GhostButton
import com.novelreader.app.ui.design.MutedText
import com.novelreader.app.ui.design.SegmentedControl
import com.novelreader.app.ui.design.SettingRow
import com.novelreader.app.ui.design.SoftIconButton
import com.novelreader.app.ui.design.appClickable
import com.novelreader.app.ui.design.palette

/* Pieces shared by the PDF, comic and document readers so they look and behave like the EPUB reader's chrome. */

@Composable
fun GlassButton(icon: ImageVector, description: String, onClick: () -> Unit, selected: Boolean = false) {
    val p = palette
    Box(
        Modifier
            .size(40.dp)
            .appClickable(onClick)
            .clip(CircleShape)
            .background(if (selected) p.accent else p.surface.copy(alpha = 0.95f))
            .border(1.dp, p.outline.copy(alpha = 0.7f), CircleShape),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, contentDescription = description, tint = if (selected) p.onAccent else p.text, modifier = Modifier.size(20.dp)) }
}

/** Back button, title pill and any number of round action buttons. */
@Composable
fun FormatTopBar(title: String, onBack: () -> Unit, modifier: Modifier = Modifier, actions: @Composable RowScope.() -> Unit = {}) {
    val p = palette
    Row(
        modifier.fillMaxWidth().windowInsetsPadding(WindowInsets.statusBars).padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        GlassButton(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back), onBack)
        Box(
            Modifier
                .weight(1f)
                .height(40.dp)
                .clip(CircleShape)
                .background(p.surface.copy(alpha = 0.95f))
                .border(1.dp, p.outline.copy(alpha = 0.7f), CircleShape)
                .padding(horizontal = 16.dp),
            contentAlignment = Alignment.CenterStart,
        ) {
            Text(title, style = MaterialTheme.typography.titleSmall, color = p.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        actions()
    }
}

/**
 * Bottom bar: slider over [total] pages with "page / total" under it. [current] is zero-based. With [rtl] the slider
 * runs right-to-left (page 1 at the right), matching right-to-left reading. [onSeek] gets a zero-based page.
 */
@Composable
fun PageSliderBar(
    current: Int,
    total: Int,
    onSeek: (Int) -> Unit,
    modifier: Modifier = Modifier,
    rtl: Boolean = false,
    onPrev: (() -> Unit)? = null,
    onNext: (() -> Unit)? = null,
    trailing: @Composable (() -> Unit)? = null,
    /** Replaces the "Page x of y" text (documents show the chapter instead). */
    centerLabel: ((Int) -> String)? = null,
) {
    val p = palette
    var drag by remember { mutableStateOf<Float?>(null) }
    val maxIdx = (total - 1).coerceAtLeast(0)
    val shown = (drag ?: current.toFloat()).coerceIn(0f, maxIdx.toFloat())
    Column(
        modifier
            .fillMaxWidth()
            .clip(androidx.compose.foundation.shape.RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp))
            .background(p.surface.copy(alpha = 0.96f))
            .border(1.dp, p.outline.copy(alpha = 0.6f), androidx.compose.foundation.shape.RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp))
            .windowInsetsPadding(WindowInsets.navigationBars)
            .padding(horizontal = 12.dp, vertical = 8.dp),
    ) {
        Row(Modifier.fillMaxWidth().height(40.dp), verticalAlignment = Alignment.CenterVertically) {
            if (onPrev != null) SoftIconButton(AppIcons.ChevronLeft, stringResource(R.string.fmt_prev_page), onPrev, size = 36.dp)
            Box(Modifier.weight(1f).padding(horizontal = 4.dp)) {
                CompositionLocalProvider(LocalLayoutDirection provides if (rtl) LayoutDirection.Rtl else LayoutDirection.Ltr) {
                    AppSlider(
                        value = shown,
                        onValueChange = { drag = it },
                        valueRange = 0f..maxIdx.coerceAtLeast(1).toFloat(),
                        onValueChangeFinished = { drag?.let { onSeek(it.toInt().coerceIn(0, maxIdx)) }; drag = null },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
            if (onNext != null) SoftIconButton(AppIcons.ChevronRight, stringResource(R.string.fmt_next_page), onNext, size = 36.dp)
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            val pct = if (total > 1) Localized.percent((shown / maxIdx.coerceAtLeast(1) * 100).toInt()) else Localized.percent(if (total == 1) 100 else 0)
            Text(pct, style = MaterialTheme.typography.labelLarge, color = p.accentText)
            Text(
                centerLabel?.invoke(shown.toInt().coerceIn(0, maxIdx)) ?: stringResource(R.string.fmt_page_of, Localized.number(shown.toInt() + 1), Localized.number(total)),
                style = MaterialTheme.typography.labelLarge,
                color = p.text,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            )
            if (trailing != null) trailing() else Spacer(Modifier.width(1.dp))
        }
    }
}

/** "Go to page" dialog; [onGo] gets a zero-based page. */
@Composable
fun GoToPageDialog(total: Int, current: Int, onDismiss: () -> Unit, onGo: (Int) -> Unit) {
    var text by remember { mutableStateOf((current + 1).toString()) }
    val target = text.trim().toIntOrNull()
    val valid = target != null && target in 1..total
    AppDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.fmt_go_to_page)) },
        text = {
            Column {
                AppTextField(
                    value = text,
                    onValueChange = { text = it.filter { c -> c.isDigit() }.take(7) },
                    placeholder = stringResource(R.string.fmt_page_number_hint, Localized.number(total)),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                )
            }
        },
        confirmButton = { AccentButton(stringResource(R.string.fmt_go), { if (valid) { onGo(target!! - 1); onDismiss() } }, enabled = valid, height = 44.dp) },
        dismissButton = { GhostButton(stringResource(R.string.cancel), onDismiss, height = 44.dp) },
    )
}

/** Bookmarks of the open book. [label] describes where a bookmark points ("Page 12"). */
@Composable
fun FormatBookmarksSheet(
    bookmarks: List<BookmarkEntity>,
    label: (BookmarkEntity) -> String,
    onAdd: () -> Unit,
    onOpen: (BookmarkEntity) -> Unit,
    onDelete: (BookmarkEntity) -> Unit,
    onDismiss: () -> Unit,
) {
    val p = palette
    AppSheet(onDismiss) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 20.dp)) {
            Text(stringResource(R.string.bookmarks), style = MaterialTheme.typography.titleLarge, color = p.text)
            Spacer(Modifier.height(12.dp))
            AccentButton(stringResource(R.string.add_bookmark), onAdd, Modifier.fillMaxWidth(), icon = AppIcons.BookmarkAdd, height = 46.dp)
            Spacer(Modifier.height(8.dp))
            if (bookmarks.isEmpty()) {
                MutedText(stringResource(R.string.no_bookmarks), Modifier.padding(vertical = 16.dp))
            } else {
                LazyColumn(Modifier.fillMaxWidth().height((bookmarks.size.coerceAtMost(6) * 64).dp)) {
                    items(bookmarks, key = { it.id }) { b ->
                        Row(
                            Modifier.fillMaxWidth().appClickable({ onOpen(b) }, scaleTo = 0.99f).padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(AppIcons.Bookmark, contentDescription = null, tint = p.accent, modifier = Modifier.size(22.dp))
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(b.title?.takeIf { it.isNotBlank() } ?: label(b), style = MaterialTheme.typography.bodyLarge, color = p.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                MutedText(label(b) + " · " + Localized.percent((b.progress * 100).toInt()), maxLines = 1)
                            }
                            SoftIconButton(AppIcons.Delete, stringResource(R.string.delete), { onDelete(b) }, size = 40.dp)
                        }
                    }
                }
            }
        }
    }
}

// ---- settings building blocks ----

@Composable
fun SwitchSetting(title: String, checked: Boolean, onChange: (Boolean) -> Unit, subtitle: String? = null) {
    SettingRow(title, subtitle = subtitle, onClick = { onChange(!checked) }, trailing = { AppSwitch(checked, null) })
}

@Composable
fun ChoiceSetting(title: String, options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Text(title, style = MaterialTheme.typography.bodyLarge, color = palette.text)
        Spacer(Modifier.height(8.dp))
        SegmentedControl(options, selected, onSelect)
    }
}

/** Keeps a lambda-driven effect out of the way: runs [block] once when the composable enters the composition. */
@Composable
fun OnceEffect(block: suspend () -> Unit) {
    LaunchedEffect(Unit) { block() }
}

/** Full-screen "this file could not be opened" with a way back. */
@Composable
fun FormatOpenError(message: String, onBack: () -> Unit) {
    val p = palette
    Box(Modifier.fillMaxSize().background(p.bg).windowInsetsPadding(WindowInsets.statusBars), contentAlignment = Alignment.Center) {
        Column(Modifier.padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(stringResource(R.string.fmt_open_failed_title), style = MaterialTheme.typography.titleLarge, color = p.text)
            Spacer(Modifier.height(12.dp))
            Text(message, style = MaterialTheme.typography.bodyMedium, color = p.textMuted)
            Spacer(Modifier.height(24.dp))
            AccentButton(stringResource(R.string.back), onBack, height = 46.dp)
        }
    }
}

/** One option per row with a check on the chosen one; for settings whose labels are too long for a segmented control. */
@Composable
fun RadioSetting(title: String, options: List<String>, selected: Int, onSelect: (Int) -> Unit, note: String? = null) {
    val p = palette
    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Text(title, style = MaterialTheme.typography.bodyLarge, color = p.text)
        options.forEachIndexed { i, label ->
            Row(
                Modifier.fillMaxWidth().appClickable({ onSelect(i) }, scaleTo = 0.99f, role = androidx.compose.ui.semantics.Role.RadioButton).padding(vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium, color = if (i == selected) p.accentText else p.textMuted)
                if (i == selected) Icon(AppIcons.Check, null, tint = p.accent, modifier = Modifier.size(20.dp))
            }
        }
        if (note != null) MutedText(note, Modifier.padding(top = 2.dp))
    }
}
