package com.novelreader.app.reader

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import com.novelreader.app.data.PageFlipAnim
import com.novelreader.app.reader.curl.CurlRenderer
import com.novelreader.app.reader.curl.FlipDir
import com.novelreader.app.reader.curl.GoogleCurlRenderer
import com.novelreader.app.reader.curl.IBookCurlRenderer
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Draws the page that is being turned, above the live reader (which is transparent wherever this view draws nothing).
 *
 *  - Curl styles (Apple / Google): the renderers of libreadview (MIT, see THIRD_PARTY_NOTICES.md) driven by a touch
 *    point; everything is drawn in "spine space" (x = 0 at the binding, the sheet on x in [0, pageWidth]) by moving
 *    the canvas to the spine and mirroring it for right-to-left books. In Dual-Page Mode the spine is the middle of
 *    the screen, so one sheet turns over the other.
 *  - Slide, Two-way slide, Fade and Swing: a photograph of the old page that is moved / faded / swung away.
 */
class PageTurnView(context: Context) : View(context) {

    // ---- photograph styles -------------------------------------------------------------------------
    private var bitmap: Bitmap? = null
    private var anim = PageFlipAnim.NONE
    private var exitLeft = true
    private var forward = true

    var progress: Float = 0f
        set(value) {
            field = value.coerceIn(0f, 1f)
            invalidate()
        }

    // ---- curl --------------------------------------------------------------------------------------
    private val apple = IBookCurlRenderer()
    private val google = GoogleCurlRenderer()
    private var renderer: CurlRenderer? = null
    private var curlActive = false
    private var dir = FlipDir.NEXT
    private var dual = false
    private var mirrored = false
    private var spineX = 0f
    private var pageW = 0f
    private var downY = 0f
    private var travel = 1.55f
    private var curlP = 0f

    /** Flat photograph of the old screen, shown until the sheet to turn is ready. */
    var pending: Bitmap? = null
    var curlTop: Bitmap? = null
    var curlBottom: Bitmap? = null
    var curlBack: Bitmap? = null
    /** Dual-Page: the other page before / after the turn (spine space), cross-faded as the sheet passes over it. */
    var otherOld: Bitmap? = null
    var otherNew: Bitmap? = null

    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val shadePaint = Paint().apply { color = Color.BLACK }
    private val gradPaint = Paint()
    private val src = Rect()
    private val dst = RectF()

    init {
        visibility = INVISIBLE
        isClickable = false
        isFocusable = false
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
    }

    /** Photograph styles: shows [bmp] (this view's size) as the page that is about to be turned. */
    fun begin(bmp: Bitmap, style: PageFlipAnim, exitLeft: Boolean, forward: Boolean) {
        curlActive = false
        bitmap = bmp
        anim = style
        this.exitLeft = exitLeft
        this.forward = forward
        progress = 0f
        visibility = VISIBLE
    }

    /**
     * Curl styles. [pageWidth] is the width of one sheet (the screen, or half of it in Dual-Page Mode) and [spine]
     * the screen x of the binding. [dir] says whether the sheet leaves (NEXT) or comes back (PREV).
     */
    fun beginCurl(style: PageFlipAnim, dir: FlipDir, dual: Boolean, mirrored: Boolean, spine: Float, pageWidth: Float, downY: Float, paper: Int) {
        bitmap = null
        anim = style
        curlActive = true
        this.dir = dir
        this.dual = dual
        this.mirrored = mirrored
        this.spineX = spine
        this.pageW = pageWidth
        this.downY = downY
        val apple = style == PageFlipAnim.APPLE_CURL
        travel = if (apple) 1.55f else 1.0f
        renderer = if (apple) this.apple else google
        pending = null; curlTop = null; curlBottom = null; curlBack = null; otherOld = null; otherNew = null
        this.apple.setBackTintColor(paper or (0xFF shl 24))
        curlP = if (dir == FlipDir.PREV) 1f else 0f
        visibility = VISIBLE
        invalidate()
    }

    /** Hands the bitmaps to the renderer once the sheet to turn exists (and again when late ones arrive). */
    fun applyCurlPages() {
        val top = curlTop ?: return
        val r = renderer ?: return
        r.setPageSize(pageW, height.toFloat())
        r.setPages(top, curlBottom, curlBack)
        if (r === google) {
            google.setInitDirection(if (dir == FlipDir.PREV) FlipDir.PREV else FlipDir.NEXT)
            google.initControllPosition(if (dir == FlipDir.PREV) 0f else pageW, downY)
        } else {
            apple.initControllPosition(pageW, downY)
        }
        setCurl(curlP, downY)
    }

    /** Where the free edge of the sheet is for turn progress [p] (0 = lying flat on the page, 1 = gone). */
    private fun touchX(p: Float): Float = pageW - p.coerceIn(0f, 1f) * travel * pageW

    /** Moves the sheet: [p] = 0 flat .. 1 gone, [y] = height of the finger (steers the curl). */
    fun setCurl(p: Float, y: Float) {
        curlP = p.coerceIn(0f, 1f)
        val r = renderer
        if (r != null && curlTop != null && pageW > 0f) r.updateTouchPosition(touchX(curlP), y)
        invalidate()
    }

    fun end() {
        bitmap = null
        curlActive = false
        curlTop = null; curlBottom = null; curlBack = null; otherOld = null; otherNew = null; pending = null
        renderer?.release()
        renderer = null
        visibility = INVISIBLE
    }

    val isShowing: Boolean get() = bitmap != null || curlActive

    override fun onDraw(canvas: Canvas) {
        if (curlActive) { drawCurl(canvas); return }
        val bmp = bitmap ?: return
        if (bmp.isRecycled) return
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        when (anim) {
            PageFlipAnim.SHIFT_HORIZONTAL -> drawSlide(canvas, bmp, w, h)
            PageFlipAnim.TWO_WAY_SLIDE -> drawTwoWay(canvas, bmp, w)
            PageFlipAnim.FADE -> drawFade(canvas, bmp)
            PageFlipAnim.FLIP_HORIZONTAL -> drawDoor(canvas, bmp, w, h, horizontal = true)
            PageFlipAnim.FLIP_VERTICAL -> drawDoor(canvas, bmp, w, h, horizontal = false)
            else -> Unit
        }
    }

    private fun smooth(x: Float): Float { val t = x.coerceIn(0f, 1f); return t * t * (3f - 2f * t) }

    private fun drawCurl(c: Canvas) {
        val top = curlTop
        if (top == null || top.isRecycled) {
            pending?.let { if (!it.isRecycled) c.drawBitmap(it, 0f, 0f, null) }
            return
        }
        val r = renderer ?: return
        val t = if (dir == FlipDir.PREV) 1f - curlP else curlP     // how far the turn has gone, 0..1
        c.save()
        c.translate(spineX, 0f)
        if (mirrored) c.scale(-1f, 1f)
        if (dual) {
            otherOld?.let { if (!it.isRecycled) c.drawBitmap(it, -pageW, 0f, null) }
            otherNew?.let {
                if (!it.isRecycled) {
                    bmpPaint.alpha = (smooth((t - 0.3f) / 0.7f) * 255).roundToInt()
                    c.drawBitmap(it, -pageW, 0f, bmpPaint)
                    bmpPaint.alpha = 255
                }
            }
        }
        // In Dual-Page Mode the sheet lands on the other page, so it dissolves into it at the ends of the turn.
        var leaf = 1f
        if (dual) {
            leaf = ((1f - t) / 0.2f).coerceIn(0f, 1f)
            if (dir == FlipDir.PREV) leaf = min(leaf, (t / 0.15f).coerceIn(0f, 1f))
        }
        if (leaf < 0.999f) {
            val save = c.saveLayerAlpha(-pageW, 0f, pageW, height.toFloat(), (leaf * 255).roundToInt())
            r.render(c)
            c.restoreToCount(save)
        } else {
            r.render(c)
        }
        c.restore()
    }

    /** Soft shadow between two screen x positions: [alpha] at [xNear], fading to nothing at [xFar]. */
    private fun shadowBetween(c: Canvas, h: Float, xNear: Float, xFar: Float, alpha: Float) {
        if (alpha <= 0.01f || xNear == xFar) return
        val a = (alpha.coerceIn(0f, 1f) * 255).roundToInt()
        gradPaint.shader = LinearGradient(
            xNear, 0f, xFar, 0f,
            intArrayOf(Color.argb(a, 0, 0, 0), Color.argb((a * 0.35f).roundToInt(), 0, 0, 0), Color.argb(0, 0, 0, 0)),
            floatArrayOf(0f, 0.4f, 1f),
            Shader.TileMode.CLAMP,
        )
        c.drawRect(min(xNear, xFar), 0f, max(xNear, xFar), h, gradPaint)
        gradPaint.shader = null
    }

    /** Two-way slide: the old page moves out while the (live) new page moves in right behind it. */
    private fun drawTwoWay(c: Canvas, bmp: Bitmap, w: Float) {
        val dx = (if (exitLeft) -1f else 1f) * progress * w
        c.drawBitmap(bmp, dx.roundToInt().toFloat(), 0f, bmpPaint)
    }

    // ---------------------------------------------------------------------------------------------
    // Slide / fade / door
    // ---------------------------------------------------------------------------------------------

    private fun drawSlide(c: Canvas, bmp: Bitmap, w: Float, h: Float) {
        val dx = (if (exitLeft) -1f else 1f) * progress * w
        val edgeX = if (exitLeft) w + dx else dx
        val reach = w * 0.10f
        shadowBetween(c, h, edgeX, if (exitLeft) edgeX + reach else edgeX - reach, 0.38f * (1f - progress))
        c.drawBitmap(bmp, dx, 0f, bmpPaint)
    }

    private fun drawFade(c: Canvas, bmp: Bitmap) {
        bmpPaint.alpha = ((1f - progress) * 255).roundToInt().coerceIn(0, 255)
        c.drawBitmap(bmp, 0f, 0f, bmpPaint)
        bmpPaint.alpha = 255
    }

    /**
     * The page swings away like a door hinged at the spine (horizontal) or at the top / bottom edge (vertical), with
     * perspective: the free edge grows as it comes towards the reader. Drawn as thin strips whose size follows the
     * projection, so it also works where a perspective canvas matrix is not available.
     */
    private fun drawDoor(c: Canvas, bmp: Bitmap, w: Float, h: Float, horizontal: Boolean) {
        val angle = progress * (PI / 2.0)
        val cosA = cos(angle).toFloat()
        val sinA = sin(angle).toFloat()
        val length = if (horizontal) w else h
        val camera = length * 1.7f
        val shade = 0.55f * sinA
        val step = 6
        val total = length.toInt()
        // Far strips first so the near (larger) ones paint over them. Iterate directly:
        // allocating and filling a list on every animation frame creates avoidable GC pressure.
        val lastStart = ((total - 1).coerceAtLeast(0) / step) * step
        for (a in lastStart downTo 0 step step) {
            val b = min(total, a + step)
            val za = a * sinA
            val zb = b * sinA
            val sa = camera / (camera - za)
            val sb = camera / (camera - zb)
            val sm = (sa + sb) / 2f
            if (horizontal) {
                val xa = a * cosA * sa
                val xb = b * cosA * sb
                val hingeX = if (exitLeft) 0f else w
                val x0 = if (exitLeft) hingeX + xa else hingeX - xa
                val x1 = if (exitLeft) hingeX + xb else hingeX - xb
                val s0 = if (exitLeft) a.toFloat() else w - a
                val s1 = if (exitLeft) b.toFloat() else w - b
                src.set(min(s0, s1).roundToInt(), 0, max(s0, s1).roundToInt(), bmp.height)
                if (src.width() <= 0) continue
                val hh = h * sm
                dst.set(min(x0, x1), (h - hh) / 2f, max(x0, x1), (h + hh) / 2f)
            } else {
                val ya = a * cosA * sa
                val yb = b * cosA * sb
                val hingeY = if (forward) 0f else h
                val y0 = if (forward) hingeY + ya else hingeY - ya
                val y1 = if (forward) hingeY + yb else hingeY - yb
                val s0 = if (forward) a.toFloat() else h - a
                val s1 = if (forward) b.toFloat() else h - b
                src.set(0, min(s0, s1).roundToInt(), bmp.width, max(s0, s1).roundToInt())
                if (src.height() <= 0) continue
                val ww = w * sm
                dst.set((w - ww) / 2f, min(y0, y1), (w + ww) / 2f, max(y0, y1))
            }
            if (dst.width() < 0.05f || dst.height() < 0.05f) continue
            c.drawBitmap(bmp, src, dst, bmpPaint)
            if (shade > 0.01f) {
                shadePaint.alpha = (shade * 255).roundToInt().coerceIn(0, 255)
                c.drawRect(dst, shadePaint)
            }
        }
    }
}
