package com.novelreader.app.reader

import android.os.Parcel
import android.os.Parcelable
import com.novelreader.app.data.AnnotationStyle
import com.novelreader.app.data.HighlightEntity
import org.json.JSONArray
import org.json.JSONObject
import org.readium.r2.navigator.Decoration
import org.readium.r2.navigator.html.HtmlDecorationTemplate
import org.readium.r2.navigator.html.HtmlDecorationTemplates
import org.readium.r2.navigator.html.toCss
import org.readium.r2.shared.publication.Locator

/** Strikethrough drawn through the middle of the selected lines. */
class StrikeStyle(override val tint: Int) : Decoration.Style, Decoration.Style.Tinted {
    override fun describeContents(): Int = 0
    override fun writeToParcel(dest: Parcel, flags: Int) { dest.writeInt(tint) }
    companion object {
        @JvmField
        val CREATOR: Parcelable.Creator<StrikeStyle> = object : Parcelable.Creator<StrikeStyle> {
            override fun createFromParcel(source: Parcel) = StrikeStyle(source.readInt())
            override fun newArray(size: Int): Array<StrikeStyle?> = arrayOfNulls(size)
        }
    }
}

/** Dotted underline that marks text carrying a note. */
class NoteStyle(override val tint: Int) : Decoration.Style, Decoration.Style.Tinted {
    override fun describeContents(): Int = 0
    override fun writeToParcel(dest: Parcel, flags: Int) { dest.writeInt(tint) }
    companion object {
        @JvmField
        val CREATOR: Parcelable.Creator<NoteStyle> = object : Parcelable.Creator<NoteStyle> {
            override fun createFromParcel(source: Parcel) = NoteStyle(source.readInt())
            override fun newArray(size: Int): Array<NoteStyle?> = arrayOfNulls(size)
        }
    }
}

/**
 * Turns the stored annotations into Readium decorations.
 *  - HIGHLIGHT / UNDERLINE use Readium's own styles; STRIKE and NOTE are custom decoration templates.
 *  - BOLD cannot be a decoration (decorations are overlays and cannot change glyph weight), so it is applied by
 *    [BoldInjector] directly in the page DOM each time a resource is loaded.
 */
object AnnotationDecor {
    const val GROUP = "user-highlights"

    fun templates(): HtmlDecorationTemplates {
        val t = HtmlDecorationTemplates.defaultTemplates()
        t[StrikeStyle::class] = HtmlDecorationTemplate(
            layout = HtmlDecorationTemplate.Layout.BOXES,
            width = HtmlDecorationTemplate.Width.WRAP,
            element = { d ->
                val c = ((d.style as? StrikeStyle)?.tint ?: 0xFFE53935.toInt()).toCss()
                "<div style=\"background: linear-gradient(to bottom, transparent 47%, $c 47%, $c 55%, transparent 55%) !important\"></div>"
            },
        )
        t[NoteStyle::class] = HtmlDecorationTemplate(
            layout = HtmlDecorationTemplate.Layout.BOXES,
            width = HtmlDecorationTemplate.Width.WRAP,
            element = { d ->
                val c = ((d.style as? NoteStyle)?.tint ?: 0xFF64B5F6.toInt()).toCss()
                "<div style=\"border-bottom: 2px dotted $c !important; box-sizing: border-box\"></div>"
            },
        )
        return t
    }

    fun defaultColor(style: AnnotationStyle): Int = when (style) {
        AnnotationStyle.HIGHLIGHT -> 0xFFFFEB3B.toInt()
        AnnotationStyle.UNDERLINE -> 0xFF1E88E5.toInt()
        AnnotationStyle.STRIKE -> 0xFFE53935.toInt()
        AnnotationStyle.BOLD -> 0xFF9E9E9E.toInt()
        AnnotationStyle.NOTE -> 0xFF8E24AA.toInt()
    }

    fun styleOf(h: HighlightEntity): AnnotationStyle =
        AnnotationStyle.entries.firstOrNull { it.name == h.style } ?: AnnotationStyle.HIGHLIGHT

    fun decorations(list: List<HighlightEntity>): List<Decoration> = list.mapNotNull { h ->
        val loc = parseLocator(h.locatorJson) ?: return@mapNotNull null
        val style: Decoration.Style = when (styleOf(h)) {
            AnnotationStyle.HIGHLIGHT -> Decoration.Style.Highlight(tint = h.color)
            AnnotationStyle.UNDERLINE -> Decoration.Style.Underline(tint = h.color)
            AnnotationStyle.STRIKE -> StrikeStyle(h.color)
            AnnotationStyle.NOTE -> NoteStyle(h.color)
            AnnotationStyle.BOLD -> return@mapNotNull null
        }
        Decoration(id = "hl-${h.id}", locator = loc, style = style)
    }

    fun parseLocator(json: String): Locator? =
        try { Locator.fromJSON(JSONObject(json)) } catch (_: Throwable) { null }
}

/**
 * Makes text bold by wrapping the matching text nodes in <b data-nr-bold>. The target text is located by the
 * quote stored in the annotation's locator (before + text + after, falling back to the text alone), so it survives
 * font-size and layout changes. The EPUB file is never modified - only the loaded page is.
 */
object BoldInjector {
    fun script(list: List<HighlightEntity>): String {
        val items = JSONArray()
        list.filter { AnnotationDecor.styleOf(it) == AnnotationStyle.BOLD }.forEach { h ->
            val loc = AnnotationDecor.parseLocator(h.locatorJson) ?: return@forEach
            items.put(
                JSONObject()
                    .put("href", loc.href.toString())
                    .put("text", loc.text.highlight ?: h.text)
                    .put("before", loc.text.before ?: "")
                    .put("after", loc.text.after ?: ""),
            )
        }
        return "(function(items){$BODY})(${items})"
    }

    private const val BODY = """
      try {
        var old = document.querySelectorAll('b[data-nr-bold]');
        for (var i = 0; i < old.length; i++) {
          var b = old[i], p = b.parentNode;
          while (b.firstChild) p.insertBefore(b.firstChild, b);
          p.removeChild(b); p.normalize();
        }
        var base = function (p) { return decodeURIComponent((p || '').split('?')[0].split('#')[0].split('/').pop()); };
        items.forEach(function (it) {
          if (it.href && base(it.href) !== base(location.pathname)) return;
          var walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null);
          var nodes = [], full = '';
          while (walker.nextNode()) { nodes.push({ n: walker.currentNode, s: full.length }); full += walker.currentNode.nodeValue; }
          var idx = full.indexOf((it.before || '') + it.text + (it.after || ''));
          var start;
          if (idx >= 0) start = idx + (it.before || '').length; else start = full.indexOf(it.text);
          if (start < 0) return;
          var end = start + it.text.length;
          for (var k = nodes.length - 1; k >= 0; k--) {
            var nd = nodes[k], ns = nd.s, ne = ns + nd.n.nodeValue.length;
            if (ne <= start || ns >= end) continue;
            var a = Math.max(start, ns) - ns, z = Math.min(end, ne) - ns;
            var node = nd.n;
            if (z < node.nodeValue.length) node.splitText(z);
            var mid = a > 0 ? node.splitText(a) : node;
            var wrap = document.createElement('b');
            wrap.setAttribute('data-nr-bold', '1');
            mid.parentNode.insertBefore(wrap, mid);
            wrap.appendChild(mid);
          }
        });
      } catch (e) {}
    """
}
