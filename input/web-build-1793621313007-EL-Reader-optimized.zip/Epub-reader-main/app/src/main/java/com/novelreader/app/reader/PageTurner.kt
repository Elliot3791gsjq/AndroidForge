package com.novelreader.app.reader

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.TimeInterpolator
import android.animation.ValueAnimator
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.PixelCopy
import android.view.Window
import android.view.Choreographer
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import com.novelreader.app.data.PageFlipAnim
import com.novelreader.app.reader.curl.FlipDir
import kotlin.math.max
import kotlin.math.min

/**
 * Runs the page-turn animation around the real navigation.
 *
 * The reading engine is never re-implemented: before it moves, the current screen is photographed, the engine is told
 * to go to the next / previous page, and [view] draws the photograph (or, for a backward curl, the previous page that
 * is photographed once the engine has drawn it) over the live reader while it turns. A finger drag steers the turn;
 * a tap, key or command plays the whole turn.
 *
 * Curl styles (Apple / Google) use the libreadview renderers: the sheet follows the finger's x AND y, a backward turn
 * brings the previous page back over the current one, and in Dual-Page Mode the binding is the middle of the screen so
 * one page turns over the other. The other styles move a photograph (Slide, Two-way slide, Fade, Swing).
 */
class PageTurner(
    private val view: PageTurnView,
    private val layers: List<View>,
    private val paintBase: (Canvas, Int, Int) -> Unit,
    private val config: () -> Config,
    private val target: Target,
    private val densityDpi: () -> Float,
    /** Moves the live reader sideways (Two-way slide: the new page travels in behind the old one). */
    private val liveTranslate: (Float) -> Unit = {},
    /** The activity window, for [PixelCopy] (a GPU screenshot that does not stall the UI thread). */
    private val window: () -> Window? = { null },
) {
    data class Config(
        val style: PageFlipAnim,
        val speed: Int,
        val rtl: Boolean,
        /** Page colour, used to tint the back of a curling sheet. */
        val paper: Int,
        val enabled: Boolean,
        /** Two pages per screen. */
        val dual: Boolean = false,
        /** True when nothing but the page is on screen, so a window screenshot is the page and nothing else. */
        val pixelCopy: Boolean = false,
    )

    private class Release(val dragPx: Float, val velocity: Float, val cancelled: Boolean)

    interface Target {
        /** Moves the reader one page; false when there is nowhere to go (nothing has changed then). */
        fun go(forward: Boolean): Boolean
        fun position(): Any?
        fun restore(position: Any?)
    }

    private val handler = Handler(Looper.getMainLooper())
    private val pool = ArrayList<Bitmap>()
    private val owned = ArrayList<Bitmap>()
    private val copyPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private var animator: ValueAnimator? = null
    private var dragging = false
    private var savedPosition: Any? = null
    private var revertPending = false
    private var pageReady = true
    private var turnStartedAt = 0L
    private var lastTurnAt = 0L
    private var resumeAfterReady: ((Boolean) -> Unit)? = null
    private var turnId = 0

    // ---- current turn ----
    private var style = PageFlipAnim.NONE
    private var curl = false
    private var dir = FlipDir.NEXT
    private var exitLeft = true            // photograph styles
    private var dual = false
    private var mirrored = false
    private var spine = 0f
    private var pw = 0f
    private var leafX0 = 0
    private var otherX0 = 0
    private var downX = 0f
    private var downY = 0f
    private var fingerY = 0f
    private var p = 0f
    private var synthetic = true
    private var chained = false
    private var oldSig = 0L
    private var settled = false
    private var navMoved = false
    private val whenSettledQueue = ArrayList<(Boolean) -> Unit>()
    private var capturing = false
    private var early: Release? = null
    private val queued = ArrayList<Boolean>()
    private var tapBlocked: (() -> Unit)? = null
    private var latestDragPx = 0f
    private var latestY = 0f
    private var lastOverlayEndAt = 0L

    val busy: Boolean get() = capturing || dragging || animator != null || view.isShowing

    // ---------------------------------------------------------------------------------------------
    // Starting a turn (tap / key / command / finger)
    // ---------------------------------------------------------------------------------------------

    /**
     * Turns one page with the animation. Returns false only when the animation is off (the page then turns plainly and
     * the result says whether there was a page). With the animation on, the turn starts asynchronously and the result
     * is true; [onBlocked] runs when it turns out there is no such page (end / start of the book).
     */
    fun turn(forward: Boolean, onBlocked: (() -> Unit)? = null): Boolean {
        val cfg = config()
        if (!cfg.enabled || view.width <= 0) return target.go(forward)
        // Taps that arrive while the previous page is still being photographed are kept and played right after it.
        if (capturing) { if (queued.size < 2) queued.add(forward); return true }
        if (busy) finishNow()
        markTurnStart()
        synthetic = true
        tapBlocked = onBlocked
        startTurn(forward, cfg, view.width.toFloat(), view.height * 0.88f, instant = true)
        return true
    }

    /** The reader reported a new position (called for every locator change). */
    fun onPageChanged() {
        pageReady = true
        resumeAfterReady?.let { resumeAfterReady = null; handler.removeCallbacks(timeout); it(true) }
    }

    private val timeout = Runnable {
        resumeAfterReady?.let { resumeAfterReady = null; it(false) }
    }

    /** Runs [block] with true as soon as the engine reported a new page, or with false after MAX_WAIT without one. */
    private fun whenPageReady(block: (Boolean) -> Unit) {
        val waited = SystemClock.elapsedRealtime() - turnStartedAt
        when {
            pageReady -> block(true)
            waited >= MAX_WAIT -> block(false)
            else -> {
                resumeAfterReady = block
                handler.postDelayed(timeout, MAX_WAIT - waited)
            }
        }
    }

    private fun markTurnStart() {
        val now = SystemClock.elapsedRealtime()
        chained = now - lastTurnAt < 700
        lastTurnAt = now
    }

    private fun isCurl(s: PageFlipAnim) = s == PageFlipAnim.APPLE_CURL || s == PageFlipAnim.GOOGLE_CURL

    private fun duration(speed: Int): Long {
        val base = CurlGeometry.durationFor(speed)
        return if (chained) (base * 0.55f).toLong() else base
    }

    /**
     * Photographs the screen, then moves the engine and starts the turn. [instant] = play it by itself (tap); a finger
     * drag (instant = false) is steered afterwards by [dragMove] / [dragEnd].
     */
    private fun startTurn(forward: Boolean, cfg: Config, fx: Float, fy: Float, instant: Boolean) {
        val id = ++turnId
        capturing = true
        settled = false
        navMoved = false
        whenSettledQueue.clear()
        captureAsync(cfg, id) { full ->
            if (id != turnId) { full?.let { give(it) }; return@captureAsync }
            capturing = false
            if (full == null) {
                // Could not photograph the page: no animation, just turn it.
                if (!target.go(forward)) tapBlocked?.invoke()
                dragging = false
                early = null
                return@captureAsync
            }
            var playNow = instant
            val rel = early
            if (rel != null) {
                // The finger was already lifted while the page was being photographed.
                early = null
                dragging = false
                val complete = !rel.cancelled && CurlGeometry.shouldComplete(rel.dragPx, view.width.toFloat(), rel.velocity, densityDpi())
                if (!complete) { give(full); finish(); drain(); return@captureAsync }
                synthetic = true
                playNow = true
            }
            val ok = if (isCurl(cfg.style)) proceedCurl(full, forward, cfg, fx, fy, id, playNow) else proceedPhoto(full, forward, cfg, id, playNow)
            if (ok && !playNow) dragMove(latestDragPx, latestY)
            drain()
        }
    }

    private fun drain() {
        if (queued.isEmpty()) return
        val next = queued.removeAt(0)
        turn(next, tapBlocked)
    }

    private fun proceedPhoto(full: Bitmap, forward: Boolean, cfg: Config, id: Int, playNow: Boolean): Boolean {
        exitLeft = forward != cfg.rtl
        style = cfg.style
        curl = false
        dir = if (forward) FlipDir.NEXT else FlipDir.PREV
        pageReady = false
        turnStartedAt = SystemClock.elapsedRealtime()
        savedPosition = target.position()
        if (!target.go(forward)) { give(full); finish(); tapBlocked?.invoke(); return false }
        view.begin(full, cfg.style, exitLeft, forward)
        setProgress(0f)
        watchNavigation()
        if (playNow) {
            // Starts at once; it is held back a little (see gate) until the engine confirms the page, so the first
            // frames never reveal the old page again.
            play(0f, 1f, duration(cfg.speed), AccelerateDecelerateInterpolator()) { finish() }
            whenSettled { moved -> if (id == turnId && !moved) { animator?.cancel(); finish() } }
        }
        return true
    }

    private fun proceedCurl(full: Bitmap, forward: Boolean, cfg: Config, fx: Float, fy: Float, id: Int, playNow: Boolean): Boolean {
        if (!setupCurl(full, forward, cfg, fx, fy)) return false
        pageReady = false
        turnStartedAt = SystemClock.elapsedRealtime()
        savedPosition = target.position()
        if (!target.go(forward)) { finish(); tapBlocked?.invoke(); return false }
        watchNavigation()
        if (playNow) {
            if (dir == FlipDir.NEXT) {
                play(0f, 1f, duration(cfg.speed), AccelerateDecelerateInterpolator()) { finish() }
                whenSettled { moved -> if (id == turnId && !moved) { animator?.cancel(); finish() } }
            } else {
                // The previous page has to be photographed after the engine drew it; the turn starts then.
                whenSettled { moved ->
                    if (id != turnId) return@whenSettled
                    if (!moved) finish() else play(1f, 0f, duration(cfg.speed), AccelerateDecelerateInterpolator()) { finish() }
                }
            }
        }
        return true
    }

    // ---------------------------------------------------------------------------------------------
    // Curl set-up
    // ---------------------------------------------------------------------------------------------

    /**
     * Prepares the sheet for a turn from the photograph [full] of the screen. [forward] = reading direction; [fx], [fy]
     * = where the finger is (or the corner a tap pretends to grab).
     */
    private fun setupCurl(full: Bitmap, forward: Boolean, cfg: Config, fx: Float, fy: Float): Boolean {
        val w = view.width
        val h = view.height
        style = cfg.style
        curl = true
        dir = if (forward) FlipDir.NEXT else FlipDir.PREV
        dual = cfg.dual
        mirrored = cfg.rtl
        pw = if (dual) w / 2f else w.toFloat()
        spine = if (dual) w / 2f else if (mirrored) w.toFloat() else 0f
        leafX0 = if (!dual) 0 else if (!mirrored) w / 2 else 0
        otherX0 = if (dual) (if (!mirrored) 0 else w / 2) else 0
        downX = fx
        downY = fy
        fingerY = fy
        oldSig = signature(full)
        p = if (dir == FlipDir.PREV) 1f else 0f
        view.beginCurl(cfg.style, dir, dual, mirrored, spine, pw, fy, cfg.paper)
        val m = mirrored
        val leafWhole = !dual && !m
        try {
            if (dir == FlipDir.NEXT) {
                view.curlTop = if (leafWhole) full else slice(full, leafX0, pw.toInt(), h, m)
                if (dual) view.otherOld = slice(full, otherX0, pw.toInt(), h, m)
                if (!leafWhole) give(full)
                view.applyCurlPages()
            } else {
                view.pending = full
                view.curlBottom = if (leafWhole) full else slice(full, leafX0, pw.toInt(), h, m)
                if (dual) {
                    view.curlBack = slice(full, otherX0, pw.toInt(), h, !m)
                    view.otherOld = slice(full, otherX0, pw.toInt(), h, m)
                }
            }
        } catch (e: OutOfMemoryError) {
            finish()
            return false
        }
        return true
    }

    /** Waits for the engine to report the new page; for a backward curl then photographs it (it is the sheet to turn). */
    private fun watchNavigation() {
        val id = turnId
        whenPageReady { moved ->
            if (id != turnId) return@whenPageReady
            if (!moved) { settle(false); return@whenPageReady }
            if (curl && dir == FlipDir.PREV) captureAfterNavigation(id, 0) else settle(true)
        }
    }

    private fun captureAfterNavigation(id: Int, tries: Int) {
        afterFrames(2, id) {
            val fresh = capture()
            if (fresh == null) { settle(true); return@afterFrames }
            // The engine can report the new page a moment before the WebView has painted it: look again.
            if (signature(fresh) == oldSig && tries < 3) {
                give(fresh)
                captureAfterNavigation(id, tries + 1)
                return@afterFrames
            }
            try {
                view.curlTop = slice(fresh, leafX0, pw.toInt(), view.height, mirrored)
                view.applyCurlPages()
                view.pending = null
                view.setCurl(p, if (synthetic) curlY(p) else fingerY)
            } catch (e: OutOfMemoryError) {
                // No sheet to show: the page simply stays as it is (the engine already moved).
            }
            give(fresh)
            settle(true)
        }
    }

    private fun settle(moved: Boolean) {
        settled = true
        navMoved = moved
        val q = ArrayList(whenSettledQueue)
        whenSettledQueue.clear()
        for (b in q) b(moved)
    }

    private fun whenSettled(block: (Boolean) -> Unit) {
        if (settled) block(navMoved) else whenSettledQueue.add(block)
    }

    private fun afterFrames(n: Int, id: Int, block: () -> Unit) {
        if (id != turnId) return
        if (n <= 0) { block(); return }
        Choreographer.getInstance().postFrameCallback { afterFrames(n - 1, id, block) }
    }

    /** The engine reports a new page a moment after it moved; until then the turn is held at its very beginning. */
    private fun gate(value: Float): Float =
        if (settled || (curl && dir == FlipDir.PREV)) value else min(value, GATE)

    /** Height of the pretend finger during a tap-driven curl: lifts the corner so the sheet rolls diagonally. */
    private fun curlY(progress: Float): Float = downY - view.height * 0.22f * min(1f, progress * 3f)

    // ---------------------------------------------------------------------------------------------
    // Finger drag
    // ---------------------------------------------------------------------------------------------

    val dragListener = object : VerticalSwipeLayout.DragListener {
        override fun onStart(towardsLeft: Boolean, downX: Float, downY: Float): Boolean = dragStart(towardsLeft, downX, downY)
        override fun onMove(dragPx: Float, x: Float, y: Float) = dragMove(dragPx, y)
        override fun onEnd(dragPx: Float, velocity: Float, cancelled: Boolean) = dragEnd(dragPx, velocity, cancelled)
    }

    private fun dragStart(towardsLeft: Boolean, fx: Float, fy: Float): Boolean {
        val cfg = config()
        if (!cfg.enabled || view.width <= 0) return false
        if (capturing) return false
        if (busy) finishNow()
        markTurnStart()
        val forward = towardsLeft != cfg.rtl
        synthetic = false
        tapBlocked = null
        dragging = true
        early = null
        latestDragPx = 0f
        latestY = fy
        startTurn(forward, cfg, fx, fy, instant = false)
        return true
    }

    private fun dragMove(dragPx: Float, y: Float) {
        if (!dragging) return
        latestDragPx = dragPx
        latestY = y
        if (capturing) return
        if (!curl) {
            val w = view.width.toFloat()
            setProgress(gate(if (w <= 0f) 0f else (dragPx / w).coerceIn(0f, 1f)))
            return
        }
        // Distance from the finger's first position to the binding, so the sheet's edge reaches the binding exactly
        // when the finger does (the edge never runs away from, or lags far behind, the finger).
        val rel = (if (mirrored) spine - downX else downX - spine).coerceIn(0.35f * pw, pw)
        p = if (dir == FlipDir.NEXT) dragPx / (travel() * max(rel, 0.5f * pw))
        else 1f - dragPx / max(pw - rel, 0.35f * pw)
        p = p.coerceIn(0f, 1f)
        fingerY = y.coerceIn(0f, view.height.toFloat())
        view.setCurl(gate(p), fingerY)
    }

    private fun travel(): Float = if (style == PageFlipAnim.APPLE_CURL) 1.55f else 1.0f

    private fun dragEnd(dragPx: Float, velocity: Float, cancelled: Boolean) {
        if (!dragging) return
        if (capturing) {
            // Still photographing the page: decide as soon as it is done (see startTurn).
            early = Release(dragPx, velocity, cancelled)
            return
        }
        dragging = false
        val base = duration(config().speed)
        val w = view.width.toFloat()
        val complete = !cancelled && CurlGeometry.shouldComplete(dragPx, if (curl) pw else w, velocity, densityDpi())
        val id = turnId
        whenSettled { moved ->
            if (id != turnId) return@whenSettled
            val home = if (curl && dir == FlipDir.PREV) 1f else 0f
            val away = 1f - home
            val cur = if (curl) p else view.progress
            when {
                !moved -> finish()
                complete -> play(cur, away, max(110L, (base * kotlin.math.abs(away - cur) * 0.8f).toLong()), DecelerateInterpolator(1.3f)) { finish() }
                else -> {
                    revertPending = true
                    play(cur, home, max(90L, (base * kotlin.math.abs(home - cur) * 0.6f).toLong()), DecelerateInterpolator()) { revert() }
                }
            }
        }
    }

    /** A cancelled drag: the engine already moved, so put it back, then take the photograph away. */
    private fun revert() {
        if (revertPending) {
            revertPending = false
            target.restore(savedPosition)
        }
        val id = turnId
        handler.postDelayed({ if (id == turnId && !dragging && animator == null) finish() }, 140)
    }

    // ---------------------------------------------------------------------------------------------
    // Plumbing
    // ---------------------------------------------------------------------------------------------

    private fun setProgress(value: Float) {
        view.progress = value
        if (style == PageFlipAnim.TWO_WAY_SLIDE && !curl) {
            val w = view.width.toFloat()
            // The old page (photograph) leaves by value * w; the live, already-turned page follows right behind it.
            liveTranslate(if (exitLeft) w * (1f - value) else -w * (1f - value))
        }
    }

    private fun applyProgress(value: Float) {
        if (curl) {
            p = value
            view.setCurl(gate(value), if (synthetic) curlY(value) else fingerY)
        } else {
            setProgress(gate(value))
        }
    }

    private fun play(from: Float, to: Float, duration: Long, interpolator: TimeInterpolator, onDone: () -> Unit) {
        animator?.let { it.removeAllListeners(); it.cancel() }
        val a = ValueAnimator.ofFloat(from, to)
        a.duration = duration
        a.interpolator = interpolator
        a.addUpdateListener { applyProgress(it.animatedValue as Float) }
        a.addListener(object : AnimatorListenerAdapter() {
            private var cancelled = false
            override fun onAnimationCancel(animation: Animator) { cancelled = true }
            override fun onAnimationEnd(animation: Animator) {
                if (animator === animation) animator = null
                if (!cancelled) onDone()
            }
        })
        animator = a
        a.start()
    }

    private fun finish() {
        animator = null
        ++turnId
        capturing = false
        early = null
        lastOverlayEndAt = SystemClock.uptimeMillis()
        view.end()
        liveTranslate(0f)
        whenSettledQueue.clear()
        releaseBitmaps()
    }

    /** Ends everything at once (new turn starting, app going away). */
    fun finishNow() {
        handler.removeCallbacksAndMessages(null)
        resumeAfterReady = null
        animator?.let { it.removeAllListeners(); it.cancel() }
        animator = null
        if (revertPending) {
            revertPending = false
            target.restore(savedPosition)
        }
        dragging = false
        queued.clear()
        finish()
    }

    /**
     * Photographs the screen. With [Config.pixelCopy] this is a GPU copy of the window (a few milliseconds, no UI-thread
     * stall); a window copy would also contain this overlay, so it waits for a frame without it. Otherwise (or when the
     * copy fails) the views are drawn into a bitmap, which can take far longer with a WebView.
     */
    private fun captureAsync(cfg: Config, id: Int, done: (Bitmap?) -> Unit) {
        val w = view.width
        val h = view.height
        val win = window()
        if (!cfg.pixelCopy || win == null || w <= 0 || h <= 0) { done(capture()); return }
        val frames = if (SystemClock.uptimeMillis() - lastOverlayEndAt < 120) 2 else 0
        afterFrames(frames, id) {
            val bmp = obtain(w, h)
            if (bmp == null) {
                done(null)
            } else try {
                PixelCopy.request(win, Rect(0, 0, w, h), bmp, { result ->
                    if (id != turnId) give(bmp)
                    else if (result == PixelCopy.SUCCESS) done(bmp)
                    else { give(bmp); done(capture()) }
                }, handler)
            } catch (e: Exception) {
                give(bmp)
                done(capture())
            }
        }
    }

    // ---- bitmaps ----

    private fun obtain(w: Int, h: Int): Bitmap? {
        val i = pool.indexOfFirst { !it.isRecycled && it.width == w && it.height == h }
        val b = if (i >= 0) pool.removeAt(i).also { it.eraseColor(0) } else try {
            Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        } catch (e: OutOfMemoryError) {
            null
        }
        if (b != null) owned.add(b)
        return b
    }

    private fun give(b: Bitmap) {
        if (owned.remove(b)) pool.add(b)
        while (pool.size > 6) pool.removeAt(0).recycle()
    }

    private fun releaseBitmaps() {
        for (b in ArrayList(owned)) give(b)
    }

    /** Photograph of the whole screen: backdrop + the live reader. */
    private fun capture(): Bitmap? {
        val w = view.width
        val h = view.height
        if (w <= 0 || h <= 0) return null
        val bmp = obtain(w, h) ?: return null
        val c = Canvas(bmp)
        paintBase(c, w, h)
        for (layer in layers) layer.draw(c)
        return bmp
    }

    /** Copy of [width] columns of [src] starting at [x0], optionally mirrored left-to-right. */
    private fun slice(src: Bitmap, x0: Int, width: Int, height: Int, mirror: Boolean): Bitmap {
        val out = obtain(width, height) ?: throw OutOfMemoryError()
        val c = Canvas(out)
        if (mirror) c.scale(-1f, 1f, width / 2f, 0f)
        c.drawBitmap(src, Rect(x0, 0, x0 + width, height), RectF(0f, 0f, width.toFloat(), height.toFloat()), copyPaint)
        return out
    }

    /** Cheap fingerprint of a picture (sampled pixels), to tell whether the page has really changed. */
    private fun signature(bmp: Bitmap): Long {
        var hash = -0x340d631b7bdddcdbL
        val stepX = max(1, bmp.width / 32)
        val stepY = max(1, bmp.height / 48)
        var y = 0
        while (y < bmp.height) {
            var x = 0
            while (x < bmp.width) {
                hash = (hash xor bmp.getPixel(x, y).toLong()) * 0x100000001b3L
                x += stepX
            }
            y += stepY
        }
        return hash
    }

    fun release() {
        finishNow()
        for (b in pool) b.recycle()
        pool.clear()
    }

    private companion object {
        const val MAX_WAIT = 260L
        const val GATE = 0.08f
    }
}
