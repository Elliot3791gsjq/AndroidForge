package com.novelreader.app.formats.pdf

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Point
import android.graphics.pdf.PdfRenderer
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.LruCache
import androidx.annotation.RequiresApi
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.yield
import java.io.Closeable
import java.io.File
import java.io.IOException
import kotlin.math.ceil
import kotlin.math.sqrt

/** Text the user selected on one page, with the rectangles it covers (page space, points). */
class PdfTextSelection(val page: Int, val text: String, val rects: List<FloatArray>)

/**
 * Thin, thread-safe wrapper around the platform's [PdfRenderer] (PDFium). PdfRenderer allows ONE open page at a
 * time, so every access goes through [lock] (a fair mutex: a render waiting for the lock is served before the next
 * background size scan step). Text search / selection exist only on Android 15+ (API 35) and are guarded; on older
 * versions they simply return nothing and the reader hides those controls ([textSupported]).
 */
class PdfEngine private constructor(
    private val pfd: ParcelFileDescriptor,
    private val renderer: PdfRenderer,
) : Closeable {

    val pageCount: Int = renderer.pageCount

    private val lock = Mutex()
    @Volatile private var closed = false

    // Page sizes in points (unrotated). 0 = not read yet; until then the first page's size is assumed.
    private val widths = FloatArray(pageCount)
    private val heights = FloatArray(pageCount)
    @Volatile private var guessW = 612f
    @Volatile private var guessH = 792f

    private val _sizeVersion = MutableStateFlow(0)
    /** Grows whenever more page sizes become known (layout is recomputed). */
    val sizeVersion: StateFlow<Int> = _sizeVersion

    val textSupported: Boolean get() = Build.VERSION.SDK_INT >= 35

    init {
        // The first page is read up front so the layout has a sensible default for pages not scanned yet.
        try {
            renderer.openPage(0).use { p -> setSize(0, p.width.toFloat(), p.height.toFloat()) }
        } catch (_: Exception) {
        }
    }

    private fun setSize(i: Int, w: Float, h: Float) {
        if (i !in 0 until pageCount || w <= 0f || h <= 0f) return
        heights[i] = h
        widths[i] = w
        if (i == 0) { guessW = w; guessH = h }
    }

    /** Size of [page] in points as PdfRenderer reports it (null while not read yet). */
    fun sizeOf(page: Int): PdfSize? {
        if (page !in 0 until pageCount) return null
        val w = widths[page]
        val h = heights[page]
        return if (w > 0f && h > 0f) PdfSize(w, h) else null
    }

    fun sizeOrGuess(page: Int): PdfSize = sizeOf(page) ?: PdfSize(guessW, guessH)

    /** Reads the size of every page in the background (publishes progress through [sizeVersion]). */
    suspend fun scanSizes() {
        for (i in 0 until pageCount) {
            if (closed) return
            if (widths[i] > 0f) continue
            lock.withLock {
                if (!closed) {
                    try {
                        renderer.openPage(i).use { p -> setSize(i, p.width.toFloat(), p.height.toFloat()) }
                    } catch (_: Exception) {
                        setSize(i, guessW, guessH)
                    }
                }
            }
            if (i % 24 == 23) _sizeVersion.value = _sizeVersion.value + 1
            yield()
        }
        _sizeVersion.value = _sizeVersion.value + 1
    }

    /**
     * Renders [page] so that it is [widthPx] wide (height follows the page's real proportions; capped to about
     * 12 megapixels). Used for the "base" picture of a page and for thumbnails.
     */
    suspend fun renderToWidth(page: Int, rotation: Int, widthPx: Int): Bitmap? {
        if (widthPx <= 0 || page !in 0 until pageCount) return null
        return withContext(Dispatchers.IO) {
            try {
                lock.withLock {
                    ensureActive()   // a render nobody waits for any more is skipped
                    if (closed) return@withLock null
                    renderer.openPage(page).use { p ->
                        val w = p.width.toFloat()
                        val h = p.height.toFloat()
                        setSize(page, w, h)
                        val disp = PdfGeometry.displaySize(w, h, rotation)
                        var ppp = widthPx / disp.w
                        var outW = widthPx
                        var outH = ceil(disp.h * ppp).toInt().coerceAtLeast(1)
                        val px = outW.toLong() * outH
                        if (px > MAX_BASE_PIXELS) {
                            val f = sqrt(MAX_BASE_PIXELS.toDouble() / px).toFloat()
                            ppp *= f
                            outW = (outW * f).toInt().coerceAtLeast(1)
                            outH = (outH * f).toInt().coerceAtLeast(1)
                        }
                        drawInto(p, rotation, w, h, ppp, 0, 0, outW, outH)
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                null
            }
        }
    }

    /**
     * Renders the part of [page] that starts at display pixel ([left], [top]) when one point is [pxPerPt] pixels,
     * into a [width] x [height] bitmap: the crisp picture shown while zoomed in.
     */
    suspend fun renderRegion(page: Int, rotation: Int, pxPerPt: Float, left: Int, top: Int, width: Int, height: Int): Bitmap? {
        if (width <= 0 || height <= 0 || page !in 0 until pageCount) return null
        return withContext(Dispatchers.IO) {
            try {
                lock.withLock {
                    ensureActive()   // a render nobody waits for any more is skipped
                    if (closed) return@withLock null
                    renderer.openPage(page).use { p ->
                        setSize(page, p.width.toFloat(), p.height.toFloat())
                        drawInto(p, rotation, p.width.toFloat(), p.height.toFloat(), pxPerPt, left, top, width, height)
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                null
            }
        }
    }

    private fun drawInto(
        p: PdfRenderer.Page, rotation: Int, w: Float, h: Float, ppp: Float, left: Int, top: Int, outW: Int, outH: Int,
    ): Bitmap? {
        val bmp = try {
            Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        } catch (_: OutOfMemoryError) {
            return null
        }
        bmp.eraseColor(Color.WHITE)   // PdfRenderer paints only the page content, not the paper
        val m = Matrix()
        m.setValues(PdfGeometry.renderMatrix(rotation, w, h, ppp, left.toFloat(), top.toFloat()))
        p.render(bmp, null, m, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
        return bmp
    }

    // ---- text (Android 15+) ----

    /** Every match of [query] on [page]; a match is the list of rectangles (page space, points) it covers. */
    suspend fun search(page: Int, query: String): List<List<FloatArray>> {
        if (!textSupported || query.isBlank() || page !in 0 until pageCount) return emptyList()
        return withContext(Dispatchers.IO) {
            lock.withLock {
                if (closed) emptyList() else try {
                    Api35.search(renderer, page, query)
                } catch (e: CancellationException) {
                    throw e
                } catch (_: Throwable) {
                    emptyList()
                }
            }
        }
    }

    /** Text between two page-space points (a word when both are the same point), or null when there is none. */
    suspend fun selectText(page: Int, ax: Float, ay: Float, bx: Float, by: Float): PdfTextSelection? {
        if (!textSupported || page !in 0 until pageCount) return null
        return withContext(Dispatchers.IO) {
            lock.withLock {
                if (closed) null else try {
                    Api35.select(renderer, page, ax, ay, bx, by)
                } catch (e: CancellationException) {
                    throw e
                } catch (_: Throwable) {
                    null
                }
            }
        }
    }

    @RequiresApi(35)
    private object Api35 {
        fun search(r: PdfRenderer, page: Int, q: String): List<List<FloatArray>> =
            r.openPage(page).use { p ->
                p.searchText(q).map { m ->
                    m.bounds.map { b -> floatArrayOf(b.left.toFloat(), b.top.toFloat(), b.right.toFloat(), b.bottom.toFloat()) }
                }
            }

        fun select(r: PdfRenderer, page: Int, ax: Float, ay: Float, bx: Float, by: Float): PdfTextSelection? =
            r.openPage(page).use { p ->
                val sel = p.selectContent(
                    android.graphics.pdf.models.selection.SelectionBoundary(Point(ax.toInt(), ay.toInt())),
                    android.graphics.pdf.models.selection.SelectionBoundary(Point(bx.toInt(), by.toInt())),
                ) ?: return@use null
                val parts = sel.selectedTextContents
                val text = parts.joinToString(" ") { it.text }.trim()
                if (text.isEmpty()) return@use null
                val rects = parts.flatMap { c ->
                    c.bounds.map { b -> floatArrayOf(b.left.toFloat(), b.top.toFloat(), b.right.toFloat(), b.bottom.toFloat()) }
                }
                PdfTextSelection(page, text, rects)
            }
    }

    override fun close() {
        if (closed) return
        closed = true
        // Closing waits for a render in progress, so it happens off the calling (main) thread.
        CoroutineScope(Dispatchers.IO).launch {
            lock.withLock {
                try { renderer.close() } catch (_: Exception) { }
                try { pfd.close() } catch (_: IOException) { }
            }
        }
    }

    companion object {
        private const val MAX_BASE_PIXELS = 12_000_000L

        /**
         * Opens [file]. Throws [SecurityException] for a password-protected PDF and [IOException] (or
         * IllegalArgumentException from the platform) for a damaged one.
         */
        fun open(file: File): PdfEngine {
            val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            try {
                val r = PdfRenderer(pfd)
                if (r.pageCount <= 0) {
                    r.close()
                    throw IOException("PDF has no pages")
                }
                return PdfEngine(pfd, r)
            } catch (t: Throwable) {
                try { pfd.close() } catch (_: IOException) { }
                throw t
            }
        }
    }
}

/** Byte-budgeted cache of rendered page pictures (and thumbnails). */
class PdfBitmapCache(private val engine: PdfEngine, budgetBytes: Int) {
    private data class Key(val page: Int, val rotation: Int, val widthPx: Int)

    private val lru = object : LruCache<Key, Bitmap>(budgetBytes.coerceAtLeast(4 * 1024 * 1024)) {
        override fun sizeOf(key: Key, value: Bitmap): Int = value.byteCount
    }

    fun peek(page: Int, rotation: Int, widthPx: Int): Bitmap? = lru.get(Key(page, rotation, widthPx))

    suspend fun get(page: Int, rotation: Int, widthPx: Int): Bitmap? {
        val key = Key(page, rotation, widthPx)
        lru.get(key)?.let { return it }
        val bmp = engine.renderToWidth(page, rotation, widthPx) ?: return null
        lru.put(key, bmp)
        return bmp
    }

    fun clear() = lru.evictAll()
}
