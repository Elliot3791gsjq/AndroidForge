package com.novelreader.app.reader.curl

/*
 * The curl renderers in this package (CurlRenderer, IBookCurlRenderer, GoogleCurlRenderer and the geometry helpers)
 * are taken from https://github.com/Peyilo/libreadview (MIT License, Copyright (c) 2025 Peyilo) and adapted:
 * logging removed, the revealed page and the back of the sheet are optional bitmaps, and the degenerate
 * "finger exactly on the corner" state is guarded. Licence text: see THIRD_PARTY_NOTICES.md.
 */

/** Direction of one page turn. NEXT: the current page leaves; PREV: the previous page comes back over it. */
enum class FlipDir { NONE, NEXT, PREV }

@Suppress("UNUSED_PARAMETER")
internal inline fun computeTime(tag: String, msg: String, block: () -> Unit) = block()
