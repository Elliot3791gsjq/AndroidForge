package com.novelreader.app.ui.reader

import androidx.activity.compose.rememberLauncherForActivityResult
import android.net.Uri
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import com.novelreader.app.core.PickKind
import com.novelreader.app.ui.files.PickFromStorage
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import com.novelreader.app.ui.design.AlertDialog
import com.novelreader.app.ui.design.Button
import androidx.compose.material3.Card
import com.novelreader.app.ui.design.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import com.novelreader.app.ui.design.OutlinedButton
import com.novelreader.app.ui.design.RadioButton
import com.novelreader.app.ui.design.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.novelreader.app.R
import com.novelreader.app.core.ColorMath
import com.novelreader.app.data.AlignMode
import com.novelreader.app.data.BgImageMode
import com.novelreader.app.data.CustomFont
import com.novelreader.app.data.DirectionMode
import com.novelreader.app.data.FontChoice
import com.novelreader.app.data.ReaderSettings
import com.novelreader.app.data.Swatches
import com.novelreader.app.data.effectiveBackground
import com.novelreader.app.data.effectiveText
import com.novelreader.app.data.ReadingThemes
import com.novelreader.app.graph
import com.novelreader.app.reader.ReaderViewModel
import com.novelreader.app.ui.ChoiceChips
import com.novelreader.app.ui.ColorPickerDialog
import com.novelreader.app.ui.Localized
import com.novelreader.app.ui.design.Checkbox
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.clickable
import androidx.compose.ui.graphics.Color
import com.novelreader.app.ui.SectionTitle
import com.novelreader.app.ui.design.MutedText
import com.novelreader.app.ui.design.appClickable
import com.novelreader.app.ui.design.palette
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import com.novelreader.app.ui.StepperSlider
import com.novelreader.app.ui.SwatchRow
import java.io.File

// =============================================================================================
// Text & fonts
// =============================================================================================

private val SUGGESTED_FONTS = listOf(
    "Vazirmatn-Regular.ttf" to R.string.font_vazirmatn,
    "Amiri-Regular.ttf" to R.string.font_amiri,
    "Lora-Regular.ttf" to R.string.font_lora,
)

@Composable
fun TextPanel(vm: ReaderViewModel) {
    val s by vm.settings.collectAsState()
    val fonts by vm.customFonts.collectAsState()
    val available by vm.availableFontIds.collectAsState()
    val context = LocalContext.current
    var confirmDelete by remember { mutableStateOf<Set<String>?>(null) }
    var checked by remember { mutableStateOf<Set<String>>(emptySet()) }
    // Drop ticks for fonts that no longer exist.
    val ticked = checked.intersect(fonts.map { it.id }.toSet())

    // The app's own file manager: browse the real storage, tick any number of fonts or press "Select all".
    val pickFonts = rememberLauncherForActivityResult(PickFromStorage()) { list ->
        vm.importFonts(list.map { Uri.parse(it) })
    }
    val usingCustom = s.faFontId != null || s.latinFontId != null

    LazyColumn(Modifier.fillMaxWidth(), contentPadding = PaddingValues(bottom = 16.dp)) {
      item { Column {
        StepperSlider(
            label = stringResource(R.string.font_size),
            value = s.fontSizePercent.toFloat(),
            range = 50f..300f,
            step = 5f,
            valueText = { Localized.percent(it.toInt()) },
            onCommit = { v -> vm.updateSettings { it.copy(fontSizePercent = v.toInt()) } },
        )

        SectionTitle(stringResource(R.string.fonts_section_builtin))
        listOf(
            FontChoice.ORIGINAL to stringResource(R.string.default_font_system),
            FontChoice.SERIF to stringResource(R.string.font_serif),
            FontChoice.SANS_SERIF to stringResource(R.string.font_sans),
            FontChoice.MONOSPACE to stringResource(R.string.font_monospace),
        ).forEach { (choice, label) ->
            CompactRow(
                selected = !usingCustom && s.fontChoice == choice,
                onClick = { vm.updateSettings { it.copy(fontChoice = choice, faFontId = null, latinFontId = null) } },
            ) {
                Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                if (choice == FontChoice.ORIGINAL) Text(stringResource(R.string.font_default_tag), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        if (usingCustom && s.keepPublisherStyles) {
            Text(stringResource(R.string.font_publisher_hint), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
        }

        SectionTitle(stringResource(R.string.fonts_section_suggested))
        Text(stringResource(R.string.fonts_suggested_hint), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        SUGGESTED_FONTS.forEach { (asset, label) ->
            val installed = fonts.firstOrNull { it.originalName.equals(asset, ignoreCase = true) }
            CompactRow(
                selected = installed != null && (s.faFontId == installed.id || s.latinFontId == installed.id),
                onClick = {
                    if (installed != null && installed.id in available) vm.selectFonts(
                        if (installed.coversPersian) installed.id else s.faFontId,
                        if (installed.coversLatin) installed.id else s.latinFontId,
                    ) else vm.useBundledFont(asset)
                },
            ) {
                Text(stringResource(label), style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                if (installed != null) Text(stringResource(R.string.font_installed), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
            }
        }

        SectionTitle(stringResource(R.string.fonts_section_imported))
        if (fonts.isEmpty()) {
            Text(stringResource(R.string.imported_fonts_empty), style = MaterialTheme.typography.bodySmall)
        } else {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(
                    checked = ticked.size == fonts.size,
                    onCheckedChange = { all -> checked = if (all) fonts.map { it.id }.toSet() else emptySet() },
                )
                Text(stringResource(R.string.font_select_all), style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                TextButton(onClick = { confirmDelete = ticked }, enabled = ticked.isNotEmpty()) {
                    Text(stringResource(R.string.font_delete_selected, ticked.size), color = if (ticked.isNotEmpty()) MaterialTheme.colorScheme.error else Color.Unspecified)
                }
            }
        }
      } }
        items(fonts, key = { it.id }) { font ->
            FontRow(
                font = font,
                file = context.graph.fonts.file(font),
                ticked = font.id in ticked,
                persianSelected = s.faFontId == font.id,
                latinSelected = s.latinFontId == font.id,
                onTick = { on -> checked = if (on) ticked + font.id else ticked - font.id },
                onPersian = { on -> vm.selectFonts(if (on) font.id else null, s.latinFontId) },
                onLatin = { on -> vm.selectFonts(s.faFontId, if (on) font.id else null) },
            )
        }
      item { Column {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { pickFonts.launch(PickKind.FONTS) }) {
                Icon(Icons.Default.Add, contentDescription = null)
                Text(stringResource(R.string.font_import_many), modifier = Modifier.padding(start = 6.dp))
            }
            OutlinedButton(onClick = { vm.resetFonts() }, enabled = usingCustom || s.fontChoice != FontChoice.ORIGINAL) {
                Text(stringResource(R.string.reset_font))
            }
        }
        Text(
            stringResource(R.string.font_import_picker_hint) + " " + stringResource(R.string.font_import_note),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 6.dp),
        )
      } }
    }

    confirmDelete?.let { ids ->
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            title = { Text(stringResource(R.string.delete_font_title)) },
            text = { Text(stringResource(R.string.font_delete_selected, ids.size)) },
            confirmButton = {
                TextButton(onClick = { vm.deleteFonts(ids); checked = emptySet(); confirmDelete = null }) { Text(stringResource(R.string.delete)) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = null }) { Text(stringResource(R.string.cancel)) } },
        )
    }
}

@Composable
private fun CompactRow(selected: Boolean, onClick: () -> Unit, content: @Composable androidx.compose.foundation.layout.RowScope.() -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = onClick)
        content()
    }
}

@Composable
private fun FontRow(
    font: CustomFont,
    file: File,
    ticked: Boolean,
    persianSelected: Boolean,
    latinSelected: Boolean,
    onTick: (Boolean) -> Unit,
    onPersian: (Boolean) -> Unit,
    onLatin: (Boolean) -> Unit,
) {
    // The name is drawn with the real font file (Compose's text engine; not the EPUB WebView).
    val preview: FontFamily? = remember(font.id) {
        try {
            if (file.isFile) FontFamily(Font(file, FontWeight(font.weight), if (font.italic) FontStyle.Italic else FontStyle.Normal)) else null
        } catch (_: Throwable) {
            null
        }
    }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = ticked, onCheckedChange = onTick)
        Column(Modifier.weight(1f)) {
            Text(font.displayName, style = MaterialTheme.typography.titleSmall.copy(fontFamily = preview), maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
            val tags = buildList {
                add(font.extension.uppercase())
                if (font.coversPersian) add(stringResource(R.string.font_has_persian))
                if (font.coversLatin) add(stringResource(R.string.font_has_latin))
            }
            Text(tags.joinToString(" · "), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
        }
        // Always tappable: choosing a font the open book does not know yet makes the reader reload itself once.
        FilterChip(selected = persianSelected, onClick = { onPersian(!persianSelected) }, label = { Text(stringResource(R.string.font_use_fa_short)) })
        Spacer(Modifier.width(4.dp))
        FilterChip(selected = latinSelected, onClick = { onLatin(!latinSelected) }, label = { Text(stringResource(R.string.font_use_en_short)) })
    }
}

// =============================================================================================
// Layout
// =============================================================================================

@Composable
fun LayoutPanel(vm: ReaderViewModel) {
    val s by vm.settings.collectAsState()
    Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 16.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(stringResource(R.string.keep_publisher_styles), style = MaterialTheme.typography.bodyLarge)
                Text(
                    stringResource(R.string.keep_publisher_styles_hint),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Switch(checked = s.keepPublisherStyles, onCheckedChange = { on -> vm.updateSettings { it.copy(keepPublisherStyles = on) } })
        }

        StepperSlider(
            label = stringResource(R.string.line_height),
            value = s.lineHeight.toFloat(), range = 1f..2.5f, step = 0.05f,
            valueText = { Localized.decimal(it.toDouble(), 2) },
            onCommit = { v -> vm.updateSettings { it.copy(lineHeight = v.toDouble(), keepPublisherStyles = false) } },
        )
        StepperSlider(
            label = stringResource(R.string.paragraph_spacing),
            value = s.paragraphSpacing.toFloat(), range = 0f..3f, step = 0.1f,
            valueText = { Localized.decimal(it.toDouble(), 1) },
            onCommit = { v -> vm.updateSettings { it.copy(paragraphSpacing = v.toDouble(), keepPublisherStyles = false) } },
        )
        StepperSlider(
            label = stringResource(R.string.paragraph_indent),
            value = s.paragraphIndent.toFloat(), range = 0f..3f, step = 0.1f,
            valueText = { Localized.decimal(it.toDouble(), 1) },
            onCommit = { v -> vm.updateSettings { it.copy(paragraphIndent = v.toDouble(), keepPublisherStyles = false) } },
        )
        StepperSlider(
            label = stringResource(R.string.page_margins),
            value = s.pageMargins.toFloat(), range = 0.5f..3f, step = 0.1f,
            valueText = { Localized.decimal(it.toDouble(), 1) },
            onCommit = { v -> vm.updateSettings { it.copy(pageMargins = v.toDouble()) } },
        )

        SectionTitle(stringResource(R.string.text_alignment))
        ChoiceChips(
            options = listOf(
                AlignMode.ORIGINAL to stringResource(R.string.align_original),
                AlignMode.RIGHT to stringResource(R.string.align_right),
                AlignMode.CENTER to stringResource(R.string.align_center),
                AlignMode.LEFT to stringResource(R.string.align_left),
            ),
            selected = s.align,
            onSelect = { a -> vm.updateSettings { it.copy(align = a, keepPublisherStyles = if (a == AlignMode.ORIGINAL) it.keepPublisherStyles else false) } },
        )

        OutlinedButton(
            onClick = {
                vm.updateSettings {
                    it.copy(
                        keepPublisherStyles = true, lineHeight = 1.5, paragraphSpacing = 0.5, paragraphIndent = 0.0,
                        align = AlignMode.ORIGINAL, pageMargins = 1.0,
                    )
                }
            },
            modifier = Modifier.padding(top = 12.dp),
        ) { Text(stringResource(R.string.restore_book_layout)) }
    }
}

// =============================================================================================
// Colours of the reading page. These are the BOOK's colours: they never follow the app UI theme, and the app UI
// theme (Settings > Appearance) never changes them. There is no contrast refusal here - any colour is accepted.
// =============================================================================================

private fun readingThemeName(id: String): Int = when (id) {
    "night" -> R.string.rt_night
    "slate" -> R.string.rt_slate
    "sepia" -> R.string.rt_sepia
    "cream" -> R.string.rt_cream
    "mint" -> R.string.rt_mint
    "paper" -> R.string.rt_paper
    else -> R.string.rt_black
}

@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun ColorsPanel(vm: ReaderViewModel) {
    val s by vm.settings.collectAsState()
    var pickText by remember { mutableStateOf(false) }
    var pickBg by remember { mutableStateOf(false) }

    val bg = s.effectiveBackground()
    val fg = s.effectiveText()

    // Every way to reach pictures on the phone (gallery, any file manager, in-app storage browser).
    var showImagePicker by remember { mutableStateOf(false) }
    com.novelreader.app.ui.files.ImagePickerHost(
        visible = showImagePicker,
        onDismiss = { showImagePicker = false },
        onPicked = { uri -> showImagePicker = false; vm.importBackground(uri) },
    )

    Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 16.dp)) {
        SectionTitle(stringResource(R.string.reading_theme))
        androidx.compose.foundation.layout.FlowRow(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            ReadingThemes.all.forEach { t ->
                val selected = bg == t.background && fg == t.text
                ReadingThemeTile(
                    name = stringResource(readingThemeName(t.id)), theme = t, selected = selected,
                    onClick = {
                        vm.updateSettings {
                            it.copy(
                                theme = if (t.isDark) com.novelreader.app.data.ThemeMode.DARK else com.novelreader.app.data.ThemeMode.LIGHT,
                                backgroundColor = t.background, textColor = t.text,
                            )
                        }
                    },
                )
            }
        }
        MutedText(stringResource(R.string.reading_theme_hint), Modifier.padding(top = 8.dp))

        // Live sample of the page colours currently in effect.
        Box(
            Modifier.fillMaxWidth().padding(top = 12.dp).clip(RoundedCornerShape(16.dp)).background(Color(bg))
                .border(1.dp, palette.outline, RoundedCornerShape(16.dp)).padding(16.dp),
        ) {
            Text(stringResource(R.string.page_preview_sample), color = Color(fg), style = MaterialTheme.typography.bodyLarge)
        }

        SectionTitle(stringResource(R.string.background_color))
        SwatchRow(colors = Swatches.background, selected = s.backgroundColor, onPick = { c -> vm.updateSettings { it.copy(backgroundColor = c) } })
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
            OutlinedButton(onClick = { pickBg = true }) { Text(stringResource(R.string.custom_color)) }
            OutlinedButton(onClick = { vm.updateSettings { it.copy(backgroundColor = null) } }, enabled = s.backgroundColor != null) {
                Text(stringResource(R.string.restore_original))
            }
        }

        SectionTitle(stringResource(R.string.text_color))
        SwatchRow(colors = Swatches.text, selected = s.textColor, onPick = { c -> vm.updateSettings { it.copy(textColor = c) } })
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
            OutlinedButton(onClick = { pickText = true }) { Text(stringResource(R.string.custom_color)) }
            OutlinedButton(onClick = { vm.updateSettings { it.copy(textColor = null) } }, enabled = s.textColor != null) {
                Text(stringResource(R.string.restore_original))
            }
        }

        SectionTitle(stringResource(R.string.background_image))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { showImagePicker = true }) {
                Text(stringResource(R.string.choose_image))
            }
            OutlinedButton(onClick = { vm.removeBackgroundImage() }, enabled = s.backgroundImagePath != null) {
                Text(stringResource(R.string.remove_image))
            }
        }
        if (s.backgroundImagePath != null) {
            ChoiceChips(
                options = listOf(
                    BgImageMode.COVER to stringResource(R.string.bg_cover),
                    BgImageMode.FIT to stringResource(R.string.bg_fit),
                    BgImageMode.TILE to stringResource(R.string.bg_tile),
                ),
                selected = s.backgroundImageMode,
                onSelect = { m -> vm.updateSettings { it.copy(backgroundImageMode = m) } },
                modifier = Modifier.padding(top = 8.dp),
            )
            StepperSlider(
                label = stringResource(R.string.bg_opacity),
                value = s.backgroundImageOpacity, range = 0f..1f, step = 0.05f,
                valueText = { Localized.percent((it * 100).toInt()) },
                onCommit = { v -> vm.updateSettings { it.copy(backgroundImageOpacity = v) } },
            )
        }
    }

    if (pickText) {
        ColorPickerDialog(
            title = stringResource(R.string.text_color),
            initial = fg,
            onDismiss = { pickText = false },
            onConfirm = { c ->
                vm.updateSettings { it.copy(textColor = c) }
                pickText = false
            },
            preview = { c -> Text("Aa", color = Color(c), style = MaterialTheme.typography.titleMedium) },
        )
    }
    if (pickBg) {
        ColorPickerDialog(
            title = stringResource(R.string.background_color),
            initial = bg,
            onDismiss = { pickBg = false },
            onConfirm = { c ->
                vm.updateSettings {
                    it.copy(
                        backgroundColor = c,
                        theme = if (com.novelreader.app.core.ColorMath.isDark(c)) com.novelreader.app.data.ThemeMode.DARK else com.novelreader.app.data.ThemeMode.LIGHT,
                    )
                }
                pickBg = false
            },
        )
    }
}

/** A reading-theme swatch: the page colours with a sample glyph. */
@Composable
private fun ReadingThemeTile(name: String, theme: com.novelreader.app.data.ReadingTheme, selected: Boolean, onClick: () -> Unit) {
    val p = palette
    Column(
        Modifier
            .width(104.dp)
            .appClickable(onClick, role = androidx.compose.ui.semantics.Role.RadioButton, scaleTo = 0.95f)
            .clip(RoundedCornerShape(16.dp))
            .background(Color(theme.background))
            .border(if (selected) 2.5.dp else 1.dp, if (selected) p.accent else p.outline, RoundedCornerShape(16.dp))
            .padding(12.dp),
    ) {
        Text("Aa", color = Color(theme.text), style = MaterialTheme.typography.headlineSmall)
        Text(name, color = Color(theme.text), style = MaterialTheme.typography.labelMedium, maxLines = 1)
    }
}

// =============================================================================================
// Scroll, direction, fullscreen
// =============================================================================================

@Composable
fun ScrollPanel(vm: ReaderViewModel) {
    val s: ReaderSettings by vm.settings.collectAsState()
    Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 16.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(stringResource(R.string.fullscreen), style = MaterialTheme.typography.bodyLarge)
                Text(
                    stringResource(R.string.fullscreen_hint),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Switch(checked = s.fullscreen, onCheckedChange = { on -> vm.updateSettings { it.copy(fullscreen = on) } })
        }

        SectionTitle(stringResource(R.string.zoom))
        Text(
            stringResource(R.string.zoom_note),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
