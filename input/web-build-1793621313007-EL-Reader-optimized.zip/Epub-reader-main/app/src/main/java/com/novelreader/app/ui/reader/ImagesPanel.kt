package com.novelreader.app.ui.reader

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.novelreader.app.R
import com.novelreader.app.reader.ImageItem
import com.novelreader.app.reader.ReaderViewModel
import com.novelreader.app.ui.AppIcons
import com.novelreader.app.ui.Localized
import com.novelreader.app.ui.design.AppShapes
import com.novelreader.app.ui.design.appClickable
import com.novelreader.app.ui.design.palette

/**
 * Every picture of the book (read from the EPUB itself) as a thumbnail grid. Tapping one closes the panel and
 * opens the book exactly where that picture is.
 */
@Composable
fun ImagesPanel(vm: ReaderViewModel, onClose: () -> Unit) {
    val items by vm.images.collectAsState()
    LaunchedEffect(Unit) { vm.loadImages() }
    val list = items
    when {
        list == null -> Box(Modifier.fillMaxWidth().padding(vertical = 40.dp), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = palette.accent)
        }
        list.isEmpty() -> Text(
            stringResource(R.string.images_empty),
            style = MaterialTheme.typography.bodyMedium, color = palette.textMuted, textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(vertical = 32.dp),
        )
        else -> LazyVerticalGrid(
            columns = GridCells.Adaptive(92.dp),
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(bottom = 16.dp, top = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            itemsIndexed(list, key = { _, it -> it.ref.globalIndex }) { n, item ->
                ImageTile(n + 1, item, vm) { vm.goToImage(item); onClose() }
            }
        }
    }
}

@Composable
private fun ImageTile(number: Int, item: ImageItem, vm: ReaderViewModel, onClick: () -> Unit) {
    val p = palette
    val bmp by produceState<ImageBitmap?>(null, item.ref.globalIndex) {
        value = vm.imageThumbnail(item, 320)?.asImageBitmap()
    }
    Column(Modifier.appClickable(onClick, scaleTo = 0.96f)) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(3f / 4f)
                .clip(AppShapes.chip)
                .background(p.surfaceHigh),
            contentAlignment = Alignment.Center,
        ) {
            val img = bmp
            if (img != null) {
                Image(bitmap = img, contentDescription = item.ref.alt, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            } else {
                Icon(AppIcons.Image, contentDescription = null, tint = p.textMuted, modifier = Modifier.size(28.dp))
            }
            Box(
                Modifier
                    .align(Alignment.TopStart)
                    .padding(6.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.62f))
                    .padding(horizontal = 7.dp, vertical = 2.dp),
            ) {
                Text(Localized.number(number), style = MaterialTheme.typography.labelSmall, color = Color.White)
            }
        }
        Text(
            item.chapter ?: item.ref.alt ?: stringResource(R.string.image_number, Localized.number(number)),
            style = MaterialTheme.typography.labelSmall, color = p.textMuted,
            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp),
        )
    }
}
