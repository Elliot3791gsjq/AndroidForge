package com.novelreader.app.formats.doc

import com.novelreader.app.formats.BookFormat
import com.novelreader.app.formats.DocAlign
import com.novelreader.app.formats.DocDirection
import com.novelreader.app.formats.DocFont
import com.novelreader.app.formats.DocRange
import com.novelreader.app.formats.DocSettings
import com.novelreader.app.formats.TextBookOptions
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedWriter
import java.io.ByteArrayInputStream
import java.io.Closeable
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStreamWriter
import java.io.SequenceInputStream
import java.util.Collections
import java.util.zip.ZipFile

object DocLimits {
    /** Largest plain-text file taken in (the text is held in memory as UTF-16 once loaded). */
    const val MAX_TXT_BYTES = 16L * 1024 * 1024

    /** From this many blocks on the page skips the layout of off-screen blocks (see doc.css / doc.js). */
    const val BIG_BLOCKS = 1500
}

class EmptyDocException : Exception("nothing to show")
class DocTooLargeException : Exception("document too large")

/** A parsed document ready to be served to the WebView: the markup as three pieces, the images, the block texts. */
class DocPage(
    val result: DocParseResult,
    private val bodyFile: File,
    private val head: ByteArray,
    private val tail: ByteArray,
    /** The encoding a text file was read with (null for .docx). */
    val encoding: TextEncoding?,
    /** The encoding automatic detection picks for the file, even while another one is forced (null for .docx). */
    val autoEncoding: TextEncoding?,
    private val zip: ZipFile?,
) : Closeable {

    fun openHtml(): InputStream = SequenceInputStream(
        Collections.enumeration(
            listOf<InputStream>(ByteArrayInputStream(head), BufferedInputStream(FileInputStream(bodyFile), 1 shl 16), ByteArrayInputStream(tail))
        )
    )

    /** MIME type and bytes of document image [index], or null. */
    fun openImage(index: Int): Pair<String, InputStream>? {
        val img = result.images.getOrNull(index) ?: return null
        val z = zip ?: return null
        val e = z.getEntry(img.entry) ?: return null
        return img.mime to z.getInputStream(e)
    }

    override fun close() {
        try { zip?.close() } catch (_: Exception) { }
        bodyFile.delete()
    }
}

/** Reads TXT and DOCX files into a [DocPage]. Pure JVM; blocking, call it off the main thread. */
object DocLoader {

    fun load(file: File, format: BookFormat, bodyFile: File, options: TextBookOptions, title: String?, docx: DocxParser = DocxParser()): DocPage {
        bodyFile.parentFile?.mkdirs()
        var encoding: TextEncoding? = null
        var autoEncoding: TextEncoding? = null
        val result: DocParseResult = BufferedWriter(OutputStreamWriter(FileOutputStream(bodyFile), Charsets.UTF_8), 1 shl 16).use { w ->
            when (format) {
                BookFormat.TXT -> {
                    if (file.length() > DocLimits.MAX_TXT_BYTES) throw DocTooLargeException()
                    val decoded = TextDecoder.decode(file.readBytes(), options.encoding)
                    encoding = decoded.encoding
                    autoEncoding = decoded.auto
                    TxtParser.parse(decoded.text, options.paragraphMode, title, w)
                }
                BookFormat.DOCX -> try {
                    docx.parse(file, w)
                } catch (e: DocxException) {
                    if (e.reason == DocxException.Reason.TOO_LARGE) throw DocTooLargeException() else throw e
                }
                else -> throw IllegalArgumentException("not a document format: $format")
            }
        }
        if (result.texts.isEmpty() && result.images.isEmpty()) {
            bodyFile.delete()
            throw EmptyDocException()
        }
        val big = result.texts.size > DocLimits.BIG_BLOCKS
        val head = ("<!doctype html><html><head><meta charset=\"utf-8\">" +
            "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1\">" +
            "<link rel=\"stylesheet\" href=\"/doc.css\"><link rel=\"stylesheet\" href=\"/fonts.css\"></head>" +
            "<body" + (if (big) " class=\"big\"" else "") + "><main id=\"doc\">").toByteArray(Charsets.UTF_8)
        val tail = "</main><script src=\"/doc.js\"></script></body></html>".toByteArray(Charsets.UTF_8)
        val zip = if (format == BookFormat.DOCX && result.images.isNotEmpty()) ZipFile(file) else null
        return DocPage(result, bodyFile, head, tail, encoding, autoEncoding, zip)
    }
}

/** The JSON the page's script takes (pure, unit-tested). */
object DocJs {

    /** CSS font stack for a [DocSettings] choice; [customFamily] is the CSS family of the chosen imported font. */
    fun fontStack(s: DocSettings, customFamily: String?): String = when {
        customFamily != null -> "\"$customFamily\",sans-serif"
        else -> when (s.font) {
            DocFont.SYSTEM_SANS -> "sans-serif"
            DocFont.SYSTEM_SERIF -> "serif"
            DocFont.MONO -> "monospace"
            DocFont.VAZIRMATN -> "\"Vazirmatn\",sans-serif"
            DocFont.AMIRI -> "\"Amiri\",serif"
            DocFont.LORA -> "\"Lora\",serif"
        }
    }

    fun cssColor(argb: Int): String = String.format("#%06X", argb and 0xFFFFFF)

    fun style(s: DocSettings, format: BookFormat, fg: Int, bg: Int, link: Int, dark: Boolean, customFamily: String?): JSONObject = JSONObject()
        .put("fs", s.fontSize)
        .put("lh", s.lineHeight.toDouble())
        .put("para", s.paragraphSpacing.toDouble())
        .put("mx", s.marginDp)
        .put("indent", if (format == BookFormat.TXT) s.indent.toDouble() else 0.0)
        .put("fg", cssColor(fg))
        .put("bg", cssColor(bg))
        .put("link", cssColor(link))
        .put("font", fontStack(s, customFamily))
        .put("weight", s.weight)
        .put("align", when (if (format == BookFormat.TXT && s.align == DocAlign.DOCUMENT) DocAlign.START else s.align) {
            DocAlign.DOCUMENT -> "doc"
            DocAlign.START -> "start"
            DocAlign.JUSTIFY -> "justify"
            DocAlign.CENTER -> "center"
        })
        .put("dir", when (s.direction) { DocDirection.AUTO -> "auto"; DocDirection.LTR -> "ltr"; DocDirection.RTL -> "rtl" })
        .put("docFonts", format == BookFormat.DOCX && s.useDocFonts)
        .put("docColors", format != BookFormat.DOCX || s.keepDocColors)
        .put("dark", dark)

    /** One highlight as the script wants it: per-block pieces with id, colour and kind. */
    class HighlightJs(val id: Long, val range: DocRange, val color: Int, val kind: String)

    fun highlights(items: List<HighlightJs>, texts: List<String>): JSONArray {
        val arr = JSONArray()
        for (h in items) {
            for (pc in h.range.pieces { b -> texts.getOrNull(b)?.length ?: -1 }) {
                arr.put(JSONObject().put("id", h.id).put("b", pc[0]).put("s", pc[1]).put("e", pc[2]).put("c", cssColor(h.color)).put("k", h.kind))
            }
        }
        return arr
    }

    fun hits(hits: List<DocHit>): JSONArray {
        val arr = JSONArray()
        for (h in hits) arr.put(JSONArray().put(h.block).put(h.start).put(h.end))
        return arr
    }
}
