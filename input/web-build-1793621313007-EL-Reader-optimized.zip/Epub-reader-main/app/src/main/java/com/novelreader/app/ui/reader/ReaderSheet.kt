package com.novelreader.app.ui.reader

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.novelreader.app.R
import com.novelreader.app.reader.ReaderGroup
import com.novelreader.app.reader.ReaderTab
import com.novelreader.app.reader.ReaderViewModel
import com.novelreader.app.ui.design.AppChip
import com.novelreader.app.ui.design.AppShapes
import com.novelreader.app.ui.design.SheetHandle
import com.novelreader.app.ui.design.SoftIconButton
import com.novelreader.app.ui.design.palette
import androidx.compose.material3.MaterialTheme

/**
 * Non-modal bottom panel (no scrim) so every change is visible live in the upper part of the page.
 * It takes at most about half of the screen height. The caller animates it in and out.
 */
@Composable
fun ReaderSheet(vm: ReaderViewModel, onDismiss: () -> Unit) {
    BackHandler(onBack = onDismiss)
    val tab by vm.tab.collectAsState()
    val tabs = ReaderGroup.of(tab).tabs
    val p = palette

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val maxPanel = maxHeight * 0.55f
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .heightIn(max = maxPanel)
                .shadow(24.dp, AppShapes.sheet, ambientColor = Color.Black, spotColor = Color.Black)
                .clip(AppShapes.sheet)
                .background(p.surface)
                .border(1.dp, p.outline, AppShapes.sheet)
                .windowInsetsPadding(WindowInsets.navigationBars),
        ) {
            Box(Modifier.fillMaxWidth().padding(top = 8.dp), contentAlignment = Alignment.Center) { SheetHandle() }
            Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                if (tabs.size == 1) {
                    Text(
                        stringResource(tabs.first().labelRes()),
                        style = MaterialTheme.typography.titleMedium,
                        color = p.text,
                        modifier = Modifier.weight(1f),
                    )
                } else {
                    Row(
                        Modifier.weight(1f).horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        tabs.forEach { t -> AppChip(stringResource(t.labelRes()), selected = t == tab, onClick = { vm.openTab(t) }, leadingIcon = t.icon()) }
                    }
                }
                SoftIconButton(Icons.Default.Close, stringResource(R.string.close), onDismiss, size = 40.dp, filled = false)
            }
            Box(Modifier.weight(1f, fill = false).padding(horizontal = 16.dp)) {
                when (tab) {
                    ReaderTab.TEXT -> TextPanel(vm)
                    ReaderTab.LAYOUT -> LayoutPanel(vm)
                    ReaderTab.COLORS -> ColorsPanel(vm)
                    ReaderTab.SCROLL -> ScrollPanel(vm)
                    ReaderTab.TOC -> TocPanel(vm, onDismiss)
                    ReaderTab.IMAGES -> ImagesPanel(vm, onDismiss)
                    ReaderTab.SEARCH -> SearchPanel(vm, onDismiss)
                    ReaderTab.MARKS -> MarksPanel(vm, onDismiss)
                    ReaderTab.NOTES -> NotesPanel(vm, onDismiss)
                }
            }
        }
    }
}

private fun ReaderTab.labelRes(): Int = when (this) {
    ReaderTab.TEXT -> R.string.toolbar_fonts
    ReaderTab.LAYOUT -> R.string.tab_layout
    ReaderTab.COLORS -> R.string.tab_colors
    ReaderTab.SCROLL -> R.string.tab_display
    ReaderTab.TOC -> R.string.tab_toc
    ReaderTab.IMAGES -> R.string.tab_images
    ReaderTab.SEARCH -> R.string.tab_search
    ReaderTab.MARKS -> R.string.nav_bookmarks
    ReaderTab.NOTES -> R.string.nav_notes
}

/** Small icon shown on the tab chips of the Chapters panel (Chapters / Images); other tabs have none. */
private fun ReaderTab.icon(): androidx.compose.ui.graphics.vector.ImageVector? = when (this) {
    ReaderTab.TOC -> com.novelreader.app.ui.AppIcons.ViewList
    ReaderTab.IMAGES -> com.novelreader.app.ui.AppIcons.Image
    else -> null
}
