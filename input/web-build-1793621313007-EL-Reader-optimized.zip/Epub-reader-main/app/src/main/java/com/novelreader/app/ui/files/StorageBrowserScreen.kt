package com.novelreader.app.ui.files

import android.net.Uri
import android.text.format.DateUtils
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.novelreader.app.R
import com.novelreader.app.core.FileScan
import com.novelreader.app.core.PickKind
import com.novelreader.app.ui.AppIcons
import com.novelreader.app.ui.design.AccentButton
import com.novelreader.app.ui.design.AppBackdrop
import com.novelreader.app.ui.design.AppChip
import com.novelreader.app.ui.design.AppDropdownMenu
import com.novelreader.app.ui.design.AppMenuItem
import com.novelreader.app.ui.design.AppShapes
import com.novelreader.app.ui.design.Checkbox
import com.novelreader.app.ui.design.EmptyState
import com.novelreader.app.ui.design.GhostButton
import com.novelreader.app.ui.design.MutedText
import com.novelreader.app.ui.design.SoftIconButton
import com.novelreader.app.ui.design.Space
import com.novelreader.app.ui.design.appClickable
import com.novelreader.app.ui.design.palette
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * The app's own file manager: browses the phone's real storage (needs "All files access"), lets the user tick any
 * number of EPUB / font / image files, with Select all, or - in folder mode - add everything inside a folder.
 *
 * It only reports what was chosen through [onDone] (as file:// URI strings); the caller imports them.
 */
@Composable
fun StorageBrowserScreen(
    kind: PickKind,
    hasAccess: Boolean,
    busy: Boolean,
    onDone: (List<String>) -> Unit,
    onCancel: () -> Unit,
    onAllowAccess: () -> Unit,
    onSystemPicker: () -> Unit,
    onFileManagerApp: () -> Unit,
) {
    val context = LocalContext.current
    val p = palette
    val scope = rememberCoroutineScope()
    val roots = remember(hasAccess) { if (hasAccess) FileAccess.roots(context) else emptyList() }

    var currentPath by remember { mutableStateOf<String?>(null) }
    val current: File? = currentPath?.let { File(it) } ?: roots.firstOrNull()?.dir
    var entries by remember { mutableStateOf<List<FileScan.Entry>?>(null) }
    var unreadable by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<Set<String>>(emptySet()) }
    var menu by remember { mutableStateOf(false) }
    var found by remember { mutableStateOf<Int?>(null) }
    var finishing by remember { mutableStateOf(false) }

    val multi = kind == PickKind.BOOKS || kind == PickKind.FONTS
    val folderMode = kind == PickKind.FOLDER

    LaunchedEffect(current?.absolutePath, hasAccess) {
        val dir = current
        if (!hasAccess || dir == null) return@LaunchedEffect
        entries = null
        val r = withContext(Dispatchers.IO) { FileScan.list(dir, kind.extensions) }
        unreadable = r == null
        entries = r ?: emptyList()
    }
    LaunchedEffect(current?.absolutePath, hasAccess, folderMode) {
        val dir = current
        if (!hasAccess || dir == null || !folderMode) return@LaunchedEffect
        found = null
        found = withContext(Dispatchers.IO) { FileScan.scan(dir, kind.extensions, cancelled = { !isActive }).size }
    }

    val atRoot = current == null || roots.any { it.dir.absolutePath == current.absolutePath }
    fun goUp() {
        val parent = current?.parentFile
        if (atRoot || parent == null) onCancel() else currentPath = parent.absolutePath
    }
    BackHandler(enabled = hasAccess && !atRoot) { goUp() }

    val title = stringResource(
        when (kind) {
            PickKind.BOOKS -> R.string.picker_title_books
            PickKind.FOLDER -> R.string.picker_title_folder
            PickKind.FONTS -> R.string.picker_title_fonts
            PickKind.IMAGE -> R.string.picker_title_image
        }
    )

    AppBackdrop {
        Column(Modifier.fillMaxSize()) {
            // ---- Header ----
            Row(
                Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.statusBars)
                    .padding(horizontal = Space.m, vertical = Space.s),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                SoftIconButton(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back), { if (hasAccess) goUp() else onCancel() })
                Column(Modifier.weight(1f).padding(horizontal = Space.m)) {
                    Text(title, style = MaterialTheme.typography.titleLarge, color = p.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (hasAccess && current != null) {
                        Text(
                            FileAccess.relativePath(context, current, roots),
                            style = MaterialTheme.typography.labelSmall, color = p.textMuted,
                            maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
                Box {
                    SoftIconButton(Icons.Default.MoreVert, stringResource(R.string.picker_more_ways), { menu = true })
                    AppDropdownMenu(menu, { menu = false }) {
                        if (hasAccess && multi) {
                            val here = entries.orEmpty().filter { !it.isDir }
                            val allOn = here.isNotEmpty() && here.all { it.file.absolutePath in selected }
                            AppMenuItem(
                                stringResource(if (allOn) R.string.picker_clear_selection else R.string.picker_select_all),
                                onClick = {
                                    selected = if (allOn) selected - here.map { it.file.absolutePath }.toSet()
                                    else selected + here.map { it.file.absolutePath }
                                    menu = false
                                },
                            )
                        }
                        AppMenuItem(stringResource(R.string.picker_use_system), onClick = { menu = false; onSystemPicker() })
                        AppMenuItem(stringResource(R.string.picker_use_app), onClick = { menu = false; onFileManagerApp() })
                    }
                }
            }

            if (!hasAccess) {
                Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
                    Spacer(Modifier.height(Space.xl))
                    EmptyState(
                        icon = AppIcons.FolderOpen,
                        title = stringResource(R.string.picker_access_title),
                        body = stringResource(R.string.picker_access_body),
                        actionLabel = stringResource(R.string.picker_allow_access),
                        onAction = onAllowAccess,
                    )
                    Column(Modifier.padding(horizontal = Space.gutter), verticalArrangement = Arrangement.spacedBy(Space.s)) {
                        GhostButton(stringResource(R.string.picker_use_system), onSystemPicker, Modifier.fillMaxWidth())
                        GhostButton(stringResource(R.string.picker_use_app), onFileManagerApp, Modifier.fillMaxWidth())
                    }
                    Spacer(Modifier.height(Space.xxl))
                }
            } else {
                // ---- Quick places ----
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = Space.l, vertical = Space.xs),
                    horizontalArrangement = Arrangement.spacedBy(Space.s),
                ) {
                    roots.forEach { r ->
                        AppChip(
                            r.label, selected = current?.absolutePath == r.dir.absolutePath,
                            onClick = { currentPath = r.dir.absolutePath },
                            leadingIcon = AppIcons.Phone,
                        )
                        FileAccess.quickFolders(r.dir).forEach { q ->
                            AppChip(
                                q.name, selected = current?.absolutePath == q.absolutePath,
                                onClick = { currentPath = q.absolutePath },
                                leadingIcon = AppIcons.Folder,
                            )
                        }
                    }
                }

                // ---- Listing ----
                val list = entries
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    when {
                        list == null -> CircularProgressIndicator(Modifier.align(Alignment.Center), color = p.accent)
                        list.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text(
                                stringResource(
                                    when {
                                        unreadable -> R.string.picker_unreadable
                                        kind == PickKind.FONTS -> R.string.picker_empty_fonts
                                        kind == PickKind.IMAGE -> R.string.picker_empty_image
                                        else -> R.string.picker_empty_books
                                    }
                                ),
                                style = MaterialTheme.typography.bodyMedium, color = p.textMuted,
                            )
                        }
                        else -> LazyColumn(
                            Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(horizontal = Space.m, vertical = Space.xs),
                        ) {
                            items(list, key = { it.file.absolutePath }) { e ->
                                val path = e.file.absolutePath
                                EntryRow(
                                    entry = e,
                                    kind = kind,
                                    showCheck = multi && !e.isDir,
                                    checked = path in selected,
                                    dimmed = folderMode && !e.isDir,
                                    onClick = {
                                        when {
                                            e.isDir -> currentPath = path
                                            kind == PickKind.IMAGE -> onDone(listOf(Uri.fromFile(e.file).toString()))
                                            multi -> selected = if (path in selected) selected - path else selected + path
                                        }
                                    },
                                )
                            }
                        }
                    }
                }

                // ---- Bottom action bar ----
                if (multi || folderMode) {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .background(p.surface)
                            .border(1.dp, p.outline)
                            .windowInsetsPadding(WindowInsets.navigationBars)
                            .padding(Space.l),
                        verticalArrangement = Arrangement.spacedBy(Space.s),
                    ) {
                        if (folderMode) {
                            MutedText(
                                when (val f = found) {
                                    null -> stringResource(R.string.picker_folder_scanning)
                                    0 -> stringResource(R.string.picker_folder_none)
                                    else -> stringResource(R.string.picker_folder_found, f)
                                }
                            )
                            AccentButton(
                                text = stringResource(R.string.picker_add_folder_books, found ?: 0),
                                onClick = {
                                    val dir = current ?: return@AccentButton
                                    finishing = true
                                    scope.launch {
                                        val files = withContext(Dispatchers.IO) { FileScan.scan(dir, kind.extensions) }
                                        onDone(files.map { Uri.fromFile(it).toString() })
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                icon = AppIcons.LibraryAdd,
                                enabled = (found ?: 0) > 0 && !finishing,
                            )
                        } else {
                            val here = entries.orEmpty().filter { !it.isDir }
                            val allOn = here.isNotEmpty() && here.all { it.file.absolutePath in selected }
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(Space.m)) {
                                GhostButton(
                                    stringResource(if (allOn) R.string.picker_clear_selection else R.string.picker_select_all),
                                    onClick = {
                                        selected = if (allOn) selected - here.map { it.file.absolutePath }.toSet()
                                        else selected + here.map { it.file.absolutePath }
                                    },
                                    icon = AppIcons.SelectAll,
                                    enabled = here.isNotEmpty(),
                                )
                                AccentButton(
                                    text = stringResource(
                                        if (kind == PickKind.FONTS) R.string.picker_add_n_fonts else R.string.picker_add_n_books,
                                        selected.size,
                                    ),
                                    onClick = {
                                        // Keep a stable order: the order of ticking is not meaningful.
                                        onDone(selected.sortedWith { a, b -> FileScan.naturalOrder.compare(a, b) }.map { Uri.fromFile(File(it)).toString() })
                                    },
                                    modifier = Modifier.weight(1f),
                                    icon = AppIcons.LibraryAdd,
                                    enabled = selected.isNotEmpty(),
                                )
                            }
                        }
                    }
                }
            }
        }

        if (busy || finishing) {
            Box(
                Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.5f)).appClickable({}, role = null, scaleTo = 1f),
                contentAlignment = Alignment.Center,
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = p.accent)
                    Spacer(Modifier.height(Space.m))
                    Text(stringResource(R.string.picker_scanning_tree), color = androidx.compose.ui.graphics.Color.White, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}

@Composable
private fun EntryRow(
    entry: FileScan.Entry,
    kind: PickKind,
    showCheck: Boolean,
    checked: Boolean,
    dimmed: Boolean,
    onClick: () -> Unit,
) {
    val p = palette
    val context = LocalContext.current
    Row(
        Modifier
            .fillMaxWidth()
            .clip(AppShapes.chip)
            .background(if (checked) p.accentSoft else androidx.compose.ui.graphics.Color.Transparent)
            .appClickable(onClick, role = if (showCheck) Role.Checkbox else Role.Button, scaleTo = 0.99f, enabled = !dimmed)
            .padding(horizontal = Space.s, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(44.dp).clip(AppShapes.chip).background(if (entry.isDir) p.accentSoft else p.surfaceHigh),
            contentAlignment = Alignment.Center,
        ) {
            if (kind == PickKind.IMAGE && !entry.isDir) {
                AsyncImage(model = entry.file, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            } else {
                Icon(
                    when {
                        entry.isDir -> AppIcons.Folder
                        kind == PickKind.FONTS -> AppIcons.TextFields
                        else -> AppIcons.MenuBook
                    },
                    contentDescription = null,
                    tint = if (entry.isDir) p.onAccentSoft else p.textMuted,
                    modifier = Modifier.size(24.dp),
                )
            }
        }
        Column(Modifier.weight(1f).padding(horizontal = Space.m)) {
            Text(
                entry.name, style = MaterialTheme.typography.bodyMedium,
                color = if (dimmed) p.textMuted else p.text, maxLines = 2, overflow = TextOverflow.Ellipsis,
            )
            if (!entry.isDir) {
                Text(
                    FileScan.formatSize(entry.size) + " · " +
                        DateUtils.formatDateTime(context, entry.modified, DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_ABBREV_MONTH or DateUtils.FORMAT_SHOW_YEAR),
                    style = MaterialTheme.typography.labelSmall, color = p.textMuted, maxLines = 1,
                )
            }
        }
        when {
            showCheck -> Checkbox(checked = checked, onCheckedChange = null)
            entry.isDir -> Icon(AppIcons.ChevronRight, contentDescription = null, tint = p.textMuted, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.width(2.dp))
    }
}
