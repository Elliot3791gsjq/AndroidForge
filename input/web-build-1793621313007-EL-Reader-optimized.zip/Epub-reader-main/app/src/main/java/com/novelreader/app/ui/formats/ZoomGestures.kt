package com.novelreader.app.ui.formats

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerInputScope
import androidx.compose.ui.input.pointer.positionChanged
import kotlin.math.abs

/**
 * Zoom/pan of one page, drawn with `graphicsLayer { transformOrigin = TopStart; scale; translation }`.
 * With the origin at the top-left corner a point c of the content is shown at c * scale + translation.
 * The content is [contentW] x [contentH] pixels at scale 1 (0 = same as the view). When it is smaller than the view
 * on an axis it is centred, otherwise it can be panned within its edges. [minScale] defaults to 1 (the fitted page).
 */
@Stable
class ZoomState(var maxScale: Float = 6f) {
    var scale by mutableFloatStateOf(1f)
        private set
    var tx by mutableFloatStateOf(0f)
        private set
    var ty by mutableFloatStateOf(0f)
        private set

    var viewW = 0f
    var viewH = 0f
    var contentW = 0f
    var contentH = 0f
    var minScale = 1f

    private val cw: Float get() = if (contentW > 0f) contentW else viewW
    private val ch: Float get() = if (contentH > 0f) contentH else viewH

    val zoomed: Boolean get() = scale > minScale * 1.02f && scale > 1.02f

    /** The content is wider than the view: one finger pans sideways (and a pager must stay still). */
    val panX: Boolean get() = cw * scale > viewW + 1f

    /** The content is taller than the view: one finger pans up and down. */
    val panY: Boolean get() = ch * scale > viewH + 1f

    private fun clampX(v: Float): Float {
        val c = cw * scale
        return if (c <= viewW) (viewW - c) / 2f else v.coerceIn(viewW - c, 0f)
    }

    private fun clampY(v: Float): Float {
        val c = ch * scale
        return if (c <= viewH) (viewH - c) / 2f else v.coerceIn(viewH - c, 0f)
    }

    /** Back to [base] x zoom, centred sideways and aligned to the top (the fitted page for base = 1). */
    fun reset(base: Float = 1f) {
        scale = base.coerceIn(minScale, maxScale)
        tx = clampX((viewW - cw * scale) / 2f)
        ty = clampY(0f)
    }

    /** Brings the content row [contentY] (pixels at scale 1) to the top edge of the view as far as the page allows. */
    fun scrollToContentY(contentY: Float) {
        if (!contentY.isFinite()) return
        ty = clampY(-contentY * scale)
    }

    /** Content row (pixels at scale 1) currently at the top edge of the view. */
    fun topContentY(): Float = (-ty / scale).coerceAtLeast(0f)

    /** Applies a gesture: zoom by [zoom] about [centroid] (view coordinates), then move by [pan]. Returns the x movement that could NOT be applied. */
    fun transform(centroid: Offset, pan: Offset, zoom: Float, allowPanY: Boolean = true): Float {
        // The gesture helpers give an unspecified (NaN) centroid for the event in which the last finger lifts; a NaN
        // must never reach the state, or every position derived from it (and the drawing) breaks.
        val s0 = scale
        if (!(s0 > 0f) || !s0.isFinite()) return 0f
        val cx0 = if (centroid.x.isFinite()) centroid.x else viewW / 2f
        val cy0 = if (centroid.y.isFinite()) centroid.y else viewH / 2f
        val z = if (zoom.isFinite() && zoom > 0f) zoom else 1f
        val px = if (pan.x.isFinite()) pan.x else 0f
        val py = if (pan.y.isFinite()) pan.y else 0f
        val s1 = (s0 * z).coerceIn(minScale, maxScale)
        var nx = cx0 - (cx0 - tx) * (s1 / s0) + px
        var ny = cy0 - (cy0 - ty) * (s1 / s0) + (if (allowPanY) py else 0f)
        scale = s1
        val cx = clampX(nx)
        val unusedX = nx - cx
        nx = cx
        ny = clampY(ny)
        tx = nx
        ty = ny
        return unusedX
    }

    /** Smooth zoom to [target] (1 = fitted page) about [centroid]. */
    suspend fun animateTo(target: Float, centroid: Offset, millis: Int = 220) {
        val from = scale
        val to = target.coerceIn(minScale, maxScale)
        if (abs(from - to) < 0.001f) return
        val a = Animatable(0f)
        a.animateTo(1f, tween(millis)) {
            val s = from + (to - from) * value
            transform(centroid, Offset.Zero, s / scale)
        }
    }
}

/**
 * Paged mode: pinch zooms; while the content is wider than the view one finger pans it (the pager is switched off by
 * the caller via [ZoomState.panX]) and [onEdgeSwipe] fires with -1 / +1 when the user keeps dragging past the left /
 * right edge. When the content is only taller than the view (e.g. "fit width" on a tall page) vertical drags scroll
 * it, while sideways drags are left to the pager. Plain drags of a page that fits are NOT consumed.
 */
suspend fun PointerInputScope.pagedZoomGestures(state: ZoomState, onEdgeSwipe: (Int) -> Unit) {
    val slop = viewConfiguration.touchSlop
    awaitEachGesture {
        awaitFirstDown(requireUnconsumed = false)
        var multi = false
        var overscroll = 0f
        var lock = 0            // 0 = undecided, 1 = this handler pans, 2 = leave the drag to the pager
        var accX = 0f
        var accY = 0f
        do {
            val event = awaitPointerEvent()
            if (event.changes.any { it.isConsumed }) break
            val pressed = event.changes.count { it.pressed }
            if (pressed >= 2) {
                multi = true
                state.transform(event.calculateCentroid(useCurrent = true), event.calculatePan(), event.calculateZoom())
                event.changes.forEach { if (it.positionChanged()) it.consume() }
            } else if (!multi && (state.panX || state.panY)) {
                val pan = event.calculatePan()
                if (state.panX) {
                    lock = 1
                } else if (lock == 0) {
                    accX += pan.x
                    accY += pan.y
                    if (kotlin.math.hypot(accX, accY) > slop) lock = if (abs(accY) > abs(accX)) 1 else 2
                }
                if (lock == 1) {
                    val usable = if (state.panX) pan else Offset(0f, pan.y)
                    val unused = state.transform(event.calculateCentroid(useCurrent = true), usable, 1f)
                    if (state.panX) overscroll += unused
                    event.changes.forEach { if (it.positionChanged()) it.consume() }
                }
            }
        } while (event.changes.any { it.pressed })
        val threshold = 72.dpToPx()
        if (!multi && abs(overscroll) > threshold) onEdgeSwipe(if (overscroll > 0) -1 else 1)
    }
}

/**
 * Vertical (scrolling) mode: the list scrolls itself, so this only watches in the Initial pass. Two fingers pinch/pan
 * (consumed, so the list does not scroll); one finger on a zoomed list also pans sideways without consuming, so
 * vertical scrolling keeps working.
 */
suspend fun PointerInputScope.scrollZoomGestures(state: ZoomState) {
    awaitEachGesture {
        awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
        var multi = false
        do {
            val event = awaitPointerEvent(PointerEventPass.Initial)
            val pressed = event.changes.count { it.pressed }
            if (pressed >= 2) {
                multi = true
                state.transform(event.calculateCentroid(useCurrent = true), event.calculatePan(), event.calculateZoom())
                event.changes.forEach { if (it.positionChanged()) it.consume() }
            } else if (state.zoomed && !multi) {
                val pan = event.calculatePan()
                state.transform(event.calculateCentroid(useCurrent = true), Offset(pan.x, 0f), 1f, allowPanY = false)
            }
        } while (event.changes.any { it.pressed })
    }
}

private fun Int.dpToPx(): Float = this * android.content.res.Resources.getSystem().displayMetrics.density

/** Which horizontal third of a view a tap landed in. */
enum class TapZone { START, CENTER, END }

fun tapZone(x: Float, width: Float): TapZone = when {
    width <= 0f -> TapZone.CENTER
    x < width * 0.3f -> TapZone.START
    x > width * 0.7f -> TapZone.END
    else -> TapZone.CENTER
}
