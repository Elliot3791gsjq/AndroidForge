package com.novelreader.app.ui.design

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Column
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp

// ---------------------------------------------------------------------------------------------------------------
// Drop-in replacements for the Material controls the reader panels were written with. Same call shapes, but drawn
// by the design system (accent pills, custom switches, ...), so no panel keeps the stock Material look.
// ---------------------------------------------------------------------------------------------------------------

@Composable
fun AlertDialog(
    onDismissRequest: () -> Unit,
    confirmButton: @Composable () -> Unit,
    modifier: Modifier = Modifier,
    dismissButton: (@Composable () -> Unit)? = null,
    icon: (@Composable () -> Unit)? = null,
    title: (@Composable () -> Unit)? = null,
    text: (@Composable () -> Unit)? = null,
) = AppDialog(onDismissRequest, confirmButton, modifier, dismissButton, icon, title, text)

@Composable
fun Button(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    content: @Composable RowScope.() -> Unit,
) {
    val p = palette
    val brush = Brush.verticalGradient(listOf(lerp(p.accent, Color.White, if (p.dark) 0.14f else 0.10f), p.accent))
    Row(
        modifier
            .height(44.dp)
            .graphicsLayer { alpha = if (enabled) 1f else 0.4f }
            .appClickable(onClick, enabled = enabled)
            .clip(CircleShape)
            .background(brush)
            .padding(horizontal = 20.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CompositionLocalProvider(
            LocalContentColor provides p.onAccent,
            LocalTextStyle provides MaterialTheme.typography.labelLarge,
        ) { content() }
    }
}

@Composable
fun OutlinedButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    content: @Composable RowScope.() -> Unit,
) {
    val p = palette
    Row(
        modifier
            .height(44.dp)
            .graphicsLayer { alpha = if (enabled) 1f else 0.4f }
            .appClickable(onClick, enabled = enabled)
            .clip(CircleShape)
            .background(p.surfaceHigh)
            .border(1.dp, p.outline, CircleShape)
            .padding(horizontal = 18.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CompositionLocalProvider(
            LocalContentColor provides p.text,
            LocalTextStyle provides MaterialTheme.typography.labelLarge,
        ) { content() }
    }
}

@Composable
fun Switch(checked: Boolean, onCheckedChange: ((Boolean) -> Unit)?, modifier: Modifier = Modifier, enabled: Boolean = true) =
    AppSwitch(checked, onCheckedChange, modifier, enabled)

@Composable
fun RadioButton(selected: Boolean, onClick: (() -> Unit)?, modifier: Modifier = Modifier, enabled: Boolean = true) {
    val p = palette
    val ring by animateColorAsState(if (selected) p.accent else p.textMuted, motion.fast(), label = "radioRing")
    val dot by animateDpAsState(if (selected) 10.dp else 0.dp, motion.fast(), label = "radioDot")
    val base = modifier.size(40.dp).graphicsLayer { alpha = if (enabled) 1f else 0.4f }
    Box(
        if (onClick != null) base.selectable(selected, enabled = enabled, role = Role.RadioButton, onClick = onClick) else base,
        contentAlignment = Alignment.Center,
    ) {
        Box(Modifier.size(20.dp).clip(CircleShape).border(2.dp, ring, CircleShape), contentAlignment = Alignment.Center) {
            Box(Modifier.size(dot).clip(CircleShape).background(p.accent))
        }
    }
}

@Composable
fun Checkbox(checked: Boolean, onCheckedChange: ((Boolean) -> Unit)?, modifier: Modifier = Modifier, enabled: Boolean = true) {
    val p = palette
    val fill by animateColorAsState(if (checked) p.accent else Color.Transparent, motion.fast(), label = "cbFill")
    val ring by animateColorAsState(if (checked) p.accent else p.textMuted, motion.fast(), label = "cbRing")
    val base = modifier.size(40.dp).graphicsLayer { alpha = if (enabled) 1f else 0.4f }
    Box(
        if (onCheckedChange != null) base.toggleable(checked, enabled = enabled, role = Role.Checkbox, onValueChange = onCheckedChange) else base,
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier.size(22.dp).clip(RoundedCornerShape(7.dp)).background(fill).border(2.dp, ring, RoundedCornerShape(7.dp)),
            contentAlignment = Alignment.Center,
        ) {
            if (checked) Icon(Icons.Default.Check, contentDescription = null, tint = p.onAccent, modifier = Modifier.size(16.dp))
        }
    }
}

@Composable
fun FilterChip(
    selected: Boolean,
    onClick: () -> Unit,
    label: @Composable () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
) {
    val p = palette
    val bg by animateColorAsState(if (selected) p.accent else p.surfaceHigh, motion.fast(), label = "fcBg")
    val fg by animateColorAsState(if (selected) p.onAccent else p.textMuted, motion.fast(), label = "fcFg")
    Row(
        modifier
            .height(34.dp)
            .graphicsLayer { alpha = if (enabled) 1f else 0.4f }
            .appClickable(onClick, enabled = enabled, role = Role.Tab)
            .clip(AppShapes.chip)
            .background(bg)
            .padding(horizontal = 14.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CompositionLocalProvider(LocalContentColor provides fg, LocalTextStyle provides MaterialTheme.typography.labelLarge) { label() }
    }
}

@Composable
fun HorizontalDivider(modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().height(1.dp).background(palette.outline))
}

@Composable
fun LinearProgressIndicator(progress: () -> Float, modifier: Modifier = Modifier) = AppProgressBar(progress(), modifier)

/** Text field with a small label above the input, drawn in the app's surface style. */
@Composable
fun OutlinedTextField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    label: (@Composable () -> Unit)? = null,
    singleLine: Boolean = false,
    readOnly: Boolean = false,
    trailingIcon: (@Composable () -> Unit)? = null,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    keyboardActions: KeyboardActions = KeyboardActions.Default,
) {
    val p = palette
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    val border by animateColorAsState(if (focused) p.accent else p.outline, motion.fast(), label = "otfBorder")
    BasicTextField(
        value = value,
        onValueChange = onValueChange,
        singleLine = singleLine,
        readOnly = readOnly,
        interactionSource = source,
        textStyle = MaterialTheme.typography.bodyMedium.copy(color = p.text),
        cursorBrush = SolidColor(p.accent),
        keyboardOptions = keyboardOptions,
        keyboardActions = keyboardActions,
        modifier = modifier,
        decorationBox = { inner ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(AppShapes.field)
                    .background(p.surface)
                    .border(if (focused) 1.5.dp else 1.dp, border, AppShapes.field)
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    if (label != null) {
                        CompositionLocalProvider(
                            LocalContentColor provides if (focused) p.accentText else p.textMuted,
                            LocalTextStyle provides MaterialTheme.typography.labelMedium,
                        ) { label() }
                        Spacer(Modifier.height(2.dp))
                    }
                    inner()
                }
                if (trailingIcon != null) {
                    Spacer(Modifier.width(8.dp))
                    trailingIcon()
                }
            }
        },
    )
}
