package com.novelreader.app.ui.formats

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.novelreader.app.R
import com.novelreader.app.formats.ComicDirection
import com.novelreader.app.formats.ComicFit
import com.novelreader.app.formats.ComicLayout
import com.novelreader.app.formats.ComicSettings
import com.novelreader.app.formats.FormatLocator
import com.novelreader.app.formats.ImageDecode
import com.novelreader.app.formats.comic.ComicFailure
import com.novelreader.app.formats.comic.ComicLoad
import com.novelreader.app.formats.comic.ComicReaderViewModel
import com.novelreader.app.formats.comic.ComicSpreads
import com.novelreader.app.ui.AppIcons
import com.novelreader.app.ui.Localized
import com.novelreader.app.ui.design.AppSheet
import com.novelreader.app.ui.design.AppSlider
import com.novelreader.app.ui.design.ColorDot
import com.novelreader.app.ui.design.MutedText
import com.novelreader.app.ui.design.SettingsGroup
import com.novelreader.app.ui.design.GhostButton
import com.novelreader.app.ui.design.palette
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs

private enum class ComicSheet { SETTINGS, PAGES, BOOKMARKS, GOTO }

@Composable
fun ComicReaderScreen(vm: ComicReaderViewModel, onBack: () -> Unit) {
    val load by vm.load.collectAsState()
    val settings by vm.settings.collectAsState()
    when (val l = load) {
        ComicLoad.Loading -> Box(Modifier.fillMaxSize().background(palette.bg), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = palette.accent)
        }
        is ComicLoad.Failed -> FormatOpenError(
            stringResource(
                when (l.reason) {
                    ComicFailure.MISSING -> R.string.fmt_err_missing
                    ComicFailure.EMPTY -> R.string.fmt_err_empty
                    ComicFailure.ENCRYPTED -> R.string.fmt_err_encrypted
                    ComicFailure.NO_SPACE -> R.string.fmt_err_no_space
                    ComicFailure.CORRUPT -> R.string.fmt_err_corrupt
                }
            ),
            onBack,
        )
        is ComicLoad.Ready -> {
            val s = settings
            if (s == null) Box(Modifier.fillMaxSize().background(palette.bg)) else ComicReaderContent(vm, l, s, onBack)
        }
    }
}

@Composable
private fun ComicReaderContent(vm: ComicReaderViewModel, ready: ComicLoad.Ready, s: ComicSettings, onBack: () -> Unit) {
    val p = palette
    val chrome by vm.chromeVisible.collectAsState()
    val page by vm.page.collectAsState()
    val readyCount by vm.readyCount.collectAsState()
    val bookmarks by vm.bookmarks.collectAsState()
    val boundsVersion by vm.boundsVersion.collectAsState()
    val direction = vm.resolveDirection(s)
    val vertical = direction == ComicDirection.VERTICAL
    val rtl = direction == ComicDirection.RTL
    val config = LocalConfiguration.current
    val landscape = config.screenWidthDp > config.screenHeightDp
    val dual = !vertical && (s.layout == ComicLayout.DUAL || (s.layout == ComicLayout.AUTO && landscape))
    var sheet by remember { mutableStateOf<ComicSheet?>(null) }
    val total = ready.pageCount
    val context = androidx.compose.ui.platform.LocalContext.current
    val pageLabel = { n: Int -> context.getString(R.string.fmt_page_label, Localized.number(n)) }

    Box(Modifier.fillMaxSize().background(Color(s.background))) {
        if (vertical) {
            ComicVertical(vm, s, boundsVersion)
        } else {
            ComicPaged(vm, s, rtl, dual, boundsVersion)
        }

        // Page number while the bars are hidden.
        if (!chrome && s.showPageNumber) {
            Box(
                Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 10.dp)
                    .clip(CircleShape).background(Color.Black.copy(alpha = 0.55f)).padding(horizontal = 12.dp, vertical = 4.dp),
            ) {
                Text("${Localized.number(page + 1)} / ${Localized.number(total)}", color = Color.White, style = MaterialTheme.typography.labelMedium)
            }
        }

        // Unpacking progress (CBR).
        if (readyCount < total) {
            Box(
                Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = if (chrome) 60.dp else 8.dp)
                    .clip(CircleShape).background(p.surface.copy(alpha = 0.92f)).padding(horizontal = 14.dp, vertical = 6.dp),
            ) {
                Text(
                    stringResource(R.string.comic_preparing, Localized.number(readyCount), Localized.number(total)),
                    style = MaterialTheme.typography.labelMedium, color = p.text,
                )
            }
        }

        AnimatedVisibility(
            visible = chrome, modifier = Modifier.align(Alignment.TopCenter),
            enter = fadeIn() + slideInVertically { -it }, exit = fadeOut() + slideOutVertically { -it },
        ) {
            FormatTopBar(ready.title, onBack) {
                GlassButton(AppIcons.BookmarkAdd, stringResource(R.string.bookmarks), { sheet = ComicSheet.BOOKMARKS })
                GlassButton(AppIcons.GridView, stringResource(R.string.fmt_pages), { sheet = ComicSheet.PAGES })
                GlassButton(AppIcons.Tune, stringResource(R.string.fmt_settings), { sheet = ComicSheet.SETTINGS })
            }
        }
        AnimatedVisibility(
            visible = chrome, modifier = Modifier.align(Alignment.BottomCenter),
            enter = fadeIn() + slideInVertically { it }, exit = fadeOut() + slideOutVertically { it },
        ) {
            PageSliderBar(
                current = page, total = total, onSeek = { vm.goTo(it) }, rtl = rtl,
                trailing = { GhostButton(stringResource(R.string.fmt_go_to_page), { sheet = ComicSheet.GOTO }, height = 32.dp) },
            )
        }
    }

    when (sheet) {
        ComicSheet.SETTINGS -> ComicSettingsSheet(s, vm, onDismiss = { sheet = null })
        ComicSheet.PAGES -> ComicThumbnailsSheet(vm, total, page, onPick = { vm.goTo(it); sheet = null }, onDismiss = { sheet = null })
        ComicSheet.BOOKMARKS -> FormatBookmarksSheet(
            bookmarks = bookmarks,
            label = { b -> (FormatLocator.parse(b.locatorJson) as? FormatLocator.Comic)?.let { pageLabel(it.page + 1) } ?: "" },
            onAdd = { vm.addBookmarkHere(pageLabel(page + 1)) },
            onOpen = { b -> (FormatLocator.parse(b.locatorJson) as? FormatLocator.Comic)?.let { vm.goTo(it.page) }; sheet = null },
            onDelete = { vm.deleteBookmark(it.id) },
            onDismiss = { sheet = null },
        )
        ComicSheet.GOTO -> GoToPageDialog(total, page, onDismiss = { sheet = null }, onGo = { vm.goTo(it) })
        null -> {}
    }
}

// ================================================================================================================
// Paged reading (one or two pages per screen)
// ================================================================================================================

@Composable
private fun ComicPaged(vm: ComicReaderViewModel, s: ComicSettings, rtl: Boolean, dual: Boolean, boundsVersion: Int) {
    val cache = vm.cache ?: return
    val total = vm.pageCount.collectAsState().value
    val page = vm.page.value
    val spreads = remember(total, dual, s.coverAlone, boundsVersion) {
        ComicSpreads.build(total, dual, s.coverAlone) { i -> cache.knownSize(i)?.let { it.width > it.height } ?: false }
    }
    val spreadsState = rememberUpdatedState(spreads)
    val scope = rememberCoroutineScope()
    val config = LocalConfiguration.current

    // The pager always follows the READING direction, whatever the language of the app is.
    CompositionLocalProvider(LocalLayoutDirection provides if (rtl) LayoutDirection.Rtl else LayoutDirection.Ltr) {
        val pagerState = rememberPagerState(initialPage = ComicSpreads.indexOf(spreads, page)) { spreads.size.coerceAtLeast(1) }
        val zoomed = remember { mutableStateMapOf<Int, Boolean>() }

        LaunchedEffect(spreads) {
            val target = ComicSpreads.indexOf(spreads, vm.page.value)
            if (pagerState.currentPage != target) pagerState.scrollToPage(target)
        }
        LaunchedEffect(pagerState) {
            snapshotFlow { pagerState.settledPage }.collect { idx -> spreadsState.value.getOrNull(idx)?.let { vm.onPageShown(it[0]) } }
        }
        LaunchedEffect(Unit) {
            vm.commands.collect { target ->
                val idx = ComicSpreads.indexOf(spreadsState.value, target)
                if (abs(idx - pagerState.currentPage) <= 1) pagerState.animateScrollToPage(idx) else pagerState.scrollToPage(idx)
            }
        }
        // Warm the pages around the one on screen.
        LaunchedEffect(pagerState.currentPage, spreads) {
            val reqW = (config.screenWidthDp * 2 * 2).coerceAtLeast(1)
            val reqH = (config.screenHeightDp * 2 * 2).coerceAtLeast(1)
            val around = (pagerState.currentPage - 1..pagerState.currentPage + 2).mapNotNull { spreads.getOrNull(it) }.flatMap { it.toList() }
            cache.prefetch(around, reqW, reqH)
        }

        HorizontalPager(
            state = pagerState,
            modifier = Modifier.fillMaxSize(),
            userScrollEnabled = zoomed[pagerState.currentPage] != true,
            beyondViewportPageCount = 1,
            key = { spreads.getOrNull(it)?.firstOrNull() ?: it },
        ) { idx ->
            val pages = spreads.getOrNull(idx) ?: return@HorizontalPager
            ComicSpread(
                vm = vm, pages = pages, s = s, rtl = rtl, boundsVersion = boundsVersion,
                onZoomed = { z -> if (z) zoomed[idx] = true else zoomed.remove(idx) },
                onTurn = { forward ->
                    val to = if (forward) idx + 1 else idx - 1
                    if (to in 0 until spreadsState.value.size) scope.launch { pagerState.animateScrollToPage(to) }
                },
            )
        }
    }
}

@Composable
private fun ComicSpread(
    vm: ComicReaderViewModel,
    pages: IntArray,
    s: ComicSettings,
    rtl: Boolean,
    boundsVersion: Int,
    onZoomed: (Boolean) -> Unit,
    onTurn: (forward: Boolean) -> Unit,
) {
    val cache = vm.cache ?: return
    val zoom = remember(pages.first()) { ZoomState(6f) }
    val scope = rememberCoroutineScope()
    var pendingToggle by remember { mutableStateOf<Job?>(null) }
    var lastCenterTap by remember { mutableStateOf(0L) }

    LaunchedEffect(zoom) { snapshotFlow { zoom.zoomed }.collect { onZoomed(it) } }
    DisposableEffect(zoom) { onDispose { onZoomed(false) } }

    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .onSizeChanged { zoom.viewW = it.width.toFloat(); zoom.viewH = it.height.toFloat() }
            .pointerInput(zoom) {
                pagedZoomGestures(zoom) { dir -> onTurn(if (rtl) dir < 0 else dir > 0) }
            }
            .pointerInput(s.tapToTurn, rtl, zoom) {
                detectTapGestures { offset ->
                    val zone = tapZone(offset.x, size.width.toFloat())
                    if (zone != TapZone.CENTER && s.tapToTurn) {
                        // Physical left/right; in right-to-left reading the left edge is "next".
                        val forward = if (rtl) zone == TapZone.START else zone == TapZone.END
                        onTurn(forward)
                    } else {
                        val now = System.currentTimeMillis()
                        if (now - lastCenterTap < 300L) {
                            pendingToggle?.cancel()
                            lastCenterTap = 0L
                            scope.launch { if (zoom.zoomed) zoom.animateTo(1f, offset) else zoom.animateTo(2.5f, offset) }
                        } else {
                            lastCenterTap = now
                            pendingToggle = scope.launch { delay(300); vm.toggleChrome() }
                        }
                    }
                }
            },
    ) {
        val wPx = constraints.maxWidth
        val hPx = constraints.maxHeight
        val boxW = wPx / pages.size
        // "Page width" fit: the fitted page is scaled up until it spans the screen width, starting at its top.
        val base = remember(pages.toList(), s.fit, wPx, hPx, boundsVersion) {
            if (s.fit != ComicFit.WIDTH || wPx <= 0 || hPx <= 0) 1f else {
                val sizes = pages.map { cache.knownSize(it) }
                if (sizes.any { it == null }) 1f else {
                    val ar = sizes.sumOf { it!!.width.toDouble() / it.height.coerceAtLeast(1) }.toFloat()
                    (wPx / (hPx * ar)).coerceAtLeast(1f)
                }
            }
        }
        LaunchedEffect(base, wPx, hPx) { if (wPx > 0) zoom.reset(base) }

        Row(
            Modifier
                .fillMaxSize()
                .graphicsLayer {
                    transformOrigin = TransformOrigin(0f, 0f)
                    scaleX = zoom.scale; scaleY = zoom.scale
                    translationX = zoom.tx; translationY = zoom.ty
                },
        ) {
            pages.forEach { idx ->
                ComicPageImage(vm, idx, boxW, hPx, Modifier.weight(1f).fillMaxHeight(), ContentScale.Fit, boundsVersion)
            }
        }
    }
}

/** One decoded page, with a spinner while it loads and a notice when the picture is damaged. */
@Composable
private fun ComicPageImage(
    vm: ComicReaderViewModel,
    index: Int,
    boxW: Int,
    boxH: Int,
    modifier: Modifier,
    scale: ContentScale,
    @Suppress("UNUSED_PARAMETER") boundsVersion: Int,
) {
    val cache = vm.cache ?: return
    var decoded by remember(index) { mutableStateOf<ImageDecode.Decoded?>(cache.peek(index)) }
    var failed by remember(index) { mutableStateOf(false) }
    LaunchedEffect(index, boxW, boxH) {
        if (boxW <= 0 || boxH <= 0) return@LaunchedEffect
        val d = cache.page(index, boxW * 2, boxH * 2)
        if (d != null) { decoded = d; failed = false } else if (decoded == null) failed = true
    }
    Box(modifier, contentAlignment = Alignment.Center) {
        val d = decoded
        when {
            d != null -> {
                val img = remember(d.bitmap) { d.bitmap.asImageBitmap() }
                Image(img, contentDescription = null, contentScale = scale, modifier = Modifier.fillMaxSize())
            }
            failed -> Text(stringResource(R.string.comic_page_damaged), color = Color.White.copy(alpha = 0.7f), style = MaterialTheme.typography.bodySmall)
            else -> CircularProgressIndicator(color = palette.accent, strokeWidth = 2.dp, modifier = Modifier.size(28.dp))
        }
    }
}

// ================================================================================================================
// Vertical continuous scrolling
// ================================================================================================================

@Composable
private fun ComicVertical(vm: ComicReaderViewModel, s: ComicSettings, boundsVersion: Int) {
    val cache = vm.cache ?: return
    val total = vm.pageCount.collectAsState().value
    val listState = rememberLazyListState(initialFirstVisibleItemIndex = vm.page.value.coerceIn(0, (total - 1).coerceAtLeast(0)))
    val zoom = remember { ZoomState(4f) }
    val scope = rememberCoroutineScope()
    var pendingToggle by remember { mutableStateOf<Job?>(null) }
    var lastTap by remember { mutableStateOf(0L) }

    LaunchedEffect(listState) {
        snapshotFlow {
            val info = listState.layoutInfo
            val center = (info.viewportStartOffset + info.viewportEndOffset) / 2
            info.visibleItemsInfo.firstOrNull { center >= it.offset && center <= it.offset + it.size }?.index
                ?: listState.firstVisibleItemIndex
        }.collect { vm.onPageShown(it) }
    }
    LaunchedEffect(Unit) { vm.commands.collect { listState.scrollToItem(it) } }

    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .onSizeChanged { zoom.viewW = it.width.toFloat(); zoom.viewH = it.height.toFloat() }
            .pointerInput(zoom) { scrollZoomGestures(zoom) }
            .pointerInput(zoom) {
                detectTapGestures { offset ->
                    val now = System.currentTimeMillis()
                    if (now - lastTap < 300L) {
                        pendingToggle?.cancel(); lastTap = 0L
                        scope.launch { if (zoom.zoomed) zoom.animateTo(1f, offset) else zoom.animateTo(2f, offset) }
                    } else {
                        lastTap = now
                        pendingToggle = scope.launch { delay(300); vm.toggleChrome() }
                    }
                }
            },
    ) {
        val wPx = constraints.maxWidth
        val bucket = kotlin.math.ceil(zoom.scale).toInt().coerceAtLeast(1)
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    transformOrigin = TransformOrigin(0f, 0f)
                    scaleX = zoom.scale; scaleY = zoom.scale
                    translationX = zoom.tx; translationY = zoom.ty
                },
            verticalArrangement = Arrangement.spacedBy(s.pageGapDp.dp),
        ) {
            items(total, key = { it }) { i ->
                val size = remember(boundsVersion, i) { cache.knownSize(i) }
                val ratio = size?.let { it.width.toFloat() / it.height.coerceAtLeast(1) } ?: (1f / 1.4f)
                ComicPageImage(vm, i, wPx * bucket, 1, Modifier.fillMaxWidth().aspectRatio(ratio), ContentScale.FillWidth, boundsVersion)
            }
        }
    }
}

// ================================================================================================================
// Sheets
// ================================================================================================================

@Composable
private fun ComicSettingsSheet(s: ComicSettings, vm: ComicReaderViewModel, onDismiss: () -> Unit) {
    val format = vm.book.collectAsState().value?.format ?: "CBZ"
    AppSheet(onDismiss) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 24.dp)) {
            Text(stringResource(R.string.fmt_settings), style = MaterialTheme.typography.titleLarge, color = palette.text)
            MutedText(stringResource(R.string.fmt_settings_note, format), Modifier.padding(top = 4.dp, bottom = 8.dp))

            SettingsGroup(null) {
                RadioSetting(
                    stringResource(R.string.comic_direction),
                    listOf(
                        stringResource(R.string.comic_dir_auto), stringResource(R.string.comic_dir_ltr),
                        stringResource(R.string.comic_dir_rtl), stringResource(R.string.comic_dir_vertical),
                    ),
                    ComicDirection.entries.indexOf(s.direction),
                    { i -> vm.updateSettings { it.copy(direction = ComicDirection.entries[i]) } },
                    note = if (s.direction == ComicDirection.AUTO) stringResource(R.string.comic_dir_auto_note) else null,
                )
            }
            if (s.direction != ComicDirection.VERTICAL) {
                SettingsGroup(null, Modifier.padding(top = 12.dp)) {
                    ChoiceSetting(
                        stringResource(R.string.comic_layout),
                        listOf(stringResource(R.string.comic_layout_single), stringResource(R.string.comic_layout_dual), stringResource(R.string.comic_layout_auto)),
                        listOf(ComicLayout.SINGLE, ComicLayout.DUAL, ComicLayout.AUTO).indexOf(s.layout),
                        { i -> vm.updateSettings { it.copy(layout = listOf(ComicLayout.SINGLE, ComicLayout.DUAL, ComicLayout.AUTO)[i]) } },
                    )
                    if (s.layout == ComicLayout.AUTO) MutedText(stringResource(R.string.comic_layout_auto_note))
                    if (s.layout != ComicLayout.SINGLE) {
                        SwitchSetting(stringResource(R.string.comic_cover_alone), s.coverAlone, { v -> vm.updateSettings { it.copy(coverAlone = v) } })
                    }
                    ChoiceSetting(
                        stringResource(R.string.comic_fit),
                        listOf(stringResource(R.string.comic_fit_screen), stringResource(R.string.comic_fit_width)),
                        if (s.fit == ComicFit.WIDTH) 1 else 0,
                        { i -> vm.updateSettings { it.copy(fit = if (i == 1) ComicFit.WIDTH else ComicFit.SCREEN) } },
                    )
                    SwitchSetting(stringResource(R.string.comic_tap_to_turn), s.tapToTurn, { v -> vm.updateSettings { it.copy(tapToTurn = v) } })
                }
            } else {
                SettingsGroup(null, Modifier.padding(top = 12.dp)) {
                    Column(Modifier.padding(vertical = 8.dp)) {
                        Text(stringResource(R.string.comic_page_gap), style = MaterialTheme.typography.bodyLarge, color = palette.text)
                        var gap by remember(s.pageGapDp) { mutableStateOf(s.pageGapDp.toFloat()) }
                        AppSlider(gap, { gap = it }, 0f..32f, onValueChangeFinished = { vm.updateSettings { it.copy(pageGapDp = gap.toInt()) } })
                    }
                }
            }
            SettingsGroup(null, Modifier.padding(top = 12.dp)) {
                Column(Modifier.padding(vertical = 8.dp)) {
                    Text(stringResource(R.string.comic_background), style = MaterialTheme.typography.bodyLarge, color = palette.text)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        listOf(0xFF000000.toInt(), 0xFF1C1C1E.toInt(), 0xFF808080.toInt(), 0xFFF4ECD8.toInt(), 0xFFFFFFFF.toInt()).forEach { c ->
                            ColorDot(Color(c), s.background == c, onClick = { vm.updateSettings { it.copy(background = c) } })
                        }
                    }
                }
                SwitchSetting(stringResource(R.string.comic_show_page_number), s.showPageNumber, { v -> vm.updateSettings { it.copy(showPageNumber = v) } })
                SwitchSetting(stringResource(R.string.comic_keep_awake), s.keepScreenOn, { v -> vm.updateSettings { it.copy(keepScreenOn = v) } })
            }
            MutedText(stringResource(R.string.comic_zoom_hint), Modifier.padding(top = 12.dp))
        }
    }
}

@Composable
private fun ComicThumbnailsSheet(vm: ComicReaderViewModel, total: Int, current: Int, onPick: (Int) -> Unit, onDismiss: () -> Unit) {
    val cache = vm.cache ?: return
    val readyCount by vm.readyCount.collectAsState()
    val p = palette
    AppSheet(onDismiss) {
        Text(stringResource(R.string.fmt_pages), style = MaterialTheme.typography.titleLarge, color = p.text, modifier = Modifier.padding(horizontal = 20.dp))
        val grid = rememberLazyGridState(initialFirstVisibleItemIndex = (current - 3).coerceAtLeast(0))
        LazyVerticalGrid(
            columns = GridCells.Adaptive(92.dp), state = grid,
            modifier = Modifier.fillMaxWidth().height(460.dp).padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items((0 until total).toList(), key = { it }) { i ->
                val thumb by produceThumb(vm, i, readyCount > i || vm.archive?.isReady(i) == true)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        Modifier.fillMaxWidth().aspectRatio(0.7f).clip(RoundedCornerShape(8.dp)).background(p.surfaceHighest)
                            .border(if (i == current) 3.dp else 1.dp, if (i == current) p.accent else p.outline, RoundedCornerShape(8.dp))
                            .pointerInput(i) { detectTapGestures { onPick(i) } },
                        contentAlignment = Alignment.Center,
                    ) {
                        thumb?.let { Image(it.asImageBitmap(), null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()) }
                    }
                    Text(Localized.number(i + 1), style = MaterialTheme.typography.labelSmall, color = if (i == current) p.accentText else p.textMuted)
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun produceThumb(vm: ComicReaderViewModel, index: Int, available: Boolean) =
    androidx.compose.runtime.produceState<android.graphics.Bitmap?>(null, index, available) {
        value = if (available) vm.cache?.thumb(index) else null
    }
