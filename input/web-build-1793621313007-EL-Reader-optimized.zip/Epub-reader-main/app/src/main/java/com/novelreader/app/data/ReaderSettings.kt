package com.novelreader.app.data

/** Brightness of the reading page's base colours (Readium theme + default page colours). Dark is the default. */
enum class ThemeMode { DARK, LIGHT }

/** Brightness of the app's own UI (library, settings, panels). Independent from the reading page colours. */
enum class UiMode { SYSTEM, DARK, LIGHT }

/** Paragraph alignment. ORIGINAL keeps whatever the EPUB specifies (the default - nothing is forced). */
enum class AlignMode { ORIGINAL, RIGHT, CENTER, LEFT }

/** Font choice. ORIGINAL keeps the book's own font. */
enum class FontChoice { ORIGINAL, SERIF, SANS_SERIF, MONOSPACE }

/** How a custom background image fills the reading area. */
enum class BgImageMode { COVER, FIT, TILE }

/** Page-turn direction: follow the book, or force LTR/RTL. */
enum class DirectionMode { AUTO, LTR, RTL }

enum class LibrarySort { LAST_READ, TITLE, ADDED }

/** Page-turn direction/mode. Null in [ReaderSettings.pageFlipMode] = "Right to Left" default (follows the book). */
enum class PageFlipMode { RIGHT_TO_LEFT, LEFT_TO_RIGHT, TOP_TO_BOTTOM_CONTINUOUS, TOP_TO_BOTTOM_SEPARATE }

/** Visual effect played when the page changes. Default NONE. */
/** Declaration order = the order of the options in Page Flip Settings. */
enum class PageFlipAnim { NONE, APPLE_CURL, GOOGLE_CURL, TWO_WAY_SLIDE, SHIFT_HORIZONTAL, FLIP_HORIZONTAL, FLIP_VERTICAL, FADE }

/** Automatic reading modes reachable from Options > Auto Scroll. */
enum class AutoScrollMode { ROLLING_BLIND_PIXEL, ROLLING_BLIND_LINE, SCROLL_PIXEL, SCROLL_LINE, SCROLL_PAGE, SPEED_READ }

/** Ids of the reader's bottom-toolbar entries (used by "Customize Toolbar"). */
object ToolbarItems {
    const val CONTENTS = "contents"
    const val SEARCH = "search"
    const val BOOKMARKS = "bookmarks"
    const val NOTES = "notes"
    const val APPEARANCE = "appearance"
    const val FONTS = "fonts"
    val all = listOf(CONTENTS, SEARCH, BOOKMARKS, NOTES, APPEARANCE, FONTS)
}

/**
 * Every reader preference. All of these are persisted (DataStore) and each one is wired to the
 * navigator in [com.novelreader.app.reader.ReaderPreferencesMapper] - nothing here is cosmetic only.
 */
data class ReaderSettings(
    val theme: ThemeMode = ThemeMode.DARK,

    /** Percent, 50..300. 100 = the book's/engine default size. */
    val fontSizePercent: Int = 100,
    val fontChoice: FontChoice = FontChoice.ORIGINAL,

    /**
     * Imported fonts (see [CustomFont]). When either is set it takes priority over [fontChoice].
     * [faFontId] styles Persian/Arabic-script text, [latinFontId] everything else; null = the book's/default font
     * for that script. The same id in both = one font for everything.
     */
    val faFontId: String? = null,
    val latinFontId: String? = null,

    /**
     * When true the book's own CSS decides spacing/alignment/font (Readium "publisher styles").
     * Line height, paragraph spacing/indent, alignment and font choice only take effect when false.
     */
    val keepPublisherStyles: Boolean = true,
    val lineHeight: Double = 1.5,          // 1.0 .. 2.5
    val paragraphSpacing: Double = 0.5,    // 0.0 .. 3.0 (Readium relative units)
    val paragraphIndent: Double = 0.0,     // 0.0 .. 3.0
    val align: AlignMode = AlignMode.ORIGINAL,
    val pageMargins: Double = 1.0,         // 0.5 .. 3.0  (side margins / max text width)

    /** null = use the theme's colour. */
    val textColor: Int? = null,
    val backgroundColor: Int? = null,

    /** Absolute path of a validated copy inside app-private storage, or null. */
    val backgroundImagePath: String? = null,
    val backgroundImageMode: BgImageMode = BgImageMode.COVER,
    /** How visible the image is, 0..1 (the rest is the plain background colour). */
    val backgroundImageOpacity: Float = 0.35f,

    /** true = continuous vertical scroll, false = paginated. */
    val scroll: Boolean = false,
    val direction: DirectionMode = DirectionMode.AUTO,
    /** Last chosen fullscreen state. */
    val fullscreen: Boolean = false,

    // ---- App-wide appearance (the UI theme; never touches the reading page colours above) ----
    /** Light / Dark / follow the system. */
    val uiMode: UiMode = UiMode.DARK,
    /** Preset id from [com.novelreader.app.ui.design.Presets] or the id of one of [customThemes]. */
    val colorThemeId: String = DEFAULT_COLOR_THEME,
    val customThemes: List<CustomTheme> = emptyList(),
    /** Skips decorative animations (also honoured automatically when the system animation scale is 0). */
    val reduceMotion: Boolean = false,

    // ---- Reader toolbar / options ----
    /** Ids from [ToolbarItems] the user has hidden. Nothing is hidden by default. */
    val toolbarHidden: Set<String> = emptySet(),
    /** Two pages side by side: always in landscape, in portrait only when [dualPagePortrait] is on as well. */
    val dualPage: Boolean = false,
    val dualPagePortrait: Boolean = false,
    /** null = default (Right to Left, follows the book's own direction). */
    val pageFlipMode: PageFlipMode? = null,
    val pageFlipAnim: PageFlipAnim = PageFlipAnim.NONE,
    /** 1 (slow) .. 10 (fast). */
    val pageFlipSpeed: Int = 5,
    val autoScrollMode: AutoScrollMode = AutoScrollMode.SCROLL_PIXEL,
    /** Percent of the base speed, 10..300. */
    val autoScrollSpeed: Int = 100,
    /** Words per minute for Speed Read (RSVP). */
    val rsvpWpm: Int = 300,
) {
    companion object {
        const val DEFAULT_COLOR_THEME = "ember"
        val FONT_SIZE_RANGE = 50..300
        val LINE_HEIGHT_RANGE = 1.0..2.5
        val PARAGRAPH_SPACING_RANGE = 0.0..3.0
        val PARAGRAPH_INDENT_RANGE = 0.0..3.0
        val PAGE_MARGINS_RANGE = 0.5..3.0
    }
}

/** A ready-made colour pair for the reading page ("book theme"). Independent from the app UI theme. */
data class ReadingTheme(val id: String, val background: Int, val text: Int) {
    val isDark: Boolean get() = com.novelreader.app.core.ColorMath.isDark(background)
}

object ReadingThemes {
    val all = listOf(
        ReadingTheme("black", 0xFF0E0E0E.toInt(), 0xFFE4E4E4.toInt()),
        ReadingTheme("night", 0xFF141821.toInt(), 0xFFD5D9E2.toInt()),
        ReadingTheme("slate", 0xFF26303A.toInt(), 0xFFE3E8EE.toInt()),
        ReadingTheme("sepia", 0xFFF1E4C8.toInt(), 0xFF4B3621.toInt()),
        ReadingTheme("cream", 0xFFFAF1DC.toInt(), 0xFF2B2B2B.toInt()),
        ReadingTheme("mint", 0xFFDDEBD6.toInt(), 0xFF22331F.toInt()),
        ReadingTheme("paper", 0xFFFBF7F0.toInt(), 0xFF1F1F1F.toInt()),
    )
}

/**
 * Page colours actually used by the reader: the user's explicit choice, else the neutral default for [theme].
 * They never depend on the app UI theme - the two levels (app UI / book page) are separate settings.
 */
fun ReaderSettings.effectiveBackground(): Int = backgroundColor ?: ThemeColors.background(theme)
fun ReaderSettings.effectiveText(): Int = textColor
    ?: if (com.novelreader.app.core.ColorMath.isDark(effectiveBackground())) ThemeColors.DARK_TEXT else ThemeColors.LIGHT_TEXT

/** Neutral defaults for the reading page when no explicit colours were picked. */
object ThemeColors {
    const val DARK_BG = 0xFF0E0E0E.toInt()
    const val DARK_TEXT = 0xFFE4E4E4.toInt()
    const val LIGHT_BG = 0xFFFFFFFF.toInt()
    const val LIGHT_TEXT = 0xFF1A1A1A.toInt()

    fun background(theme: ThemeMode) = if (theme == ThemeMode.DARK) DARK_BG else LIGHT_BG
    fun text(theme: ThemeMode) = if (theme == ThemeMode.DARK) DARK_TEXT else LIGHT_TEXT
}

/** Ready-made swatches shown next to the colour picker. */
object Swatches {
    val background = listOf(
        0xFF000000.toInt(), // black
        0xFF121212.toInt(), // very dark grey
        0xFF2B2B2B.toInt(), // dark grey
        0xFFFFFFFF.toInt(), // white
        0xFFFAF3E0.toInt(), // cream
        0xFFF4ECD8.toInt(), // sepia
        0xFFDDEBD6.toInt(), // soft green
    )
    val text = listOf(
        0xFF000000.toInt(),
        0xFF222222.toInt(),
        0xFFE6E6E6.toInt(),
        0xFFFFFFFF.toInt(),
        0xFF5B4636.toInt(), // sepia brown
        0xFFB8C7B0.toInt(), // soft green
        0xFFFFD27F.toInt(), // warm amber
    )
    val highlight = listOf(
        0xFFFFEB3B.toInt(), // yellow
        0xFF81C784.toInt(), // green
        0xFF64B5F6.toInt(), // blue
        0xFFF48FB1.toInt(), // pink
        0xFFFFB74D.toInt(), // orange
    )
}

/** The effective page-flip mode: the explicit choice, else the legacy scroll flag, else the default (Right to Left). */
fun ReaderSettings.flipMode(): PageFlipMode =
    pageFlipMode ?: if (scroll) PageFlipMode.TOP_TO_BOTTOM_CONTINUOUS else PageFlipMode.RIGHT_TO_LEFT

fun ReaderSettings.isVerticalScrolling(): Boolean =
    flipMode().let { it == PageFlipMode.TOP_TO_BOTTOM_CONTINUOUS || it == PageFlipMode.TOP_TO_BOTTOM_SEPARATE }

/** Picks a flip mode and keeps the underlying scroll flag consistent. */
fun ReaderSettings.withFlipMode(m: PageFlipMode): ReaderSettings = copy(
    pageFlipMode = m,
    scroll = m == PageFlipMode.TOP_TO_BOTTOM_CONTINUOUS || m == PageFlipMode.TOP_TO_BOTTOM_SEPARATE,
    direction = DirectionMode.AUTO,
)
