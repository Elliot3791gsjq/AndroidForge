package com.novelreader.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        BookEntity::class, HighlightEntity::class, BookmarkEntity::class, HistoryEntity::class,
        CategoryEntity::class, BookCategoryEntity::class, ReadingSessionEntity::class,
    ],
    version = 5,
    exportSchema = true,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun books(): BookDao
    abstract fun highlights(): HighlightDao
    abstract fun bookmarks(): BookmarkDao
    abstract fun history(): HistoryDao
    abstract fun categories(): CategoryDao
    abstract fun sessions(): ReadingSessionDao

    companion object {
        /** v1 -> v2: highlights get a `style`; books get reading time and cached character/word counts. Existing rows stay valid. */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE highlights ADD COLUMN style TEXT NOT NULL DEFAULT 'HIGHLIGHT'")
                db.execSQL("ALTER TABLE books ADD COLUMN readingMillis INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE books ADD COLUMN charCount INTEGER")
                db.execSQL("ALTER TABLE books ADD COLUMN wordCount INTEGER")
            }
        }

        /** v2 -> v3: books can be marked as favourites. Purely additive; existing rows keep every value. */
        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE books ADD COLUMN favorite INTEGER NOT NULL DEFAULT 0")
            }
        }

        /**
         * v3 -> v4: custom covers, user categories and reading sessions. Purely additive (one nullable column and
         * three new tables), so every existing row keeps all of its values.
         */
        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE books ADD COLUMN customCoverPath TEXT")
                db.execSQL("CREATE TABLE IF NOT EXISTS `categories` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `name` TEXT NOT NULL, `createdAt` INTEGER NOT NULL)")
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `book_categories` (`bookId` INTEGER NOT NULL, `categoryId` INTEGER NOT NULL, " +
                        "PRIMARY KEY(`bookId`, `categoryId`), " +
                        "FOREIGN KEY(`bookId`) REFERENCES `books`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE, " +
                        "FOREIGN KEY(`categoryId`) REFERENCES `categories`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE)"
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_book_categories_categoryId` ON `book_categories` (`categoryId`)")
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `reading_sessions` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`bookId` INTEGER NOT NULL, `startAt` INTEGER NOT NULL, `durationMs` INTEGER NOT NULL, " +
                        "`startProgress` REAL NOT NULL, `endProgress` REAL NOT NULL, " +
                        "FOREIGN KEY(`bookId`) REFERENCES `books`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE)"
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_reading_sessions_bookId` ON `reading_sessions` (`bookId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_reading_sessions_startAt` ON `reading_sessions` (`startAt`)")
            }
        }

        /**
         * v4 -> v5: multi-format library. `format` (default EPUB, so every existing row stays an EPUB) and a nullable
         * `pageCount`. Purely additive; positions, bookmarks and highlights keep their values.
         */
        val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE books ADD COLUMN format TEXT NOT NULL DEFAULT 'EPUB'")
                db.execSQL("ALTER TABLE books ADD COLUMN pageCount INTEGER")
            }
        }

        @Volatile private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "novel_reader.db",
                ).addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5).build().also { instance = it }
            }
    }
}
