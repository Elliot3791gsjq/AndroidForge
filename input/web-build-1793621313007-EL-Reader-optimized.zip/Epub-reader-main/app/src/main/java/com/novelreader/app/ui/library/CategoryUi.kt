package com.novelreader.app.ui.library

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.novelreader.app.R
import com.novelreader.app.data.BookCategoryEntity
import com.novelreader.app.data.BookEntity
import com.novelreader.app.data.CategoryEntity
import com.novelreader.app.data.LibraryRepository
import com.novelreader.app.ui.AppIcons
import com.novelreader.app.ui.design.AccentButton
import com.novelreader.app.ui.design.AppDialog
import com.novelreader.app.ui.design.AppSheet
import com.novelreader.app.ui.design.AppShapes
import com.novelreader.app.ui.design.AppTextField
import com.novelreader.app.ui.design.Checkbox
import com.novelreader.app.ui.design.GhostButton
import com.novelreader.app.ui.design.MutedText
import com.novelreader.app.ui.design.Space
import com.novelreader.app.ui.design.appClickable
import com.novelreader.app.ui.design.motion
import com.novelreader.app.ui.design.palette
import java.io.File

/** A category in the filter row (long-press for rename / delete / choose books). */
@Composable
fun CategoryChip(label: String, selected: Boolean, onClick: () -> Unit, onLongClick: () -> Unit) {
    val p = palette
    val bg by animateColorAsState(if (selected) p.accent else p.surfaceHigh, motion.fast(), label = "catBg")
    val fg by animateColorAsState(if (selected) p.onAccent else p.textMuted, motion.fast(), label = "catFg")
    Row(
        Modifier
            .height(36.dp)
            .appClickable(onClick, onLongClick = onLongClick, role = Role.Tab)
            .clip(AppShapes.chip)
            .background(bg)
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(AppIcons.Label, contentDescription = null, tint = fg, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, style = MaterialTheme.typography.labelLarge, color = fg, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 150.dp))
    }
}

/** The "+" next to the categories: a dashed accent pill that creates a new category. */
@Composable
fun NewCategoryChip(onClick: () -> Unit) {
    val p = palette
    val label = stringResource(R.string.category_new_chip)
    Box(
        Modifier
            .size(36.dp)
            .semantics { contentDescription = label }
            .appClickable(onClick, role = Role.Button)
            .clip(AppShapes.chip)
            .background(p.accentSoft)
            .drawBehind {
                drawRoundRect(
                    color = p.accent,
                    cornerRadius = CornerRadius(14.dp.toPx()),
                    style = Stroke(width = 1.5.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(9f, 7f))),
                )
            },
        contentAlignment = Alignment.Center,
    ) {
        Icon(Icons.Default.Add, contentDescription = null, tint = p.onAccentSoft, modifier = Modifier.size(20.dp))
    }
}

/** One text field dialog, used for creating and renaming a category. */
@Composable
fun CategoryNameDialog(
    title: String,
    initial: String,
    confirmLabel: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit,
) {
    var name by remember { mutableStateOf(initial) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    AppDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            AppTextField(
                value = name,
                onValueChange = { name = it.take(LibraryRepository.MAX_CATEGORY_NAME) },
                placeholder = stringResource(R.string.category_name_hint),
                modifier = Modifier.fillMaxWidth().focusRequester(focus),
            )
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(name.trim()) }, enabled = name.isNotBlank()) { Text(confirmLabel) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}

/** Tick which library books belong to [category]. Each tap is saved at once. */
@Composable
fun CategoryBooksSheet(
    category: CategoryEntity,
    books: List<BookEntity>,
    links: List<BookCategoryEntity>,
    coverOf: (BookEntity) -> File?,
    onToggle: (bookId: Long, member: Boolean) -> Unit,
    onDismiss: () -> Unit,
) {
    val p = palette
    val members = links.filter { it.categoryId == category.id }.map { it.bookId }.toSet()
    AppSheet(onDismiss = onDismiss) {
        Column(Modifier.padding(horizontal = Space.gutter).navigationBarsPadding().padding(bottom = Space.l)) {
            Text(
                stringResource(R.string.category_books_title, category.name),
                style = MaterialTheme.typography.titleMedium, color = p.text, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(Space.s))
            LazyColumn(Modifier.heightIn(max = 460.dp)) {
                items(books, key = { it.id }) { b ->
                    val on = b.id in members
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(AppShapes.chip)
                            .appClickable({ onToggle(b.id, !on) }, role = Role.Checkbox, scaleTo = 0.99f)
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        BookCover(b.title, coverOf(b), Modifier.width(38.dp).aspectRatio(2f / 3f), elevation = 3.dp)
                        Column(Modifier.weight(1f).padding(horizontal = Space.m)) {
                            Text(b.title, style = MaterialTheme.typography.bodyMedium, color = p.text, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            b.author?.let { MutedText(it, maxLines = 1) }
                        }
                        Checkbox(checked = on, onCheckedChange = null)
                    }
                }
            }
            Spacer(Modifier.height(Space.m))
            AccentButton(stringResource(R.string.done), onDismiss, Modifier.fillMaxWidth())
        }
    }
}

/** Categories of one book as checkboxes (+ create a new one). */
@Composable
fun BookCategoriesSheet(
    book: BookEntity,
    categories: List<CategoryEntity>,
    links: List<BookCategoryEntity>,
    onToggle: (categoryId: Long, member: Boolean) -> Unit,
    onNew: () -> Unit,
    onDismiss: () -> Unit,
) {
    val p = palette
    val mine = links.filter { it.bookId == book.id }.map { it.categoryId }.toSet()
    AppSheet(onDismiss = onDismiss) {
        Column(Modifier.padding(horizontal = Space.gutter).navigationBarsPadding().padding(bottom = Space.l)) {
            Text(stringResource(R.string.book_categories), style = MaterialTheme.typography.titleMedium, color = p.text)
            MutedText(book.title, maxLines = 1)
            Spacer(Modifier.height(Space.s))
            if (categories.isEmpty()) {
                MutedText(stringResource(R.string.category_none_yet), Modifier.padding(vertical = Space.m))
            }
            LazyColumn(Modifier.heightIn(max = 380.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                items(categories, key = { it.id }) { c ->
                    val on = c.id in mine
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(AppShapes.chip)
                            .appClickable({ onToggle(c.id, !on) }, role = Role.Checkbox, scaleTo = 0.99f)
                            .padding(vertical = 4.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(AppIcons.Label, null, tint = if (on) p.accentText else p.textMuted, modifier = Modifier.size(20.dp))
                        Text(c.name, style = MaterialTheme.typography.bodyLarge, color = p.text, modifier = Modifier.weight(1f).padding(horizontal = Space.m), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Checkbox(checked = on, onCheckedChange = null)
                    }
                }
            }
            Spacer(Modifier.height(Space.m))
            GhostButton(stringResource(R.string.category_new), onNew, Modifier.fillMaxWidth(), icon = Icons.Default.Add)
        }
    }
}

/** Long-press menu of a category chip. */
@Composable
fun CategoryActionsSheet(
    category: CategoryEntity,
    onChooseBooks: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit,
    onDismiss: () -> Unit,
) {
    AppSheet(onDismiss = onDismiss) {
        Column(Modifier.padding(horizontal = Space.gutter).navigationBarsPadding().padding(bottom = Space.xxl)) {
            Text(category.name, style = MaterialTheme.typography.titleMedium, color = palette.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(Space.m))
            AccentButton(stringResource(R.string.category_choose_books), onChooseBooks, Modifier.fillMaxWidth(), icon = AppIcons.LibraryAdd)
            Spacer(Modifier.height(Space.s))
            GhostButton(stringResource(R.string.category_rename), onRename, Modifier.fillMaxWidth(), icon = AppIcons.Edit)
            Spacer(Modifier.height(Space.s))
            GhostButton(stringResource(R.string.category_delete), onDelete, Modifier.fillMaxWidth(), icon = AppIcons.Delete, destructive = true)
        }
    }
}
