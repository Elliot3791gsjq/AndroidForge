package com.novelreader.app.formats.pdf

import com.novelreader.app.formats.comic.ComicSpreads

/** How a page (or spread) is sized on screen before any zoom. */
enum class PdfFit { WIDTH, PAGE, ACTUAL }

/** Size of a page in PDF points (1/72 inch) as it is DISPLAYED (view rotation already applied). */
data class PdfSize(val w: Float, val h: Float)

/**
 * What the reader shows at once: one page, or two side by side. Sizes are in points; [pageRects] hold
 * left/top/right/bottom of every page inside the cell, in left-to-right screen order (for right-to-left reading the
 * first page of the pair is the right-hand one).
 */
class PdfCell(val pages: IntArray, val ptsW: Float, val ptsH: Float, val pageRects: List<FloatArray>)

/**
 * Pure geometry of the PDF reader (unit-tested): rotation maths, fit scales, spreads and the matrix handed to
 * PdfRenderer. Page space = the unrotated page as PdfRenderer reports it (points, origin top-left, y down);
 * display space = the same page after the user's view rotation.
 */
object PdfGeometry {

    fun normalizeRotation(deg: Int): Int = ((deg % 360) + 360) % 360 / 90 * 90

    fun displaySize(w: Float, h: Float, rotation: Int): PdfSize =
        if (rotation == 90 || rotation == 270) PdfSize(h, w) else PdfSize(w, h)

    /** Page-space point -> display-space point for a page of [w] x [h] points rotated clockwise by [rotation]. */
    fun toDisplay(x: Float, y: Float, w: Float, h: Float, rotation: Int): FloatArray = when (normalizeRotation(rotation)) {
        90 -> floatArrayOf(h - y, x)
        180 -> floatArrayOf(w - x, h - y)
        270 -> floatArrayOf(y, w - x)
        else -> floatArrayOf(x, y)
    }

    /** Inverse of [toDisplay]. */
    fun toPage(dx: Float, dy: Float, w: Float, h: Float, rotation: Int): FloatArray = when (normalizeRotation(rotation)) {
        90 -> floatArrayOf(dy, h - dx)
        180 -> floatArrayOf(w - dx, h - dy)
        270 -> floatArrayOf(w - dy, dx)
        else -> floatArrayOf(dx, dy)
    }

    /** Page-space rectangle (l, t, r, b) -> display-space rectangle (normalised so l <= r, t <= b). */
    fun rectToDisplay(l: Float, t: Float, r: Float, b: Float, w: Float, h: Float, rotation: Int): FloatArray {
        val a = toDisplay(l, t, w, h, rotation)
        val c = toDisplay(r, b, w, h, rotation)
        return floatArrayOf(minOf(a[0], c[0]), minOf(a[1], c[1]), maxOf(a[0], c[0]), maxOf(a[1], c[1]))
    }

    /**
     * Matrix values (android.graphics.Matrix layout, 9 floats) that map page space to bitmap pixels:
     * rotate by [rotation], scale by [pxPerPt], then move so that display pixel ([originX], [originY]) becomes the
     * bitmap's top-left corner.
     */
    fun renderMatrix(rotation: Int, w: Float, h: Float, pxPerPt: Float, originX: Float, originY: Float): FloatArray {
        // x' = a*x + b*y + tx ; y' = c*x + d*y + ty  (rotation about the origin followed by a shift into the positive quadrant)
        val a: Float; val b: Float; val tx: Float; val c: Float; val d: Float; val ty: Float
        when (normalizeRotation(rotation)) {
            90 -> { a = 0f; b = -1f; tx = h; c = 1f; d = 0f; ty = 0f }
            180 -> { a = -1f; b = 0f; tx = w; c = 0f; d = -1f; ty = h }
            270 -> { a = 0f; b = 1f; tx = 0f; c = -1f; d = 0f; ty = w }
            else -> { a = 1f; b = 0f; tx = 0f; c = 0f; d = 1f; ty = 0f }
        }
        return floatArrayOf(
            pxPerPt * a, pxPerPt * b, pxPerPt * tx - originX,   // MSCALE_X, MSKEW_X, MTRANS_X
            pxPerPt * c, pxPerPt * d, pxPerPt * ty - originY,   // MSKEW_Y, MSCALE_Y, MTRANS_Y
            0f, 0f, 1f,
        )
    }

    /** Device pixels per PDF point for a cell of [cellW] x [cellH] points in a [viewW] x [viewH] view. */
    fun pxPerPoint(fit: PdfFit, viewW: Float, viewH: Float, cellW: Float, cellH: Float, actualPxPerPt: Float): Float {
        if (cellW <= 0f || cellH <= 0f || viewW <= 0f || viewH <= 0f) return 1f
        return when (fit) {
            PdfFit.WIDTH -> viewW / cellW
            PdfFit.PAGE -> minOf(viewW / cellW, viewH / cellH)
            PdfFit.ACTUAL -> actualPxPerPt.coerceAtLeast(0.1f)
        }
    }

    /**
     * Groups pages into cells. [size] gives the displayed size of a page; a landscape page always stands alone in
     * two-page layouts. With [rtl] the first page of a pair sits on the right.
     */
    fun cells(pageCount: Int, dual: Boolean, coverAlone: Boolean, rtl: Boolean, size: (Int) -> PdfSize): List<PdfCell> {
        val spreads = ComicSpreads.build(pageCount, dual, coverAlone) { i -> size(i).let { it.w > it.h } }
        return spreads.map { pages ->
            val sizes = pages.map { size(it) }
            val w = sizes.sumOf { it.w.toDouble() }.toFloat()
            val h = sizes.maxOf { it.h }
            val ordered = if (rtl && pages.size == 2) listOf(1, 0) else listOf(0, 1).take(pages.size)
            val rects = arrayOfNulls<FloatArray>(pages.size)
            var x = 0f
            for (slot in ordered) {
                val s = sizes[slot]
                val top = (h - s.h) / 2f
                rects[slot] = floatArrayOf(x, top, x + s.w, top + s.h)
                x += s.w
            }
            PdfCell(pages, w, h, rects.map { it!! })
        }
    }

    fun cellIndexOf(cells: List<PdfCell>, page: Int): Int {
        if (cells.isEmpty()) return 0
        val i = cells.indexOfFirst { c -> c.pages.any { it == page } }
        return if (i >= 0) i else if (page < 0) 0 else cells.lastIndex
    }

    /** Whole-book progress 0..1 (first page 0, last page 1). */
    fun progress(page: Int, pageCount: Int): Double = ComicSpreads.progress(page, pageCount)

    /** Rectangle (l,t,r,b) intersection or null when empty. */
    fun intersect(a: FloatArray, b: FloatArray): FloatArray? {
        val l = maxOf(a[0], b[0]); val t = maxOf(a[1], b[1]); val r = minOf(a[2], b[2]); val bt = minOf(a[3], b[3])
        return if (r > l && bt > t) floatArrayOf(l, t, r, bt) else null
    }
}
