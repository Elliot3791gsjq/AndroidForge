package com.novelreader.app.formats.doc

/**
 * What the document engine produces for TXT and DOCX. The HTML of the document body goes to an [Appendable] (a
 * cache file on the device) while parsing; everything the reader needs besides the markup is in this result.
 *
 * The central contract: the document is a list of *blocks* (paragraphs, headings, list items, table-cell paragraphs).
 * Block `i` is an element `<... class="b" data-i="i">` in the HTML and its `textContent` is exactly `texts[i]`.
 * Search results, highlights, notes, bookmarks and the reading position all address `(block, character offset)`.
 */
class DocParseResult(
    /** Plain text of every block, in document order. */
    val texts: List<String>,
    /** Headings / chapter titles, for the contents list. */
    val outline: List<DocOutline>,
    /** Images referenced by the HTML as `/m/<index>`. */
    val images: List<DocImage>,
    /** Internal link targets (DOCX bookmarks): name to block index. */
    val anchors: Map<String, Int>,
    val title: String?,
    /** Default direction of the document (majority of the paragraphs). */
    val rtl: Boolean,
    /** Things that could not be shown faithfully, as codes plus a count (e.g. unsupported image formats). */
    val warnings: List<DocWarning>,
)

class DocOutline(val title: String, val level: Int, val block: Int)

/** An image inside the document file: [entry] is the zip entry name, [mime] the content type the WebView needs. */
class DocImage(val entry: String, val mime: String)

enum class DocWarningKind { IMAGES_UNSUPPORTED, TEXT_BOXES, HEADERS_FOOTERS, FOOTNOTES, EQUATIONS }

class DocWarning(val kind: DocWarningKind, val count: Int)

object DocHtml {

    /** Characters that cannot live in HTML text (NUL, most C0 controls) are dropped; CR never reaches a block. */
    fun sanitize(s: String): String {
        var clean = true
        for (c in s) if (isBad(c)) { clean = false; break }
        if (clean) return s
        val sb = StringBuilder(s.length)
        for (c in s) if (!isBad(c)) sb.append(c)
        return sb.toString()
    }

    private fun isBad(c: Char): Boolean = (c.code < 0x20 && c != '\t' && c != '\n') || c.code == 0x7F || c == '￾' || c == '￿'

    fun escape(s: String, out: Appendable) {
        var last = 0
        for (i in s.indices) {
            val rep = when (s[i]) {
                '&' -> "&amp;"
                '<' -> "&lt;"
                '>' -> "&gt;"
                else -> continue
            }
            out.append(s, last, i).append(rep)
            last = i + 1
        }
        out.append(s, last, s.length)
    }

    fun escapeAttr(s: String): String {
        val sb = StringBuilder(s.length + 8)
        for (c in s) when (c) {
            '&' -> sb.append("&amp;")
            '<' -> sb.append("&lt;")
            '>' -> sb.append("&gt;")
            '"' -> sb.append("&quot;")
            else -> sb.append(c)
        }
        return sb.toString()
    }

    /**
     * Direction of a paragraph by its first strong letter (what `dir=auto` does), or [fallback] when it has none
     * (numbers, punctuation only). The markup carries it explicitly so alignment follows it everywhere.
     */
    fun directionOf(text: String, fallbackRtl: Boolean): Boolean {
        var i = 0
        while (i < text.length) {
            val cp = text.codePointAt(i)
            i += Character.charCount(cp)
            when (Character.getDirectionality(cp)) {
                Character.DIRECTIONALITY_LEFT_TO_RIGHT -> return false
                Character.DIRECTIONALITY_RIGHT_TO_LEFT, Character.DIRECTIONALITY_RIGHT_TO_LEFT_ARABIC -> return true
                else -> {}
            }
        }
        return fallbackRtl
    }
}
