package com.novelreader.app.formats.comic

import android.graphics.Bitmap
import android.util.LruCache
import com.novelreader.app.formats.ImageDecode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap

/**
 * Lazy page decoding for the comic reader: only pages near the reader are decoded, at about the size they are shown,
 * and kept in a memory-bounded LRU cache (bytes, not entries). Decoding runs on a small private thread pool, never on
 * the UI thread. Bitmaps handed out are never recycled here (Compose may still be drawing them); eviction just drops
 * the reference and the GC reclaims the memory.
 */
@OptIn(ExperimentalCoroutinesApi::class)
class ComicPageCache(private val archive: ComicArchive, private val scope: CoroutineScope) {

    private val pageDispatcher = Dispatchers.IO.limitedParallelism(3)
    private val thumbDispatcher = Dispatchers.IO.limitedParallelism(2)

    private val budget = (Runtime.getRuntime().maxMemory() / 4).coerceIn(24L * 1024 * 1024, 160L * 1024 * 1024).toInt()

    private val pages = object : LruCache<Int, ImageDecode.Decoded>(budget) {
        override fun sizeOf(key: Int, value: ImageDecode.Decoded): Int = value.bitmap.allocationByteCount
    }
    private val thumbs = object : LruCache<Int, Bitmap>(12 * 1024 * 1024) {
        override fun sizeOf(key: Int, value: Bitmap): Int = value.allocationByteCount
    }
    private val sizes = ConcurrentHashMap<Int, Long>()
    private val inflight = HashMap<Int, Deferred<ImageDecode.Decoded?>>()

    /** Pixel size of page [index] if it is already known (decoded earlier). */
    fun knownSize(index: Int): ImageDecode.Size? = sizes[index]?.let { unpack(it) }

    fun peek(index: Int): ImageDecode.Decoded? = synchronized(pages) { pages.get(index) }

    /** Page size without decoding the picture. Null for a damaged page. */
    suspend fun sizeOf(index: Int): ImageDecode.Size? {
        knownSize(index)?.let { return it }
        return withContext(pageDispatcher) {
            val s = try { ImageDecode.bounds { archive.openPage(index) } } catch (_: IOException) { null }
            if (s != null) sizes[index] = pack(s)
            s
        }
    }

    private fun satisfies(d: ImageDecode.Decoded, reqW: Int, reqH: Int): Boolean =
        d.sample == 1 || ImageDecode.sampleSize(d.srcWidth, d.srcHeight, reqW, reqH) >= d.sample

    /** Decodes page [index] for a box of about [reqW] x [reqH] px. Null when the page is damaged. */
    suspend fun page(index: Int, reqW: Int, reqH: Int): ImageDecode.Decoded? {
        repeat(2) {
            peek(index)?.let { if (satisfies(it, reqW, reqH)) return it }
            val job = synchronized(inflight) {
                inflight[index] ?: scope.async(pageDispatcher) {
                    try {
                        ImageDecode.decodeWithInfo({ archive.openPage(index) }, reqW, reqH, MAX_PAGE_PIXELS)
                    } catch (_: IOException) {
                        null
                    }
                }.also { d ->
                    inflight[index] = d
                    d.invokeOnCompletion { synchronized(inflight) { if (inflight[index] === d) inflight.remove(index) } }
                }
            }
            val decoded = job.await() ?: return null
            sizes[index] = pack(ImageDecode.Size(decoded.srcWidth, decoded.srcHeight))
            synchronized(pages) {
                val existing = pages.get(index)
                if (existing == null || existing.sample > decoded.sample) pages.put(index, decoded)
            }
            if (satisfies(decoded, reqW, reqH)) return decoded
        }
        return peek(index)
    }

    /** Warms the cache for pages the reader will probably show next. Fire and forget. */
    fun prefetch(indices: List<Int>, reqW: Int, reqH: Int) {
        for (i in indices) {
            if (i !in 0 until archive.pageCount || !archive.isReady(i)) continue
            val have = peek(i)
            if (have != null && satisfies(have, reqW, reqH)) continue
            scope.launch { page(i, reqW, reqH) }
        }
    }

    suspend fun thumb(index: Int): Bitmap? {
        synchronized(thumbs) { thumbs.get(index) }?.let { return it }
        if (!archive.isReady(index)) return null
        return withContext(thumbDispatcher) {
            val b = try {
                ImageDecode.decode({ archive.openPage(index) }, 160, 230, 1_000_000L)
            } catch (_: IOException) { null }
            if (b != null) synchronized(thumbs) { thumbs.put(index, b) }
            b
        }
    }

    fun clear() {
        synchronized(pages) { pages.evictAll() }
        synchronized(thumbs) { thumbs.evictAll() }
        sizes.clear()
    }

    private fun pack(s: ImageDecode.Size): Long = (s.width.toLong() shl 32) or (s.height.toLong() and 0xFFFFFFFFL)
    private fun unpack(v: Long) = ImageDecode.Size((v shr 32).toInt(), (v and 0xFFFFFFFFL).toInt())

    companion object {
        /** About 48 MB of ARGB per page at most. */
        const val MAX_PAGE_PIXELS = 12_000_000L
    }
}
