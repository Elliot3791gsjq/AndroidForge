package com.novelreader.app.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import com.novelreader.app.R
import com.novelreader.app.core.ColorMath
import com.novelreader.app.data.CustomTheme
import com.novelreader.app.data.ReaderSettings
import com.novelreader.app.ui.ColorPickerDialog
import com.novelreader.app.ui.design.AccentButton
import com.novelreader.app.ui.design.AppBackdrop
import com.novelreader.app.ui.design.AppCard
import com.novelreader.app.ui.design.AppChip
import com.novelreader.app.ui.design.AppDialog
import com.novelreader.app.ui.design.AppProgressBar
import com.novelreader.app.ui.design.AppTextField
import com.novelreader.app.ui.design.AppThemeFromPalette
import com.novelreader.app.ui.design.ColorDot
import com.novelreader.app.ui.design.GhostButton
import com.novelreader.app.ui.design.MutedText
import com.novelreader.app.ui.design.PaletteFactory
import com.novelreader.app.ui.design.Presets
import com.novelreader.app.ui.design.SectionLabel
import com.novelreader.app.ui.design.SegmentedControl
import com.novelreader.app.ui.design.SoftIconButton
import com.novelreader.app.ui.design.Space
import com.novelreader.app.ui.design.appClickable
import com.novelreader.app.ui.design.palette
import com.novelreader.app.ui.design.toAppPalette
import com.novelreader.app.ui.library.LibraryViewModel

private enum class Field { ACCENT, BG, SURFACE, TEXT }

/**
 * Full-screen custom theme editor. The whole screen is drawn with the draft palette, so every colour change is
 * previewed live on real components before anything is saved. Background / surface / text are edited per
 * brightness (the accent is shared); surface and text can stay "Auto" (derived and kept legible).
 */
@Composable
fun ThemeEditorScreen(vm: LibraryViewModel, initial: CustomTheme?, onClose: () -> Unit) {
    val settings by vm.settings.collectAsState()
    val systemDark = isSystemInDarkTheme()
    val newId = remember { CustomTheme.newId() }
    val defaultName = stringResource(R.string.theme_default_name)
    val seed = remember(initial?.id) { initial ?: seedFrom(settings, newId, defaultName) }

    var name by remember { mutableStateOf(seed.name) }
    var accent by remember { mutableStateOf(seed.accent) }
    var darkBg by remember { mutableStateOf(seed.darkBg) }
    var darkSurface by remember { mutableStateOf(seed.darkSurface) }
    var darkText by remember { mutableStateOf(seed.darkText) }
    var lightBg by remember { mutableStateOf(seed.lightBg) }
    var lightSurface by remember { mutableStateOf(seed.lightSurface) }
    var lightText by remember { mutableStateOf(seed.lightText) }
    var editDark by remember { mutableStateOf(PaletteFactory.isDark(settings.uiMode, systemDark)) }
    var picking by remember { mutableStateOf<Field?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }

    val draft = CustomTheme(
        id = initial?.id ?: newId, name = name.ifBlank { defaultName }, accent = accent,
        darkBg = darkBg, darkSurface = darkSurface, darkText = darkText,
        lightBg = lightBg, lightSurface = lightSurface, lightText = lightText,
    )
    val argb = remember(draft, editDark) { PaletteFactory.build(draft, editDark) }
    val draftPalette = remember(argb) { argb.toAppPalette() }

    fun save() {
        vm.updateSettings { st ->
            val exists = st.customThemes.any { it.id == draft.id }
            val list = if (exists) st.customThemes.map { if (it.id == draft.id) draft else it } else st.customThemes + draft
            st.copy(customThemes = list, colorThemeId = draft.id)
        }
        onClose()
    }

    fun resetToDefault() {
        val e = Presets.byId(Presets.EMBER)
        accent = e.accentDark; darkBg = e.darkBg; darkText = null; darkSurface = null
        lightBg = e.lightBg; lightText = null; lightSurface = null
    }

    AppThemeFromPalette(draftPalette, settings.reduceMotion, instantColors = true) {
        val p = palette
        AppBackdrop {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = Space.l, vertical = Space.m),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    SoftIconButton(Icons.Default.Close, stringResource(R.string.close), onClose)
                    Text(
                        stringResource(R.string.theme_editor_title), style = MaterialTheme.typography.titleLarge, color = p.text,
                        modifier = Modifier.weight(1f).padding(horizontal = Space.m),
                    )
                    AccentButton(stringResource(R.string.save), ::save, height = 44.dp)
                }
                Column(
                    Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = Space.gutter).padding(bottom = Space.xl),
                    verticalArrangement = Arrangement.spacedBy(Space.m),
                ) {
                    AppTextField(name, { name = it.take(32) }, placeholder = stringResource(R.string.theme_name))

                    SectionLabel(stringResource(R.string.theme_preview), Modifier.padding(top = Space.xs, bottom = 0.dp))
                    PreviewCard()
                    SegmentedControl(
                        options = listOf(stringResource(R.string.theme_dark), stringResource(R.string.theme_light)),
                        selectedIndex = if (editDark) 0 else 1,
                        onSelect = { editDark = it == 0 },
                    )
                    MutedText(stringResource(R.string.theme_editing_hint))

                    AppCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(horizontal = Space.l, vertical = Space.s)) {
                            ColorRow(stringResource(R.string.theme_accent), accent, null, { picking = Field.ACCENT })
                            ColorRow(
                                stringResource(R.string.theme_background), if (editDark) darkBg else lightBg, null, { picking = Field.BG },
                            )
                            ColorRow(
                                stringResource(R.string.theme_surface), argb.surface,
                                auto = if (editDark) darkSurface == null else lightSurface == null,
                                onPick = { picking = Field.SURFACE },
                                onAuto = { if (editDark) darkSurface = null else lightSurface = null },
                            )
                            ColorRow(
                                stringResource(R.string.theme_text), argb.text,
                                auto = if (editDark) darkText == null else lightText == null,
                                onPick = { picking = Field.TEXT },
                                onAuto = { if (editDark) darkText = null else lightText = null },
                            )
                        }
                    }
                    MutedText(stringResource(R.string.theme_legible_hint))

                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Space.m)) {
                        GhostButton(stringResource(R.string.theme_reset), ::resetToDefault, Modifier.weight(1f))
                        if (initial != null) {
                            GhostButton(stringResource(R.string.theme_delete), { confirmDelete = true }, Modifier.weight(1f), destructive = true)
                        }
                    }
                }
            }
        }

        picking?.let { field ->
            val current = when (field) {
                Field.ACCENT -> accent
                Field.BG -> if (editDark) darkBg else lightBg
                Field.SURFACE -> argb.surface
                Field.TEXT -> argb.text
            }
            ColorPickerDialog(
                title = stringResource(
                    when (field) {
                        Field.ACCENT -> R.string.theme_accent
                        Field.BG -> R.string.theme_background
                        Field.SURFACE -> R.string.theme_surface
                        Field.TEXT -> R.string.theme_text
                    }
                ),
                initial = current,
                onDismiss = { picking = null },
                onConfirm = { c ->
                    when (field) {
                        Field.ACCENT -> accent = c
                        Field.BG -> if (editDark) darkBg = c else lightBg = c
                        Field.SURFACE -> if (editDark) darkSurface = c else lightSurface = c
                        Field.TEXT -> if (editDark) darkText = c else lightText = c
                    }
                    picking = null
                },
            )
        }

        if (confirmDelete && initial != null) {
            AppDialog(
                onDismissRequest = { confirmDelete = false },
                title = { Text(stringResource(R.string.theme_delete)) },
                text = { Text(stringResource(R.string.theme_delete_message, initial.name)) },
                confirmButton = {
                    TextButton(onClick = {
                        vm.updateSettings { st ->
                            st.copy(
                                customThemes = st.customThemes.filter { it.id != initial.id },
                                colorThemeId = if (st.colorThemeId == initial.id) ReaderSettings.DEFAULT_COLOR_THEME else st.colorThemeId,
                            )
                        }
                        confirmDelete = false
                        onClose()
                    }) { Text(stringResource(R.string.delete), color = p.danger) }
                },
                dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text(stringResource(R.string.cancel)) } },
            )
        }
    }
}

/** Starting point for a new theme: the currently active theme's colours. */
private fun seedFrom(s: ReaderSettings, id: String, name: String): CustomTheme {
    val custom = s.customThemes.firstOrNull { it.id == s.colorThemeId }
    if (custom != null) return custom.copy(id = id, name = name)
    val spec = Presets.byId(s.colorThemeId)
    return CustomTheme(
        id = id, name = name, accent = spec.accentDark,
        darkBg = spec.darkBg, darkText = spec.darkText, lightBg = spec.lightBg, lightText = spec.lightText,
    )
}

@Composable
private fun ColorRow(label: String, color: Int, auto: Boolean?, onPick: () -> Unit, onAuto: (() -> Unit)? = null) {
    val p = palette
    Row(
        Modifier.fillMaxWidth().appClickable(onPick, role = Role.Button, scaleTo = 0.985f).padding(vertical = Space.m),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        ColorDot(Color(color), selected = false, size = 34.dp)
        Column(Modifier.weight(1f).padding(horizontal = Space.m)) {
            Text(label, style = MaterialTheme.typography.bodyLarge, color = p.text)
            Text(ColorMath.toHex(color), style = MaterialTheme.typography.labelMedium, color = p.textMuted)
        }
        if (auto != null && onAuto != null) {
            AppChip(stringResource(R.string.theme_auto), selected = auto, onClick = onAuto)
        }
    }
}

/** A miniature app screen built from the real components, so the preview is exactly what the app will show. */
@Composable
private fun PreviewCard() {
    val p = palette
    Column(
        Modifier
            .fillMaxWidth()
            .clip(com.novelreader.app.ui.design.AppShapes.cardLarge)
            .background(p.bg)
            .border(1.dp, p.outline, com.novelreader.app.ui.design.AppShapes.cardLarge)
            .padding(Space.l),
        verticalArrangement = Arrangement.spacedBy(Space.m),
    ) {
        Text(stringResource(R.string.library), style = MaterialTheme.typography.headlineMedium, color = p.text)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AppChip(stringResource(R.string.filter_all), selected = true, onClick = {})
            AppChip(stringResource(R.string.filter_reading), selected = false, onClick = {})
            AppChip(stringResource(R.string.filter_favorites), selected = false, onClick = {})
        }
        AppCard(Modifier.fillMaxWidth()) {
            Row(Modifier.padding(Space.m), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(width = 44.dp, height = 64.dp).clip(com.novelreader.app.ui.design.AppShapes.cover).background(p.accent))
                Column(Modifier.weight(1f).padding(start = Space.m)) {
                    Text(stringResource(R.string.theme_preview_title), style = MaterialTheme.typography.titleSmall, color = p.text)
                    MutedText(stringResource(R.string.theme_preview_author))
                    Spacer(Modifier.height(8.dp))
                    AppProgressBar(0.64f, height = 5.dp)
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(Space.m), verticalAlignment = Alignment.CenterVertically) {
            AccentButton(stringResource(R.string.continue_action), {}, height = 40.dp)
            GhostButton(stringResource(R.string.cancel), {}, height = 40.dp)
        }
    }
}
