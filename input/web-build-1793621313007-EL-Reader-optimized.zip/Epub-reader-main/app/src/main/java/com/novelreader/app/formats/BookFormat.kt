package com.novelreader.app.formats

import java.util.Locale

/**
 * Every file type EL Reader can open. The stored name of a book's format ([BookFormat.name]) lives in
 * `books.format`; rows created before DB v5 are EPUBs (the column default).
 *
 * [extensions] are only hints (a ".cbr" that is really a ZIP is opened as CBZ): the type of an imported file is
 * decided by its content, see [FormatDetector].
 */
enum class BookFormat(val storedExtension: String, val extensions: Set<String>, val mimeTypes: Set<String>) {
    EPUB("epub", setOf("epub"), setOf("application/epub+zip", "application/epub", "application/x-epub+zip")),
    PDF("pdf", setOf("pdf"), setOf("application/pdf")),
    TXT("txt", setOf("txt", "text", "log", "md"), setOf("text/plain", "text/markdown")),
    DOCX(
        "docx", setOf("docx"),
        setOf("application/vnd.openxmlformats-officedocument.wordprocessingml.document"),
    ),
    CBZ("cbz", setOf("cbz"), setOf("application/vnd.comicbook+zip", "application/x-cbz")),
    CBR("cbr", setOf("cbr"), setOf("application/vnd.comicbook-rar", "application/x-cbr"));

    /** Comic archives share one reading engine. */
    val isComic: Boolean get() = this == CBZ || this == CBR

    /** Text-like documents share the HTML document engine. */
    val isDocument: Boolean get() = this == TXT || this == DOCX

    companion object {
        /** Every extension the file pickers offer. */
        val allExtensions: Set<String> = entries.flatMap { it.extensions }.toSet()

        fun fromStored(name: String?): BookFormat = entries.firstOrNull { it.name == name } ?: EPUB

        fun extensionOf(fileName: String?): String? {
            val n = fileName?.trim() ?: return null
            val dot = n.lastIndexOf('.')
            if (dot < 0 || dot == n.length - 1) return null
            return n.substring(dot + 1).lowercase(Locale.ROOT)
        }

        /** Format suggested by the display name alone (hint only). */
        fun fromExtension(fileName: String?): BookFormat? {
            val e = extensionOf(fileName) ?: return null
            return entries.firstOrNull { e in it.extensions }
        }

        fun fromMime(mime: String?): BookFormat? {
            val m = mime?.lowercase(Locale.ROOT) ?: return null
            return entries.firstOrNull { m in it.mimeTypes }
        }
    }
}
