package com.novelreader.app.reader

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File
import java.util.zip.ZipFile

/** Decodes small previews of pictures stored inside an EPUB (read straight from the ZIP, never extracted to disk). */
object ImageThumbs {

    /** Large version for the zoom viewer: longest side at most [maxSide] px (never upscaled). */
    fun loadForZoom(epub: File, entry: String, maxSide: Int = 3000): Bitmap? = try {
        ZipFile(epub).use { zip ->
            val e = zip.getEntry(entry) ?: return null
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            zip.getInputStream(e).use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > maxSide) sample *= 2
            zip.getInputStream(e).use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample }) }
        }
    } catch (_: Throwable) {
        null
    }

    fun load(epub: File, entry: String, maxSide: Int): Bitmap? = try {
        ZipFile(epub).use { zip ->
            val e = zip.getEntry(entry) ?: return null
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            zip.getInputStream(e).use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxSide) sample *= 2
            zip.getInputStream(e).use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample }) }
        }
    } catch (_: Throwable) {
        null
    }
}
