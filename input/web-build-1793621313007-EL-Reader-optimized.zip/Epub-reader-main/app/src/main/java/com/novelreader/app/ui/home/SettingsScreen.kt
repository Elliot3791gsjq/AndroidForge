package com.novelreader.app.ui.home

import android.app.Activity
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.os.LocaleListCompat
import com.novelreader.app.R
import com.novelreader.app.data.CustomTheme
import com.novelreader.app.data.FontChoice
import com.novelreader.app.data.UiMode
import com.novelreader.app.ui.AppIcons
import com.novelreader.app.ui.ChoiceChips
import com.novelreader.app.ui.ToolbarCatalog
import com.novelreader.app.ui.design.AppPalette
import com.novelreader.app.ui.design.AppShapes
import com.novelreader.app.ui.design.AppSwitch
import com.novelreader.app.ui.design.GhostButton
import com.novelreader.app.ui.design.MutedText
import com.novelreader.app.ui.design.PaletteFactory
import com.novelreader.app.ui.design.Presets
import com.novelreader.app.ui.design.ScreenHeader
import com.novelreader.app.ui.design.SegmentedControl
import com.novelreader.app.ui.design.SettingRow
import com.novelreader.app.ui.design.SettingsGroup
import com.novelreader.app.ui.design.Space
import com.novelreader.app.ui.design.appClickable
import com.novelreader.app.ui.design.bottomClearance
import com.novelreader.app.ui.design.motion
import com.novelreader.app.ui.design.palette
import com.novelreader.app.ui.design.toAppPalette
import com.novelreader.app.ui.library.LibraryViewModel

fun presetNameRes(id: String): Int = when (id) {
    Presets.OCEAN -> R.string.theme_ocean
    Presets.VIOLET -> R.string.theme_violet
    Presets.FOREST -> R.string.theme_forest
    Presets.CRIMSON -> R.string.theme_crimson
    Presets.TEAL -> R.string.theme_teal
    Presets.MINIMAL -> R.string.theme_minimal
    Presets.PAPER -> R.string.theme_paper
    else -> R.string.theme_ember
}

@Composable
fun SettingsScreen(vm: LibraryViewModel, onEditTheme: (CustomTheme?) -> Unit) {
    val s by vm.settings.collectAsState()
    val context = LocalContext.current
    val p = palette

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(stringResource(R.string.nav_settings))
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = Space.gutter)
                .padding(bottom = bottomClearance()),
        ) {
            // ---------------- Appearance ----------------
            SettingsGroup(stringResource(R.string.settings_appearance)) {
                Text(stringResource(R.string.theme_mode), style = MaterialTheme.typography.labelLarge, color = p.textMuted, modifier = Modifier.padding(top = Space.s, bottom = Space.s))
                SegmentedControl(
                    options = listOf(stringResource(R.string.mode_system), stringResource(R.string.theme_dark), stringResource(R.string.theme_light)),
                    selectedIndex = when (s.uiMode) { UiMode.SYSTEM -> 0; UiMode.DARK -> 1; UiMode.LIGHT -> 2 },
                    onSelect = { i -> vm.updateSettings { it.copy(uiMode = when (i) { 0 -> UiMode.SYSTEM; 1 -> UiMode.DARK; else -> UiMode.LIGHT }) } },
                )
                Text(stringResource(R.string.color_theme), style = MaterialTheme.typography.labelLarge, color = p.textMuted, modifier = Modifier.padding(top = Space.l, bottom = Space.s))
                val dark = p.dark
                val presetPalettes = remember(dark) { Presets.all.map { it to PaletteFactory.build(it, dark).toAppPalette() } }
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    presetPalettes.forEach { (spec, pal) ->
                        ThemeTile(
                            name = stringResource(presetNameRes(spec.id)), pal = pal, selected = s.colorThemeId == spec.id,
                            onClick = { vm.updateSettings { it.copy(colorThemeId = spec.id) } },
                        )
                    }
                }
                Text(stringResource(R.string.custom_themes), style = MaterialTheme.typography.labelLarge, color = p.textMuted, modifier = Modifier.padding(top = Space.l, bottom = Space.s))
                val customPalettes = remember(dark, s.customThemes) { s.customThemes.map { it to PaletteFactory.build(it, dark).toAppPalette() } }
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    customPalettes.forEach { (theme, pal) ->
                        ThemeTile(
                            name = theme.name, pal = pal, selected = s.colorThemeId == theme.id,
                            onClick = { vm.updateSettings { it.copy(colorThemeId = theme.id) } },
                            onLongClick = { onEditTheme(theme) },
                        )
                    }
                    NewThemeTile(onClick = { onEditTheme(null) })
                }
                val selectedCustom = s.customThemes.firstOrNull { it.id == s.colorThemeId }
                if (selectedCustom != null) {
                    Row(Modifier.fillMaxWidth().padding(top = Space.m), horizontalArrangement = Arrangement.spacedBy(Space.m)) {
                        GhostButton(stringResource(R.string.theme_edit), { onEditTheme(selectedCustom) }, Modifier.weight(1f))
                    }
                } else {
                    MutedText(stringResource(R.string.custom_theme_hint), Modifier.padding(top = Space.s))
                }
                SettingRow(
                    title = stringResource(R.string.reduce_motion),
                    subtitle = stringResource(R.string.reduce_motion_hint),
                    modifier = Modifier.padding(top = Space.s),
                    trailing = { AppSwitch(s.reduceMotion, { on -> vm.updateSettings { it.copy(reduceMotion = on) } }) },
                )
            }

            // ---------------- Language ----------------
            SettingsGroup(stringResource(R.string.settings_language)) {
                val currentLang = AppCompatDelegate.getApplicationLocales().let { if (it.isEmpty) "en" else it[0]?.language ?: "en" }
                Box(Modifier.padding(vertical = Space.m)) {
                    ChoiceChips(
                        options = listOf("en" to stringResource(R.string.language_english), "fa" to stringResource(R.string.language_persian)),
                        selected = if (currentLang == "fa") "fa" else "en",
                        onSelect = { tag ->
                            if (tag != currentLang) {
                                AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(tag))
                                (context as? Activity)?.recreate()
                            }
                        },
                    )
                }
            }

            // ---------------- Reading ----------------
            SettingsGroup(stringResource(R.string.settings_reading)) {
                Text(stringResource(R.string.default_font), style = MaterialTheme.typography.labelLarge, color = p.textMuted, modifier = Modifier.padding(top = Space.s, bottom = Space.s))
                ChoiceChips(
                    options = listOf(
                        FontChoice.ORIGINAL to stringResource(R.string.default_font_system),
                        FontChoice.SERIF to stringResource(R.string.font_serif),
                        FontChoice.SANS_SERIF to stringResource(R.string.font_sans),
                    ),
                    selected = s.fontChoice,
                    onSelect = { c -> vm.updateSettings { it.copy(fontChoice = c) } },
                )
                MutedText(stringResource(R.string.default_font_hint), Modifier.padding(top = Space.s, bottom = Space.m))
            }

            // ---------------- Reader toolbar ----------------
            SettingsGroup(stringResource(R.string.settings_toolbar)) {
                MutedText(stringResource(R.string.settings_toolbar_hint), Modifier.padding(top = Space.s))
                ToolbarCatalog.items.forEach { item ->
                    SettingRow(
                        title = stringResource(item.nameRes),
                        icon = item.icon,
                        trailing = {
                            AppSwitch(
                                checked = item.id !in s.toolbarHidden,
                                onCheckedChange = { shown ->
                                    vm.updateSettings { it.copy(toolbarHidden = if (shown) it.toolbarHidden - item.id else it.toolbarHidden + item.id) }
                                },
                            )
                        },
                    )
                }
                Box(Modifier.padding(bottom = Space.m)) {
                    GhostButton(stringResource(R.string.reset), { vm.updateSettings { it.copy(toolbarHidden = emptySet()) } })
                }
            }
        }
    }
}

/** A miniature of what the whole app looks like in [pal]. */
@Composable
private fun ThemeTile(name: String, pal: AppPalette, selected: Boolean, onClick: () -> Unit, onLongClick: (() -> Unit)? = null) {
    val cur = palette
    Column(
        Modifier.width(92.dp).appClickable(onClick, onLongClick = onLongClick, role = Role.RadioButton, scaleTo = 0.95f),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(104.dp)
                .clip(AppShapes.card)
                .background(pal.bg)
                .border(if (selected) 2.5.dp else 1.dp, if (selected) cur.accent else cur.outline, AppShapes.card)
                .padding(10.dp),
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(Modifier.size(20.dp).clip(CircleShape).background(pal.accent))
                Box(Modifier.width(44.dp).height(6.dp).clip(CircleShape).background(pal.text))
                Box(Modifier.width(30.dp).height(6.dp).clip(CircleShape).background(pal.textMuted))
                Box(Modifier.fillMaxWidth().height(22.dp).clip(CircleShape).background(pal.surfaceHigh)) {
                    Box(Modifier.padding(5.dp).size(width = 24.dp, height = 12.dp).clip(CircleShape).background(pal.accentSoft))
                }
            }
            if (selected) {
                Box(
                    Modifier.align(Alignment.TopEnd).size(22.dp).clip(CircleShape).background(cur.accent),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Default.Check, null, tint = cur.onAccent, modifier = Modifier.size(14.dp)) }
            }
        }
        Text(
            name, style = MaterialTheme.typography.labelMedium, color = if (selected) cur.accentText else cur.textMuted,
            maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 6.dp),
        )
    }
}

@Composable
private fun NewThemeTile(onClick: () -> Unit) {
    val cur = palette
    Column(Modifier.width(92.dp).appClickable(onClick, scaleTo = 0.95f), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .fillMaxWidth().height(104.dp)
                .clip(AppShapes.card)
                .background(cur.surface)
                .border(1.dp, cur.outline, AppShapes.card),
            contentAlignment = Alignment.Center,
        ) {
            Box(Modifier.size(40.dp).clip(CircleShape).background(cur.accentSoft), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Add, null, tint = cur.onAccentSoft)
            }
        }
        Text(
            stringResource(R.string.new_theme), style = MaterialTheme.typography.labelMedium, color = cur.textMuted,
            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp),
        )
    }
}
