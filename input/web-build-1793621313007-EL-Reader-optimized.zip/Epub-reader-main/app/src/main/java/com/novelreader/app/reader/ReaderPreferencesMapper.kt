package com.novelreader.app.reader

import com.novelreader.app.core.FontCss
import com.novelreader.app.data.AlignMode
import com.novelreader.app.data.effectiveBackground
import com.novelreader.app.data.effectiveText
import com.novelreader.app.data.DirectionMode
import com.novelreader.app.data.FontChoice
import com.novelreader.app.data.PageFlipMode
import com.novelreader.app.data.isVerticalScrolling
import com.novelreader.app.data.ReaderSettings
import com.novelreader.app.core.ColorMath
import org.readium.r2.navigator.epub.EpubPreferences
import org.readium.r2.navigator.preferences.Color
import org.readium.r2.navigator.preferences.ColumnCount
import org.readium.r2.navigator.preferences.FontFamily
import org.readium.r2.navigator.preferences.ReadingProgression
import org.readium.r2.navigator.preferences.TextAlign
import org.readium.r2.navigator.preferences.Theme

/**
 * Single translation point from the app's persisted [ReaderSettings] to Readium's [EpubPreferences].
 * Styling is applied through the navigator's presentation CSS (ReadiumCSS user properties); the EPUB file
 * itself is never modified.
 *
 * Notes on semantics (documented Readium behaviour):
 *  - keepPublisherStyles = true  -> the book's own CSS wins for spacing/alignment; custom values are ignored
 *    by the engine until it is switched off.
 *  - text/background colours and font size apply in both modes.
 *  - A custom background *image* is drawn by the app in a layer BEHIND the navigator (ReaderBackground) and the
 *    page colour is sent as fully transparent. Whether Readium honours alpha 0 is to be verified on a device.
 */
object ReaderPreferencesMapper {

    /**
     * @param availableFontIds ids of imported fonts that are actually declared in the open publication
     * (see [FontInjection]); selections pointing anywhere else are ignored instead of producing a dead family name.
     * @param landscape the screen is currently wider than tall (decides whether Dual-Page Mode applies, see [DualPage]).
     */
    fun toEpubPreferences(s: ReaderSettings, availableFontIds: Set<String> = emptySet(), landscape: Boolean = false): EpubPreferences = EpubPreferences(
        // The page's own brightness (from its background colour), never the app UI theme.
        theme = if (ColorMath.isDark(s.effectiveBackground())) Theme.DARK else Theme.LIGHT,
        // With a background image the page must be transparent so the image layer behind it shows through.
        // Readium writes this colour into the page CSS as "#RRGGBB" and DROPS the alpha channel, so an alpha-0
        // colour would become opaque black. Instead no page colour is sent at all: the reading-system colour the
        // activity sets (see ReaderActivity.TRANSPARENT_PAGE) is "transparent" and shows through. Without an image
        // the page colour is passed explicitly, so the reading page never inherits app-UI colours.
        backgroundColor = if (s.backgroundImagePath != null) null else Color(s.effectiveBackground()),
        textColor = Color(s.effectiveText()),
        fontSize = s.fontSizePercent / 100.0,
        publisherStyles = s.keepPublisherStyles,
        fontFamily = FontCss.familyFor(s.faFontId, s.latinFontId, availableFontIds)?.let { FontFamily(it) }
            ?: when (s.fontChoice) {
                FontChoice.ORIGINAL -> null
                FontChoice.SERIF -> FontFamily.SERIF
                FontChoice.SANS_SERIF -> FontFamily.SANS_SERIF
                FontChoice.MONOSPACE -> FontFamily.MONOSPACE
            },
        lineHeight = s.lineHeight,
        paragraphSpacing = s.paragraphSpacing,
        paragraphIndent = s.paragraphIndent,
        textAlign = when (s.align) {
            AlignMode.ORIGINAL -> null
            AlignMode.RIGHT -> TextAlign.RIGHT
            AlignMode.CENTER -> TextAlign.CENTER
            AlignMode.LEFT -> TextAlign.LEFT
        },
        pageMargins = s.pageMargins,
        scroll = s.isVerticalScrolling(),
        // Two columns per page = Dual-Page Mode (reflowable books, paginated only). On a phone the engine ignores this
        // user preference (viewport narrower than ~60em); ReaderActivity additionally sends the reading-system
        // column count, which is what actually makes two pages appear. Off = one column, also on wide screens.
        columnCount = if (DualPage.active(s.dualPage, s.dualPagePortrait, s.isVerticalScrolling(), landscape)) ColumnCount.TWO else ColumnCount.ONE,
        readingProgression = when (s.pageFlipMode) {
            // Explicit choices: the swipe direction the user wants for "next page".
            PageFlipMode.RIGHT_TO_LEFT -> ReadingProgression.LTR
            PageFlipMode.LEFT_TO_RIGHT -> ReadingProgression.RTL
            else -> when (s.direction) {
                DirectionMode.AUTO -> null
                DirectionMode.LTR -> ReadingProgression.LTR
                DirectionMode.RTL -> ReadingProgression.RTL
            }
        },
    )
}
