package com.novelreader.app.formats.doc

import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.File
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream
import java.util.Locale
import java.util.zip.ZipFile

class DocxException(val reason: Reason, message: String) : Exception(message) {
    enum class Reason { NOT_DOCX, TOO_LARGE, CORRUPT }
}

/**
 * Reads a .docx (Office Open XML) with a streaming XML parser and writes the document as HTML blocks (see
 * [DocParseResult] for the block contract). Covers what reading needs: styles (with inheritance), headings,
 * paragraph alignment / indents / spacing / direction, bold, italic, underline, strike, colour, size, highlight,
 * fonts, superscript / subscript, lists (numbering definitions), tables (spans, shading, borders), images,
 * hyperlinks and internal links. Not rendered: headers and footers, footnotes, text boxes, charts, drawings, page
 * layout; those are reported as [DocWarning]s. Pure JVM apart from the XML parser, which is injected.
 */
class DocxParser(
    private val newParser: () -> XmlPullParser = {
        XmlPullParserFactory.newInstance().apply { isNamespaceAware = true }.newPullParser()
    },
) {

    fun parse(file: File, out: Appendable): DocParseResult {
        val zip = try { ZipFile(file) } catch (e: IOException) { throw DocxException(DocxException.Reason.NOT_DOCX, "Not a zip file") }
        zip.use { z -> return Session(z, newParser, out).run() }
    }

    // ---------------------------------------------------------------------------------------------------------
    // Properties
    // ---------------------------------------------------------------------------------------------------------

    private class RPr {
        var b: Boolean? = null; var i: Boolean? = null; var u: Boolean? = null; var strike: Boolean? = null
        var caps: Boolean? = null; var smallCaps: Boolean? = null; var vanish: Boolean? = null
        var color: String? = null; var sz: Int? = null
        var fontLatin: String? = null; var fontCs: String? = null
        var highlight: String? = null; var shd: String? = null; var vert: String? = null
        var rStyle: String? = null

        fun overlay(o: RPr) {
            o.b?.let { b = it }; o.i?.let { i = it }; o.u?.let { u = it }; o.strike?.let { strike = it }
            o.caps?.let { caps = it }; o.smallCaps?.let { smallCaps = it }; o.vanish?.let { vanish = it }
            o.color?.let { color = it }; o.sz?.let { sz = it }
            o.fontLatin?.let { fontLatin = it }; o.fontCs?.let { fontCs = it }
            o.highlight?.let { highlight = it }; o.shd?.let { shd = it }; o.vert?.let { vert = it }
        }

        fun copy(): RPr = RPr().also { it.overlay(this) }
    }

    private class PPr {
        var jc: String? = null
        var left: Int? = null; var right: Int? = null; var first: Int? = null; var hanging: Int? = null
        var before: Int? = null; var after: Int? = null
        var bidi: Boolean? = null; var outline: Int? = null
        var numId: Int? = null; var ilvl: Int? = null
        var pStyle: String? = null

        fun overlay(o: PPr) {
            o.jc?.let { jc = it }
            o.left?.let { left = it }; o.right?.let { right = it }; o.first?.let { first = it }; o.hanging?.let { hanging = it }
            o.before?.let { before = it }; o.after?.let { after = it }
            o.bidi?.let { bidi = it }; o.outline?.let { outline = it }
            o.numId?.let { numId = it }; o.ilvl?.let { ilvl = it }
        }

        fun copy(): PPr = PPr().also { it.overlay(this); it.pStyle = pStyle }
    }

    private class Style(val id: String, val name: String, val type: String, val basedOn: String?) {
        val p = PPr()
        val r = RPr()
        var tblBorders = false
    }

    private class NumLevel(var start: Int = 1, var fmt: String = "decimal", var text: String = "", var left: Int? = null, var hanging: Int? = null)
    private class AbstractNum { val levels = arrayOfNulls<NumLevel>(9) }
    private class Num(val abstractId: Int) { val startOverride = HashMap<Int, Int>() }

    private class CellOut(val html: String, val colSpan: Int, val vMerge: Int /* 0 none, 1 restart, 2 continue */, val fill: String?, val gridCol: Int) {
        var rowSpan = 1
    }

    private class FieldState { val instr = StringBuilder(); var display = false; var link: String? = null; var linkAnchor: String? = null }

    private class ParaBuilder {
        val html = StringBuilder()
        val text = StringBuilder()
        var open: String? = null
        var close = ""
        var hasImage = false
        var linkOpen = false
        val anchors = ArrayList<String>()

        fun addRun(openS: String, closeS: String, h: CharSequence, t: CharSequence) {
            if (h.isEmpty() && t.isEmpty()) return
            if (openS != open) { closeWrapper(); html.append(openS); open = openS; close = closeS }
            html.append(h); text.append(t)
        }

        fun closeWrapper() { if (open != null) { html.append(close); open = null; close = "" } }
        fun openLink(tag: String) { closeWrapper(); closeLink(); html.append(tag); linkOpen = true }
        fun closeLink() { if (linkOpen) { closeWrapper(); html.append("</a>"); linkOpen = false } }
    }

    // ---------------------------------------------------------------------------------------------------------
    // One parse
    // ---------------------------------------------------------------------------------------------------------

    private class Session(val zip: ZipFile, val newParser: () -> XmlPullParser, val out: Appendable) {

        lateinit var p: XmlPullParser

        val styles = HashMap<String, Style>()
        val defaultRun = RPr()
        val defaultPara = PPr()
        var defaultParaStyle: String? = null
        val abstractNums = HashMap<Int, AbstractNum>()
        val nums = HashMap<Int, Num>()
        val counters = HashMap<Int, IntArray>()
        var rels: Map<String, Rel> = emptyMap()
        var docDir = "word/"
        var basePt = 10.0

        val texts = ArrayList<String>()
        val outline = ArrayList<DocOutline>()
        val images = ArrayList<DocImage>()
        val imageIndex = HashMap<String, Int>()
        val anchors = HashMap<String, Int>()
        var suppress = 0
        var emptyRun = 0
        var lastRtl = false
        var rtlBlocks = 0
        var ltrBlocks = 0
        var unsupportedImages = 0
        var textBoxes = 0
        var equations = 0
        var footnoteRefs = 0
        val fields = ArrayList<FieldState>()

        class Rel(val type: String, val target: String, val external: Boolean)

        // ---- XML helpers ----

        fun attr(name: String): String? {
            for (i in 0 until p.attributeCount) if (p.getAttributeName(i) == name) return p.getAttributeValue(i)
            return null
        }

        fun boolAttr(): Boolean = when (attr("val")?.lowercase(Locale.ROOT)) { null, "1", "true", "on" -> true; else -> false }

        /** Consumes the children of the current element; every child must be consumed by [body] (the rest is skipped). */
        fun children(body: (String) -> Unit) {
            val d = p.depth
            while (true) {
                val ev = p.next()
                if (ev == XmlPullParser.END_DOCUMENT) return
                if (ev == XmlPullParser.END_TAG && p.depth == d) return
                if (ev == XmlPullParser.START_TAG) {
                    val cd = p.depth
                    body(p.name)
                    if (!(p.eventType == XmlPullParser.END_TAG && p.depth == cd)) skipTo(cd)
                }
            }
        }

        fun skipTo(depth: Int) {
            while (true) {
                val ev = p.next()
                if (ev == XmlPullParser.END_DOCUMENT) return
                if (ev == XmlPullParser.END_TAG && p.depth == depth) return
            }
        }

        fun open(entry: String): InputStream? {
            val e = zip.getEntry(entry) ?: return null
            if (e.size > MAX_XML_BYTES) throw DocxException(DocxException.Reason.TOO_LARGE, "Part too large: $entry")
            return LimitedStream(zip.getInputStream(e), MAX_XML_BYTES)
        }

        fun startParsing(entry: String): Boolean {
            val ins = open(entry) ?: return false
            p = newParser()
            p.setInput(ins, null)
            return true
        }

        // ---- entry point ----

        fun run(): DocParseResult {
            val mainPart = locateMainPart()
            docDir = mainPart.substringBeforeLast('/', "").let { if (it.isEmpty()) "" else "$it/" }
            rels = readRels(relsPathFor(mainPart))
            val stylesPart = rels.values.firstOrNull { it.type.endsWith("/styles") }?.let { resolve(docDir, it.target) } ?: "${docDir}styles.xml"
            val numberingPart = rels.values.firstOrNull { it.type.endsWith("/numbering") }?.let { resolve(docDir, it.target) } ?: "${docDir}numbering.xml"
            try { readStyles(stylesPart) } catch (e: Exception) { if (e is DocxException) throw e }
            try { readNumbering(numberingPart) } catch (e: Exception) { if (e is DocxException) throw e }

            defaultRun.sz?.let { basePt = it / 2.0 }
            defaultParaStyle?.let { id -> styles[id]?.let { st -> resolveRun(null, st.id).sz?.let { basePt = it / 2.0 } } }
            if (basePt < 6 || basePt > 40) basePt = 10.0

            if (!startParsing(mainPart)) throw DocxException(DocxException.Reason.NOT_DOCX, "No main document part")
            try {
                var found = false
                while (true) {
                    val ev = p.next()
                    if (ev == XmlPullParser.END_DOCUMENT) break
                    if (ev == XmlPullParser.START_TAG && p.name == "body") { found = true; blocks(out); break }
                }
                if (!found) throw DocxException(DocxException.Reason.CORRUPT, "No body")
            } catch (e: org.xmlpull.v1.XmlPullParserException) {
                throw DocxException(DocxException.Reason.CORRUPT, e.message ?: "XML error")
            }

            val warnings = ArrayList<DocWarning>()
            if (unsupportedImages > 0) warnings += DocWarning(DocWarningKind.IMAGES_UNSUPPORTED, unsupportedImages)
            if (textBoxes > 0) warnings += DocWarning(DocWarningKind.TEXT_BOXES, textBoxes)
            if (equations > 0) warnings += DocWarning(DocWarningKind.EQUATIONS, equations)
            val hf = zip.entries().asSequence().count { e -> val n = e.name.substringAfterLast('/'); (n.startsWith("header") || n.startsWith("footer")) && n.endsWith(".xml") && partHasText(e.name) }
            if (hf > 0) warnings += DocWarning(DocWarningKind.HEADERS_FOOTERS, hf)
            if (footnoteRefs > 0) warnings += DocWarning(DocWarningKind.FOOTNOTES, footnoteRefs)

            return DocParseResult(texts, outline, images, anchors, readTitle(), rtlBlocks > ltrBlocks, warnings)
        }

        fun partHasText(name: String): Boolean = try {
            val e = zip.getEntry(name)
            if (e == null || e.size > 400_000) false else {
                val s = zip.getInputStream(e).use { it.readBytes() }.toString(Charsets.UTF_8)
                Regex("<w:t(?:\\s[^>]*)?>([^<]*\\S[^<]*)</w:t>").containsMatchIn(s)
            }
        } catch (_: Exception) { false }

        fun readTitle(): String? = try {
            if (!startParsing("docProps/core.xml")) null else {
                var title: String? = null
                while (true) {
                    val ev = p.next()
                    if (ev == XmlPullParser.END_DOCUMENT) break
                    if (ev == XmlPullParser.START_TAG && p.name == "title") { title = p.nextText().trim().ifEmpty { null }; break }
                }
                title
            }
        } catch (_: Exception) { null }

        // ---- package structure ----

        fun locateMainPart(): String {
            val rootRels = readRels("_rels/.rels")
            val main = rootRels.values.firstOrNull { it.type.endsWith("/officeDocument") }?.target?.trimStart('/')
            val candidate = main ?: "word/document.xml"
            if (zip.getEntry(candidate) != null) return candidate
            if (zip.getEntry("word/document.xml") != null) return "word/document.xml"
            throw DocxException(DocxException.Reason.NOT_DOCX, "No word/document.xml")
        }

        fun relsPathFor(part: String): String {
            val dir = part.substringBeforeLast('/', "")
            val name = part.substringAfterLast('/')
            return (if (dir.isEmpty()) "" else "$dir/") + "_rels/$name.rels"
        }

        fun readRels(path: String): Map<String, Rel> {
            if (!startParsing(path)) return emptyMap()
            val map = HashMap<String, Rel>()
            try {
                while (true) {
                    val ev = p.next()
                    if (ev == XmlPullParser.END_DOCUMENT) break
                    if (ev == XmlPullParser.START_TAG && p.name == "Relationship") {
                        val id = attr("Id"); val type = attr("Type"); val target = attr("Target")
                        if (id != null && type != null && target != null) map[id] = Rel(type, target, attr("TargetMode").equals("External", ignoreCase = true))
                    }
                }
            } catch (_: org.xmlpull.v1.XmlPullParserException) { }
            return map
        }

        fun resolve(baseDir: String, target: String): String {
            if (target.startsWith("/")) return target.trimStart('/')
            val parts = ArrayList<String>()
            (baseDir + target).split('/').forEach { seg ->
                when (seg) { "", "." -> {}; ".." -> if (parts.isNotEmpty()) parts.removeAt(parts.size - 1); else -> parts += seg }
            }
            return parts.joinToString("/")
        }

        // ---- styles ----

        fun readRPr(into: RPr) {
            children { n ->
                when (n) {
                    "b" -> into.b = boolAttr()
                    "i" -> into.i = boolAttr()
                    "u" -> into.u = attr("val")?.lowercase(Locale.ROOT) != "none"
                    "strike", "dstrike" -> into.strike = boolAttr()
                    "caps" -> into.caps = boolAttr()
                    "smallCaps" -> into.smallCaps = boolAttr()
                    "vanish" -> into.vanish = boolAttr()
                    "color" -> attr("val")?.takeIf { hex(it) }?.let { into.color = it.uppercase(Locale.ROOT) }
                    "sz" -> attr("val")?.toIntOrNull()?.let { into.sz = it }
                    "rFonts" -> {
                        into.fontLatin = attr("ascii") ?: attr("hAnsi") ?: into.fontLatin
                        into.fontCs = attr("cs") ?: into.fontCs
                        if (into.fontLatin == null) into.fontLatin = attr("eastAsia")
                    }
                    "highlight" -> into.highlight = attr("val")?.let { HIGHLIGHT[it] }
                    "shd" -> attr("fill")?.takeIf { hex(it) }?.let { into.shd = it.uppercase(Locale.ROOT) }
                    "vertAlign" -> into.vert = attr("val")
                    "rStyle" -> into.rStyle = attr("val")
                }
            }
        }

        fun readPPr(into: PPr) {
            children { n ->
                when (n) {
                    "jc" -> into.jc = attr("val")
                    "ind" -> {
                        (attr("left") ?: attr("start"))?.toIntOrNull()?.let { into.left = it }
                        (attr("right") ?: attr("end"))?.toIntOrNull()?.let { into.right = it }
                        attr("firstLine")?.toIntOrNull()?.let { into.first = it; into.hanging = null }
                        attr("hanging")?.toIntOrNull()?.let { into.hanging = it; into.first = null }
                    }
                    "spacing" -> {
                        attr("before")?.toIntOrNull()?.let { into.before = it }
                        attr("after")?.toIntOrNull()?.let { into.after = it }
                    }
                    "bidi" -> into.bidi = boolAttr()
                    "outlineLvl" -> attr("val")?.toIntOrNull()?.let { into.outline = it }
                    "pStyle" -> into.pStyle = attr("val")
                    "numPr" -> children { m ->
                        when (m) {
                            "ilvl" -> attr("val")?.toIntOrNull()?.let { into.ilvl = it }
                            "numId" -> attr("val")?.toIntOrNull()?.let { into.numId = it }
                        }
                    }
                }
            }
        }

        fun readStyles(part: String) {
            if (!startParsing(part)) return
            children2 {
                when (it) {
                    "docDefaults" -> children { d ->
                        when (d) {
                            "rPrDefault" -> children { x -> if (x == "rPr") readRPr(defaultRun) }
                            "pPrDefault" -> children { x -> if (x == "pPr") readPPr(defaultPara) }
                        }
                    }
                    "style" -> {
                        val id = attr("styleId")
                        val type = attr("type") ?: "paragraph"
                        val isDefault = attr("default") == "1" || attr("default") == "true"
                        var name = ""; var basedOn: String? = null
                        val pp = PPr(); val rp = RPr(); var borders = false
                        children { s ->
                            when (s) {
                                "name" -> name = attr("val") ?: ""
                                "basedOn" -> basedOn = attr("val")
                                "pPr" -> readPPr(pp)
                                "rPr" -> readRPr(rp)
                                "tblPr" -> children { t -> if (t == "tblBorders") borders = anyBorder() }
                            }
                        }
                        if (id != null) {
                            val st = Style(id, name, type, basedOn)
                            st.p.overlay(pp); st.r.overlay(rp); st.tblBorders = borders
                            styles[id] = st
                            if (isDefault && type == "paragraph") defaultParaStyle = id
                        }
                    }
                }
            }
        }

        /** Walks the children of the root element (the parser is before the first tag). */
        fun children2(body: (String) -> Unit) {
            while (true) {
                val ev = p.next()
                if (ev == XmlPullParser.END_DOCUMENT) return
                if (ev == XmlPullParser.START_TAG) { children(body); return }
            }
        }

        fun anyBorder(): Boolean {
            var any = false
            children { _ -> val v = attr("val"); if (v != null && v != "nil" && v != "none") any = true }
            return any
        }

        fun chain(styleId: String?): List<Style> {
            val list = ArrayList<Style>()
            var cur = styleId?.let { styles[it] }
            var guard = 0
            while (cur != null && guard++ < 24) { list += cur; cur = cur.basedOn?.let { styles[it] } }
            list.reverse()
            return list
        }

        fun resolvePara(styleId: String?): PPr {
            val eff = defaultPara.copy()
            val id = styleId ?: defaultParaStyle
            for (s in chain(id)) eff.overlay(s.p)
            eff.pStyle = id
            return eff
        }

        /** Run properties: defaults, then the paragraph style, then the character style. */
        fun resolveRun(charStyle: String?, paraStyle: String?): RPr {
            val eff = defaultRun.copy()
            for (s in chain(paraStyle ?: defaultParaStyle)) eff.overlay(s.r)
            if (charStyle != null) for (s in chain(charStyle)) eff.overlay(s.r)
            return eff
        }

        // ---- numbering ----

        fun readNumbering(part: String) {
            if (!startParsing(part)) return
            children2 { n ->
                when (n) {
                    "abstractNum" -> {
                        val id = attr("abstractNumId")?.toIntOrNull()
                        val an = AbstractNum()
                        children { c ->
                            if (c == "lvl") {
                                val lvl = attr("ilvl")?.toIntOrNull() ?: 0
                                val nl = NumLevel()
                                children { l ->
                                    when (l) {
                                        "start" -> attr("val")?.toIntOrNull()?.let { nl.start = it }
                                        "numFmt" -> nl.fmt = attr("val") ?: "decimal"
                                        "lvlText" -> nl.text = attr("val") ?: ""
                                        "pPr" -> { val pp = PPr(); readPPr(pp); nl.left = pp.left; nl.hanging = pp.hanging }
                                    }
                                }
                                if (lvl in 0..8) an.levels[lvl] = nl
                            }
                        }
                        if (id != null) abstractNums[id] = an
                    }
                    "num" -> {
                        val id = attr("numId")?.toIntOrNull()
                        var abs: Int? = null
                        val overrides = HashMap<Int, Int>()
                        children { c ->
                            when (c) {
                                "abstractNumId" -> abs = attr("val")?.toIntOrNull()
                                "lvlOverride" -> {
                                    val lvl = attr("ilvl")?.toIntOrNull() ?: 0
                                    children { o -> if (o == "startOverride") attr("val")?.toIntOrNull()?.let { overrides[lvl] = it } }
                                }
                            }
                        }
                        if (id != null && abs != null) nums[id] = Num(abs!!).also { it.startOverride.putAll(overrides) }
                    }
                }
            }
        }

        /** Marker text of the next item of list [numId] at level [lvl]; null when the list is unknown. */
        fun nextMarker(numId: Int, lvl: Int): Pair<String, NumLevel>? {
            val num = nums[numId] ?: return null
            val abs = abstractNums[num.abstractId] ?: return null
            val level = abs.levels.getOrNull(lvl) ?: return null
            val arr = counters.getOrPut(numId) { IntArray(9) { -1 } }
            fun startOf(k: Int) = num.startOverride[k] ?: abs.levels.getOrNull(k)?.start ?: 1
            arr[lvl] = if (arr[lvl] < 0) startOf(lvl) else arr[lvl] + 1
            for (k in lvl + 1..8) arr[k] = -1
            if (level.fmt == "bullet") return bulletOf(level.text) to level
            if (level.fmt == "none") return "" to level
            var text = level.text.ifEmpty { "%${lvl + 1}." }
            for (k in 0..lvl) {
                val ph = "%${k + 1}"
                if (!text.contains(ph)) continue
                val lv = abs.levels.getOrNull(k)
                val value = if (arr[k] < 0) startOf(k) else arr[k]
                text = text.replace(ph, formatNumber(value, lv?.fmt ?: "decimal"))
            }
            return DocHtml.sanitize(text) to level
        }

        fun bulletOf(t: String): String {
            val c = t.firstOrNull() ?: return "•"
            return when {
                c.code in 0xF000..0xF0FF -> when (c.code) { 0xF0A7 -> "▪"; 0xF0D8 -> "➢"; 0xF0FC -> "✓"; 0xF076 -> "❖"; else -> "•" }
                c == 'o' -> "◦"
                c == '§' -> "▪"
                c.isLetterOrDigit() -> "•"
                else -> t.take(2)
            }
        }

        // ---- body ----

        /** Block-level content: paragraphs, tables, content controls. */
        fun blocks(sink: Appendable) {
            children { n ->
                when (n) {
                    "p" -> paragraph(sink)
                    "tbl" -> table(sink)
                    "sdt" -> children { c -> if (c == "sdtContent") blocks(sink) }
                    "customXml", "ins", "moveTo" -> blocks(sink)
                    "del", "moveFrom" -> {}
                }
            }
        }

        fun paragraph(sink: Appendable) {
            val direct = PPr()
            val pb = ParaBuilder()
            var eff: PPr? = null
            var baseRun: RPr? = null
            fun ensure() {
                if (eff == null) {
                    val e = resolvePara(direct.pStyle)
                    e.overlay(direct)
                    eff = e
                    baseRun = resolveRun(null, direct.pStyle)
                    // A hyperlink field that began in an earlier paragraph continues here.
                    fields.lastOrNull { it.display && (it.link != null || it.linkAnchor != null) }?.let { f -> pb.openLink(linkTag(f.link, f.linkAnchor)) }
                }
            }
            children { n ->
                when (n) {
                    "pPr" -> readPPr(direct)
                    else -> { ensure(); inline(n, pb, baseRun!!) }
                }
            }
            ensure()
            pb.closeLink(); pb.closeWrapper()
            emitParagraph(sink, eff!!, direct, baseRun!!, pb)
        }

        fun linkTag(href: String?, anchor: String?): String =
            if (anchor != null) "<a data-a=\"${DocHtml.escapeAttr(anchor)}\">" else "<a data-href=\"${DocHtml.escapeAttr(href ?: "")}\">"

        /** One inline child of a paragraph (the parser is on its start tag). */
        fun inline(n: String, pb: ParaBuilder, base: RPr) {
            when (n) {
                "r" -> run(pb, base)
                "hyperlink" -> {
                    val id = attr("id"); val anchor = attr("anchor")
                    val rel = id?.let { rels[it] }
                    val href = rel?.takeIf { it.external }?.target
                    val tag = when {
                        anchor != null && href == null -> linkTag(null, anchor)
                        href != null && safeHref(href) -> linkTag(href, null)
                        else -> null
                    }
                    if (tag != null) pb.openLink(tag)
                    children { c -> inline(c, pb, base) }
                    if (tag != null) pb.closeLink()
                }
                "ins", "moveTo", "smartTag", "sdtContent", "customXml", "fldSimple", "bdo", "dir", "sdt" -> children { c -> inline(c, pb, base) }
                "bookmarkStart" -> attr("name")?.let { if (!it.startsWith("_GoBack")) pb.anchors += it }
                "oMath", "oMathPara" -> { equations++; val t = mathText(); val h = StringBuilder(); DocHtml.escape(t, h); pb.addRun("", "", h, t) }
                "AlternateContent" -> {
                    var used = false
                    children { c -> if (c == "Choice" && !used) { used = true; children { x -> inline(x, pb, base) } } }
                }
            }
        }

        /** The text of an equation, flattened (its structure is not drawn). */
        fun mathText(): String {
            val sb = StringBuilder()
            val d = p.depth
            while (true) {
                val ev = p.next()
                if (ev == XmlPullParser.END_DOCUMENT) break
                if (ev == XmlPullParser.END_TAG && p.depth == d) break
                if (ev == XmlPullParser.START_TAG && p.name == "t") sb.append(DocHtml.sanitize(p.nextText()))
            }
            return sb.toString()
        }

        fun safeHref(h: String): Boolean {
            val l = h.trim().lowercase(Locale.ROOT)
            return l.startsWith("http://") || l.startsWith("https://") || l.startsWith("mailto:") || l.startsWith("tel:")
        }

        fun run(pb: ParaBuilder, base: RPr) {
            val direct = RPr()
            val rh = StringBuilder()
            val rt = StringBuilder()
            runContent(direct, rh, rt, pb)
            if (direct.vanish == true) return
            // The paragraph's own run formatting, then the character style, then the run's direct formatting.
            val merged = base.copy()
            direct.rStyle?.let { id -> for (st in chain(id)) merged.overlay(st.r) }
            merged.overlay(direct)
            if (merged.vanish == true) return
            val (o, c) = wrapperFor(merged, base, hasRtl(rt))
            pb.addRun(o, c, rh, rt)
        }

        fun runContent(direct: RPr, rh: StringBuilder, rt: StringBuilder, pb: ParaBuilder) {
            children { n ->
                when (n) {
                    "rPr" -> readRPr(direct)
                    "t" -> { val s = DocHtml.sanitize(p.nextText()); if (!inFieldInstruction()) { rt.append(s); DocHtml.escape(s, rh) } }
                    "tab", "ptab" -> if (!inFieldInstruction()) { rt.append('\t'); rh.append('\t') }
                    "br", "cr" -> if (attr("type") != "page" && !inFieldInstruction()) { rt.append('\n'); rh.append('\n') }
                    "noBreakHyphen" -> { rt.append('‑'); rh.append('‑') }
                    "instrText" -> fields.lastOrNull()?.let { f -> if (!f.display) f.instr.append(p.nextText()) }
                    "fldChar" -> fieldChar(attr("fldCharType"), pb)
                    "drawing" -> drawing(rh, pb)
                    "pict", "object" -> pict(rh, pb)
                    "footnoteReference", "endnoteReference" -> footnoteRefs++
                    "AlternateContent" -> {
                        var used = false
                        children { c -> if (c == "Choice" && !used) { used = true; runContentInto(rh, rt, pb, direct) } }
                    }
                }
            }
        }

        fun runContentInto(rh: StringBuilder, rt: StringBuilder, pb: ParaBuilder, direct: RPr) = runContent(direct, rh, rt, pb)

        fun inFieldInstruction(): Boolean = fields.lastOrNull()?.let { !it.display } ?: false

        fun fieldChar(type: String?, pb: ParaBuilder) {
            when (type) {
                "begin" -> fields += FieldState()
                "separate" -> fields.lastOrNull()?.let { f ->
                    f.display = true
                    val instr = f.instr.toString().trim()
                    if (instr.startsWith("HYPERLINK", ignoreCase = true)) {
                        val anchor = Regex("\\\\l\\s+\"([^\"]+)\"").find(instr)?.groupValues?.get(1)
                        val href = Regex("^HYPERLINK\\s+\"([^\"]+)\"", RegexOption.IGNORE_CASE).find(instr)?.groupValues?.get(1)
                        if (anchor != null) { f.linkAnchor = anchor; pb.openLink(linkTag(null, anchor)) }
                        else if (href != null && safeHref(href)) { f.link = href; pb.openLink(linkTag(href, null)) }
                    }
                }
                "end" -> if (fields.isNotEmpty()) {
                    val f = fields.removeAt(fields.size - 1)
                    if (f.link != null || f.linkAnchor != null) pb.closeLink()
                }
            }
        }

        fun hasRtl(s: CharSequence): Boolean {
            var i = 0
            while (i < s.length) {
                val c = s[i]
                if (c.code >= 0x0590) {
                    val d = Character.getDirectionality(c)
                    if (d == Character.DIRECTIONALITY_RIGHT_TO_LEFT || d == Character.DIRECTIONALITY_RIGHT_TO_LEFT_ARABIC) return true
                }
                i++
            }
            return false
        }

        // ---- images ----

        fun drawing(rh: StringBuilder, pb: ParaBuilder) {
            var cx = 0L
            var alt: String? = null
            val embeds = ArrayList<String>()
            val d = p.depth
            while (true) {
                val ev = p.next()
                if (ev == XmlPullParser.END_DOCUMENT) break
                if (ev == XmlPullParser.END_TAG && p.depth == d) break
                if (ev == XmlPullParser.START_TAG) {
                    when (p.name) {
                        "extent" -> if (cx == 0L) cx = attr("cx")?.toLongOrNull() ?: 0L
                        "docPr" -> if (alt == null) alt = attr("descr") ?: attr("title")
                        "blip" -> (attr("embed") ?: attr("link"))?.let { embeds += it }
                        "txbx" -> { textBoxes++; skipTo(p.depth) }
                    }
                }
            }
            for ((k, id) in embeds.withIndex()) emitImage(rh, pb, id, if (k == 0 && embeds.size == 1) cx else 0L, alt)
        }

        fun pict(rh: StringBuilder, pb: ParaBuilder) {
            val embeds = ArrayList<String>()
            val d = p.depth
            while (true) {
                val ev = p.next()
                if (ev == XmlPullParser.END_DOCUMENT) break
                if (ev == XmlPullParser.END_TAG && p.depth == d) break
                if (ev == XmlPullParser.START_TAG) {
                    when (p.name) {
                        "imagedata" -> attr("id")?.let { embeds += it }
                        "textbox" -> { textBoxes++; skipTo(p.depth) }
                    }
                }
            }
            for (id in embeds) emitImage(rh, pb, id, 0L, null)
        }

        fun emitImage(rh: StringBuilder, pb: ParaBuilder, relId: String, cxEmu: Long, alt: String?) {
            val rel = rels[relId] ?: return
            if (rel.external) return
            val path = resolve(docDir, rel.target)
            val mime = IMAGE_TYPES[path.substringAfterLast('.', "").lowercase(Locale.ROOT)]
            if (mime == null || zip.getEntry(path) == null) { unsupportedImages++; return }
            val idx = imageIndex.getOrPut(path) { images += DocImage(path, mime); images.size - 1 }
            rh.append("<img src=\"/m/").append(idx).append("\" alt=\"").append(DocHtml.escapeAttr(alt ?: "").take(300)).append('"')
            if (cxEmu > 0) rh.append(" style=\"width:").append((cxEmu / 9525L).coerceIn(8L, 4000L)).append("px\"")
            rh.append('>')
            pb.hasImage = true
        }

        // ---- formatting ----

        fun fontFor(r: RPr, rtl: Boolean): String? = if (rtl) (r.fontCs ?: r.fontLatin) else (r.fontLatin ?: r.fontCs)

        /** Opening and closing markup for a run with properties [r]; [base] is the paragraph's own run formatting. */
        fun wrapperFor(r: RPr, base: RPr, rtl: Boolean): Pair<String, String> {
            val open = StringBuilder()
            val close = StringBuilder()
            val style = StringBuilder()
            var cls = ""
            val baseSz = base.sz
            r.sz?.let { sz ->
                val ratio = sz.toDouble() / (baseSz ?: (basePt * 2).toInt())
                if (Math.abs(ratio - 1.0) >= 0.03) style.append("font-size:").append(fmt(ratio.coerceIn(0.4, 5.0))).append("em;")
            }
            r.color?.let { style.append("color:#").append(it).append(';'); cls = "dc" }
            (r.highlight ?: r.shd)?.let { style.append("background:#").append(it).append(';'); cls = "dc" }
            if (r.caps == true) style.append("text-transform:uppercase;")
            if (r.smallCaps == true) style.append("font-variant:small-caps;")
            fontFor(r, rtl)?.let { f -> cssFont(f)?.let { stack -> style.append("--ff:").append(stack).append(';'); cls = if (cls.isEmpty()) "f" else "$cls f" } }
            if (style.isNotEmpty() || cls.isNotEmpty()) {
                open.append("<span")
                if (cls.isNotEmpty()) open.append(" class=\"").append(cls).append('"')
                if (style.isNotEmpty()) open.append(" style=\"").append(style).append('"')
                open.append('>')
                close.insert(0, "</span>")
            }
            fun tag(on: Boolean?, t: String) { if (on == true) { open.append('<').append(t).append('>'); close.insert(0, "</$t>") } }
            tag(r.b, "b"); tag(r.i, "i"); tag(r.u, "u"); tag(r.strike, "s")
            when (r.vert) { "superscript" -> tag(true, "sup"); "subscript" -> tag(true, "sub") }
            return open.toString() to close.toString()
        }

        fun fmt(d: Double): String = String.format(Locale.ROOT, "%.2f", d)

        fun cssFont(name: String): String? {
            val clean = name.filter { it.isLetterOrDigit() || it == ' ' || it == '-' || it == '_' || it == '.' }.trim().take(60)
            if (clean.isEmpty()) return null
            val l = clean.lowercase(Locale.ROOT)
            val generic = when {
                MONO.any { l.contains(it) } -> "monospace"
                SERIF.any { l.contains(it) } -> "serif"
                else -> "sans-serif"
            }
            return "'$clean',$generic"
        }

        // ---- paragraph output ----

        fun emitParagraph(sink: Appendable, eff: PPr, direct: PPr, baseRun: RPr, pb: ParaBuilder) {
            if (suppress > 0) return
            val text = pb.text.toString()
            // list marker
            val numId = eff.numId
            val mk = if (numId != null && numId > 0) nextMarker(numId, (eff.ilvl ?: 0).coerceIn(0, 8)) else null
            val marker: String? = mk?.first
            val level: NumLevel? = mk?.second

            val styleName = eff.pStyle?.let { styles[it]?.name }?.lowercase(Locale.ROOT).orEmpty()
            val isTitle = styleName == "title" || styleName == "subtitle"
            val named = HEADING_RE.find(styleName)?.groupValues?.get(1)?.toIntOrNull()
            val headingLevel: Int? = (named ?: if (isTitle) null else eff.outline?.takeIf { it in 0..5 }?.let { it + 1 })?.coerceAtMost(6)

            val hasContent = text.isNotEmpty() || pb.hasImage || !marker.isNullOrEmpty()
            if (!hasContent) {
                // An empty paragraph is only vertical space, not a block; long runs of them collapse.
                for (a in pb.anchors) anchors.putIfAbsent(a, texts.size)
                if (emptyRun++ < 3) sink.append("<div class=\"sp\"></div>")
                return
            }
            emptyRun = 0

            val index = texts.size
            texts += text
            for (a in pb.anchors) anchors.putIfAbsent(a, index)

            val strongRtl = hasRtl(text)
            val rtl = when {
                eff.bidi == true -> true
                strongRtl -> true
                text.any { Character.isLetter(it) } -> false
                else -> lastRtl
            }
            lastRtl = rtl
            if (text.length > 2) { if (rtl) rtlBlocks++ else ltrBlocks++ }

            val tag = headingLevel?.let { "h$it" } ?: "p"
            val cls = StringBuilder("b")
            if (headingLevel != null) cls.append(" hd")
            if (isTitle) cls.append(" doctitle")
            if (marker != null) cls.append(" li")
            val style = StringBuilder()
            when (eff.jc) {
                "center" -> style.append("text-align:center;")
                "both", "distribute", "thaiDistribute" -> style.append("text-align:justify;")
                "right", "end" -> style.append("text-align:end;")
                "left", "start" -> style.append("text-align:start;")
            }
            // Own paragraph size: a run is sized relative to it (see wrapperFor).
            baseRun.sz?.let { sz -> val ratio = sz / 2.0 / basePt; if (Math.abs(ratio - 1.0) >= 0.03) style.append("font-size:").append(fmt(ratio.coerceIn(0.4, 5.0))).append("em;") }
            val lv = level
            val left = (if (direct.left != null) eff.left else null) ?: lv?.left ?: eff.left
            val hanging = if (direct.hanging != null || direct.first != null) eff.hanging else lv?.hanging ?: eff.hanging
            val first = if (direct.hanging != null || direct.first != null) eff.first else if (lv != null) null else eff.first
            if (left != null && left > 0) style.append("margin-inline-start:min(").append(left / 20).append("pt,35vw);")
            eff.right?.takeIf { it > 0 }?.let { style.append("margin-inline-end:min(").append(it / 20).append("pt,25vw);") }
            val textIndent = when { hanging != null && hanging > 0 -> -hanging; first != null && first != 0 -> first; else -> null }
            if (textIndent != null) style.append("text-indent:").append(textIndent / 20).append("pt;")
            eff.before?.takeIf { it > 0 }?.let { style.append("margin-top:").append(fmt((it / 20.0 / basePt).coerceAtMost(3.0))).append("em;") }
            eff.after?.let { style.append("margin-bottom:").append(fmt((it / 20.0 / basePt).coerceIn(0.0, 3.0))).append("em;") }

            sink.append('<').append(tag).append(" class=\"").append(cls).append("\" dir=\"").append(if (rtl) "rtl" else "ltr")
                .append("\" data-i=\"").append(index.toString()).append('"')
            marker?.let { m -> if (m.isNotEmpty()) sink.append(" data-m=\"").append(DocHtml.escapeAttr(m)).append('"') }
            if (style.isNotEmpty()) sink.append(" style=\"").append(style).append('"')
            sink.append('>').append(pb.html).append("</").append(tag).append('>')

            if (headingLevel != null || isTitle) {
                val t = text.trim()
                if (t.isNotEmpty()) outline += DocOutline(t.take(120).replace('\n', ' '), if (isTitle) 1 else headingLevel ?: 1, index)
            }
        }

        // ---- tables ----

        fun table(sink: Appendable) {
            var borders = false
            var bidi = false
            val grid = ArrayList<Int>()
            val rows = ArrayList<ArrayList<CellOut>>()
            children { n ->
                when (n) {
                    "tblPr" -> children { c ->
                        when (c) {
                            "tblStyle" -> if (attr("val")?.let { styles[it]?.tblBorders } == true) borders = true
                            "tblBorders" -> if (anyBorder()) borders = true
                            "bidiVisual" -> bidi = boolAttr()
                        }
                    }
                    "tblGrid" -> children { c -> if (c == "gridCol") grid += attr("w")?.toIntOrNull() ?: 0 }
                    "tr" -> rows += row()
                }
            }
            if (rows.isEmpty()) return
            // vertical merges: a restart cell spans the continue cells below it in the same grid column
            for (r in rows.indices) for (cell in rows[r]) if (cell.vMerge == 1) {
                var span = 1
                var rr = r + 1
                while (rr < rows.size) {
                    rows[rr].firstOrNull { it.gridCol == cell.gridCol && it.vMerge == 2 } ?: break
                    span++; rr++
                }
                cell.rowSpan = span
            }
            sink.append("<div class=\"tw\"><table class=\"t").append(if (borders) " bd" else "").append('"')
            if (bidi) sink.append(" dir=\"rtl\"")
            sink.append('>')
            val total = grid.sum()
            if (grid.size >= 2 && total > 0) {
                sink.append("<colgroup>")
                for (w in grid) sink.append("<col style=\"width:").append(fmt(w * 100.0 / total)).append("%\">")
                sink.append("</colgroup>")
            }
            for (row in rows) {
                sink.append("<tr>")
                for (cell in row) {
                    if (cell.vMerge == 2) continue
                    sink.append("<td")
                    if (cell.colSpan > 1) sink.append(" colspan=\"").append(cell.colSpan.toString()).append('"')
                    if (cell.rowSpan > 1) sink.append(" rowspan=\"").append(cell.rowSpan.toString()).append('"')
                    if (cell.fill != null) sink.append(" class=\"dc\" style=\"background:#").append(cell.fill).append("\"")
                    sink.append('>').append(cell.html).append("</td>")
                }
                sink.append("</tr>")
            }
            sink.append("</table></div>")
        }

        fun row(): ArrayList<CellOut> {
            val cells = ArrayList<CellOut>()
            var col = 0
            children { n -> if (n == "tc") { val c = cell(col); cells += c; col += c.colSpan.coerceAtLeast(1) } }
            return cells
        }

        fun cell(gridCol: Int): CellOut {
            var span = 1
            var vMerge = 0
            var fill: String? = null
            val sb = StringBuilder()
            children { n ->
                when (n) {
                    "tcPr" -> children { c ->
                        when (c) {
                            "gridSpan" -> attr("val")?.toIntOrNull()?.let { span = it.coerceIn(1, 64) }
                            "vMerge" -> vMerge = if (attr("val") == "restart") 1 else 2
                            "shd" -> attr("fill")?.takeIf { hex(it) }?.let { fill = it.uppercase(Locale.ROOT) }
                        }
                    }
                    "p" -> { if (vMerge == 2) suppress++; try { paragraph(sb) } finally { if (vMerge == 2) suppress-- } }
                    "tbl" -> { if (vMerge == 2) suppress++; try { table(sb) } finally { if (vMerge == 2) suppress-- } }
                    "sdt" -> children { c -> if (c == "sdtContent") blocks(sb) }
                }
            }
            return CellOut(sb.toString(), span, vMerge, fill, gridCol)
        }

        fun hex(s: String) = s.length == 6 && s.all { it in '0'..'9' || it in 'a'..'f' || it in 'A'..'F' }
    }

    private class LimitedStream(ins: InputStream, private val limit: Long) : FilterInputStream(ins) {
        private var count = 0L
        override fun read(): Int { val b = super.read(); if (b >= 0 && ++count > limit) throw DocxException(DocxException.Reason.TOO_LARGE, "XML too large"); return b }
        override fun read(b: ByteArray, off: Int, len: Int): Int {
            val n = super.read(b, off, len)
            if (n > 0) { count += n; if (count > limit) throw DocxException(DocxException.Reason.TOO_LARGE, "XML too large") }
            return n
        }
    }

    companion object {
        const val MAX_XML_BYTES = 160L * 1024 * 1024

        private val HIGHLIGHT = mapOf(
            "yellow" to "FFFF00", "green" to "00FF00", "cyan" to "00FFFF", "magenta" to "FF00FF", "blue" to "0000FF", "red" to "FF0000",
            "darkBlue" to "000080", "darkCyan" to "008080", "darkGreen" to "008000", "darkMagenta" to "800080", "darkRed" to "800000",
            "darkYellow" to "808000", "darkGray" to "808080", "lightGray" to "C0C0C0", "black" to "000000", "white" to "FFFFFF",
        )

        private val IMAGE_TYPES = mapOf(
            "png" to "image/png", "jpg" to "image/jpeg", "jpeg" to "image/jpeg", "gif" to "image/gif", "bmp" to "image/bmp",
            "webp" to "image/webp", "svg" to "image/svg+xml",
        )

        private val HEADING_RE = Regex("^heading\\s*([1-9])$")
        private val MONO = listOf("courier", "consolas", "mono", "menlo", "monaco", "lucida console", "terminal")
        private val SERIF = listOf(
            "times", "georgia", "cambria", "garamond", "palatino", "book antiqua", "bookman", "century", "constantia", "sylfaen",
            "minion", "baskerville", "didot", "traditional arabic", "amiri", "lora", "nazanin", "lotus", "mitra", "zar", "titr",
        )

        fun formatNumber(n: Int, fmt: String): String = when (fmt) {
            "decimalZero" -> if (n < 10) "0$n" else n.toString()
            "lowerLetter" -> letters(n, false)
            "upperLetter" -> letters(n, true)
            "lowerRoman" -> roman(n).lowercase(Locale.ROOT)
            "upperRoman" -> roman(n)
            else -> n.toString()
        }

        private fun letters(n: Int, upper: Boolean): String {
            var v = n.coerceAtLeast(1)
            val sb = StringBuilder()
            while (v > 0) { v--; sb.append(('a' + v % 26)); v /= 26 }
            val s = sb.reverse().toString()
            return if (upper) s.uppercase(Locale.ROOT) else s
        }

        private fun roman(n: Int): String {
            if (n <= 0 || n >= 4000) return n.toString()
            val vals = intArrayOf(1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1)
            val syms = arrayOf("M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I")
            var v = n
            val sb = StringBuilder()
            for (i in vals.indices) while (v >= vals[i]) { sb.append(syms[i]); v -= vals[i] }
            return sb.toString()
        }
    }
}
