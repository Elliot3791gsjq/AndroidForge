package com.novelreader.app.ui.library

import android.text.format.DateUtils
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.novelreader.app.R
import com.novelreader.app.data.BookEntity
import com.novelreader.app.data.LibrarySort
import com.novelreader.app.ui.AppIcons
import com.novelreader.app.ui.Localized
import com.novelreader.app.ui.design.AccentButton
import com.novelreader.app.ui.design.AppCard
import com.novelreader.app.ui.design.AppChip
import com.novelreader.app.ui.design.AppDialog
import com.novelreader.app.ui.design.AppDropdownMenu
import com.novelreader.app.ui.design.AppMenuItem
import com.novelreader.app.ui.design.AppProgressBar
import com.novelreader.app.ui.design.AppSheet
import com.novelreader.app.ui.design.AppTextField
import com.novelreader.app.ui.design.EmptyState
import com.novelreader.app.ui.design.GhostButton
import com.novelreader.app.ui.design.MutedText
import com.novelreader.app.ui.design.ScreenHeader
import com.novelreader.app.ui.design.SectionLabel
import com.novelreader.app.ui.design.SoftIconButton
import com.novelreader.app.ui.design.bottomClearance
import com.novelreader.app.ui.files.ImagePickerHost
import com.novelreader.app.ui.design.Space
import com.novelreader.app.ui.design.appClickable
import com.novelreader.app.ui.design.motion
import com.novelreader.app.ui.design.palette
import com.novelreader.app.ui.home.sharedCover

/** Source tags for the shared cover transition (a book can be on screen twice: hero card and grid). */
const val SOURCE_HERO = "hero"
const val SOURCE_GRID = "grid"

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun LibraryScreen(
    vm: LibraryViewModel,
    onOpenBook: (Long) -> Unit,
    onOpenDetail: (Long, String) -> Unit,
    onPickBooks: () -> Unit,
    onPickFolder: () -> Unit,
) {
    val books by vm.books.collectAsState()
    val total by vm.total.collectAsState()
    val query by vm.queryText.collectAsState()
    val sort by vm.sort.collectAsState()
    val grid by vm.grid.collectAsState()
    val importing by vm.importing.collectAsState()
    val loaded by vm.loaded.collectAsState()
    val filter by vm.filterState.collectAsState()
    val continueBook by vm.continueBook.collectAsState()
    val categories by vm.categories.collectAsState()
    val links by vm.categoryLinks.collectAsState()
    val allBooks by vm.allBooks.collectAsState()
    val categoryId by vm.categoryFilterState.collectAsState()
    val progress by vm.importProgress.collectAsState()

    var sortMenu by remember { mutableStateOf(false) }
    var addMenu by remember { mutableStateOf(false) }
    var actionBook by remember { mutableStateOf<BookEntity?>(null) }
    var confirmDelete by remember { mutableStateOf<BookEntity?>(null) }
    var newCategory by remember { mutableStateOf<Long?>(null) }          // -1 = plain "new category", >= 0 = also tick this book
    var categoryActions by remember { mutableStateOf<Long?>(null) }
    var chooseBooksFor by remember { mutableStateOf<Long?>(null) }
    var renameCategory by remember { mutableStateOf<Long?>(null) }
    var deleteCategory by remember { mutableStateOf<Long?>(null) }
    var categoriesOfBook by remember { mutableStateOf<Long?>(null) }
    var coverFor by remember { mutableStateOf<Long?>(null) }
    val p = palette
    val reduce = motion.reduce

    Box(Modifier.fillMaxSize()) {
        when {
            !loaded -> CircularProgressIndicator(Modifier.align(Alignment.Center), color = p.accent)
            total == 0 -> Column(Modifier.fillMaxSize()) {
                ScreenHeader(stringResource(R.string.library))
                Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        EmptyState(
                            icon = AppIcons.MenuBook,
                            title = stringResource(R.string.empty_title),
                            body = stringResource(R.string.empty_hint),
                        )
                        AccentButton(stringResource(R.string.add_menu_book), onPickBooks, icon = AppIcons.LibraryAdd)
                        Spacer(Modifier.height(Space.s))
                        GhostButton(stringResource(R.string.add_menu_folder), onPickFolder, icon = AppIcons.CreateNewFolder)
                    }
                }
            }
            else -> LazyVerticalGrid(
                columns = if (grid) GridCells.Adaptive(150.dp) else GridCells.Fixed(1),
                contentPadding = PaddingValues(start = Space.gutter, end = Space.gutter, bottom = bottomClearance()),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(if (grid) 20.dp else 12.dp),
                modifier = Modifier.fillMaxSize(),
            ) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    ScreenHeader(
                        title = stringResource(R.string.library),
                        subtitle = stringResource(R.string.books_count, Localized.number(total)),
                        horizontalPadding = 0.dp,
                    ) {
                        Box {
                            SoftIconButton(AppIcons.Sort, stringResource(R.string.sort), { sortMenu = true })
                            AppDropdownMenu(sortMenu, { sortMenu = false }) {
                                listOf(
                                    LibrarySort.LAST_READ to R.string.sort_last_read,
                                    LibrarySort.TITLE to R.string.sort_title,
                                    LibrarySort.ADDED to R.string.sort_added,
                                ).forEach { (s, label) ->
                                    AppMenuItem(stringResource(label), onClick = { vm.setSort(s); sortMenu = false }, selected = s == sort)
                                }
                            }
                        }
                        SoftIconButton(
                            if (grid) AppIcons.ViewList else AppIcons.GridView,
                            stringResource(if (grid) R.string.view_list else R.string.view_grid),
                            { vm.setGrid(!grid) },
                        )
                        Box {
                            SoftIconButton(Icons.Default.Add, stringResource(R.string.add_book), { addMenu = true }, selected = true)
                            AppDropdownMenu(addMenu, { addMenu = false }) {
                                AddMenuItem(AppIcons.CreateNewFolder, stringResource(R.string.add_menu_folder), stringResource(R.string.add_menu_folder_hint)) {
                                    addMenu = false; onPickFolder()
                                }
                                AddMenuItem(AppIcons.LibraryAdd, stringResource(R.string.add_menu_book), stringResource(R.string.add_menu_book_hint)) {
                                    addMenu = false; onPickBooks()
                                }
                            }
                        }
                    }
                }
                item(span = { GridItemSpan(maxLineSpan) }) {
                    AppTextField(
                        value = query,
                        onValueChange = vm::setQuery,
                        placeholder = stringResource(R.string.search_books),
                        leadingIcon = Icons.Default.Search,
                        trailing = if (query.isNotEmpty()) {
                            { SoftIconButton(Icons.Default.Clear, stringResource(R.string.clear), { vm.setQuery("") }, size = 32.dp, filled = false) }
                        } else null,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Row(
                        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 2.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        listOf(
                            LibraryFilter.ALL to R.string.filter_all,
                            LibraryFilter.READING to R.string.filter_reading,
                            LibraryFilter.UNREAD to R.string.filter_new,
                            LibraryFilter.FINISHED to R.string.filter_finished,
                            LibraryFilter.FAVORITES to R.string.filter_favorites,
                        ).forEach { (f, label) ->
                            AppChip(stringResource(label), selected = categoryId == null && filter == f, onClick = { vm.setFilter(f) })
                        }
                        categories.forEach { c ->
                            CategoryChip(c.name, selected = categoryId == c.id, onClick = { vm.setCategoryFilter(c.id) }, onLongClick = { categoryActions = c.id })
                        }
                        NewCategoryChip { newCategory = -1L }
                    }
                }
                val hero = continueBook
                if (hero != null && filter == LibraryFilter.ALL && categoryId == null && query.isBlank()) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        ContinueCard(
                            book = hero, vm = vm,
                            onContinue = { onOpenBook(hero.id) },
                            onDetail = { onOpenDetail(hero.id, SOURCE_HERO) },
                        )
                    }
                }
                if (books.isNotEmpty()) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        SectionLabel(stringResource(R.string.your_books), Modifier.padding(top = Space.xs))
                    }
                }
                if (books.isEmpty()) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        Column(Modifier.fillMaxWidth().padding(vertical = 48.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                stringResource(
                                    when {
                                        query.isNotBlank() -> R.string.no_search_results
                                        categoryId != null -> R.string.category_empty
                                        else -> R.string.filter_empty
                                    }
                                ),
                                style = MaterialTheme.typography.bodyMedium,
                                color = p.textMuted,
                                textAlign = TextAlign.Center,
                            )
                            if (categoryId != null && query.isBlank()) {
                                Spacer(Modifier.height(Space.m))
                                GhostButton(stringResource(R.string.category_choose_books), { chooseBooksFor = categoryId }, icon = AppIcons.LibraryAdd)
                            }
                        }
                    }
                }
                items(books, key = { it.id }) { b ->
                    val itemMod = if (reduce) Modifier.animateItem(null, null, null) else Modifier.animateItem()
                    if (grid) {
                        GridBook(b, vm, itemMod, onClick = { onOpenDetail(b.id, SOURCE_GRID) }, onLongClick = { actionBook = b })
                    } else {
                        ListBook(b, vm, itemMod, onClick = { onOpenDetail(b.id, SOURCE_GRID) }, onLongClick = { actionBook = b })
                    }
                }
            }
        }
        if (importing) {
            Column(Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(top = 4.dp)) {
                AppProgressBarIndeterminate()
                Text(
                    progress?.let { stringResource(R.string.import_progress, it.done + 1, it.total) } ?: stringResource(R.string.importing),
                    modifier = Modifier.padding(8.dp).align(Alignment.CenterHorizontally),
                    style = MaterialTheme.typography.labelMedium,
                    color = p.textMuted,
                )
            }
        }
    }

    actionBook?.let { book ->
        AppSheet(onDismiss = { actionBook = null }) {
            Column(Modifier.padding(horizontal = Space.gutter).padding(bottom = Space.xxl).navigationBarsPadding()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    BookCover(book.title, vm.coverFile(book), Modifier.width(48.dp).aspectRatio(2f / 3f), elevation = 4.dp)
                    Column(Modifier.padding(start = Space.m)) {
                        Text(book.title, style = MaterialTheme.typography.titleMedium, color = p.text, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        book.author?.let { MutedText(it, maxLines = 1) }
                    }
                }
                Spacer(Modifier.height(Space.l))
                AccentButton(stringResource(R.string.open), { onOpenBook(book.id); actionBook = null }, Modifier.fillMaxWidth())
                Spacer(Modifier.height(Space.s))
                GhostButton(
                    stringResource(if (book.favorite) R.string.favorite_remove else R.string.favorite_add),
                    { vm.setFavorite(book.id, !book.favorite); actionBook = null },
                    Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(Space.s))
                GhostButton(
                    stringResource(R.string.book_categories),
                    { categoriesOfBook = book.id; actionBook = null },
                    Modifier.fillMaxWidth(), icon = AppIcons.Label,
                )
                Spacer(Modifier.height(Space.s))
                GhostButton(
                    stringResource(R.string.cover_change),
                    { coverFor = book.id; actionBook = null },
                    Modifier.fillMaxWidth(), icon = AppIcons.AddPhoto,
                )
                Spacer(Modifier.height(Space.s))
                GhostButton(stringResource(R.string.remove_from_library), { vm.removeFromLibrary(book.id); actionBook = null }, Modifier.fillMaxWidth())
                Spacer(Modifier.height(Space.s))
                GhostButton(
                    stringResource(R.string.delete_with_data),
                    { confirmDelete = book; actionBook = null },
                    Modifier.fillMaxWidth(), destructive = true,
                )
                MutedText(stringResource(R.string.book_actions_hint), Modifier.padding(top = Space.m))
            }
        }
    }
    confirmDelete?.let { book ->
        AppDialog(
            onDismissRequest = { confirmDelete = null },
            title = { Text(stringResource(R.string.delete_with_data)) },
            text = { Text(stringResource(R.string.delete_with_data_message, book.title)) },
            confirmButton = {
                TextButton(onClick = { vm.deleteCompletely(book.id); confirmDelete = null }) {
                    Text(stringResource(R.string.delete), color = p.danger)
                }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = null }) { Text(stringResource(R.string.cancel)) } },
        )
    }

    // ---- Categories ----
    newCategory?.let { bookToTick ->
        CategoryNameDialog(
            title = stringResource(R.string.category_new),
            initial = "",
            confirmLabel = stringResource(R.string.category_create),
            onDismiss = { newCategory = null },
            onConfirm = { name ->
                newCategory = null
                vm.createCategory(name) { id ->
                    if (bookToTick >= 0) {
                        vm.setBookInCategory(bookToTick, id, true)
                    } else {
                        // A fresh category: show it and let the user tick its books right away.
                        vm.setCategoryFilter(id)
                        chooseBooksFor = id
                    }
                }
            },
        )
    }
    categoryActions?.let { id ->
        categories.firstOrNull { it.id == id }?.let { c ->
            CategoryActionsSheet(
                category = c,
                onChooseBooks = { chooseBooksFor = id; categoryActions = null },
                onRename = { renameCategory = id; categoryActions = null },
                onDelete = { deleteCategory = id; categoryActions = null },
                onDismiss = { categoryActions = null },
            )
        }
    }
    chooseBooksFor?.let { id ->
        categories.firstOrNull { it.id == id }?.let { c ->
            CategoryBooksSheet(
                category = c, books = allBooks.filter { it.inLibrary }, links = links,
                coverOf = { vm.coverFile(it) },
                onToggle = { bookId, member -> vm.setBookInCategory(bookId, id, member) },
                onDismiss = { chooseBooksFor = null },
            )
        }
    }
    renameCategory?.let { id ->
        categories.firstOrNull { it.id == id }?.let { c ->
            CategoryNameDialog(
                title = stringResource(R.string.category_rename),
                initial = c.name,
                confirmLabel = stringResource(R.string.save),
                onDismiss = { renameCategory = null },
                onConfirm = { vm.renameCategory(id, it); renameCategory = null },
            )
        }
    }
    deleteCategory?.let { id ->
        categories.firstOrNull { it.id == id }?.let { c ->
            AppDialog(
                onDismissRequest = { deleteCategory = null },
                title = { Text(stringResource(R.string.category_delete)) },
                text = { Text(stringResource(R.string.category_delete_message, c.name)) },
                confirmButton = {
                    TextButton(onClick = { vm.deleteCategory(id); deleteCategory = null }) { Text(stringResource(R.string.delete), color = p.danger) }
                },
                dismissButton = { TextButton(onClick = { deleteCategory = null }) { Text(stringResource(R.string.cancel)) } },
            )
        }
    }
    categoriesOfBook?.let { bookId ->
        allBooks.firstOrNull { it.id == bookId }?.let { b ->
            BookCategoriesSheet(
                book = b, categories = categories, links = links,
                onToggle = { cid, member -> vm.setBookInCategory(bookId, cid, member) },
                onNew = { newCategory = bookId },
                onDismiss = { categoriesOfBook = null },
            )
        }
    }

    // ---- Custom cover from the phone ----
    ImagePickerHost(
        visible = coverFor != null,
        onDismiss = { coverFor = null },
        onPicked = { uri -> coverFor?.let { vm.setCustomCover(it, uri) }; coverFor = null },
    )
}

@Composable
private fun AppProgressBarIndeterminate() {
    androidx.compose.material3.LinearProgressIndicator(
        modifier = Modifier.fillMaxWidth(),
        color = palette.accent,
        trackColor = palette.surfaceHighest,
    )
}

@Composable
private fun lastReadText(book: BookEntity): String {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val at = book.lastReadAt
    // Formatted once per book change instead of on every recomposition of every visible card.
    return remember(at, ctx) {
        if (at == null) ctx.getString(R.string.not_read_yet)
        else ctx.getString(R.string.last_read, DateUtils.getRelativeTimeSpanString(at, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS).toString())
    }
}

/** "46% · Last read 2 hours ago", built once per book change (NumberFormat / DateUtils are costly per frame). */
@Composable
private fun bookMeta(book: BookEntity): String {
    val last = lastReadText(book)
    return remember(book.progress, last) { "${Localized.percent((book.progress * 100).toInt())} · $last" }
}

/** "Continue reading" hero: the most recent unfinished book with a glowing card and a primary action. */
@Composable
private fun ContinueCard(book: BookEntity, vm: LibraryViewModel, onContinue: () -> Unit, onDetail: () -> Unit) {
    val p = palette
    AppCard(Modifier.fillMaxWidth(), onClick = onDetail, shape = com.novelreader.app.ui.design.AppShapes.cardLarge) {
        Box(
            Modifier
                .fillMaxWidth()
                .drawBehind {
                    drawRect(
                        Brush.radialGradient(
                            listOf(p.accent.copy(alpha = if (p.dark) 0.22f else 0.14f), Color.Transparent),
                            center = Offset(size.width * 0.95f, 0f),
                            radius = size.width * 0.7f,
                        )
                    )
                }
        ) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                BookCover(
                    book.title, vm.coverFile(book),
                    Modifier.width(104.dp).aspectRatio(2f / 3f).sharedCover("cover-$SOURCE_HERO-${book.id}"),
                    elevation = 14.dp,
                )
                Column(Modifier.weight(1f).padding(start = 16.dp)) {
                    Text(
                        stringResource(R.string.continue_reading).uppercase(),
                        style = MaterialTheme.typography.labelSmall, color = p.accentText,
                    )
                    Text(
                        book.title, style = MaterialTheme.typography.headlineSmall, color = p.text,
                        maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp),
                    )
                    book.author?.let { MutedText(it, maxLines = 1) }
                    Spacer(Modifier.height(12.dp))
                    AppProgressBar(book.progress.toFloat())
                    Text(
                        Localized.percent((book.progress * 100).toInt()),
                        style = MaterialTheme.typography.labelMedium, color = p.textMuted,
                        modifier = Modifier.padding(top = 4.dp, bottom = 10.dp),
                    )
                    AccentButton(stringResource(R.string.continue_action), onContinue, height = 40.dp)
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun GridBook(book: BookEntity, vm: LibraryViewModel, modifier: Modifier, onClick: () -> Unit, onLongClick: () -> Unit) {
    val p = palette
    Column(modifier.appClickable(onClick, onLongClick = onLongClick, role = null, scaleTo = 0.97f)) {
        Box {
            BookCover(
                book.title, vm.coverFile(book),
                Modifier.fillMaxWidth().aspectRatio(2f / 3f).sharedCover("cover-$SOURCE_GRID-${book.id}"),
            )
            FormatBadge(book.format, Modifier.align(Alignment.TopStart).padding(8.dp))
            if (book.favorite) {
                Box(
                    Modifier.align(Alignment.TopEnd).padding(8.dp).size(28.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.55f)),
                    contentAlignment = Alignment.Center,
                ) { Icon(AppIcons.Heart, null, tint = p.accent, modifier = Modifier.size(16.dp)) }
            }
        }
        Text(
            book.title, maxLines = 2, overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.titleSmall, color = p.text, modifier = Modifier.padding(top = 10.dp),
        )
        book.author?.let { MutedText(it, maxLines = 1) }
        MutedText(bookInfoLine(book), maxLines = 1)
        AppProgressBar(book.progress.toFloat(), Modifier.padding(top = 8.dp), height = 4.dp)
        Text(
            bookMeta(book),
            style = MaterialTheme.typography.labelSmall, color = p.textMuted,
            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp),
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ListBook(book: BookEntity, vm: LibraryViewModel, modifier: Modifier, onClick: () -> Unit, onLongClick: () -> Unit) {
    val p = palette
    AppCard(modifier.fillMaxWidth(), onClick = onClick, onLongClick = onLongClick) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            BookCover(
                book.title, vm.coverFile(book),
                Modifier.width(60.dp).aspectRatio(2f / 3f).sharedCover("cover-$SOURCE_GRID-${book.id}"),
                elevation = 6.dp,
            )
            Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        book.title, maxLines = 2, overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.titleSmall, color = p.text, modifier = Modifier.weight(1f),
                    )
                    if (book.favorite) Icon(AppIcons.Heart, null, tint = p.accent, modifier = Modifier.padding(start = 6.dp).size(16.dp))
                }
                book.author?.let { MutedText(it, maxLines = 1) }
                MutedText(bookInfoLine(book), maxLines = 1)
                AppProgressBar(book.progress.toFloat(), Modifier.padding(top = 8.dp), height = 4.dp)
                Text(
                    bookMeta(book),
                    style = MaterialTheme.typography.labelSmall, color = p.textMuted,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp),
                )
            }
        }
    }
}


@Composable
private fun AddMenuItem(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, hint: String, onClick: () -> Unit) {
    val p = palette
    DropdownMenuItem(
        text = {
            Column {
                Text(title, style = MaterialTheme.typography.titleSmall, color = p.text)
                Text(hint, style = MaterialTheme.typography.labelSmall, color = p.textMuted, modifier = Modifier.widthIn(max = 220.dp))
            }
        },
        leadingIcon = { Icon(icon, contentDescription = null, tint = p.accentText, modifier = Modifier.size(22.dp)) },
        onClick = onClick,
    )
}
