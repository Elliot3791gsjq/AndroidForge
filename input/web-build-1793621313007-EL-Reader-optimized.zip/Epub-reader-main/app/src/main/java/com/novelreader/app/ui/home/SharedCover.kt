@file:OptIn(androidx.compose.animation.ExperimentalSharedTransitionApi::class)

package com.novelreader.app.ui.home

import androidx.compose.animation.AnimatedVisibilityScope
import androidx.compose.animation.SharedTransitionScope
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.Modifier
import com.novelreader.app.ui.design.motion

/** The enclosing shared-transition layout, provided by [AppRoot]; null when a screen is shown on its own. */
val LocalSharedTransitionScope = compositionLocalOf<SharedTransitionScope?> { null }

/** The visibility scope of the destination currently being composed (library or book detail). */
val LocalContentVisibilityScope = compositionLocalOf<AnimatedVisibilityScope?> { null }

/**
 * Marks a book cover as a shared element so it flies from the library card into the book-detail header (and back).
 * Falls back to a plain modifier when no transition scope is available.
 */
@Composable
fun Modifier.sharedCover(key: String): Modifier {
    val shared = LocalSharedTransitionScope.current ?: return this
    val visibility = LocalContentVisibilityScope.current ?: return this
    val m = motion
    return with(shared) {
        this@sharedCover.sharedElement(
            sharedContentState = rememberSharedContentState(key = key),
            animatedVisibilityScope = visibility,
            boundsTransform = { _, _ -> m.medium() },
        )
    }
}
