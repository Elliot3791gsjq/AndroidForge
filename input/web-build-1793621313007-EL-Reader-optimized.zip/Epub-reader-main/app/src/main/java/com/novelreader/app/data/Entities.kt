package com.novelreader.app.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * A book in the app's private store.
 *
 * The EPUB is always copied to app-private storage ([filePath], relative to filesDir) so access can never be
 * revoked by the file manager / sharing app. The user's original file is never modified or deleted.
 *
 * [inLibrary] = false hides the book from the library while keeping its private copy and annotations
 * (used for "remove from library, keep my data" and for books opened once via "Open with").
 */
@Entity(tableName = "books", indices = [Index(value = ["sha256"], unique = true)])
data class BookEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val author: String?,
    val fileName: String,
    val filePath: String,
    val coverPath: String?,
    val sizeBytes: Long,
    val sha256: String,
    val addedAt: Long,
    val lastReadAt: Long? = null,
    /** Whole-book progression 0..1 as last reported by the navigator. */
    val progress: Double = 0.0,
    /** Readium Locator JSON for EPUBs, a [com.novelreader.app.formats.FormatLocator] JSON for the other formats; null until opened. */
    val lastLocatorJson: String? = null,
    val inLibrary: Boolean = true,
    /** Foreground time spent reading this book (ms), accumulated by the reader. */
    @ColumnInfo(defaultValue = "0") val readingMillis: Long = 0,
    /** Characters / words of the book's text; computed once from the EPUB's XHTML files, null until then. */
    val charCount: Long? = null,
    val wordCount: Long? = null,
    /** Marked as a favourite in the library (added in DB v3). */
    @ColumnInfo(defaultValue = "0") val favorite: Boolean = false,
    /** Cover chosen by the user from the phone (absolute-in-filesDir relative path); overrides [coverPath] (DB v4). */
    val customCoverPath: String? = null,
    /** [com.novelreader.app.formats.BookFormat] name; rows from before DB v5 are EPUBs (DB v5). */
    @ColumnInfo(defaultValue = "'EPUB'") val format: String = "EPUB",
    /** Pages of a PDF / comic archive (DB v5); null for formats without a fixed page count. */
    val pageCount: Int? = null,
)

@Entity(
    tableName = "highlights",
    foreignKeys = [ForeignKey(entity = BookEntity::class, parentColumns = ["id"], childColumns = ["bookId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("bookId")],
)
data class HighlightEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bookId: Long,
    /** Readium Locator JSON (includes href, locations and the selected text) - stable across font/size changes. */
    val locatorJson: String,
    val text: String,
    /** ARGB colour. */
    val color: Int,
    val note: String? = null,
    val chapterTitle: String? = null,
    val createdAt: Long,
    /** [AnnotationStyle] name: how the selection is drawn. Rows created before DB v2 are plain highlights. */
    @ColumnInfo(defaultValue = "'HIGHLIGHT'") val style: String = AnnotationStyle.HIGHLIGHT.name,
)

/** Visual kind of a text annotation. NOTE = a note attached to a selection (drawn as a dotted underline). */
enum class AnnotationStyle { HIGHLIGHT, UNDERLINE, STRIKE, BOLD, NOTE }

@Entity(
    tableName = "bookmarks",
    foreignKeys = [ForeignKey(entity = BookEntity::class, parentColumns = ["id"], childColumns = ["bookId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("bookId")],
)
data class BookmarkEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bookId: Long,
    val locatorJson: String,
    /** Optional user-given name. */
    val title: String? = null,
    val note: String? = null,
    val chapterTitle: String? = null,
    val progress: Double = 0.0,
    val createdAt: Long,
)

/** Trail of recent reading positions (one entry per chapter visit / exit). */
@Entity(
    tableName = "history",
    foreignKeys = [ForeignKey(entity = BookEntity::class, parentColumns = ["id"], childColumns = ["bookId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("bookId")],
)
data class HistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bookId: Long,
    val locatorJson: String,
    val chapterTitle: String? = null,
    val progress: Double = 0.0,
    val createdAt: Long,
)

/** A user-made library category (DB v4). A book can belong to any number of categories. */
@Entity(tableName = "categories")
data class CategoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAt: Long,
)

/** Link table between books and categories; rows disappear with either side. */
@Entity(
    tableName = "book_categories",
    primaryKeys = ["bookId", "categoryId"],
    foreignKeys = [
        ForeignKey(entity = BookEntity::class, parentColumns = ["id"], childColumns = ["bookId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = CategoryEntity::class, parentColumns = ["id"], childColumns = ["categoryId"], onDelete = ForeignKey.CASCADE),
    ],
    indices = [Index("categoryId")],
)
data class BookCategoryEntity(
    val bookId: Long,
    val categoryId: Long,
)

/**
 * One "sitting": a stretch of foreground reading of one book (DB v4). Feeds the Reading stats screen.
 * Progress values are the book's whole-book progression (0..1) when the sitting began / ended.
 */
@Entity(
    tableName = "reading_sessions",
    foreignKeys = [ForeignKey(entity = BookEntity::class, parentColumns = ["id"], childColumns = ["bookId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("bookId"), Index("startAt")],
)
data class ReadingSessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bookId: Long,
    val startAt: Long,
    val durationMs: Long,
    val startProgress: Double,
    val endProgress: Double,
)
