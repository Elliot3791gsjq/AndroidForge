package com.novelreader.app.formats

import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

/**
 * Reading positions of the non-EPUB formats, stored as JSON in the same `lastLocatorJson` / bookmark / highlight
 * columns the EPUB reader uses for Readium locators. Parsing is tolerant: anything unreadable yields null and the
 * reader simply starts at the beginning.
 */
sealed interface FormatLocator {
    fun toJson(): String

    /** PDF: zero-based [page], [y] = fraction of that page that is above the top of the screen, [rotation] in degrees. */
    data class Pdf(val page: Int, val y: Double = 0.0, val rotation: Int = 0) : FormatLocator {
        override fun toJson(): String = JSONObject().put("f", "pdf").put("p", page).put("y", y).put("r", rotation).toString()
    }

    /** Comic archive: zero-based page index. */
    data class Comic(val page: Int) : FormatLocator {
        override fun toJson(): String = JSONObject().put("f", "comic").put("p", page).toString()
    }

    /** TXT / DOCX: zero-based content [block] (paragraph, table, ...) and the [frac] of it that is above the top of the screen. */
    data class Doc(val block: Int, val frac: Double = 0.0) : FormatLocator {
        override fun toJson(): String = JSONObject().put("f", "doc").put("b", block).put("y", frac).toString()
    }

    companion object {
        fun parse(json: String?): FormatLocator? {
            if (json.isNullOrBlank()) return null
            return try {
                val o = JSONObject(json)
                when (o.optString("f")) {
                    "pdf" -> Pdf(o.getInt("p").coerceAtLeast(0), o.optDouble("y", 0.0).coerceIn(0.0, 1.0), normalizeRotation(o.optInt("r", 0)))
                    "comic" -> Comic(o.getInt("p").coerceAtLeast(0))
                    "doc" -> Doc(o.getInt("b").coerceAtLeast(0), o.optDouble("y", 0.0).coerceIn(0.0, 1.0))
                    else -> null
                }
            } catch (_: JSONException) {
                null
            }
        }

        fun normalizeRotation(deg: Int): Int = ((deg % 360) + 360) % 360 / 90 * 90
    }
}

/**
 * What a highlight on a PDF page covers: the page and the rectangles (PDF page points, origin top-left) of the
 * selected text. Stored in `highlights.locatorJson`.
 */
data class PdfHighlightRects(val page: Int, val rects: List<FloatArray>) {
    fun toJson(): String {
        val arr = JSONArray()
        rects.forEach { r -> arr.put(JSONArray().put(r[0].toDouble()).put(r[1].toDouble()).put(r[2].toDouble()).put(r[3].toDouble())) }
        return JSONObject().put("f", "pdfhl").put("p", page).put("rects", arr).toString()
    }

    companion object {
        fun parse(json: String?): PdfHighlightRects? {
            if (json.isNullOrBlank()) return null
            return try {
                val o = JSONObject(json)
                if (o.optString("f") != "pdfhl") return null
                val a = o.getJSONArray("rects")
                val list = ArrayList<FloatArray>(a.length())
                for (i in 0 until a.length()) {
                    val r = a.getJSONArray(i)
                    list += floatArrayOf(r.getDouble(0).toFloat(), r.getDouble(1).toFloat(), r.getDouble(2).toFloat(), r.getDouble(3).toFloat())
                }
                PdfHighlightRects(o.getInt("p"), list)
            } catch (_: JSONException) {
                null
            }
        }
    }
}

/**
 * A text range of a TXT/DOCX document: from character [start] of block [block] to character [end] of block [endBlock]
 * (offsets in the blocks' plain text; [endBlock] equals [block] for the usual single-paragraph selection). Highlight locator.
 */
data class DocRange(val block: Int, val start: Int, val end: Int, val endBlock: Int = block) {
    fun toJson(): String {
        val o = JSONObject().put("f", "dochl").put("b", block).put("s", start).put("e", end)
        if (endBlock != block) o.put("b2", endBlock)
        return o.toString()
    }

    /** The per-block pieces of this range: (block, start, end) triples. A block missing from [lengths] ends the range. */
    fun pieces(textLength: (Int) -> Int): List<IntArray> {
        if (endBlock <= block) return listOf(intArrayOf(block, start, end))
        val out = ArrayList<IntArray>()
        for (b in block..endBlock) {
            val len = textLength(b)
            if (len < 0) break
            val s = if (b == block) start else 0
            val e = if (b == endBlock) end else len
            if (e > s) out += intArrayOf(b, s, e)
        }
        return out
    }

    /** The covered text, blocks joined by a line break (what is stored with the highlight and used to check it still fits). */
    fun slice(texts: List<String>): String? {
        if (block !in texts.indices || endBlock !in texts.indices || endBlock < block) return null
        val sb = StringBuilder()
        for (b in block..endBlock) {
            val t = texts[b]
            val s = if (b == block) start else 0
            val e = if (b == endBlock) end else t.length
            if (s < 0 || e > t.length || e < s) return null
            if (b > block) sb.append('\n')
            sb.append(t, s, e)
        }
        return sb.toString()
    }

    companion object {
        fun parse(json: String?): DocRange? {
            if (json.isNullOrBlank()) return null
            return try {
                val o = JSONObject(json)
                if (o.optString("f") != "dochl") return null
                val b = o.getInt("b")
                DocRange(b, o.getInt("s"), o.getInt("e"), o.optInt("b2", b))
            } catch (_: JSONException) {
                null
            }
        }
    }
}
