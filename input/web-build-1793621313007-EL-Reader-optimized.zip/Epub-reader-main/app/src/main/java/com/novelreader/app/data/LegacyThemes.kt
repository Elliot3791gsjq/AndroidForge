package com.novelreader.app.data

/** The page colours and ids of the pre-redesign colour presets (used only by the one-time migration). */
internal object LegacyThemes {
    private data class Row(val newId: String, val darkBg: Int, val darkText: Int, val lightBg: Int, val lightText: Int)

    private val rows = mapOf(
        "sepia" to Row("paper", 0xFF2B2118.toInt(), 0xFFE9D8BD.toInt(), 0xFFF4ECD8.toInt(), 0xFF4B3A26.toInt()),
        "ocean" to Row("ocean", 0xFF0E1B26.toInt(), 0xFFD6E6F2.toInt(), 0xFFEAF4FB.toInt(), 0xFF12324A.toInt()),
        "forest" to Row("forest", 0xFF11201A.toInt(), 0xFFD3E6D6.toInt(), 0xFFE6F2E6.toInt(), 0xFF1F3A25.toInt()),
        "rose" to Row("crimson", 0xFF261218.toInt(), 0xFFF1D7E0.toInt(), 0xFFFBEAF0.toInt(), 0xFF4A1F2D.toInt()),
        "violet" to Row("violet", 0xFF1A1426.toInt(), 0xFFE0D8F2.toInt(), 0xFFF1EDFB.toInt(), 0xFF2E2150.toInt()),
        "mono" to Row("minimal", 0xFF000000.toInt(), 0xFFCFCFCF.toInt(), 0xFFF5F5F5.toInt(), 0xFF202020.toInt()),
    )

    fun newId(old: String?): String = rows[old]?.newId ?: when (old) {
        null, "classic" -> ReaderSettings.DEFAULT_COLOR_THEME
        else -> old // already a new-style id
    }

    /** (background, text) the old preset painted on the page in the given brightness; null for classic/unknown. */
    fun page(old: String?, dark: Boolean): Pair<Int, Int>? = rows[old]?.let {
        if (dark) it.darkBg to it.darkText else it.lightBg to it.lightText
    }
}
