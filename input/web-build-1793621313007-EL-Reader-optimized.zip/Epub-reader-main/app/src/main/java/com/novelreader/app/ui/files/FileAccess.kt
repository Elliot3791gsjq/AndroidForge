package com.novelreader.app.ui.files

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.novelreader.app.R
import com.novelreader.app.core.FileScan
import java.io.File

/** A place the browser can start from: internal storage, an SD card or a USB drive. */
data class StorageRoot(val label: String, val dir: File, val removable: Boolean)

/**
 * Everything about reaching the phone's real file system.
 *
 * The system picker (Storage Access Framework, "Open from") only shows what the document providers expose, and on
 * many phones that hides the normal folders. With the "All files access" permission the app can browse the actual
 * storage itself, so books can be picked from any folder, several at once.
 */
object FileAccess {

    /** True when the app may read arbitrary files on shared storage. */
    fun hasAllFiles(context: Context): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        }

    /** Android 11+ needs the user to flip a switch in system settings; before that a normal runtime permission works. */
    fun needsSettingsScreen(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.R

    /** The system screen where the user grants "All files access" to this app (falls back to the generic list). */
    fun settingsIntents(context: Context): List<Intent> {
        val pkg = Uri.parse("package:${context.packageName}")
        return listOf(
            Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, pkg),
            Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION),
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg),
        )
    }

    /** Starts the first of [settingsIntents] the device can resolve. Returns false when none could be started. */
    fun openSettings(context: Context, launcher: (Intent) -> Unit): Boolean {
        for (i in settingsIntents(context)) {
            try {
                launcher(i)
                return true
            } catch (_: Exception) {
                // try the next, more generic screen
            }
        }
        return false
    }

    /** Internal storage first, then every mounted SD card / USB drive the app can see. */
    fun roots(context: Context): List<StorageRoot> {
        val out = ArrayList<StorageRoot>()
        val internal = Environment.getExternalStorageDirectory()
        if (internal != null) out += StorageRoot(context.getString(R.string.storage_internal), internal, false)
        val seen = HashSet<String>()
        internal?.let { seen += it.absolutePath }
        val dirs = try { context.getExternalFilesDirs(null) } catch (_: Exception) { emptyArray() }
        var n = 0
        for (d in dirs) {
            if (d == null) continue
            val path = d.absolutePath
            val cut = path.indexOf("/Android/")
            if (cut <= 0) continue
            val rootPath = path.substring(0, cut)
            if (!seen.add(rootPath)) continue
            val root = File(rootPath)
            if (root.canRead()) {
                n++
                out += StorageRoot(
                    if (n == 1) context.getString(R.string.storage_sd) else context.getString(R.string.storage_sd_n, n),
                    root, true,
                )
            }
        }
        return out
    }

    /** Common places books live in, only those that exist: Download, Documents, Books, Telegram... */
    fun quickFolders(root: File): List<File> =
        listOf("Download", "Documents", "Books", "Telegram", "Telegram/Telegram Documents", "Android/media")
            .map { File(root, it) }
            .filter { it.isDirectory && it.canRead() }

    /** Folder name to show in the header ("Internal storage" for the root itself). */
    fun displayName(context: Context, dir: File, roots: List<StorageRoot>): String =
        roots.firstOrNull { it.dir.absolutePath == dir.absolutePath }?.label ?: dir.name.ifEmpty { dir.absolutePath }

    /** Path relative to the storage root the folder lives in, for the small path line under the header. */
    fun relativePath(context: Context, dir: File, roots: List<StorageRoot>): String {
        val root = roots.firstOrNull { dir.absolutePath == it.dir.absolutePath || dir.absolutePath.startsWith(it.dir.absolutePath + "/") }
            ?: return dir.absolutePath
        val rel = dir.absolutePath.removePrefix(root.dir.absolutePath).trim('/')
        return if (rel.isEmpty()) root.label else root.label + " / " + rel.replace("/", " / ")
    }
}

/** Recursive listing of a folder picked with the system "choose folder" screen (a SAF tree URI). */
object SafScan {

    fun scanTree(
        context: Context,
        tree: Uri,
        extensions: Set<String>,
        maxResults: Int = 20_000,
        maxDepth: Int = 24,
        cancelled: () -> Boolean = { false },
    ): List<Uri> {
        val found = ArrayList<Uri>()
        val resolver = context.contentResolver
        val rootId = try { DocumentsContract.getTreeDocumentId(tree) } catch (_: Exception) { return found }
        val queue = ArrayDeque<Pair<String, Int>>()
        queue.add(rootId to 0)
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
        )
        while (queue.isNotEmpty() && found.size < maxResults) {
            if (cancelled()) break
            val (docId, depth) = queue.removeFirst()
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
            val subs = ArrayList<String>()
            val here = ArrayList<Pair<String, Uri>>()
            try {
                resolver.query(children, projection, null, null, null)?.use { c ->
                    while (c.moveToNext()) {
                        val id = c.getString(0) ?: continue
                        val name = c.getString(1) ?: ""
                        val mime = c.getString(2) ?: ""
                        if (name.startsWith(".")) continue
                        if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                            if (depth < maxDepth) subs += id
                        } else if (FileScan.hasExtension(name, extensions)) {
                            here += name to DocumentsContract.buildDocumentUriUsingTree(tree, id)
                        }
                    }
                }
            } catch (_: Exception) {
                continue
            }
            here.sortWith { a, b -> FileScan.naturalOrder.compare(a.first, b.first) }
            for ((_, u) in here) {
                if (found.size >= maxResults) break
                found += u
            }
            for (s in subs) queue.add(s to depth + 1)
        }
        return found
    }
}
