package com.novelreader.app.data

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.provider.OpenableColumns
import com.novelreader.app.core.EpubFileCheck
import com.novelreader.app.formats.BookFormat
import com.novelreader.app.formats.Detection
import com.novelreader.app.formats.FormatDetector
import com.novelreader.app.formats.FormatInspector
import com.novelreader.app.formats.InspectFailure
import com.novelreader.app.reader.EngineResult
import com.novelreader.app.reader.EpubEngine
import com.novelreader.app.reader.EpubFailure
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.security.MessageDigest
import java.util.UUID

sealed interface ImportResult {
    /** [alreadyPresent] = the same file (by content hash) was already stored; nothing was duplicated. */
    data class Success(val bookId: Long, val alreadyPresent: Boolean) : ImportResult
    data class Failure(val error: ImportError, val detail: String? = null) : ImportResult
}

enum class ImportError { NO_ACCESS, NOT_EPUB, NOT_SUPPORTED, CORRUPT, ENCRYPTED, UNSUPPORTED, IO, TOO_LARGE }

class LibraryRepository(
    private val context: Context,
    private val db: AppDatabase,
    private val engine: EpubEngine,
) {
    private val booksDir get() = File(context.filesDir, "books").apply { mkdirs() }
    private val coversDir get() = File(context.filesDir, "covers").apply { mkdirs() }

    fun observeLibrary(): Flow<List<BookEntity>> = db.books().observeLibrary()

    /** Every stored book, including ones hidden from the library (their reading sittings still count in the stats). */
    fun observeAllBooks(): Flow<List<BookEntity>> = db.books().observeAll()

    // ---- Categories ----
    fun observeCategories(): Flow<List<CategoryEntity>> = db.categories().observeAll()
    fun observeCategoryLinks(): Flow<List<BookCategoryEntity>> = db.categories().observeLinks()

    /** Creates a category; blank names are ignored. Returns the new id or null. */
    suspend fun createCategory(name: String): Long? {
        val clean = name.trim().take(MAX_CATEGORY_NAME)
        if (clean.isEmpty()) return null
        return db.categories().insert(CategoryEntity(name = clean, createdAt = System.currentTimeMillis()))
    }

    suspend fun renameCategory(id: Long, name: String) {
        val clean = name.trim().take(MAX_CATEGORY_NAME)
        if (clean.isNotEmpty()) db.categories().rename(id, clean)
    }

    suspend fun deleteCategory(id: Long) = db.categories().delete(id)

    suspend fun setBookInCategory(bookId: Long, categoryId: Long, member: Boolean) {
        if (member) db.categories().link(BookCategoryEntity(bookId, categoryId)) else db.categories().unlink(bookId, categoryId)
    }

    // ---- Reading sittings (stats) ----
    fun observeSessions(): Flow<List<ReadingSessionEntity>> = db.sessions().observeAll()

    suspend fun recordSession(bookId: Long, startAt: Long, durationMs: Long, startProgress: Double, endProgress: Double) {
        if (durationMs <= 0) return
        db.sessions().insert(
            ReadingSessionEntity(
                bookId = bookId, startAt = startAt, durationMs = durationMs,
                startProgress = startProgress.coerceIn(0.0, 1.0), endProgress = endProgress.coerceIn(0.0, 1.0),
            )
        )
    }

    // ---- Custom cover ----

    /**
     * Stores an image picked from the phone (gallery / file manager) as this book's cover. The picture is decoded
     * down-sampled (long side <= 1400 px, EXIF orientation honoured on Android 9+) and saved as JPEG in private
     * storage, so it keeps working if the original is moved. Returns false when the file is not a decodable image.
     */
    suspend fun setCustomCover(bookId: Long, uri: Uri): Boolean = withContext(Dispatchers.IO) {
        val book = db.books().getById(bookId) ?: return@withContext false
        val bmp = decodeImage(uri, 1400) ?: return@withContext false
        val dest = File(coversDir, "custom-$bookId-${System.currentTimeMillis()}.jpg")
        if (!saveCover(bmp, dest)) { bmp.recycle(); return@withContext false }
        bmp.recycle()
        val old = book.customCoverPath
        db.books().setCustomCover(bookId, "covers/${dest.name}")
        old?.let { File(context.filesDir, it).delete(); forget(it) }
        true
    }

    suspend fun clearCustomCover(bookId: Long) = withContext(Dispatchers.IO) {
        val book = db.books().getById(bookId) ?: return@withContext
        db.books().setCustomCover(bookId, null)
        book.customCoverPath?.let { File(context.filesDir, it).delete() }
        forget(book.customCoverPath)
    }

    private fun decodeImage(uri: Uri, maxSide: Int): Bitmap? = try {
        if (android.os.Build.VERSION.SDK_INT >= 28) {
            val source = android.graphics.ImageDecoder.createSource(context.contentResolver, uri)
            android.graphics.ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                val longSide = maxOf(info.size.width, info.size.height)
                if (longSide > maxSide) {
                    val k = maxSide.toFloat() / longSide
                    decoder.setTargetSize((info.size.width * k).toInt().coerceAtLeast(1), (info.size.height * k).toInt().coerceAtLeast(1))
                }
                decoder.allocator = android.graphics.ImageDecoder.ALLOCATOR_SOFTWARE
            }
        } else {
            val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > maxSide) sample *= 2
            context.contentResolver.openInputStream(uri)?.use {
                android.graphics.BitmapFactory.decodeStream(it, null, android.graphics.BitmapFactory.Options().apply { inSampleSize = sample })
            }
        }
    } catch (_: Throwable) {
        null
    }
    suspend fun get(id: Long): BookEntity? = db.books().getById(id)

    fun bookFile(book: BookEntity): File = File(context.filesDir, book.filePath)

    /**
     * Copies the book behind [uri] (EPUB, PDF, TXT, DOCX, CBZ or CBR) into private storage, decides what it really is
     * from its CONTENT ([FormatDetector]), validates it, extracts title/author/cover/page count and stores a library
     * row. All I/O runs on Dispatchers.IO.
     *
     * [addToLibrary] = false stores the book hidden (used by "Open with" until the user adds it).
     * The source file is only ever read.
     */
    suspend fun importFromUri(uri: Uri, addToLibrary: Boolean): ImportResult = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        val displayName = EpubFileCheck.safeDisplayName(queryDisplayName(uri) ?: uri.lastPathSegment)
        val tmp = File(booksDir, "tmp-${UUID.randomUUID()}")
        try {
            val sha = MessageDigest.getInstance("SHA-256")
            var size = 0L
            val input = try {
                resolver.openInputStream(uri)
            } catch (e: SecurityException) {
                return@withContext ImportResult.Failure(ImportError.NO_ACCESS, e.message)
            } catch (e: java.io.FileNotFoundException) {
                return@withContext ImportResult.Failure(ImportError.NO_ACCESS, e.message)
            }
            if (input == null) return@withContext ImportResult.Failure(ImportError.NO_ACCESS, "no stream")

            input.use { ins ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        sha.update(buf, 0, n)
                        out.write(buf, 0, n)
                        size += n
                    }
                }
            }
            if (size == 0L) return@withContext ImportResult.Failure(ImportError.NOT_SUPPORTED, "empty file")

            val hash = sha.digest().joinToString("") { "%02x".format(it) }
            db.books().getBySha(hash)?.let { existing ->
                if (addToLibrary && !existing.inLibrary) db.books().setInLibrary(existing.id, true)
                return@withContext ImportResult.Success(existing.id, alreadyPresent = true)
            }

            val format = when (val d = FormatDetector.detect(tmp, displayName, queryMimeType(uri))) {
                is Detection.Found -> d.format
                is Detection.Damaged -> return@withContext ImportResult.Failure(ImportError.CORRUPT, "damaged ${d.format}")
                Detection.Unknown -> return@withContext ImportResult.Failure(ImportError.NOT_SUPPORTED, "unknown type")
            }

            val finalFile = File(booksDir, "${hash.take(32)}.${format.storedExtension}")
            if (finalFile.exists()) finalFile.delete()
            if (!tmp.renameTo(finalFile)) {
                tmp.copyTo(finalFile, overwrite = true)
                tmp.delete()
            }

            if (format != BookFormat.EPUB) {
                return@withContext importOther(format, finalFile, displayName, hash, size, addToLibrary)
            }

            when (val opened = engine.open(finalFile)) {
                is EngineResult.Failed -> {
                    finalFile.delete()
                    ImportResult.Failure(opened.reason.toImportError(), opened.detail)
                }
                is EngineResult.Ok -> {
                    val pub = opened.value
                    try {
                        val title = pub.metadata.title?.takeIf { it.isNotBlank() }
                            ?: displayName.removeSuffix(".epub").removeSuffix(".EPUB")
                        val author = pub.metadata.authors.map { it.name }.filter { it.isNotBlank() }
                            .joinToString("، ").ifBlank { null }
                        var coverPath: String? = null
                        engine.coverOf(pub)?.let { bmp ->
                            val f = File(coversDir, "${hash.take(32)}.jpg")
                            if (saveCover(bmp, f)) coverPath = "covers/${f.name}"
                        }
                        val id = db.books().insert(
                            BookEntity(
                                title = title,
                                author = author,
                                fileName = displayName,
                                filePath = "books/${finalFile.name}",
                                coverPath = coverPath,
                                sizeBytes = size,
                                sha256 = hash,
                                addedAt = System.currentTimeMillis(),
                                inLibrary = addToLibrary,
                            )
                        )
                        ImportResult.Success(id, alreadyPresent = false)
                    } finally {
                        pub.close()
                    }
                }
            }
        } catch (e: IOException) {
            ImportResult.Failure(ImportError.IO, e.message)
        } finally {
            if (tmp.exists()) tmp.delete()
        }
    }

    /** PDF / TXT / DOCX / CBZ / CBR: validate, read the metadata and store the row. */
    private suspend fun importOther(
        format: BookFormat, finalFile: File, displayName: String, hash: String, size: Long, addToLibrary: Boolean,
    ): ImportResult {
        val meta = try {
            FormatInspector.inspect(context, format, finalFile, displayName)
        } catch (e: InspectFailure) {
            finalFile.delete()
            return ImportResult.Failure(e.error, e.message)
        } catch (e: Exception) {
            finalFile.delete()
            return ImportResult.Failure(ImportError.CORRUPT, e.message)
        }
        var coverPath: String? = null
        meta.cover?.let { bmp ->
            val f = File(coversDir, "${hash.take(32)}.jpg")
            if (saveCover(bmp, f)) coverPath = "covers/${f.name}"
            bmp.recycle()
        }
        val id = db.books().insert(
            BookEntity(
                title = meta.title ?: displayName,
                author = meta.author,
                fileName = displayName,
                filePath = "books/${finalFile.name}",
                coverPath = coverPath,
                sizeBytes = size,
                sha256 = hash,
                addedAt = System.currentTimeMillis(),
                inLibrary = addToLibrary,
                format = format.name,
                pageCount = meta.pageCount,
            )
        )
        return ImportResult.Success(id, alreadyPresent = false)
    }

    /** Hides the book from the library; the private copy, highlights, bookmarks and position are kept. */
    suspend fun removeFromLibrary(id: Long) = db.books().setInLibrary(id, false)

    suspend fun addToLibrary(id: Long) = db.books().setInLibrary(id, true)

    suspend fun setFavorite(id: Long, favorite: Boolean) = db.books().setFavorite(id, favorite)

    suspend fun addReadingTime(id: Long, deltaMs: Long) { if (deltaMs > 0) db.books().addReadingTime(id, deltaMs) }

    /** Returns cached character/word counts, computing (and caching) them from the EPUB on first use. */
    suspend fun textStats(book: BookEntity): com.novelreader.app.core.TextStats.Result? = withContext(Dispatchers.IO) {
        val c = book.charCount
        val w = book.wordCount
        if (c != null && w != null) return@withContext com.novelreader.app.core.TextStats.Result(c, w)
        // Character / word counts are computed from EPUB XHTML; the other formats have their own info.
        if (BookFormat.fromStored(book.format) != BookFormat.EPUB) return@withContext null
        com.novelreader.app.core.TextStats.compute(bookFile(book))?.also { db.books().setTextStats(book.id, it.characters, it.words) }
    }

    suspend fun touch(id: Long) = db.books().touch(id, System.currentTimeMillis())

    /** Deletes the private copy, cover and every annotation of the book (rows cascade). The user's original file is untouched. */
    suspend fun deleteCompletely(id: Long) = withContext(Dispatchers.IO) {
        val book = db.books().getById(id) ?: return@withContext
        File(context.filesDir, book.filePath).delete()
        File(context.cacheDir, "comics/${book.sha256.take(32)}").deleteRecursively()
        book.coverPath?.let { File(context.filesDir, it).delete() }
        book.customCoverPath?.let { File(context.filesDir, it).delete() }
        forget(book.coverPath); forget(book.customCoverPath)
        db.books().deleteById(id)
    }

    /** The user's own cover if one was set, otherwise the one extracted from the EPUB. */
    fun coverFile(book: BookEntity): File? = existingFile(book.customCoverPath) ?: existingFile(book.coverPath)

    /**
     * Called from composables for every visible book on every recomposition, so the "does the file exist" disk
     * check is remembered (a stat per cover per frame was visible as scroll / animation jank on slower phones).
     * Cover paths are unique per file (custom covers carry a timestamp); deleting one drops its entry.
     */
    private val existing = java.util.concurrent.ConcurrentHashMap<String, File>()

    private fun existingFile(rel: String?): File? {
        if (rel == null) return null
        existing[rel]?.let { return it }
        val f = File(context.filesDir, rel)
        return if (f.exists()) f.also { existing[rel] = it } else null
    }

    private fun forget(rel: String?) { if (rel != null) existing.remove(rel) }

    companion object {
        const val MAX_CATEGORY_NAME = 40
    }

    private fun queryDisplayName(uri: Uri): String? = try {
        if (uri.scheme == "content") {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        } else uri.lastPathSegment
    } catch (_: Exception) {
        null
    }

    private fun queryMimeType(uri: Uri): String? = try {
        context.contentResolver.getType(uri)
    } catch (_: Exception) {
        null
    }

    private fun saveCover(bmp: Bitmap, file: File): Boolean = try {
        file.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
    } catch (_: IOException) {
        false
    }

    private fun EpubFailure.toImportError() = when (this) {
        EpubFailure.NOT_EPUB -> ImportError.NOT_EPUB
        EpubFailure.ENCRYPTED -> ImportError.ENCRYPTED
        EpubFailure.CORRUPT -> ImportError.CORRUPT
        EpubFailure.UNSUPPORTED -> ImportError.UNSUPPORTED
    }
}
