package com.novelreader.app.formats

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

/*
 * Per-format reading settings. Every format owns its own DataStore file, so changing the font size of TXT can never
 * touch PDF or comic settings, and CBZ and CBR keep separate settings of their own. Only genuinely shared things
 * live elsewhere: the app theme / dark mode (SettingsRepository), bookmarks and the library (Room).
 */
private val Context.pdfStore: DataStore<Preferences> by preferencesDataStore(name = "fmt_pdf")
private val Context.txtStore: DataStore<Preferences> by preferencesDataStore(name = "fmt_txt")
private val Context.docxStore: DataStore<Preferences> by preferencesDataStore(name = "fmt_docx")
private val Context.cbzStore: DataStore<Preferences> by preferencesDataStore(name = "fmt_cbz")
private val Context.cbrStore: DataStore<Preferences> by preferencesDataStore(name = "fmt_cbr")

internal fun Context.formatStore(format: BookFormat): DataStore<Preferences> = when (format) {
    BookFormat.PDF -> pdfStore
    BookFormat.TXT -> txtStore
    BookFormat.DOCX -> docxStore
    BookFormat.CBZ -> cbzStore
    BookFormat.CBR -> cbrStore
    BookFormat.EPUB -> throw IllegalArgumentException("EPUB settings live in SettingsRepository")
}

internal inline fun <reified E : Enum<E>> Preferences.enumOf(key: Preferences.Key<String>, default: E): E =
    this[key]?.let { v -> enumValues<E>().firstOrNull { it.name == v } } ?: default

/** Shared plumbing: a DataStore of one format, read as a flow of [T] and updated with a transform. */
abstract class FormatSettingsRepository<T>(protected val store: DataStore<Preferences>) {
    protected abstract fun read(p: Preferences): T
    protected abstract fun write(p: androidx.datastore.preferences.core.MutablePreferences, v: T)

    val flow: Flow<T> = store.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { read(it) }

    suspend fun update(transform: (T) -> T) {
        store.edit { p -> write(p, transform(read(p))) }
    }
}

// ================================================================================================================
// Comics (CBZ / CBR)
// ================================================================================================================

/** AUTO follows the archive's ComicInfo.xml (manga = right-to-left), otherwise left-to-right. */
enum class ComicDirection { AUTO, LTR, RTL, VERTICAL }

/** AUTO = two pages side by side in landscape, one in portrait. */
enum class ComicLayout { SINGLE, DUAL, AUTO }

enum class ComicFit { SCREEN, WIDTH, HEIGHT }

data class ComicSettings(
    val direction: ComicDirection = ComicDirection.AUTO,
    val layout: ComicLayout = ComicLayout.AUTO,
    /** In two-page layout the first page (the cover) stays alone so the spreads line up. */
    val coverAlone: Boolean = true,
    val fit: ComicFit = ComicFit.SCREEN,
    val background: Int = 0xFF000000.toInt(),
    val tapToTurn: Boolean = true,
    val keepScreenOn: Boolean = true,
    val showPageNumber: Boolean = true,
    /** Space between pages in vertical scrolling, dp. */
    val pageGapDp: Int = 0,
)

class ComicSettingsRepository(context: Context, format: BookFormat) :
    FormatSettingsRepository<ComicSettings>(context.formatStore(format)) {

    private object K {
        val direction = stringPreferencesKey("direction")
        val layout = stringPreferencesKey("layout")
        val coverAlone = booleanPreferencesKey("cover_alone")
        val fit = stringPreferencesKey("fit")
        val background = intPreferencesKey("background")
        val tapToTurn = booleanPreferencesKey("tap_to_turn")
        val keepScreenOn = booleanPreferencesKey("keep_screen_on")
        val showPageNumber = booleanPreferencesKey("show_page_number")
        val pageGap = intPreferencesKey("page_gap_dp")
    }

    override fun read(p: Preferences): ComicSettings {
        val d = ComicSettings()
        return ComicSettings(
            direction = p.enumOf(K.direction, d.direction),
            layout = p.enumOf(K.layout, d.layout),
            coverAlone = p[K.coverAlone] ?: d.coverAlone,
            fit = p.enumOf(K.fit, d.fit),
            background = p[K.background] ?: d.background,
            tapToTurn = p[K.tapToTurn] ?: d.tapToTurn,
            keepScreenOn = p[K.keepScreenOn] ?: d.keepScreenOn,
            showPageNumber = p[K.showPageNumber] ?: d.showPageNumber,
            pageGapDp = (p[K.pageGap] ?: d.pageGapDp).coerceIn(0, 32),
        )
    }

    override fun write(p: androidx.datastore.preferences.core.MutablePreferences, v: ComicSettings) {
        p[K.direction] = v.direction.name
        p[K.layout] = v.layout.name
        p[K.coverAlone] = v.coverAlone
        p[K.fit] = v.fit.name
        p[K.background] = v.background
        p[K.tapToTurn] = v.tapToTurn
        p[K.keepScreenOn] = v.keepScreenOn
        p[K.showPageNumber] = v.showPageNumber
        p[K.pageGap] = v.pageGapDp.coerceIn(0, 32)
    }
}

// ================================================================================================================
// PDF
// ================================================================================================================

/** SCROLL = one long vertical strip of pages; PAGED = swipe sideways, one page (or spread) per screen. */
enum class PdfReadMode { SCROLL, PAGED }

/** AUTO = two pages side by side in landscape, one in portrait. */
enum class PdfSpread { SINGLE, DUAL, AUTO }

/** Direction of page turning in [PdfReadMode.PAGED] and the order of the pages of a two-page spread. */
enum class PdfDirection { LTR, RTL }

/** Inverts the colours of the rendered pages. AUTO follows the app's dark theme. */
enum class PdfDark { OFF, ON, AUTO }

data class PdfSettings(
    val readMode: PdfReadMode = PdfReadMode.SCROLL,
    val fit: com.novelreader.app.formats.pdf.PdfFit = com.novelreader.app.formats.pdf.PdfFit.WIDTH,
    val spread: PdfSpread = PdfSpread.SINGLE,
    /** In two-page layout the first page stays alone so the pairs line up with the printed book. */
    val coverAlone: Boolean = true,
    val direction: PdfDirection = PdfDirection.LTR,
    val dark: PdfDark = PdfDark.OFF,
    val background: Int = 0xFF3A3A3A.toInt(),
    val tapToTurn: Boolean = true,
    val keepScreenOn: Boolean = false,
    val showPageNumber: Boolean = true,
    /** Space between pages in continuous scrolling, dp. */
    val pageGapDp: Int = 8,
)

class PdfSettingsRepository(context: Context) : FormatSettingsRepository<PdfSettings>(context.formatStore(BookFormat.PDF)) {

    private object K {
        val readMode = stringPreferencesKey("read_mode")
        val fit = stringPreferencesKey("fit")
        val spread = stringPreferencesKey("spread")
        val coverAlone = booleanPreferencesKey("cover_alone")
        val direction = stringPreferencesKey("direction")
        val dark = stringPreferencesKey("dark")
        val background = intPreferencesKey("background")
        val tapToTurn = booleanPreferencesKey("tap_to_turn")
        val keepScreenOn = booleanPreferencesKey("keep_screen_on")
        val showPageNumber = booleanPreferencesKey("show_page_number")
        val pageGap = intPreferencesKey("page_gap_dp")
    }

    override fun read(p: Preferences): PdfSettings {
        val d = PdfSettings()
        return PdfSettings(
            readMode = p.enumOf(K.readMode, d.readMode),
            fit = p.enumOf(K.fit, d.fit),
            spread = p.enumOf(K.spread, d.spread),
            coverAlone = p[K.coverAlone] ?: d.coverAlone,
            direction = p.enumOf(K.direction, d.direction),
            dark = p.enumOf(K.dark, d.dark),
            background = p[K.background] ?: d.background,
            tapToTurn = p[K.tapToTurn] ?: d.tapToTurn,
            keepScreenOn = p[K.keepScreenOn] ?: d.keepScreenOn,
            showPageNumber = p[K.showPageNumber] ?: d.showPageNumber,
            pageGapDp = (p[K.pageGap] ?: d.pageGapDp).coerceIn(0, 32),
        )
    }

    override fun write(p: androidx.datastore.preferences.core.MutablePreferences, v: PdfSettings) {
        p[K.readMode] = v.readMode.name
        p[K.fit] = v.fit.name
        p[K.spread] = v.spread.name
        p[K.coverAlone] = v.coverAlone
        p[K.direction] = v.direction.name
        p[K.dark] = v.dark.name
        p[K.background] = v.background
        p[K.tapToTurn] = v.tapToTurn
        p[K.keepScreenOn] = v.keepScreenOn
        p[K.showPageNumber] = v.showPageNumber
        p[K.pageGap] = v.pageGapDp.coerceIn(0, 32)
    }
}

// ================================================================================================================
// Documents (TXT / DOCX)
// ================================================================================================================

/** Typefaces of the document view. The three bundled ones are served from the APK; [customFontId] picks an imported font instead. */
enum class DocFont { SYSTEM_SANS, SYSTEM_SERIF, MONO, VAZIRMATN, AMIRI, LORA }

/** DOCUMENT keeps the alignment each paragraph of a .docx asks for. */
enum class DocAlign { DOCUMENT, START, JUSTIFY, CENTER }

/** AUTO decides per paragraph from its first strong letter; LTR / RTL force one direction everywhere. */
enum class DocDirection { AUTO, LTR, RTL }

data class DocSettings(
    val fontSize: Int = 18,
    val font: DocFont = DocFont.SYSTEM_SANS,
    val customFontId: String? = null,
    val weight: Int = 400,
    val lineHeight: Float = 1.6f,
    val paragraphSpacing: Float = 0.6f,
    /** First-line indent in em (plain text only; a .docx brings its own). */
    val indent: Float = 0f,
    val marginDp: Int = 16,
    val align: DocAlign = DocAlign.START,
    val direction: DocDirection = DocDirection.AUTO,
    /** "app" = the app's own theme colours, otherwise the id of a [com.novelreader.app.data.ReadingThemes] entry. */
    val themeId: String = "app",
    val textColor: Int? = null,
    val backgroundColor: Int? = null,
    /** .docx: use the fonts the document names when they are available (bundled or imported). */
    val useDocFonts: Boolean = true,
    /** .docx: keep the colours of text, highlights and table cells. */
    val keepDocColors: Boolean = true,
    /** Tapping the top / bottom quarter of the screen scrolls one screen. */
    val tapScroll: Boolean = false,
    val keepScreenOn: Boolean = false,
    val showProgress: Boolean = true,
) {
    companion object {
        val FONT_SIZE = 10..48
        val LINE_HEIGHT = 1.0f..2.6f
        val PARAGRAPH_SPACING = 0f..2.5f
        val INDENT = 0f..3f
        val MARGIN = 0..64

        fun defaultsFor(format: BookFormat) =
            if (format == BookFormat.DOCX) DocSettings(align = DocAlign.DOCUMENT, lineHeight = 1.5f, paragraphSpacing = 0.4f) else DocSettings()
    }
}

/** Options that belong to one text file rather than to all of them: the encoding (null = detect) and how lines become paragraphs. */
data class TextBookOptions(
    val encoding: com.novelreader.app.formats.doc.TextEncoding? = null,
    val paragraphMode: com.novelreader.app.formats.doc.ParagraphMode = com.novelreader.app.formats.doc.ParagraphMode.AUTO,
)

class DocSettingsRepository(context: Context, private val format: BookFormat) :
    FormatSettingsRepository<DocSettings>(context.formatStore(format)) {

    private object K {
        val fontSize = intPreferencesKey("font_size")
        val font = stringPreferencesKey("font")
        val customFont = stringPreferencesKey("custom_font")
        val weight = intPreferencesKey("weight")
        val lineHeight = floatPreferencesKey("line_height")
        val paraSpacing = floatPreferencesKey("para_spacing")
        val indent = floatPreferencesKey("indent")
        val margin = intPreferencesKey("margin_dp")
        val align = stringPreferencesKey("align")
        val direction = stringPreferencesKey("direction")
        val theme = stringPreferencesKey("theme")
        val textColor = intPreferencesKey("text_color")
        val bgColor = intPreferencesKey("bg_color")
        val docFonts = booleanPreferencesKey("doc_fonts")
        val docColors = booleanPreferencesKey("doc_colors")
        val tapScroll = booleanPreferencesKey("tap_scroll")
        val keepOn = booleanPreferencesKey("keep_screen_on")
        val showProgress = booleanPreferencesKey("show_progress")
        fun encoding(id: Long) = stringPreferencesKey("enc_$id")
        fun paragraphs(id: Long) = stringPreferencesKey("pm_$id")
    }

    override fun read(p: Preferences): DocSettings {
        val d = DocSettings.defaultsFor(format)
        return DocSettings(
            fontSize = (p[K.fontSize] ?: d.fontSize).coerceIn(DocSettings.FONT_SIZE),
            font = p.enumOf(K.font, d.font),
            customFontId = p[K.customFont]?.takeIf { it.isNotBlank() },
            weight = (p[K.weight] ?: d.weight).coerceIn(300, 700),
            lineHeight = (p[K.lineHeight] ?: d.lineHeight).coerceIn(DocSettings.LINE_HEIGHT),
            paragraphSpacing = (p[K.paraSpacing] ?: d.paragraphSpacing).coerceIn(DocSettings.PARAGRAPH_SPACING),
            indent = (p[K.indent] ?: d.indent).coerceIn(DocSettings.INDENT),
            marginDp = (p[K.margin] ?: d.marginDp).coerceIn(DocSettings.MARGIN),
            align = p.enumOf(K.align, d.align),
            direction = p.enumOf(K.direction, d.direction),
            themeId = p[K.theme] ?: d.themeId,
            textColor = p[K.textColor],
            backgroundColor = p[K.bgColor],
            useDocFonts = p[K.docFonts] ?: d.useDocFonts,
            keepDocColors = p[K.docColors] ?: d.keepDocColors,
            tapScroll = p[K.tapScroll] ?: d.tapScroll,
            keepScreenOn = p[K.keepOn] ?: d.keepScreenOn,
            showProgress = p[K.showProgress] ?: d.showProgress,
        )
    }

    override fun write(p: androidx.datastore.preferences.core.MutablePreferences, v: DocSettings) {
        p[K.fontSize] = v.fontSize.coerceIn(DocSettings.FONT_SIZE)
        p[K.font] = v.font.name
        if (v.customFontId != null) p[K.customFont] = v.customFontId else p.remove(K.customFont)
        p[K.weight] = v.weight.coerceIn(300, 700)
        p[K.lineHeight] = v.lineHeight.coerceIn(DocSettings.LINE_HEIGHT)
        p[K.paraSpacing] = v.paragraphSpacing.coerceIn(DocSettings.PARAGRAPH_SPACING)
        p[K.indent] = v.indent.coerceIn(DocSettings.INDENT)
        p[K.margin] = v.marginDp.coerceIn(DocSettings.MARGIN)
        p[K.align] = v.align.name
        p[K.direction] = v.direction.name
        p[K.theme] = v.themeId
        if (v.textColor != null) p[K.textColor] = v.textColor else p.remove(K.textColor)
        if (v.backgroundColor != null) p[K.bgColor] = v.backgroundColor else p.remove(K.bgColor)
        p[K.docFonts] = v.useDocFonts
        p[K.docColors] = v.keepDocColors
        p[K.tapScroll] = v.tapScroll
        p[K.keepOn] = v.keepScreenOn
        p[K.showProgress] = v.showProgress
    }

    /** Encoding / paragraph options of one text file (kept in this format's own store). */
    fun bookOptions(bookId: Long): Flow<TextBookOptions> = store.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { p ->
            TextBookOptions(
                encoding = p[K.encoding(bookId)]?.let { n -> com.novelreader.app.formats.doc.TextEncoding.entries.firstOrNull { it.name == n } },
                paragraphMode = p.enumOf(K.paragraphs(bookId), com.novelreader.app.formats.doc.ParagraphMode.AUTO),
            )
        }

    suspend fun updateBookOptions(bookId: Long, transform: (TextBookOptions) -> TextBookOptions) {
        store.edit { p ->
            val cur = TextBookOptions(
                encoding = p[K.encoding(bookId)]?.let { n -> com.novelreader.app.formats.doc.TextEncoding.entries.firstOrNull { it.name == n } },
                paragraphMode = p.enumOf(K.paragraphs(bookId), com.novelreader.app.formats.doc.ParagraphMode.AUTO),
            )
            val v = transform(cur)
            if (v.encoding != null) p[K.encoding(bookId)] = v.encoding.name else p.remove(K.encoding(bookId))
            p[K.paragraphs(bookId)] = v.paragraphMode.name
        }
    }
}

/** Entry point used by the app graph: one repository per format, created on first use. */
class FormatSettings(private val context: Context) {
    private val comics = HashMap<BookFormat, ComicSettingsRepository>()
    private val pdfRepo by lazy { PdfSettingsRepository(context) }

    private val docs = HashMap<BookFormat, DocSettingsRepository>()

    fun pdf(): PdfSettingsRepository = pdfRepo

    /** TXT and DOCX each have their own store, so changing one never changes the other. */
    @Synchronized
    fun doc(format: BookFormat): DocSettingsRepository =
        docs.getOrPut(if (format == BookFormat.DOCX) BookFormat.DOCX else BookFormat.TXT) {
            DocSettingsRepository(context, if (format == BookFormat.DOCX) BookFormat.DOCX else BookFormat.TXT)
        }

    @Synchronized
    fun comic(format: BookFormat): ComicSettingsRepository =
        comics.getOrPut(if (format == BookFormat.CBR) BookFormat.CBR else BookFormat.CBZ) {
            ComicSettingsRepository(context, if (format == BookFormat.CBR) BookFormat.CBR else BookFormat.CBZ)
        }
}
