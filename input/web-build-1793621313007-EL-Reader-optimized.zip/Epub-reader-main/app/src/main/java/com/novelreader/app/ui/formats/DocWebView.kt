package com.novelreader.app.ui.formats

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.novelreader.app.core.FontCss
import com.novelreader.app.data.CustomFont
import com.novelreader.app.formats.doc.DocFonts
import com.novelreader.app.formats.doc.DocPage
import com.novelreader.app.formats.doc.DocReaderViewModel
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream

/** The private host the document is served from; every request to it is answered by [DocWebClient], nothing goes to the network. */
private const val HOST = "doc.local"

/** Answers the WebView's requests from the loaded document, the app's assets and the font files; everything else is refused. */
internal class DocWebClient(
    private val context: Context,
    private val page: DocPage,
    private val custom: List<CustomFont>,
    private val fontsDir: File,
    private val onFinished: (WebView) -> Unit,
    private val onGone: () -> Unit,
) : WebViewClient() {

    private val fontsCss: ByteArray = DocFonts.css(custom).toByteArray(Charsets.UTF_8)

    private fun response(mime: String, status: Int, stream: java.io.InputStream): WebResourceResponse =
        WebResourceResponse(mime, "utf-8", status, if (status == 200) "OK" else "Not Found", mapOf("Cache-Control" to "no-store"), stream)

    private fun notFound() = response("text/plain", 404, ByteArrayInputStream(ByteArray(0)))

    override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
        val url = request.url
        if (url.host != HOST) return response("text/plain", 403, ByteArrayInputStream(ByteArray(0)))
        val path = url.path ?: return notFound()
        return try {
            when {
                path == "/index.html" -> response("text/html", 200, page.openHtml())
                path == "/doc.css" -> response("text/css", 200, context.assets.open("doc/doc.css"))
                path == "/doc.js" -> response("application/javascript", 200, context.assets.open("doc/doc.js"))
                path == "/fonts.css" -> response("text/css", 200, ByteArrayInputStream(fontsCss))
                path.startsWith("/f/asset/") -> {
                    val name = path.removePrefix("/f/asset/")
                    if (name in DocFonts.BUNDLED.values) response("font/ttf", 200, context.assets.open("fonts/$name")) else notFound()
                }
                path.startsWith("/f/") -> {
                    val file = path.removePrefix("/f/")
                    val id = file.substringBefore('.')
                    val f = custom.firstOrNull { it.id == id && "${it.id}.${it.extension}" == file && FontCss.isValidId(it.id) }
                    if (f == null) notFound() else response(if (f.extension == "otf") "font/otf" else "font/ttf", 200, FileInputStream(File(fontsDir, file)))
                }
                path.startsWith("/m/") -> {
                    val img = path.removePrefix("/m/").toIntOrNull()?.let { page.openImage(it) }
                    if (img == null) notFound() else response(img.first, 200, img.second)
                }
                else -> notFound()
            }
        } catch (e: Exception) {
            notFound()
        }
    }

    // The document never navigates: links are handled by the page script, which reports them to the app.
    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = true

    override fun onPageFinished(view: WebView, url: String?) = onFinished(view)

    override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
        onGone()
        return true
    }
}

/** What the page script calls (on a background thread). */
internal class DocBridge(
    private val vm: DocReaderViewModel,
    private val onLink: (String) -> Unit,
    private val onTap: (Float, Float) -> Unit,
) {
    private val main = Handler(Looper.getMainLooper())

    @JavascriptInterface fun onReady(blocks: Int) {}
    @JavascriptInterface fun onLoaded() {}
    @JavascriptInterface fun onPosition(block: Int, frac: Double) = vm.onViewport(block, frac)
    @JavascriptInterface fun onSelection(json: String) = vm.onSelection(json)
    @JavascriptInterface fun onHighlightTap(id: Long) { vm.editHighlight(id) }
    @JavascriptInterface fun onAnchor(name: String) { main.post { vm.goToAnchor(name) } }
    @JavascriptInterface fun onLink(href: String) { main.post { onLink.invoke(href) } }
    @JavascriptInterface fun onTap(x: Double, y: Double) { main.post { onTap.invoke(x.toFloat(), y.toFloat()) } }
}

/**
 * The document page. [styleJson], [highlightsJson] and the search hits are pushed into the running page whenever
 * they change, so changing a setting never reloads the document. [vm] supplies the start position and receives
 * position, selection and taps.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
internal fun DocWebView(
    page: DocPage,
    custom: List<CustomFont>,
    fontsDir: File,
    styleJson: String,
    background: Int,
    highlightsJson: String,
    hitsJson: String,
    activeHit: Int,
    vm: DocReaderViewModel,
    onLink: (String) -> Unit,
    onTap: (Float, Float) -> Unit,
    onGone: () -> Unit,
    onWebView: (WebView?) -> Unit,
    modifier: Modifier = Modifier,
) {
    val latestStyle by rememberUpdatedState(styleJson)
    val latestHighlights by rememberUpdatedState(highlightsJson)
    val latestHits by rememberUpdatedState(hitsJson)
    val latestActive by rememberUpdatedState(activeHit)
    var web by remember { mutableStateOf<WebView?>(null) }
    var inited by remember { mutableStateOf(false) }
    val appliedStyle = remember { arrayOf("") }
    val appliedHighlights = remember { arrayOf("") }

    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            WebView(ctx).apply {
                setBackgroundColor(background)
                overScrollMode = android.view.View.OVER_SCROLL_NEVER
                with(settings) {
                    javaScriptEnabled = true
                    domStorageEnabled = false
                    allowFileAccess = false
                    allowContentAccess = false
                    setSupportZoom(false)
                    builtInZoomControls = false
                    displayZoomControls = false
                    textZoom = 100
                    cacheMode = android.webkit.WebSettings.LOAD_NO_CACHE
                    safeBrowsingEnabled = false
                }
                addJavascriptInterface(DocBridge(vm, onLink, onTap), "NR")
                webViewClient = DocWebClient(ctx.applicationContext, page, custom, fontsDir, onFinished = { v ->
                    if (!inited) {
                        inited = true
                        val j = vm.currentJump()
                        val cfg = JSONObject()
                            .put("style", JSONObject(latestStyle))
                            .put("block", j.block).put("frac", j.frac)
                            .put("highlights", JSONArray(latestHighlights))
                        appliedStyle[0] = latestStyle
                        appliedHighlights[0] = latestHighlights
                        v.evaluateJavascript("DocApp.init($cfg)", null)
                    }
                }, onGone = onGone)
                loadUrl("https://$HOST/index.html")
                web = this
                onWebView(this)
            }
        },
        update = { it.setBackgroundColor(background) },
        onRelease = { v ->
            onWebView(null)
            v.removeJavascriptInterface("NR")
            v.stopLoading()
            v.destroy()
        },
    )

    LaunchedEffect(inited, styleJson) {
        val w = web ?: return@LaunchedEffect
        if (inited && styleJson != appliedStyle[0]) { appliedStyle[0] = styleJson; w.evaluateJavascript("DocApp.setStyle($styleJson)", null) }
    }
    LaunchedEffect(inited, highlightsJson) {
        val w = web ?: return@LaunchedEffect
        if (inited && highlightsJson != appliedHighlights[0]) { appliedHighlights[0] = highlightsJson; w.evaluateJavascript("DocApp.setHighlights($highlightsJson)", null) }
    }
    LaunchedEffect(inited, hitsJson) {
        val w = web ?: return@LaunchedEffect
        if (inited) w.evaluateJavascript("DocApp.setSearch($hitsJson, $latestActive)", null)
    }
    LaunchedEffect(inited, activeHit) {
        val w = web ?: return@LaunchedEffect
        if (inited) w.evaluateJavascript("DocApp.showHit($activeHit, true)", null)
    }
    LaunchedEffect(inited) {
        if (!inited) return@LaunchedEffect
        vm.commands.collect { j -> web?.evaluateJavascript("DocApp.scrollToBlock(${j.block}, ${j.frac}, ${j.offsetPx})", null) }
    }
    LaunchedEffect(inited) {
        if (!inited) return@LaunchedEffect
        vm.clearSelectionRequests.collect { web?.evaluateJavascript("DocApp.clearSelection()", null) }
    }
}
