package com.novelreader.app.formats.doc

import com.novelreader.app.core.FontCss
import com.novelreader.app.data.CustomFont

/** The @font-face rules of the document view (pure, unit-tested). */
object DocFonts {

    /** Fonts shipped inside the APK (assets/fonts): CSS family to file name. Only these names are ever served from assets. */
    val BUNDLED: Map<String, String> = linkedMapOf(
        "Vazirmatn" to "Vazirmatn-Regular.ttf",
        "Amiri" to "Amiri-Regular.ttf",
        "Lora" to "Lora-Regular.ttf",
    )

    fun customFamily(font: CustomFont): String = FontCss.singleFamily(font.id)

    private fun cssString(s: String): String = s.filter { it != '"' && it != '\\' && it != '\n' && it != '\r' && it != '<' && it != '>' }

    fun css(custom: List<CustomFont>): String {
        val sb = StringBuilder()
        for ((family, file) in BUNDLED) {
            sb.append("@font-face{font-family:\"").append(family).append("\";src:url(\"/f/asset/").append(file).append("\");font-weight:400;font-style:normal;font-display:swap}")
        }
        for (f in custom) {
            if (!FontCss.isValidId(f.id) || (f.extension != "ttf" && f.extension != "otf")) continue
            val format = if (f.extension == "otf") "opentype" else "truetype"
            val weight = if (f.variableMin != null && f.variableMax != null) "${f.variableMin} ${f.variableMax}" else f.weight.toString()
            val style = if (f.italic) "italic" else "normal"
            // Under its own id (chosen in the settings) and under the font's real name (so a .docx asking for it finds it).
            for (family in listOf(customFamily(f), cssString(f.family))) {
                if (family.isBlank()) continue
                sb.append("@font-face{font-family:\"").append(family).append("\";src:url(\"/f/").append(f.id).append('.').append(f.extension)
                    .append("\") format(\"").append(format).append("\");font-weight:").append(weight).append(";font-style:").append(style).append(";font-display:swap}")
            }
        }
        return sb.toString()
    }
}
