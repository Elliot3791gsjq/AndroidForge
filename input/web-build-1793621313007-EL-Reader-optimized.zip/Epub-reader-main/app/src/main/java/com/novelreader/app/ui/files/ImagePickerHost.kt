package com.novelreader.app.ui.files

import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.novelreader.app.R
import com.novelreader.app.core.PickKind
import com.novelreader.app.ui.AppIcons
import com.novelreader.app.ui.design.AppCard
import com.novelreader.app.ui.design.AppSheet
import com.novelreader.app.ui.design.MutedText
import com.novelreader.app.ui.design.Space
import com.novelreader.app.ui.design.palette

/**
 * "Choose an image from…" sheet with every way to reach pictures on the phone, not just the system "Open from":
 * the Gallery app, any file-manager app (Samsung My Files, Files by Google…), and the in-app storage browser.
 * The picked image is handed back as a Uri the caller can read right away.
 */
@Composable
fun ImagePickerHost(visible: Boolean, onDismiss: () -> Unit, onPicked: (Uri) -> Unit) {
    if (!visible) return

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) onPicked(uri)
    }
    val galleryApp = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        r.data?.data?.let(onPicked)
    }
    val fileManagerApp = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        r.data?.data?.let(onPicked)
    }
    val browse = rememberLauncherForActivityResult(PickFromStorage()) { list ->
        list.firstOrNull()?.let { onPicked(Uri.parse(it)) }
    }
    val chooserTitle = stringResource(R.string.image_source_files)

    AppSheet(onDismiss = onDismiss) {
        Column(Modifier.padding(horizontal = Space.gutter).padding(bottom = Space.xxl).navigationBarsPadding()) {
            Text(
                stringResource(R.string.image_source_title),
                style = MaterialTheme.typography.titleMedium, color = palette.text,
                modifier = Modifier.padding(bottom = Space.m),
            )
            SourceRow(AppIcons.PhotoLibrary, stringResource(R.string.image_source_gallery), stringResource(R.string.image_source_gallery_hint)) {
                // The gallery app (Samsung Gallery, Google Photos…); the system photo picker when none answers.
                val pick = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI).apply { type = "image/*" }
                try {
                    galleryApp.launch(pick)
                } catch (_: Exception) {
                    photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
            }
            Spacer(Modifier.height(Space.s))
            SourceRow(AppIcons.Folder, stringResource(R.string.image_source_files), stringResource(R.string.image_source_files_hint)) {
                val get = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "image/*"
                }
                try {
                    fileManagerApp.launch(Intent.createChooser(get, chooserTitle))
                } catch (_: Exception) {
                    photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
            }
            Spacer(Modifier.height(Space.s))
            SourceRow(AppIcons.FolderOpen, stringResource(R.string.image_source_browse), stringResource(R.string.image_source_browse_hint)) {
                browse.launch(PickKind.IMAGE)
            }
        }
    }
}

@Composable
private fun SourceRow(icon: ImageVector, title: String, hint: String, onClick: () -> Unit) {
    val p = palette
    AppCard(Modifier.fillMaxWidth(), onClick = onClick) {
        Row(Modifier.padding(Space.m), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).clip(CircleShape).background(p.accentSoft), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = p.onAccentSoft, modifier = Modifier.size(22.dp))
            }
            Column(Modifier.padding(start = Space.m)) {
                Text(title, style = MaterialTheme.typography.titleSmall, color = p.text)
                MutedText(hint)
            }
        }
    }
}
