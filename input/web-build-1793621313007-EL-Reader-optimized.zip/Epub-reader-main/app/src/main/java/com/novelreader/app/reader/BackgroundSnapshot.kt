package com.novelreader.app.reader

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import com.novelreader.app.data.BgImageMode
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Paints the reader's backdrop (solid colour + optional picture) into a plain bitmap canvas. The live backdrop is a
 * Compose layer behind the page ([com.novelreader.app.ui.reader.ReaderBackground]); this is the same picture drawn
 * the same way for the snapshot of the page that is being turned, so the turning page is opaque like real paper.
 */
object BackgroundSnapshot {
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)

    fun draw(canvas: Canvas, w: Int, h: Int, color: Int, image: Bitmap?, mode: BgImageMode, opacity: Float) {
        canvas.drawColor(color or (0xFF shl 24))
        if (image == null || image.isRecycled || w <= 0 || h <= 0) return
        paint.alpha = (opacity.coerceIn(0f, 1f) * 255).roundToInt()
        val iw = image.width.toFloat()
        val ih = image.height.toFloat()
        if (iw <= 0f || ih <= 0f) return
        when (mode) {
            BgImageMode.COVER -> {
                val scale = max(w / iw, h / ih)
                val dw = iw * scale
                val dh = ih * scale
                val l = (w - dw) / 2f
                val t = (h - dh) / 2f
                canvas.drawBitmap(image, null, RectF(l, t, l + dw, t + dh), paint)
            }
            BgImageMode.FIT -> {
                val scale = min(w / iw, h / ih)
                val dw = iw * scale
                val dh = ih * scale
                val l = (w - dw) / 2f
                val t = (h - dh) / 2f
                canvas.drawBitmap(image, null, RectF(l, t, l + dw, t + dh), paint)
            }
            BgImageMode.TILE -> {
                val src = Rect(0, 0, image.width, image.height)
                var y = 0
                while (y < h) {
                    var x = 0
                    while (x < w) {
                        canvas.drawBitmap(image, src, Rect(x, y, x + image.width, y + image.height), paint)
                        x += image.width
                    }
                    y += image.height
                }
            }
        }
        paint.alpha = 255
    }
}
