package com.novelreader.app.ui.formats

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.novelreader.app.R
import com.novelreader.app.data.AnnotationStyle
import com.novelreader.app.formats.FormatLocator
import com.novelreader.app.formats.PdfDark
import com.novelreader.app.formats.PdfDirection
import com.novelreader.app.formats.PdfReadMode
import com.novelreader.app.formats.PdfSettings
import com.novelreader.app.formats.PdfSpread
import com.novelreader.app.formats.pdf.PdfFailure
import com.novelreader.app.formats.pdf.PdfFit
import com.novelreader.app.formats.pdf.PdfGeometry
import com.novelreader.app.formats.pdf.PdfHighlightItem
import com.novelreader.app.formats.pdf.PdfLoad
import com.novelreader.app.formats.pdf.PdfReaderViewModel
import com.novelreader.app.ui.AppIcons
import com.novelreader.app.ui.Localized
import com.novelreader.app.ui.design.AccentButton
import com.novelreader.app.ui.design.AppDialog
import com.novelreader.app.ui.design.AppSheet
import com.novelreader.app.ui.design.AppSlider
import com.novelreader.app.ui.design.AppTextField
import com.novelreader.app.ui.design.ColorDot
import com.novelreader.app.ui.design.GhostButton
import com.novelreader.app.ui.design.MutedText
import com.novelreader.app.ui.design.SettingsGroup
import com.novelreader.app.ui.design.appClickable
import com.novelreader.app.ui.design.palette

private enum class PdfSheet { SETTINGS, PAGES, BOOKMARKS, GOTO, RESULTS }

/** Colours offered for highlights, underlines and notes. */
private val AnnotationColors = listOf(0xFFFFEB3B, 0xFF81C784, 0xFF64B5F6, 0xFFF48FB1, 0xFFFFB74D).map { it.toInt() }

@Composable
fun PdfReaderScreen(vm: PdfReaderViewModel, onBack: () -> Unit) {
    val load by vm.load.collectAsState()
    val settings by vm.settings.collectAsState()
    when (val l = load) {
        PdfLoad.Loading -> Box(Modifier.fillMaxSize().background(palette.bg), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = palette.accent)
        }
        is PdfLoad.Failed -> FormatOpenError(
            stringResource(
                when (l.reason) {
                    PdfFailure.MISSING -> R.string.fmt_err_missing
                    PdfFailure.ENCRYPTED -> R.string.fmt_err_encrypted
                    PdfFailure.CORRUPT -> R.string.fmt_err_corrupt
                }
            ),
            onBack,
        )
        is PdfLoad.Ready -> {
            val s = settings
            if (s == null) Box(Modifier.fillMaxSize().background(palette.bg)) else PdfReaderContent(vm, l, s, onBack)
        }
    }
}

@Composable
private fun PdfReaderContent(vm: PdfReaderViewModel, ready: PdfLoad.Ready, s: PdfSettings, onBack: () -> Unit) {
    val p = palette
    val engine = vm.engine ?: return
    val chrome by vm.chromeVisible.collectAsState()
    val page by vm.page.collectAsState()
    val rotation by vm.rotation.collectAsState()
    val sizesVersion by vm.sizes.collectAsState()
    val bookmarks by vm.bookmarks.collectAsState()
    val selection by vm.selection.collectAsState()
    val hits by vm.hits.collectAsState()
    val activeHit by vm.activeHit.collectAsState()
    val query by vm.query.collectAsState()
    val progress by vm.searchProgress.collectAsState()
    val context = LocalContext.current
    val config = LocalConfiguration.current
    val landscape = config.screenWidthDp > config.screenHeightDp

    val paged = s.readMode == PdfReadMode.PAGED
    val rtl = s.direction == PdfDirection.RTL
    val dual = s.spread == PdfSpread.DUAL || (s.spread == PdfSpread.AUTO && landscape)
    val invert = s.dark == PdfDark.ON || (s.dark == PdfDark.AUTO && p.dark)
    val total = ready.pageCount
    val actualPpp = (context.resources.displayMetrics.xdpi / 72f).coerceIn(1f, 8f)

    var sheet by remember { mutableStateOf<PdfSheet?>(null) }
    var searchOpen by remember { mutableStateOf(false) }
    var searchText by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<PdfHighlightItem?>(null) }
    var noteDialog by remember { mutableStateOf(false) }
    var annColor by remember { mutableIntStateOf(AnnotationColors[0]) }
    val pageLabel = { n: Int -> context.getString(R.string.fmt_page_label, Localized.number(n)) }

    BackHandler(enabled = selection != null || searchOpen) {
        if (selection != null) vm.clearSelection() else { searchOpen = false; vm.clearSearch() }
    }

    BoxWithConstraints(Modifier.fillMaxSize().background(Color(s.background))) {
        val vw = constraints.maxWidth
        val vh = constraints.maxHeight
        val cells = remember(total, dual, s.coverAlone, rtl, rotation, sizesVersion) {
            PdfGeometry.cells(total, dual, s.coverAlone, rtl) { i ->
                engine.sizeOrGuess(i).let { PdfGeometry.displaySize(it.w, it.h, rotation) }
            }
        }
        val actions = remember(vm) { PdfTapActions(onToggleChrome = { vm.toggleChrome() }, onOpenHighlight = { editing = it }) }

        if (vw > 0 && vh > 0) {
            if (paged) {
                PdfPagedViewer(vm, s, cells, rtl, rotation, invert, vw, vh, actualPpp, actions, layoutKey = listOf(dual, s.coverAlone, rtl, rotation).hashCode())
            } else {
                PdfScrollViewer(vm, s, cells, rotation, invert, vw, vh, actualPpp, actions)
            }
        }

        if (!chrome && s.showPageNumber && !searchOpen) {
            Box(
                Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 10.dp)
                    .clip(CircleShape).background(Color.Black.copy(alpha = 0.55f)).padding(horizontal = 12.dp, vertical = 4.dp),
            ) {
                Text("${Localized.number(page + 1)} / ${Localized.number(total)}", color = Color.White, style = MaterialTheme.typography.labelMedium)
            }
        }

        Column(Modifier.align(Alignment.TopCenter)) {
            AnimatedVisibility(
                visible = chrome,
                enter = fadeIn() + slideInVertically { -it }, exit = fadeOut() + slideOutVertically { -it },
            ) {
                FormatTopBar(ready.title, onBack) {
                    if (vm.textSupported) GlassButton(AppIcons.Search, stringResource(R.string.pdf_search), { searchOpen = true }, selected = searchOpen)
                    GlassButton(AppIcons.BookmarkAdd, stringResource(R.string.bookmarks), { sheet = PdfSheet.BOOKMARKS })
                    GlassButton(AppIcons.GridView, stringResource(R.string.fmt_pages), { sheet = PdfSheet.PAGES })
                    GlassButton(AppIcons.Tune, stringResource(R.string.fmt_settings), { sheet = PdfSheet.SETTINGS })
                }
            }
            if (searchOpen) {
                PdfSearchBar(
                    text = searchText, onText = { searchText = it },
                    onSearch = { vm.search(searchText) },
                    count = hits.size, active = activeHit, progress = progress, searched = query.isNotEmpty(),
                    onPrev = { vm.stepHit(-1) }, onNext = { vm.stepHit(1) },
                    onList = { sheet = PdfSheet.RESULTS },
                    onClose = { searchOpen = false; vm.clearSearch() },
                    modifier = if (chrome) Modifier else Modifier.statusBarsPadding(),
                )
            }
            if (selection != null) {
                PdfSelectionBar(
                    color = annColor,
                    onColor = { c -> annColor = c; vm.annotateSelection(AnnotationStyle.HIGHLIGHT, c, null, pageLabel((selection?.page ?: 0) + 1)) },
                    onCopy = {
                        selection?.text?.let { t ->
                            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            cm.setPrimaryClip(ClipData.newPlainText("PDF", t))
                            Toast.makeText(context, R.string.pdf_copied, Toast.LENGTH_SHORT).show()
                        }
                    },
                    onUnderline = { vm.annotateSelection(AnnotationStyle.UNDERLINE, annColor, null, pageLabel((selection?.page ?: 0) + 1)) },
                    onNote = { noteDialog = true },
                    onClose = { vm.clearSelection() },
                    modifier = if (chrome || searchOpen) Modifier else Modifier.statusBarsPadding(),
                )
            }
        }

        AnimatedVisibility(
            visible = chrome, modifier = Modifier.align(Alignment.BottomCenter),
            enter = fadeIn() + slideInVertically { it }, exit = fadeOut() + slideOutVertically { it },
        ) {
            PageSliderBar(
                current = page, total = total, onSeek = { vm.goTo(it) }, rtl = rtl && paged,
                trailing = { GhostButton(stringResource(R.string.fmt_go_to_page), { sheet = PdfSheet.GOTO }, height = 32.dp) },
            )
        }
    }

    when (sheet) {
        PdfSheet.SETTINGS -> PdfSettingsSheet(s, vm, rotation, onDismiss = { sheet = null })
        PdfSheet.PAGES -> PdfThumbnailsSheet(vm, total, page, onPick = { vm.goTo(it); sheet = null }, onDismiss = { sheet = null })
        PdfSheet.BOOKMARKS -> FormatBookmarksSheet(
            bookmarks = bookmarks,
            label = { b -> (FormatLocator.parse(b.locatorJson) as? FormatLocator.Pdf)?.let { pageLabel(it.page + 1) } ?: "" },
            onAdd = { vm.addBookmarkHere(pageLabel(page + 1)) },
            onOpen = { b -> (FormatLocator.parse(b.locatorJson) as? FormatLocator.Pdf)?.let { vm.goTo(it.page, it.y.toFloat()) }; sheet = null },
            onDelete = { vm.deleteBookmark(it.id) },
            onDismiss = { sheet = null },
        )
        PdfSheet.GOTO -> GoToPageDialog(total, page, onDismiss = { sheet = null }, onGo = { vm.goTo(it) })
        PdfSheet.RESULTS -> PdfResultsSheet(vm, hits.map { it.page }, activeHit, onPick = { vm.openHit(it); sheet = null }, onDismiss = { sheet = null })
        null -> {}
    }

    if (noteDialog) {
        var note by remember { mutableStateOf("") }
        AppDialog(
            onDismissRequest = { noteDialog = false },
            title = { Text(stringResource(R.string.pdf_note)) },
            text = {
                Column {
                    selection?.text?.let { Text(it, maxLines = 4, style = MaterialTheme.typography.bodySmall, color = p.textMuted); Spacer(Modifier.height(10.dp)) }
                    AppTextField(note, { note = it }, placeholder = stringResource(R.string.pdf_note_hint), singleLine = false)
                }
            },
            confirmButton = {
                AccentButton(stringResource(R.string.pdf_save), {
                    vm.annotateSelection(AnnotationStyle.NOTE, annColor, note, pageLabel((selection?.page ?: 0) + 1))
                    noteDialog = false
                }, enabled = note.isNotBlank(), height = 44.dp)
            },
            dismissButton = { GhostButton(stringResource(R.string.cancel), { noteDialog = false }, height = 44.dp) },
        )
    }

    editing?.let { item ->
        var note by remember(item.entity.id) { mutableStateOf(item.entity.note.orEmpty()) }
        var color by remember(item.entity.id) { mutableIntStateOf(item.entity.color) }
        AppDialog(
            onDismissRequest = { editing = null },
            title = { Text(stringResource(R.string.pdf_edit_annotation)) },
            text = {
                Column {
                    Text(item.entity.text, maxLines = 5, style = MaterialTheme.typography.bodySmall, color = p.textMuted)
                    Spacer(Modifier.height(10.dp))
                    AppTextField(note, { note = it }, placeholder = stringResource(R.string.pdf_note_hint), singleLine = false)
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        AnnotationColors.forEach { c -> ColorDot(Color(c), color == c, onClick = { color = c }) }
                    }
                    Spacer(Modifier.height(8.dp))
                    GhostButton(stringResource(R.string.pdf_delete), { vm.deleteHighlight(item.entity.id); editing = null }, destructive = true, height = 40.dp)
                }
            },
            confirmButton = {
                AccentButton(stringResource(R.string.pdf_save), {
                    vm.updateHighlight(item.entity.copy(note = note.trim().ifEmpty { null }, color = color))
                    editing = null
                }, height = 44.dp)
            },
            dismissButton = { GhostButton(stringResource(R.string.cancel), { editing = null }, height = 44.dp) },
        )
    }
}

// ================================================================================================================
// Search and selection bars
// ================================================================================================================

@Composable
private fun PdfSearchBar(
    text: String,
    onText: (String) -> Unit,
    onSearch: () -> Unit,
    count: Int,
    active: Int,
    progress: Float,
    searched: Boolean,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onList: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val p = palette
    Column(
        modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(20.dp)).background(p.surface.copy(alpha = 0.97f))
            .border(1.dp, p.outline.copy(alpha = 0.7f), RoundedCornerShape(20.dp)).padding(8.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            AppTextField(
                value = text, onValueChange = onText, modifier = Modifier.weight(1f),
                placeholder = stringResource(R.string.pdf_search_hint), leadingIcon = AppIcons.Search,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { onSearch() }),
                minHeight = 40.dp,
            )
            GlassButton(AppIcons.Close, stringResource(R.string.pdf_search_close), onClose)
        }
        if (searched) {
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                val label = when {
                    count > 0 -> stringResource(R.string.pdf_match_of, Localized.number(active + 1), Localized.number(count))
                    progress < 1f -> stringResource(R.string.pdf_searching, Localized.number((progress * 100).toInt()))
                    else -> stringResource(R.string.pdf_no_matches)
                }
                Text(
                    label, Modifier.weight(1f).then(if (count > 0) Modifier.appClickable(onList) else Modifier),
                    style = MaterialTheme.typography.bodySmall, color = if (count > 0) p.accentText else p.textMuted,
                )
                if (count > 0 && progress < 1f) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = p.accent)
                if (count > 0) {
                    GlassButton(AppIcons.ArrowUp, stringResource(R.string.pdf_search_prev), onPrev)
                    GlassButton(AppIcons.ArrowDown, stringResource(R.string.pdf_search_next), onNext)
                }
            }
        }
    }
}

@Composable
private fun PdfSelectionBar(
    color: Int,
    onColor: (Int) -> Unit,
    onCopy: () -> Unit,
    onUnderline: () -> Unit,
    onNote: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val p = palette
    Row(
        modifier.padding(horizontal = 12.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(24.dp)).background(p.surface.copy(alpha = 0.97f))
            .border(1.dp, p.outline.copy(alpha = 0.7f), RoundedCornerShape(24.dp))
            .horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        GlassButton(AppIcons.ContentCopy, stringResource(R.string.pdf_copy), onCopy)
        AnnotationColors.forEach { c -> ColorDot(Color(c), c == color, onClick = { onColor(c) }) }
        GlassButton(AppIcons.FormatUnderlined, stringResource(R.string.pdf_underline), onUnderline)
        GlassButton(AppIcons.Notes, stringResource(R.string.pdf_note), onNote)
        GlassButton(AppIcons.Close, stringResource(R.string.pdf_clear_selection), onClose)
    }
}

// ================================================================================================================
// Sheets
// ================================================================================================================

@Composable
private fun PdfSettingsSheet(s: PdfSettings, vm: PdfReaderViewModel, rotation: Int, onDismiss: () -> Unit) {
    AppSheet(onDismiss) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 24.dp)) {
            Text(stringResource(R.string.fmt_settings), style = MaterialTheme.typography.titleLarge, color = palette.text)
            MutedText(stringResource(R.string.fmt_settings_note, "PDF"), Modifier.padding(top = 4.dp, bottom = 8.dp))

            SettingsGroup(null) {
                ChoiceSetting(
                    stringResource(R.string.pdf_read_mode),
                    listOf(stringResource(R.string.pdf_mode_scroll), stringResource(R.string.pdf_mode_paged)),
                    if (s.readMode == PdfReadMode.PAGED) 1 else 0,
                    { i -> vm.updateSettings { it.copy(readMode = if (i == 1) PdfReadMode.PAGED else PdfReadMode.SCROLL) } },
                )
                RadioSetting(
                    stringResource(R.string.pdf_fit),
                    listOf(stringResource(R.string.pdf_fit_width), stringResource(R.string.pdf_fit_page), stringResource(R.string.pdf_fit_actual)),
                    PdfFit.entries.indexOf(s.fit),
                    { i -> vm.updateSettings { it.copy(fit = PdfFit.entries[i]) } },
                    note = if (s.fit == PdfFit.ACTUAL) stringResource(R.string.pdf_fit_actual_note) else null,
                )
            }
            SettingsGroup(null, Modifier.padding(top = 12.dp)) {
                ChoiceSetting(
                    stringResource(R.string.pdf_spread),
                    listOf(stringResource(R.string.pdf_spread_single), stringResource(R.string.pdf_spread_dual), stringResource(R.string.pdf_spread_auto)),
                    PdfSpread.entries.indexOf(s.spread),
                    { i -> vm.updateSettings { it.copy(spread = PdfSpread.entries[i]) } },
                )
                if (s.spread == PdfSpread.AUTO) MutedText(stringResource(R.string.pdf_spread_auto_note))
                if (s.spread != PdfSpread.SINGLE) {
                    SwitchSetting(stringResource(R.string.pdf_cover_alone), s.coverAlone, { v -> vm.updateSettings { it.copy(coverAlone = v) } })
                }
                ChoiceSetting(
                    stringResource(R.string.pdf_direction),
                    listOf(stringResource(R.string.pdf_dir_ltr), stringResource(R.string.pdf_dir_rtl)),
                    if (s.direction == PdfDirection.RTL) 1 else 0,
                    { i -> vm.updateSettings { it.copy(direction = if (i == 1) PdfDirection.RTL else PdfDirection.LTR) } },
                )
                MutedText(stringResource(R.string.pdf_dir_note))
            }
            SettingsGroup(null, Modifier.padding(top = 12.dp)) {
                ChoiceSetting(
                    stringResource(R.string.pdf_dark),
                    listOf(stringResource(R.string.pdf_dark_off), stringResource(R.string.pdf_dark_on), stringResource(R.string.pdf_dark_auto)),
                    PdfDark.entries.indexOf(s.dark),
                    { i -> vm.updateSettings { it.copy(dark = PdfDark.entries[i]) } },
                )
                MutedText(stringResource(R.string.pdf_dark_note))
                Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(stringResource(R.string.pdf_rotate), Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge, color = palette.text)
                    GlassButton(AppIcons.RotateLeft, stringResource(R.string.pdf_rotate_left), { vm.rotateBy(-90) })
                    Text(
                        stringResource(R.string.pdf_rotation_value, Localized.number(rotation)),
                        Modifier.padding(horizontal = 12.dp), style = MaterialTheme.typography.bodyMedium, color = palette.textMuted,
                    )
                    GlassButton(AppIcons.RotateRight, stringResource(R.string.pdf_rotate_right), { vm.rotateBy(90) })
                }
            }
            SettingsGroup(null, Modifier.padding(top = 12.dp)) {
                Column(Modifier.padding(vertical = 8.dp)) {
                    Text(stringResource(R.string.pdf_background), style = MaterialTheme.typography.bodyLarge, color = palette.text)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        listOf(0xFF3A3A3A, 0xFF000000, 0xFF808080, 0xFFF4ECD8, 0xFFFFFFFF).map { it.toInt() }.forEach { c ->
                            ColorDot(Color(c), s.background == c, onClick = { vm.updateSettings { it.copy(background = c) } })
                        }
                    }
                }
                if (s.readMode == PdfReadMode.PAGED) {
                    SwitchSetting(stringResource(R.string.pdf_tap_to_turn), s.tapToTurn, { v -> vm.updateSettings { it.copy(tapToTurn = v) } })
                } else {
                    Column(Modifier.padding(vertical = 8.dp)) {
                        Text(stringResource(R.string.pdf_page_gap), style = MaterialTheme.typography.bodyLarge, color = palette.text)
                        var gap by remember(s.pageGapDp) { mutableStateOf(s.pageGapDp.toFloat()) }
                        AppSlider(gap, { gap = it }, 0f..32f, onValueChangeFinished = { vm.updateSettings { it.copy(pageGapDp = gap.toInt()) } })
                    }
                }
                SwitchSetting(stringResource(R.string.pdf_show_page_number), s.showPageNumber, { v -> vm.updateSettings { it.copy(showPageNumber = v) } })
                SwitchSetting(stringResource(R.string.pdf_keep_awake), s.keepScreenOn, { v -> vm.updateSettings { it.copy(keepScreenOn = v) } })
            }
            MutedText(stringResource(R.string.pdf_zoom_hint), Modifier.padding(top = 12.dp))
            if (!vm.textSupported) MutedText(stringResource(R.string.pdf_text_unsupported), Modifier.padding(top = 4.dp))
        }
    }
}

@Composable
private fun PdfThumbnailsSheet(vm: PdfReaderViewModel, total: Int, current: Int, onPick: (Int) -> Unit, onDismiss: () -> Unit) {
    val p = palette
    AppSheet(onDismiss) {
        Text(stringResource(R.string.fmt_pages), style = MaterialTheme.typography.titleLarge, color = p.text, modifier = Modifier.padding(horizontal = 20.dp))
        val grid = rememberLazyGridState(initialFirstVisibleItemIndex = (current - 3).coerceAtLeast(0))
        LazyVerticalGrid(
            columns = GridCells.Adaptive(92.dp), state = grid,
            modifier = Modifier.fillMaxWidth().height(460.dp).padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items((0 until total).toList(), key = { it }) { i ->
                val thumb by produceState<android.graphics.Bitmap?>(null, i) { value = vm.thumb(i) }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        Modifier.fillMaxWidth().aspectRatio(0.7f).clip(RoundedCornerShape(8.dp)).background(Color.White)
                            .border(if (i == current) 3.dp else 1.dp, if (i == current) p.accent else p.outline, RoundedCornerShape(8.dp))
                            .pointerInput(i) { detectTapGestures { onPick(i) } },
                        contentAlignment = Alignment.Center,
                    ) {
                        thumb?.let { Image(it.asImageBitmap(), null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize()) }
                    }
                    Text(Localized.number(i + 1), style = MaterialTheme.typography.labelSmall, color = if (i == current) p.accentText else p.textMuted)
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun PdfResultsSheet(vm: PdfReaderViewModel, pages: List<Int>, active: Int, onPick: (Int) -> Unit, onDismiss: () -> Unit) {
    val p = palette
    val context = LocalContext.current
    AppSheet(onDismiss) {
        Text(stringResource(R.string.pdf_results), style = MaterialTheme.typography.titleLarge, color = p.text, modifier = Modifier.padding(horizontal = 20.dp))
        LazyColumn(Modifier.fillMaxWidth().height(420.dp).padding(horizontal = 12.dp)) {
            itemsIndexed(pages) { i, pg ->
                Row(
                    Modifier.fillMaxWidth().appClickable({ onPick(i) }, scaleTo = 0.99f).padding(horizontal = 8.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        context.getString(R.string.fmt_page_label, Localized.number(pg + 1)), Modifier.weight(1f),
                        style = MaterialTheme.typography.bodyMedium, color = if (i == active) p.accentText else p.text,
                    )
                    Text(Localized.number(i + 1), style = MaterialTheme.typography.labelMedium, color = p.textMuted)
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}
