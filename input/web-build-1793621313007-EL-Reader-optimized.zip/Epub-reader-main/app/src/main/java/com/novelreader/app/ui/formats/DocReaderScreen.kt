package com.novelreader.app.ui.formats

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.WebView
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.novelreader.app.R
import com.novelreader.app.core.ColorMath
import com.novelreader.app.data.AnnotationStyle
import com.novelreader.app.data.CustomFont
import com.novelreader.app.data.ReadingThemes
import com.novelreader.app.formats.BookFormat
import com.novelreader.app.formats.DocAlign
import com.novelreader.app.formats.DocDirection
import com.novelreader.app.formats.DocFont
import com.novelreader.app.formats.DocSettings
import com.novelreader.app.formats.FormatLocator
import com.novelreader.app.formats.doc.DocFailure
import com.novelreader.app.formats.doc.DocFonts
import com.novelreader.app.formats.doc.DocJs
import com.novelreader.app.formats.doc.DocLoadState
import com.novelreader.app.formats.doc.DocReaderViewModel
import com.novelreader.app.formats.doc.DocWarningKind
import com.novelreader.app.formats.doc.ParagraphMode
import com.novelreader.app.formats.doc.TextEncoding
import com.novelreader.app.graph
import com.novelreader.app.ui.AppIcons
import com.novelreader.app.ui.ChoiceChips
import com.novelreader.app.ui.ColorPickerDialog
import com.novelreader.app.ui.Localized
import com.novelreader.app.ui.StepperSlider
import com.novelreader.app.ui.design.AccentButton
import com.novelreader.app.ui.design.AppDialog
import com.novelreader.app.ui.design.AppSheet
import com.novelreader.app.ui.design.AppTextField
import com.novelreader.app.ui.design.ColorDot
import com.novelreader.app.ui.design.GhostButton
import com.novelreader.app.ui.design.MutedText
import com.novelreader.app.ui.design.SegmentedControl
import com.novelreader.app.ui.design.SettingsGroup
import com.novelreader.app.ui.design.SoftIconButton
import com.novelreader.app.ui.design.appClickable
import com.novelreader.app.ui.design.palette

private enum class DocSheet { SETTINGS, CONTENTS, MARKS, RESULTS }

private val AnnotationColors = listOf(0xFFFFEB3B, 0xFF81C784, 0xFF64B5F6, 0xFFF48FB1, 0xFFFFB74D).map { it.toInt() }

@Composable
fun DocReaderScreen(vm: DocReaderViewModel, onBack: () -> Unit) {
    val load by vm.load.collectAsState()
    val settings by vm.settings.collectAsState()
    when (val l = load) {
        DocLoadState.Loading -> Box(Modifier.fillMaxSize().background(palette.bg), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = palette.accent)
        }
        is DocLoadState.Failed -> FormatOpenError(
            stringResource(
                when (l.reason) {
                    DocFailure.MISSING -> R.string.fmt_err_missing
                    DocFailure.CORRUPT -> R.string.fmt_err_corrupt
                    DocFailure.EMPTY -> R.string.fmt_err_empty
                    DocFailure.TOO_LARGE -> R.string.doc_err_too_large
                }
            ),
            onBack,
        )
        is DocLoadState.Ready -> {
            val s = settings
            if (s == null) Box(Modifier.fillMaxSize().background(palette.bg)) else DocReaderContent(vm, l, s, onBack)
        }
    }
}

/** Reading colours: the chosen theme (or the app's own), then the user's explicit text / background colours. */
private fun readingColors(s: DocSettings, appBg: Int, appText: Int): Pair<Int, Int> {
    val theme = ReadingThemes.all.firstOrNull { it.id == s.themeId }
    val bg = s.backgroundColor ?: theme?.background ?: appBg
    val fg = s.textColor ?: theme?.text ?: appText
    return fg to bg
}

private fun styleKind(style: String): String = when (style) {
    AnnotationStyle.UNDERLINE.name -> "ul"
    AnnotationStyle.STRIKE.name -> "st"
    AnnotationStyle.NOTE.name -> "nt"
    else -> "hl"
}

@Composable
private fun DocReaderContent(vm: DocReaderViewModel, ready: DocLoadState.Ready, s: DocSettings, onBack: () -> Unit) {
    val p = palette
    val context = LocalContext.current
    val chrome by vm.chromeVisible.collectAsState()
    val block by vm.blockFlow.collectAsState()
    val bookmarks by vm.bookmarks.collectAsState()
    val selection by vm.selection.collectAsState()
    val hits by vm.hits.collectAsState()
    val activeHit by vm.activeHit.collectAsState()
    val query by vm.query.collectAsState()
    val searching by vm.searching.collectAsState()
    val highlights by vm.highlights.collectAsState()
    val editing by vm.editing.collectAsState()
    val options by vm.options.collectAsState()
    val custom by context.graph.fonts.fonts.collectAsState(emptyList())
    val fontsDir = remember { context.graph.fonts.directory }

    val result = ready.page.result
    val total = ready.blockCount
    val format = ready.format

    var sheet by remember { mutableStateOf<DocSheet?>(null) }
    var searchOpen by remember { mutableStateOf(false) }
    var searchText by remember { mutableStateOf("") }
    var noteDialog by remember { mutableStateOf(false) }
    var annColor by remember { mutableIntStateOf(AnnotationColors[0]) }
    var engineGone by remember { mutableStateOf(false) }
    var warningsDismissed by rememberSaveable { mutableStateOf(false) }
    var web by remember { mutableStateOf<WebView?>(null) }

    val (fg, bg) = readingColors(s, p.bg.toArgb(), p.text.toArgb())
    val dark = ColorMath.isDark(bg)
    val customFamily = custom.firstOrNull { it.id == s.customFontId }?.let { DocFonts.customFamily(it) }
    val styleJson = remember(s, fg, bg, p.accentText, customFamily, format) {
        DocJs.style(s, format, fg, bg, p.accentText.toArgb(), dark, customFamily).toString()
    }
    val highlightsJson = remember(highlights, result) {
        DocJs.highlights(
            highlights.filter { it.valid }.map { DocJs.HighlightJs(it.entity.id, it.range, it.entity.color, styleKind(it.entity.style)) },
            result.texts,
        ).toString()
    }
    val hitsJson = remember(hits) { DocJs.hits(hits).toString() }
    val fallbackLabel = { Localized.percent((vm.blockProgress * 100).toInt()) }

    BackHandler(enabled = selection != null || searchOpen) {
        if (selection != null) vm.clearSelection() else { searchOpen = false; vm.clearSearch() }
    }

    val openLink: (String) -> Unit = { href ->
        try { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(href))) }
        catch (_: Exception) { Toast.makeText(context, R.string.doc_no_app_for_link, Toast.LENGTH_SHORT).show() }
    }
    val onTap: (Float, Float) -> Unit = { _, y ->
        when {
            s.tapScroll && y < 0.22f -> web?.evaluateJavascript("DocApp.pageScroll(-1)", null)
            s.tapScroll && y > 0.78f -> web?.evaluateJavascript("DocApp.pageScroll(1)", null)
            else -> vm.toggleChrome()
        }
    }

    Box(Modifier.fillMaxSize().background(Color(bg))) {
        if (engineGone) {
            FormatOpenError(stringResource(R.string.doc_engine_stopped), onBack)
        } else key(ready.page) {
            DocWebView(
                page = ready.page, custom = custom, fontsDir = fontsDir,
                styleJson = styleJson, background = bg, highlightsJson = highlightsJson,
                hitsJson = hitsJson, activeHit = activeHit, vm = vm,
                onLink = openLink, onTap = onTap, onGone = { engineGone = true }, onWebView = { web = it },
                modifier = Modifier.fillMaxSize(),
            )
        }

        if (!chrome && s.showProgress && !searchOpen) {
            Box(
                Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 10.dp)
                    .clip(CircleShape).background(Color.Black.copy(alpha = 0.55f)).padding(horizontal = 12.dp, vertical = 4.dp),
            ) {
                Text(Localized.percent(((block + 0.0) / total.coerceAtLeast(1) * 100).toInt()), color = Color.White, style = MaterialTheme.typography.labelMedium)
            }
        }

        Column(Modifier.align(Alignment.TopCenter)) {
            AnimatedVisibility(visible = chrome, enter = fadeIn() + slideInVertically { -it }, exit = fadeOut() + slideOutVertically { -it }) {
                FormatTopBar(ready.title, onBack) {
                    GlassButton(AppIcons.Search, stringResource(R.string.pdf_search), { searchOpen = true }, selected = searchOpen)
                    GlassButton(AppIcons.BookmarkAdd, stringResource(R.string.doc_marks), { sheet = DocSheet.MARKS })
                    if (result.outline.isNotEmpty()) GlassButton(AppIcons.ViewList, stringResource(R.string.doc_contents), { sheet = DocSheet.CONTENTS })
                    GlassButton(AppIcons.Tune, stringResource(R.string.fmt_settings), { sheet = DocSheet.SETTINGS })
                }
            }
            if (searchOpen) {
                DocSearchBar(
                    text = searchText, onText = { searchText = it }, onSearch = { vm.search(searchText) },
                    count = hits.size, active = activeHit, searching = searching, searched = query.isNotEmpty(),
                    onPrev = { vm.stepHit(-1) }, onNext = { vm.stepHit(1) }, onList = { sheet = DocSheet.RESULTS },
                    onClose = { searchOpen = false; vm.clearSearch() },
                    modifier = if (chrome) Modifier else Modifier.statusBarsPadding(),
                )
            }
            if (selection != null) {
                DocSelectionBar(
                    color = annColor,
                    onColor = { c -> annColor = c; vm.annotateSelection(AnnotationStyle.HIGHLIGHT, c, null, fallbackLabel()) },
                    onCopy = {
                        selection?.text?.let { t ->
                            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            cm.setPrimaryClip(ClipData.newPlainText("text", t))
                            Toast.makeText(context, R.string.pdf_copied, Toast.LENGTH_SHORT).show()
                        }
                    },
                    onUnderline = { vm.annotateSelection(AnnotationStyle.UNDERLINE, annColor, null, fallbackLabel()) },
                    onNote = { noteDialog = true },
                    onClose = { vm.clearSelection() },
                    modifier = if (chrome || searchOpen) Modifier else Modifier.statusBarsPadding(),
                )
            }
            val warns = result.warnings
            if (chrome && warns.isNotEmpty() && !warningsDismissed && selection == null) {
                DocWarningsCard(warns.map { warningText(context, it.kind, it.count) }) { warningsDismissed = true }
            }
        }

        AnimatedVisibility(
            visible = chrome, modifier = Modifier.align(Alignment.BottomCenter),
            enter = fadeIn() + slideInVertically { it }, exit = fadeOut() + slideOutVertically { it },
        ) {
            PageSliderBar(
                current = block, total = total, onSeek = { vm.goTo(it) },
                rtl = false,
                centerLabel = { b -> vm.chapterAt(b)?.title ?: "" },
            )
        }
    }

    when (sheet) {
        DocSheet.SETTINGS -> DocSettingsSheet(s, vm, format, custom, options.encoding, options.paragraphMode, ready.page.autoEncoding, onDismiss = { sheet = null })
        DocSheet.CONTENTS -> DocContentsSheet(vm, block, onPick = { b -> vm.goTo(b, 0.0, 24); sheet = null }, onDismiss = { sheet = null })
        DocSheet.MARKS -> DocMarksSheet(
            vm, bookmarks,
            label = { b -> (FormatLocator.parse(b.locatorJson) as? FormatLocator.Doc)?.let { vm.chapterAt(it.block)?.title } ?: "" },
            onOpenBookmark = { b -> (FormatLocator.parse(b.locatorJson) as? FormatLocator.Doc)?.let { vm.goTo(it.block, it.frac) }; sheet = null },
            fallbackLabel = fallbackLabel,
            onOpenNote = { item ->
                if (item.valid) {
                    val len = result.texts.getOrNull(item.range.block)?.length?.coerceAtLeast(1) ?: 1
                    vm.goTo(item.range.block, (item.range.start.toDouble() / len).coerceIn(0.0, 0.95), 80)
                    sheet = null
                }
            },
            onEditNote = { vm.editHighlight(it) },
            highlights = highlights,
            onDismiss = { sheet = null },
        )
        DocSheet.RESULTS -> DocResultsSheet(hits.map { it.snippet }, activeHit, onPick = { vm.openHit(it); sheet = null }, onDismiss = { sheet = null })
        null -> {}
    }

    if (noteDialog) {
        var note by remember { mutableStateOf("") }
        AppDialog(
            onDismissRequest = { noteDialog = false },
            title = { Text(stringResource(R.string.pdf_note)) },
            text = {
                Column {
                    selection?.text?.let { Text(it, maxLines = 4, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = p.textMuted); Spacer(Modifier.height(10.dp)) }
                    AppTextField(note, { note = it }, placeholder = stringResource(R.string.pdf_note_hint), singleLine = false)
                }
            },
            confirmButton = {
                AccentButton(stringResource(R.string.pdf_save), {
                    vm.annotateSelection(AnnotationStyle.NOTE, annColor, note, fallbackLabel())
                    noteDialog = false
                }, enabled = note.isNotBlank(), height = 44.dp)
            },
            dismissButton = { GhostButton(stringResource(R.string.cancel), { noteDialog = false }, height = 44.dp) },
        )
    }

    highlights.firstOrNull { it.entity.id == editing }?.let { item ->
        var note by remember(item.entity.id) { mutableStateOf(item.entity.note.orEmpty()) }
        var color by remember(item.entity.id) { mutableIntStateOf(item.entity.color) }
        AppDialog(
            onDismissRequest = { vm.editHighlight(null) },
            title = { Text(stringResource(R.string.pdf_edit_annotation)) },
            text = {
                Column {
                    Text(item.entity.text, maxLines = 5, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = p.textMuted)
                    Spacer(Modifier.height(10.dp))
                    AppTextField(note, { note = it }, placeholder = stringResource(R.string.pdf_note_hint), singleLine = false)
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        AnnotationColors.forEach { c -> ColorDot(Color(c), color == c, onClick = { color = c }) }
                    }
                    Spacer(Modifier.height(8.dp))
                    GhostButton(stringResource(R.string.pdf_delete), { vm.deleteHighlight(item.entity.id); vm.editHighlight(null) }, destructive = true, height = 40.dp)
                }
            },
            confirmButton = {
                AccentButton(stringResource(R.string.pdf_save), {
                    vm.updateHighlight(item.entity.copy(note = note.trim().ifEmpty { null }, color = color))
                    vm.editHighlight(null)
                }, height = 44.dp)
            },
            dismissButton = { GhostButton(stringResource(R.string.cancel), { vm.editHighlight(null) }, height = 44.dp) },
        )
    }
}

private fun warningText(context: Context, kind: DocWarningKind, count: Int): String {
    val n = Localized.number(count)
    return context.getString(
        when (kind) {
            DocWarningKind.IMAGES_UNSUPPORTED -> R.string.doc_warn_images
            DocWarningKind.TEXT_BOXES -> R.string.doc_warn_textboxes
            DocWarningKind.HEADERS_FOOTERS -> R.string.doc_warn_headers
            DocWarningKind.FOOTNOTES -> R.string.doc_warn_footnotes
            DocWarningKind.EQUATIONS -> R.string.doc_warn_equations
        },
        n,
    )
}

@Composable
private fun DocWarningsCard(lines: List<String>, onDismiss: () -> Unit) {
    val p = palette
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(16.dp)).background(p.surface.copy(alpha = 0.97f))
            .border(1.dp, p.outline.copy(alpha = 0.7f), RoundedCornerShape(16.dp)).padding(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(R.string.doc_warn_title), Modifier.weight(1f), style = MaterialTheme.typography.labelLarge, color = p.text)
            GlassButton(AppIcons.Close, stringResource(R.string.doc_warn_dismiss), onDismiss)
        }
        lines.forEach { MutedText("• $it", Modifier.padding(top = 2.dp)) }
    }
}

// ================================================================================================================
// Search and selection bars
// ================================================================================================================

@Composable
private fun DocSearchBar(
    text: String,
    onText: (String) -> Unit,
    onSearch: () -> Unit,
    count: Int,
    active: Int,
    searching: Boolean,
    searched: Boolean,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onList: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val p = palette
    Column(
        modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(20.dp)).background(p.surface.copy(alpha = 0.97f))
            .border(1.dp, p.outline.copy(alpha = 0.7f), RoundedCornerShape(20.dp)).padding(8.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            AppTextField(
                value = text, onValueChange = onText, modifier = Modifier.weight(1f),
                placeholder = stringResource(R.string.doc_search_hint), leadingIcon = AppIcons.Search,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { onSearch() }),
                minHeight = 40.dp,
            )
            GlassButton(AppIcons.Close, stringResource(R.string.pdf_search_close), onClose)
        }
        if (searched) {
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                val label = when {
                    count > 0 -> stringResource(R.string.pdf_match_of, Localized.number(active + 1), Localized.number(count))
                    searching -> stringResource(R.string.doc_searching)
                    else -> stringResource(R.string.doc_no_matches)
                }
                Text(
                    label, Modifier.weight(1f).then(if (count > 0) Modifier.appClickable(onList) else Modifier),
                    style = MaterialTheme.typography.bodySmall, color = if (count > 0) p.accentText else p.textMuted,
                )
                if (searching) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = p.accent)
                if (count > 0) {
                    GlassButton(AppIcons.ArrowUp, stringResource(R.string.pdf_search_prev), onPrev)
                    GlassButton(AppIcons.ArrowDown, stringResource(R.string.pdf_search_next), onNext)
                }
            }
        }
    }
}

@Composable
private fun DocSelectionBar(
    color: Int,
    onColor: (Int) -> Unit,
    onCopy: () -> Unit,
    onUnderline: () -> Unit,
    onNote: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val p = palette
    Row(
        modifier.padding(horizontal = 12.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(24.dp)).background(p.surface.copy(alpha = 0.97f))
            .border(1.dp, p.outline.copy(alpha = 0.7f), RoundedCornerShape(24.dp))
            .horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        GlassButton(AppIcons.ContentCopy, stringResource(R.string.pdf_copy), onCopy)
        AnnotationColors.forEach { c -> ColorDot(Color(c), c == color, onClick = { onColor(c) }) }
        GlassButton(AppIcons.FormatUnderlined, stringResource(R.string.pdf_underline), onUnderline)
        GlassButton(AppIcons.Notes, stringResource(R.string.pdf_note), onNote)
        GlassButton(AppIcons.Close, stringResource(R.string.pdf_clear_selection), onClose)
    }
}

// ================================================================================================================
// Sheets
// ================================================================================================================

@Composable
private fun DocContentsSheet(vm: DocReaderViewModel, current: Int, onPick: (Int) -> Unit, onDismiss: () -> Unit) {
    val p = palette
    val outline = (vm.load.value as? DocLoadState.Ready)?.page?.result?.outline.orEmpty()
    val here = vm.chapterAt(current)
    AppSheet(onDismiss) {
        Text(stringResource(R.string.doc_contents), style = MaterialTheme.typography.titleLarge, color = p.text, modifier = Modifier.padding(horizontal = 20.dp))
        val start = if (here == null) 0 else outline.indexOf(here).coerceAtLeast(0)
        val state = rememberLazyListState(initialFirstVisibleItemIndex = (start - 2).coerceAtLeast(0))
        LazyColumn(Modifier.fillMaxWidth().height(460.dp).padding(horizontal = 12.dp), state = state) {
            itemsIndexed(outline) { _, e ->
                Row(
                    Modifier.fillMaxWidth().appClickable({ onPick(e.block) }, scaleTo = 0.99f)
                        .padding(start = (8 + (e.level - 1).coerceIn(0, 5) * 16).dp, end = 8.dp, top = 12.dp, bottom = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        e.title, Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.bodyMedium, color = if (e === here) p.accentText else p.text,
                    )
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun DocResultsSheet(snippets: List<String>, active: Int, onPick: (Int) -> Unit, onDismiss: () -> Unit) {
    val p = palette
    AppSheet(onDismiss) {
        Text(stringResource(R.string.pdf_results), style = MaterialTheme.typography.titleLarge, color = p.text, modifier = Modifier.padding(horizontal = 20.dp))
        LazyColumn(Modifier.fillMaxWidth().height(420.dp).padding(horizontal = 12.dp)) {
            itemsIndexed(snippets) { i, text ->
                Row(
                    Modifier.fillMaxWidth().appClickable({ onPick(i) }, scaleTo = 0.99f).padding(horizontal = 8.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(text, Modifier.weight(1f), maxLines = 3, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium, color = if (i == active) p.accentText else p.text)
                    Text(Localized.number(i + 1), Modifier.padding(start = 8.dp), style = MaterialTheme.typography.labelMedium, color = p.textMuted)
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

/** Bookmarks and the list of highlights / notes in one sheet. */
@Composable
private fun DocMarksSheet(
    vm: DocReaderViewModel,
    bookmarks: List<com.novelreader.app.data.BookmarkEntity>,
    label: (com.novelreader.app.data.BookmarkEntity) -> String,
    onOpenBookmark: (com.novelreader.app.data.BookmarkEntity) -> Unit,
    fallbackLabel: () -> String,
    highlights: List<com.novelreader.app.formats.doc.DocHighlightItem>,
    onOpenNote: (com.novelreader.app.formats.doc.DocHighlightItem) -> Unit,
    onEditNote: (Long) -> Unit,
    onDismiss: () -> Unit,
) {
    val p = palette
    var tab by remember { mutableIntStateOf(0) }
    AppSheet(onDismiss) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 20.dp)) {
            SegmentedControl(listOf(stringResource(R.string.bookmarks), stringResource(R.string.doc_notes)), tab, { tab = it })
            Spacer(Modifier.height(12.dp))
            if (tab == 0) {
                AccentButton(stringResource(R.string.add_bookmark), { vm.addBookmarkHere(fallbackLabel()) }, Modifier.fillMaxWidth(), icon = AppIcons.BookmarkAdd, height = 46.dp)
                Spacer(Modifier.height(8.dp))
                if (bookmarks.isEmpty()) {
                    MutedText(stringResource(R.string.no_bookmarks), Modifier.padding(vertical = 16.dp))
                } else {
                    LazyColumn(Modifier.fillMaxWidth().height((bookmarks.size.coerceAtMost(6) * 64).dp)) {
                        itemsIndexed(bookmarks) { _, b ->
                            Row(
                                Modifier.fillMaxWidth().appClickable({ onOpenBookmark(b) }, scaleTo = 0.99f).padding(vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                androidx.compose.material3.Icon(AppIcons.Bookmark, contentDescription = null, tint = p.accent, modifier = Modifier.size(22.dp))
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(b.title?.takeIf { it.isNotBlank() } ?: label(b).ifBlank { b.chapterTitle.orEmpty() }, style = MaterialTheme.typography.bodyLarge, color = p.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    MutedText(Localized.percent((b.progress * 100).toInt()), maxLines = 1)
                                }
                                SoftIconButton(AppIcons.Delete, stringResource(R.string.delete), { vm.deleteBookmark(b.id) }, size = 40.dp)
                            }
                        }
                    }
                }
            } else if (highlights.isEmpty()) {
                MutedText(stringResource(R.string.doc_no_notes), Modifier.padding(vertical = 16.dp))
            } else {
                LazyColumn(Modifier.fillMaxWidth().height((highlights.size.coerceAtMost(5) * 84).dp)) {
                    itemsIndexed(highlights) { _, h ->
                        Row(
                            Modifier.fillMaxWidth().appClickable({ onOpenNote(h) }, scaleTo = 0.99f).padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            ColorDot(Color(h.entity.color), false, size = 20.dp)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(h.entity.text, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium, color = if (h.valid) p.text else p.textMuted)
                                h.entity.note?.takeIf { it.isNotBlank() }?.let { MutedText(it, maxLines = 2) }
                                if (!h.valid) MutedText(stringResource(R.string.doc_annotation_moved), maxLines = 2)
                            }
                            SoftIconButton(AppIcons.Edit, stringResource(R.string.pdf_edit_annotation), { onEditNote(h.entity.id) }, size = 40.dp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DocSettingsSheet(
    s: DocSettings,
    vm: DocReaderViewModel,
    format: BookFormat,
    custom: List<CustomFont>,
    encoding: TextEncoding?,
    paragraphMode: ParagraphMode,
    detected: TextEncoding?,
    onDismiss: () -> Unit,
) {
    val p = palette
    val isTxt = format == BookFormat.TXT
    var pickText by remember { mutableStateOf(false) }
    var pickBg by remember { mutableStateOf(false) }
    val appBg = p.bg.toArgb()
    val appText = p.text.toArgb()
    val (fg, bg) = readingColors(s, appBg, appText)

    AppSheet(onDismiss) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 24.dp)) {
            Text(stringResource(R.string.fmt_settings), style = MaterialTheme.typography.titleLarge, color = p.text)
            MutedText(stringResource(R.string.fmt_settings_note, if (isTxt) "TXT" else "DOCX"), Modifier.padding(top = 4.dp, bottom = 8.dp))

            SettingsGroup(null) {
                StepperSlider(
                    label = stringResource(R.string.doc_font_size), value = s.fontSize.toFloat(), range = 10f..48f, step = 1f,
                    valueText = { Localized.number(it.toInt()) },
                    onCommit = { v -> vm.updateSettings { it.copy(fontSize = v.toInt()) } },
                )
                StepperSlider(
                    label = stringResource(R.string.doc_line_spacing), value = s.lineHeight, range = DocSettings.LINE_HEIGHT, step = 0.1f,
                    valueText = { Localized.decimal(it.toDouble(), 1) },
                    onCommit = { v -> vm.updateSettings { it.copy(lineHeight = v) } },
                )
                if (isTxt) {
                    StepperSlider(
                        label = stringResource(R.string.doc_para_spacing), value = s.paragraphSpacing, range = DocSettings.PARAGRAPH_SPACING, step = 0.1f,
                        valueText = { Localized.decimal(it.toDouble(), 1) },
                        onCommit = { v -> vm.updateSettings { it.copy(paragraphSpacing = v) } },
                    )
                    StepperSlider(
                        label = stringResource(R.string.doc_indent), value = s.indent, range = DocSettings.INDENT, step = 0.25f,
                        valueText = { Localized.decimal(it.toDouble(), 2) },
                        onCommit = { v -> vm.updateSettings { it.copy(indent = v) } },
                    )
                }
                StepperSlider(
                    label = stringResource(R.string.doc_margins), value = s.marginDp.toFloat(), range = 0f..64f, step = 2f,
                    valueText = { Localized.number(it.toInt()) },
                    onCommit = { v -> vm.updateSettings { it.copy(marginDp = v.toInt()) } },
                )
            }

            SettingsGroup(null, Modifier.padding(top = 12.dp)) {
                Column(Modifier.padding(vertical = 8.dp)) {
                    Text(stringResource(R.string.doc_font), style = MaterialTheme.typography.bodyLarge, color = p.text)
                    Spacer(Modifier.height(8.dp))
                    val builtIn = listOf(
                        DocFont.SYSTEM_SANS.name to stringResource(R.string.doc_font_sans),
                        DocFont.SYSTEM_SERIF.name to stringResource(R.string.doc_font_serif),
                        DocFont.MONO.name to stringResource(R.string.doc_font_mono),
                        DocFont.VAZIRMATN.name to "Vazirmatn",
                        DocFont.AMIRI.name to "Amiri",
                        DocFont.LORA.name to "Lora",
                    )
                    val imported = custom.map { "custom:${it.id}" to it.displayName }
                    val selectedKey = s.customFontId?.takeIf { id -> custom.any { it.id == id } }?.let { "custom:$it" } ?: s.font.name
                    ChoiceChips(
                        options = builtIn + imported, selected = selectedKey,
                        onSelect = { choice ->
                            if (choice.startsWith("custom:")) vm.updateSettings { it.copy(customFontId = choice.removePrefix("custom:")) }
                            else vm.updateSettings { it.copy(font = DocFont.valueOf(choice), customFontId = null) }
                        },
                    )
                    if (custom.isEmpty()) MutedText(stringResource(R.string.doc_font_import_hint), Modifier.padding(top = 6.dp))
                }
                Column(Modifier.padding(vertical = 8.dp)) {
                    Text(stringResource(R.string.doc_weight), style = MaterialTheme.typography.bodyLarge, color = p.text)
                    Spacer(Modifier.height(8.dp))
                    val weights = listOf(300, 400, 500, 600, 700)
                    ChoiceChips(
                        options = weights.map { w ->
                            w to stringResource(
                                when (w) {
                                    300 -> R.string.doc_weight_light
                                    400 -> R.string.doc_weight_regular
                                    500 -> R.string.doc_weight_medium
                                    600 -> R.string.doc_weight_semibold
                                    else -> R.string.doc_weight_bold
                                }
                            )
                        },
                        selected = s.weight, onSelect = { w -> vm.updateSettings { it.copy(weight = w) } },
                    )
                }
                if (!isTxt) {
                    SwitchSetting(stringResource(R.string.doc_use_fonts), s.useDocFonts, { v -> vm.updateSettings { it.copy(useDocFonts = v) } }, subtitle = stringResource(R.string.doc_use_fonts_note))
                }
            }

            SettingsGroup(null, Modifier.padding(top = 12.dp)) {
                Column(Modifier.padding(vertical = 8.dp)) {
                    Text(stringResource(R.string.doc_align), style = MaterialTheme.typography.bodyLarge, color = p.text)
                    Spacer(Modifier.height(8.dp))
                    val aligns = buildList {
                        if (!isTxt) add(DocAlign.DOCUMENT to stringResource(R.string.doc_align_doc))
                        add(DocAlign.START to stringResource(R.string.doc_align_start))
                        add(DocAlign.JUSTIFY to stringResource(R.string.doc_align_justify))
                        add(DocAlign.CENTER to stringResource(R.string.doc_align_center))
                    }
                    ChoiceChips(
                        options = aligns, selected = if (isTxt && s.align == DocAlign.DOCUMENT) DocAlign.START else s.align,
                        onSelect = { a -> vm.updateSettings { it.copy(align = a) } },
                    )
                }
                ChoiceSetting(
                    stringResource(R.string.doc_direction),
                    listOf(stringResource(R.string.doc_dir_auto), stringResource(R.string.doc_dir_ltr), stringResource(R.string.doc_dir_rtl)),
                    DocDirection.entries.indexOf(s.direction),
                    { i -> vm.updateSettings { it.copy(direction = DocDirection.entries[i]) } },
                )
                MutedText(stringResource(R.string.doc_dir_note))
            }

            SettingsGroup(null, Modifier.padding(top = 12.dp)) {
                Column(Modifier.padding(vertical = 8.dp)) {
                    Text(stringResource(R.string.doc_colors), style = MaterialTheme.typography.bodyLarge, color = p.text)
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        ColorDot(Color(appBg), s.themeId == "app" && s.textColor == null && s.backgroundColor == null, onClick = {
                            vm.updateSettings { it.copy(themeId = "app", textColor = null, backgroundColor = null) }
                        })
                        ReadingThemes.all.forEach { t ->
                            ColorDot(Color(t.background), s.themeId == t.id && s.textColor == null && s.backgroundColor == null, onClick = {
                                vm.updateSettings { it.copy(themeId = t.id, textColor = null, backgroundColor = null) }
                            })
                        }
                    }
                    MutedText(stringResource(R.string.doc_theme_app_note), Modifier.padding(top = 4.dp))
                    Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        GhostButton(stringResource(R.string.text_color), { pickText = true }, height = 40.dp)
                        GhostButton(stringResource(R.string.background_color), { pickBg = true }, height = 40.dp)
                    }
                }
                if (!isTxt) {
                    SwitchSetting(stringResource(R.string.doc_keep_colors), s.keepDocColors, { v -> vm.updateSettings { it.copy(keepDocColors = v) } })
                }
            }

            if (isTxt) {
                SettingsGroup(null, Modifier.padding(top = 12.dp)) {
                    val encs = TextEncoding.entries.filter { it.available() }
                    RadioSetting(
                        stringResource(R.string.doc_encoding),
                        listOf(stringResource(R.string.doc_enc_auto, detected?.label ?: "")) + encs.map { it.label },
                        if (encoding == null) 0 else encs.indexOf(encoding) + 1,
                        { i -> vm.updateOptions { it.copy(encoding = if (i == 0) null else encs[i - 1]) } },
                        note = stringResource(R.string.doc_enc_note),
                    )
                    ChoiceSetting(
                        stringResource(R.string.doc_paragraphs),
                        listOf(stringResource(R.string.doc_para_auto), stringResource(R.string.doc_para_lines), stringResource(R.string.doc_para_join)),
                        ParagraphMode.entries.indexOf(paragraphMode),
                        { i -> vm.updateOptions { it.copy(paragraphMode = ParagraphMode.entries[i]) } },
                    )
                    MutedText(stringResource(R.string.doc_para_note))
                }
            }

            SettingsGroup(null, Modifier.padding(top = 12.dp)) {
                SwitchSetting(stringResource(R.string.doc_tap_scroll), s.tapScroll, { v -> vm.updateSettings { it.copy(tapScroll = v) } })
                SwitchSetting(stringResource(R.string.doc_show_progress), s.showProgress, { v -> vm.updateSettings { it.copy(showProgress = v) } })
                SwitchSetting(stringResource(R.string.pdf_keep_awake), s.keepScreenOn, { v -> vm.updateSettings { it.copy(keepScreenOn = v) } })
            }
            MutedText(stringResource(R.string.doc_select_hint), Modifier.padding(top = 12.dp))
        }
    }

    if (pickText) {
        ColorPickerDialog(
            title = stringResource(R.string.text_color), initial = fg, onDismiss = { pickText = false },
            onConfirm = { c -> vm.updateSettings { it.copy(textColor = c) }; pickText = false },
            preview = { c -> Text("Aa", color = Color(c), style = MaterialTheme.typography.titleMedium) },
        )
    }
    if (pickBg) {
        ColorPickerDialog(
            title = stringResource(R.string.background_color), initial = bg, onDismiss = { pickBg = false },
            onConfirm = { c -> vm.updateSettings { it.copy(backgroundColor = c) }; pickBg = false },
        )
    }
}
