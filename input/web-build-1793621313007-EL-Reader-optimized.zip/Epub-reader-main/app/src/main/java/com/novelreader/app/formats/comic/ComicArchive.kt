package com.novelreader.app.formats.comic

import com.novelreader.app.core.FileScan
import com.novelreader.app.formats.BookFormat
import com.novelreader.app.formats.FormatDetector
import kotlinx.coroutines.flow.StateFlow
import java.io.Closeable
import java.io.File
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream
import java.util.zip.ZipFile

/** The archive holds no readable page images. */
class EmptyComicException : IOException("no pages")

/** The archive (or its headers) is password protected. */
class EncryptedComicException : IOException("encrypted archive")

/** Not enough free storage to unpack the archive. */
class NoSpaceComicException : IOException("not enough free space")

/** Metadata from the optional ComicInfo.xml of a comic archive. */
data class ComicInfo(
    val title: String?,
    val series: String?,
    val number: String?,
    val writer: String?,
    /** `<Manga>YesAndRightToLeft</Manga>`: true = right-to-left, false = explicitly left-to-right, null = not stated. */
    val rightToLeft: Boolean?,
) {
    val displayTitle: String?
        get() = title?.takeIf { it.isNotBlank() }
            ?: series?.takeIf { it.isNotBlank() }?.let { s -> if (number.isNullOrBlank()) s else "$s #$number" }
}

/**
 * Read access to the pages of a comic archive (CBZ or CBR), in reading order. Pages are addressed by index; archive
 * entry names are only used for sorting and are NEVER used as file-system paths (nothing is written under an
 * archive-controlled name), which rules out path traversal ("zip slip") by construction.
 */
interface ComicArchive : Closeable {
    val format: BookFormat
    val pageCount: Int
    val info: ComicInfo?

    /** Number of pages that can be read without waiting (CBZ: all of them; CBR: grows while unpacking). */
    val readyCount: StateFlow<Int>

    /** A fatal problem while unpacking (CBR), null while everything is fine. */
    val failure: Throwable?

    fun pageName(index: Int): String

    /** Whether page [index] can be opened without waiting. */
    fun isReady(index: Int): Boolean

    /**
     * Bytes of page [index]. May block (CBR: until that page is unpacked), so call it from a background thread.
     * Throws [IOException] when the page is damaged or the archive failed.
     */
    fun openPage(index: Int): InputStream
}

internal object ComicPages {
    const val MAX_ENTRY_BYTES = 256L * 1024 * 1024
    const val MAX_PAGES = 50_000

    /** A name inside an archive that cannot escape a destination folder. */
    fun isSafeName(raw: String): Boolean {
        if (raw.isEmpty() || raw.indexOf('\u0000') >= 0) return false
        val n = raw.replace('\\', '/')
        if (n.startsWith("/")) return false
        if (n.length >= 2 && n[1] == ':' && n[0].isLetter()) return false
        return n.split('/').none { it == ".." }
    }

    fun isPageName(raw: String): Boolean {
        if (!isSafeName(raw)) return false
        if (FormatDetector.isJunkEntry(raw)) return false
        val ext = BookFormat.extensionOf(raw) ?: return false
        return ext in FormatDetector.imageExtensions
    }

    val order: Comparator<String> = Comparator { a, b -> FileScan.compareNatural(a.replace('\\', '/'), b.replace('\\', '/')) }

    fun isComicInfoName(raw: String): Boolean = raw.replace('\\', '/').substringAfterLast('/').equals("ComicInfo.xml", ignoreCase = true)

    /** Minimal ComicInfo.xml reader (flat elements only; entities decoded). Returns null when nothing useful is in it. */
    fun parseInfo(xml: String): ComicInfo? {
        fun tag(name: String): String? {
            val m = Regex("<$name>(.*?)</$name>", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE)).find(xml) ?: return null
            return unescape(m.groupValues[1].trim()).takeIf { it.isNotEmpty() }
        }
        val manga = tag("Manga")?.lowercase()
        val rtl = when {
            manga == null -> null
            manga == "yesandrighttoleft" -> true
            manga == "yes" || manga == "no" -> false
            else -> null
        }
        val info = ComicInfo(tag("Title"), tag("Series"), tag("Number"), tag("Writer"), rtl)
        return if (info.title == null && info.series == null && info.writer == null && info.rightToLeft == null) null else info
    }

    private fun unescape(s: String): String {
        if (s.indexOf('&') < 0) return s
        return Regex("&(#x?[0-9A-Fa-f]+|amp|lt|gt|quot|apos);").replace(s) { m ->
            when (val g = m.groupValues[1]) {
                "amp" -> "&"; "lt" -> "<"; "gt" -> ">"; "quot" -> "\""; "apos" -> "'"
                else -> {
                    val code = try {
                        if (g.startsWith("#x") || g.startsWith("#X")) g.substring(2).toInt(16) else g.substring(1).toInt()
                    } catch (_: NumberFormatException) { -1 }
                    if (code in 1..0x10FFFF) String(Character.toChars(code)) else m.value
                }
            }
        }
    }
}

/** Caps how many bytes can be read from a stream (guards against archives that inflate far beyond their declared size). */
internal class LimitedInputStream(input: InputStream, private var remaining: Long) : FilterInputStream(input) {
    override fun read(): Int {
        if (remaining <= 0) throw IOException("entry too large")
        val b = super.read()
        if (b >= 0) remaining--
        return b
    }

    override fun read(b: ByteArray, off: Int, len: Int): Int {
        if (remaining <= 0) throw IOException("entry too large")
        val n = super.read(b, off, minOf(len.toLong(), remaining).toInt())
        if (n > 0) remaining -= n
        return n
    }
}

/** CBZ: pages are read straight from the ZIP (random access, nothing is unpacked to disk). */
class ZipComicArchive(file: File) : ComicArchive {
    override val format = BookFormat.CBZ
    private val zip = ZipFile(file)

    private class Scan(val entries: List<java.util.zip.ZipEntry>, val info: ComicInfo?)

    private val scan: Scan = try {
        scanZip(zip)
    } catch (t: Throwable) {
        try { zip.close() } catch (_: IOException) { }
        throw t
    }

    private val entries: List<java.util.zip.ZipEntry> = scan.entries
    override val info: ComicInfo? = scan.info
    override val readyCount: StateFlow<Int> = kotlinx.coroutines.flow.MutableStateFlow(entries.size)
    override val failure: Throwable? = null
    override val pageCount: Int get() = entries.size
    override fun pageName(index: Int): String = entries[index].name
    override fun isReady(index: Int): Boolean = index in entries.indices

    override fun openPage(index: Int): InputStream {
        val e = entries.getOrNull(index) ?: throw IOException("no such page")
        return LimitedInputStream(zip.getInputStream(e), ComicPages.MAX_ENTRY_BYTES)
    }

    override fun close() {
        try { zip.close() } catch (_: IOException) { }
    }

    private companion object {
        fun scanZip(zip: ZipFile): Scan {
            val pages = ArrayList<java.util.zip.ZipEntry>()
            var infoEntry: java.util.zip.ZipEntry? = null
            val en = zip.entries()
            while (en.hasMoreElements()) {
                val e = en.nextElement()
                if (e.isDirectory) continue
                if (ComicPages.isComicInfoName(e.name)) { infoEntry = e; continue }
                if (!ComicPages.isPageName(e.name)) continue
                if (e.size > ComicPages.MAX_ENTRY_BYTES) continue
                pages += e
                if (pages.size >= ComicPages.MAX_PAGES) break
            }
            pages.sortWith { a, b -> ComicPages.order.compare(a.name, b.name) }
            if (pages.isEmpty()) throw EmptyComicException()
            val info = infoEntry?.takeIf { it.size in 1..1_000_000 }?.let { e ->
                try {
                    zip.getInputStream(e).use { ComicPages.parseInfo(String(it.readBytes(), Charsets.UTF_8)) }
                } catch (_: Exception) { null }
            }
            return Scan(pages, info)
        }
    }
}

object ComicArchives {
    /**
     * Opens [file] as the comic archive its CONTENT says it is: [format] is only a hint, so a ".cbr" that is really a
     * ZIP opens as CBZ. [cacheDir] receives unpacked pages of RAR archives.
     */
    fun open(file: File, format: BookFormat, cacheDir: File): ComicArchive = when (format) {
        BookFormat.CBR -> RarComicArchive(file, cacheDir)
        else -> ZipComicArchive(file)
    }
}
