package com.novelreader.app.formats

import android.content.Context
import android.content.Intent
import com.novelreader.app.data.BookEntity
import com.novelreader.app.formats.comic.ComicReaderActivity
import com.novelreader.app.formats.doc.DocReaderActivity
import com.novelreader.app.formats.pdf.PdfReaderActivity
import com.novelreader.app.reader.ReaderActivity

/**
 * Picks the reader for a book by its format. EPUB keeps its own Readium-based reader (unchanged); every other format
 * has an engine and an activity of its own. [startLocator] (a bookmark, a note, a history entry) is passed through.
 */
object ReaderRouter {
    fun intent(context: Context, book: BookEntity, startLocator: String? = null): Intent =
        when (BookFormat.fromStored(book.format)) {
            BookFormat.EPUB -> ReaderActivity.intent(context, book.id, startLocator)
            BookFormat.CBZ, BookFormat.CBR -> ComicReaderActivity.intent(context, book.id, startLocator)
            BookFormat.PDF -> PdfReaderActivity.intent(context, book.id, startLocator)
            BookFormat.TXT, BookFormat.DOCX -> DocReaderActivity.intent(context, book.id, startLocator)
        }
}
