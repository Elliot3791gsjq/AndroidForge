package com.novelreader.app.reader.curl

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.Shader
import android.widget.Scroller
import androidx.core.graphics.withClip
import kotlin.math.min
import kotlin.math.sin

class GoogleCurlRenderer: CurlRenderer() {

    private var initDir = FlipDir.NONE

    private val touchPos = PointF()
    private val downPos = PointF()

    private val pathA = Path()
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    var meshWidth = 30
    var meshHeight = 50

    private val meshVertsCount by lazy { (meshWidth + 1) * (meshHeight + 1) }

    private val regionAMeshVerts by lazy{ FloatArray(meshVertsCount * 2) }
    // gridZ and gridX depend only on the mesh column, not the row. Keep their scratch arrays
    // so the per-frame mesh update does not repeat the same sin/division 51 times per column.
    private val columnGridZ by lazy { FloatArray(meshWidth + 1) }
    private val columnGridX by lazy { FloatArray(meshWidth + 1) }

    private var edgePos = pageWidth
    private val shadowWidth get() = min(0.08F * pageWidth, 100F)

    /**
     * 内部绘制依赖于初始的滑动方向
     */
    fun setInitDirection(direction: FlipDir) {
        // 只能是NEXT或PREV
        if (direction == FlipDir.NONE) {
            throw IllegalArgumentException("Init direction must be NEXT or PREV")
        }
        initDir = direction
    }

    override fun initControllPosition(
        x: Float, y: Float
    ) {
        downPos.x = x
        downPos.y = y
        touchPos.x = x
        touchPos.y = y
    }

    override fun updateTouchPosition(curX: Float, curY: Float) {
        touchPos.x = curX
        touchPos.y = curY
        flat = false
        edgePos = computeRegionAMeshVerts()
        if (edgePos >= 0) {
            pathA.reset()
            pathA.moveTo(topMiddlePoint.x, topMiddlePoint.y)
            pathA.lineTo(edgePos, topMiddlePoint.y)
            pathA.lineTo(edgePos, bottomMiddlePoint.y)
            pathA.lineTo(bottomMiddlePoint.x, bottomMiddlePoint.y)
            pathA.close()

        } else {
            pathA.reset()
        }
    }

    private fun computeRegionAMeshVerts(): Float {
        val radius = 0.15f
        var index = 0
        val perc = if (initDir == FlipDir.NEXT) {
            ((downPos.x - touchPos.x) / pageWidth)           // 在x轴方向上的滑动距离占据全部宽度的比例
                .coerceIn(0f, 1f)
        } else {
            (1 + (downPos.x - touchPos.x) / pageWidth).coerceIn(0f, 1f)
        }

        val dx = perc * meshWidth           // 在x轴方向上滑动的网格数量

        var calcRadius = radius             // 实际上就是sin函数振幅的大小
        if (perc < 0.2f) {                  // 当滑动的距离小于0.2时，振幅随着滑动距离增大而增大；当滑动距离大于0.2时，振幅保持不变
            calcRadius = radius * perc * 5f
        }

        val movX = if (perc > 0.1f) perc - 0.1f else 0f
        val whRatio = 1f - calcRadius
        val cameraDistance = -3.0f
        val yBendStrength = 0.15f * pageHeight

        // Both expressions are column-only. Calculate them once instead of repeating the
        // trigonometry and divisions for every row (30*51 times on every animation frame).
        for (col in 0..meshWidth) {
            columnGridZ[col] = (
                calcRadius * sin(Math.PI / (meshWidth * 0.7f) * (col - dx)) + calcRadius * 1.1f
            ).toFloat()
            columnGridX[col] = col.toFloat() / meshWidth * whRatio - movX
        }

        var maxX = Float.MIN_VALUE
        for (row in 0..meshHeight) {
            val gridY = row.toFloat() / meshHeight
            val yCenter = gridY - 0.5f
            val yWeight = kotlin.math.abs(yCenter) * 2f
            val yDir = kotlin.math.sign(yCenter)
            val rowY = gridY * pageHeight
            for (col in 0..meshWidth) {
                val gridZ = columnGridZ[col]
                val kx = cameraDistance / (cameraDistance + gridZ.coerceAtLeast(0.001f))
                val finalX = kx * columnGridX[col] * pageWidth
                val finalY = rowY + yDir * yWeight * gridZ * yBendStrength

                regionAMeshVerts[index * 2] = finalX
                regionAMeshVerts[index * 2 + 1] = finalY
                if (finalX > maxX) maxX = finalX
                index++
            }
        }
        return maxX
    }

    override fun render(canvas: Canvas) {
        canvas.save()
        canvas.clipRect(0F, 0F, pageWidth, pageHeight)
        bottomBitmap?.let { canvas.drawBitmap(it, 0F, 0F, null) }
        drawShadow(canvas)
        canvas.restore()
        // The sheet is painted over the page below, so neither needs an expensive path clip.
        if (edgePos >= 0) {
            canvas.drawBitmapMesh(topBitmap, meshWidth, meshHeight, regionAMeshVerts, 0, null, 0, null)
        }
    }

    // 绘制阴影
    private fun drawShadow(canvas: Canvas) {
        val centerX = edgePos
        val halfWidth = shadowWidth * 0.5f

        val left = centerX - halfWidth
        val right = centerX + halfWidth
        val top = 0f
        val bottom = pageHeight

        val paint = shadowPaint

        // 中间最深，两侧渐隐
        paint.shader = LinearGradient(
            left,
            0f,
            right,
            0f,
            intArrayOf(
                Color.argb(0, 0, 0, 0),   // 左侧透明
                Color.argb(60, 0, 0, 0),   // 左内
                Color.argb(120, 0, 0, 0),   // 正中最深
                Color.argb(60, 0, 0, 0),   // 右内
                Color.argb(0, 0, 0, 0)    // 右侧透明
            ),
            floatArrayOf(
                0f,
                0.25f,
                0.5f,
                0.75f,
                1f
            ),
            Shader.TileMode.CLAMP
        )

        canvas.drawRect(left, top, right, bottom, paint)
    }

    override fun flipToNextPage(scroller: Scroller, animDuration: Int) {
        val dx = (- pageWidth + (downPos.x - touchPos.x)).toInt()
        val dy = 0
        scroller.startScroll(touchPos.x.toInt(), touchPos.y.toInt(),
            dx, dy, animDuration)
    }

    override fun flipToPrevPage(scroller: Scroller, animDuration: Int) {
        val dx = (pageWidth - (downPos.x - touchPos.x)).toInt()
        val dy = 0
        scroller.startScroll(touchPos.x.toInt(), touchPos.y.toInt(),
            dx, dy, animDuration)
    }

}