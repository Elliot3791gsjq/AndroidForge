package com.novelreader.app.ui.files

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContract
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import com.novelreader.app.R
import com.novelreader.app.core.PickKind
import com.novelreader.app.data.ReaderSettings
import com.novelreader.app.graph
import com.novelreader.app.ui.design.AppTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Picks books, a folder of books, fonts or an image from the phone.
 *
 * Primary path: the in-app storage browser ([StorageBrowserScreen]) over the real file system. Fallbacks, offered in
 * the same screen: the system "Open from" picker (SAF) and any installed file-manager app (ACTION_GET_CONTENT).
 * The result is a list of URI strings (file:// from the browser, content:// from the fallbacks).
 */
class FilePickerActivity : AppCompatActivity() {

    private val tick = mutableIntStateOf(0)
    private val scanning = mutableStateOf(false)
    private lateinit var kind: PickKind

    private val systemMulti = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        finishWith(uris.map { it.toString() })
    }
    private val systemSingle = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) finishWith(listOf(uri.toString()))
    }
    private val systemTree = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) scanTree(uri)
    }
    private val chooser = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == RESULT_OK && data != null) {
            val clip = data.clipData
            val list = if (clip != null) (0 until clip.itemCount).mapNotNull { clip.getItemAt(it).uri } else listOfNotNull(data.data)
            finishWith(list.map { it.toString() })
        }
    }
    private val legacyPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { tick.intValue++ }
    private val settingsScreen = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { tick.intValue++ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        kind = runCatching { PickKind.valueOf(intent.getStringExtra(EXTRA_KIND).orEmpty()) }.getOrDefault(PickKind.BOOKS)

        setContent {
            val appSettings by graph.settings.readerSettings.collectAsState(ReaderSettings())
            val hasAccess = remember(tick.intValue) { FileAccess.hasAllFiles(this) }
            AppTheme(settings = appSettings, syncSystemChrome = true) {
                StorageBrowserScreen(
                    kind = kind,
                    hasAccess = hasAccess,
                    busy = scanning.value,
                    onDone = ::finishWith,
                    onCancel = { setResult(Activity.RESULT_CANCELED); finish() },
                    onAllowAccess = ::requestAccess,
                    onSystemPicker = ::launchSystemPicker,
                    onFileManagerApp = ::launchFileManagerApp,
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Coming back from the system settings screen: re-check the permission.
        tick.intValue++
    }

    private fun finishWith(uris: List<String>) {
        if (uris.isEmpty()) return
        setResult(Activity.RESULT_OK, Intent().putStringArrayListExtra(EXTRA_URIS, ArrayList(uris)))
        finish()
    }

    private fun requestAccess() {
        if (FileAccess.needsSettingsScreen()) {
            val ok = FileAccess.openSettings(this) { settingsScreen.launch(it) }
            if (!ok) Toast.makeText(this, R.string.import_err_no_access, Toast.LENGTH_LONG).show()
        } else {
            legacyPermission.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }

    private fun launchSystemPicker() {
        when (kind) {
            PickKind.FOLDER -> systemTree.launch(null)
            PickKind.IMAGE -> systemSingle.launch(arrayOf("image/*"))
            PickKind.BOOKS, PickKind.FONTS -> systemMulti.launch(arrayOf("*/*"))
        }
    }

    private fun launchFileManagerApp() {
        val get = Intent(Intent.ACTION_GET_CONTENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = if (kind == PickKind.IMAGE) "image/*" else "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, kind != PickKind.IMAGE)
        }
        try {
            chooser.launch(Intent.createChooser(get, getString(R.string.picker_use_app)))
        } catch (_: Exception) {
            Toast.makeText(this, R.string.import_err_no_access, Toast.LENGTH_LONG).show()
        }
    }

    /** A folder chosen with the system screen: list every EPUB inside it (and in sub-folders), then finish. */
    private fun scanTree(tree: Uri) {
        scanning.value = true
        lifecycleScope.launch {
            val uris = withContext(Dispatchers.IO) { SafScan.scanTree(this@FilePickerActivity, tree, kind.extensions) }
            scanning.value = false
            if (uris.isEmpty()) {
                Toast.makeText(this@FilePickerActivity, R.string.import_none_found, Toast.LENGTH_LONG).show()
            } else {
                finishWith(uris.map { it.toString() })
            }
        }
    }

    companion object {
        const val EXTRA_KIND = "kind"
        const val EXTRA_URIS = "uris"

        fun intent(context: Context, kind: PickKind): Intent =
            Intent(context, FilePickerActivity::class.java).putExtra(EXTRA_KIND, kind.name)
    }
}

/** `launch(PickKind.BOOKS)` -> list of URI strings the user chose (empty when cancelled). */
class PickFromStorage : ActivityResultContract<PickKind, List<String>>() {
    override fun createIntent(context: Context, input: PickKind): Intent = FilePickerActivity.intent(context, input)

    override fun parseResult(resultCode: Int, intent: Intent?): List<String> =
        if (resultCode == Activity.RESULT_OK) intent?.getStringArrayListExtra(FilePickerActivity.EXTRA_URIS).orEmpty() else emptyList()
}
