package com.novelreader.app.formats.doc

/** One search match: [block] and the character range inside the block's plain text. [snippet] is a bit of context. */
class DocHit(val block: Int, val start: Int, val end: Int, val snippet: String)

/**
 * Text search over the blocks of a document (pure, unit-tested). Matching is forgiving the way Persian and Arabic
 * readers expect: Arabic yeh/kaf equal Persian yeh/kaf, digits of all scripts are equal, the zero-width non-joiner
 * equals a space, diacritics and tatweel are ignored, case is ignored. Offsets always refer to the ORIGINAL text.
 */
object DocSearch {

    /** Normalised text plus, for every normalised character, its index in the original. */
    class Folded(val text: String, val map: IntArray)

    fun fold(s: String): Folded {
        val sb = StringBuilder(s.length)
        val map = IntArray(s.length)
        var n = 0
        for (i in s.indices) {
            val c = s[i]
            val f = foldChar(c) ?: continue
            sb.append(f)
            map[n++] = i
        }
        return Folded(sb.toString(), map.copyOf(n))
    }

    /** Folded form of one character, or null when the character is ignored (diacritics, tatweel, soft hyphen...). */
    fun foldChar(c: Char): Char? = when {
        c == 'ي' || c == 'ى' || c == 'ی' || c == 'ے' -> 'ی'      // yeh forms -> Persian yeh
        c == 'ك' || c == 'ک' -> 'ک'                                          // kaf forms -> Persian kaf
        c == 'ة' -> 'ه'                                                           // teh marbuta -> heh
        c == 'أ' || c == 'إ' || c == 'ٱ' -> 'ا'                         // hamza alef forms -> alef
        c in '۰'..'۹' -> '0' + (c - '۰')
        c in '٠'..'٩' -> '0' + (c - '٠')
        c == '‌' || c == ' ' || c == ' ' || c == '\t' || c == '\n' -> ' '
        c in 'ً'..'ٟ' || c == 'ٰ' || c == 'ـ' || c == '­' || c == '‍' || c == '‎' || c == '‏' || c == '؜' -> null
        c in 'ۖ'..'ۭ' -> null
        else -> c.lowercaseChar()
    }

    /**
     * All matches of [query] (whitespace-separated words are matched as one phrase with flexible spacing), at most
     * [limit]. Matches never span two blocks.
     */
    fun search(texts: List<String>, query: String, limit: Int = 2000, snippetChars: Int = 36): List<DocHit> {
        val q = fold(query.trim()).text.replace(Regex(" +"), " ")
        if (q.isEmpty()) return emptyList()
        val hits = ArrayList<DocHit>()
        for (bi in texts.indices) {
            val t = texts[bi]
            if (t.length < q.length) continue
            val f = fold(t)
            var from = 0
            while (true) {
                val at = f.text.indexOf(q, from)
                if (at < 0) break
                val s = f.map[at]
                val e = f.map[at + q.length - 1] + 1
                hits += DocHit(bi, s, e, snippet(t, s, e, snippetChars))
                if (hits.size >= limit) return hits
                from = at + q.length
            }
        }
        return hits
    }

    fun snippet(text: String, s: Int, e: Int, ctx: Int): String {
        val a = (s - ctx).coerceAtLeast(0)
        val b = (e + ctx).coerceAtMost(text.length)
        val core = text.substring(a, b).replace('\n', ' ').replace('\t', ' ')
        return (if (a > 0) "…" else "") + core + (if (b < text.length) "…" else "")
    }
}
