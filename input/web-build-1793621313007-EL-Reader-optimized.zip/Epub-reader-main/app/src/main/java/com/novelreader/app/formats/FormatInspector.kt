package com.novelreader.app.formats

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import com.novelreader.app.data.ImportError
import com.novelreader.app.formats.comic.ComicArchives
import com.novelreader.app.formats.comic.EmptyComicException
import com.novelreader.app.formats.comic.EncryptedComicException
import com.novelreader.app.formats.comic.NoSpaceComicException
import java.io.File
import java.io.IOException
import java.util.UUID
import java.util.zip.ZipFile

/** What the library learns about a freshly imported file. */
class BookMeta(val title: String?, val author: String?, val pageCount: Int?, val cover: Bitmap?)

class InspectFailure(val error: ImportError, detail: String? = null) : Exception(detail)

/**
 * Validates a stored file of a non-EPUB format and extracts what the library shows (title, author, page count, cover).
 * Runs on a background thread; a damaged / protected file is reported as an [InspectFailure], never as a crash.
 */
object FormatInspector {

    private const val COVER_WIDTH = 480

    fun inspect(context: Context, format: BookFormat, file: File, displayName: String): BookMeta {
        val fallbackTitle = displayName.substringBeforeLast('.', displayName).ifBlank { displayName }
        return when (format) {
            BookFormat.PDF -> inspectPdf(file, fallbackTitle)
            BookFormat.CBZ, BookFormat.CBR -> inspectComic(context, format, file, fallbackTitle)
            BookFormat.DOCX -> inspectDocx(file, fallbackTitle)
            BookFormat.TXT -> inspectText(file, fallbackTitle)
            BookFormat.EPUB -> BookMeta(fallbackTitle, null, null, null)
        }
    }

    private fun inspectPdf(file: File, title: String): BookMeta {
        var pfd: ParcelFileDescriptor? = null
        var renderer: PdfRenderer? = null
        try {
            pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            renderer = PdfRenderer(pfd)
            val pages = renderer.pageCount
            if (pages <= 0) throw InspectFailure(ImportError.CORRUPT, "no pages")
            var cover: Bitmap? = null
            val page = renderer.openPage(0)
            try {
                val w = COVER_WIDTH
                val h = (w.toFloat() * page.height / page.width.coerceAtLeast(1)).toInt().coerceIn(w / 2, w * 3)
                val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                bmp.eraseColor(Color.WHITE)
                page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                cover = bmp
            } catch (_: Exception) {
                // A page that cannot be drawn only costs the cover.
            } finally {
                page.close()
            }
            return BookMeta(title, null, pages, cover)
        } catch (e: SecurityException) {
            throw InspectFailure(ImportError.ENCRYPTED, e.message)
        } catch (e: InspectFailure) {
            throw e
        } catch (e: IOException) {
            throw InspectFailure(ImportError.CORRUPT, e.message)
        } catch (e: IllegalStateException) {
            throw InspectFailure(ImportError.CORRUPT, e.message)
        } finally {
            try { renderer?.close() } catch (_: Exception) { }
            try { pfd?.close() } catch (_: IOException) { }
        }
    }

    private fun inspectComic(context: Context, format: BookFormat, file: File, fallbackTitle: String): BookMeta {
        val tmp = File(context.cacheDir, "comics/import-${UUID.randomUUID()}")
        try {
            val archive = try {
                ComicArchives.open(file, format, tmp)
            } catch (e: EmptyComicException) {
                throw InspectFailure(ImportError.UNSUPPORTED, "no page images")
            } catch (e: EncryptedComicException) {
                throw InspectFailure(ImportError.ENCRYPTED)
            } catch (e: NoSpaceComicException) {
                throw InspectFailure(ImportError.IO, "no space")
            } catch (e: IOException) {
                throw InspectFailure(ImportError.CORRUPT, e.message)
            }
            try {
                val cover = try {
                    ImageDecode.decode({ archive.openPage(0) }, COVER_WIDTH, COVER_WIDTH * 3 / 2)
                } catch (_: Exception) {
                    null
                }
                val info = archive.info
                return BookMeta(info?.displayTitle ?: fallbackTitle, info?.writer, archive.pageCount, cover)
            } finally {
                archive.close()
            }
        } finally {
            tmp.deleteRecursively()
        }
    }

    private fun inspectDocx(file: File, fallbackTitle: String): BookMeta {
        try {
            ZipFile(file).use { zip ->
                if (zip.getEntry("word/document.xml") == null) throw InspectFailure(ImportError.CORRUPT, "no document.xml")
                val core = zip.getEntry("docProps/core.xml")
                var title: String? = null
                var author: String? = null
                if (core != null && core.size in 1..1_000_000) {
                    val xml = zip.getInputStream(core).use { String(it.readBytes(), Charsets.UTF_8) }
                    title = DocxMeta.tag(xml, "dc:title")
                    author = DocxMeta.tag(xml, "dc:creator")
                }
                return BookMeta(title?.takeIf { it.isNotBlank() } ?: fallbackTitle, author?.takeIf { it.isNotBlank() }, null, null)
            }
        } catch (e: InspectFailure) {
            throw e
        } catch (e: IOException) {
            throw InspectFailure(ImportError.CORRUPT, e.message)
        }
    }

    private fun inspectText(file: File, title: String): BookMeta {
        if (file.length() <= 0L) throw InspectFailure(ImportError.CORRUPT, "empty")
        if (file.length() > com.novelreader.app.formats.doc.DocLimits.MAX_TXT_BYTES) throw InspectFailure(ImportError.TOO_LARGE, "text file too large")
        return BookMeta(title, null, null, null)
    }
}

/** Tiny reader for the flat elements of docProps/core.xml. */
internal object DocxMeta {
    fun tag(xml: String, name: String): String? {
        val m = Regex("<${Regex.escape(name)}[^>]*>(.*?)</${Regex.escape(name)}>", RegexOption.DOT_MATCHES_ALL).find(xml) ?: return null
        val raw = m.groupValues[1].trim()
        return raw.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'")
            .takeIf { it.isNotEmpty() }
    }
}
