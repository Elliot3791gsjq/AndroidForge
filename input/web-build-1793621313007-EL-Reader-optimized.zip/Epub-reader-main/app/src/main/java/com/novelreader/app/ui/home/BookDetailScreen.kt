package com.novelreader.app.ui.home

import android.text.format.DateUtils
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.novelreader.app.R
import com.novelreader.app.data.BookEntity
import com.novelreader.app.ui.AppIcons
import com.novelreader.app.ui.Localized
import com.novelreader.app.ui.design.AccentButton
import com.novelreader.app.ui.design.AppCard
import com.novelreader.app.ui.design.AppDialog
import com.novelreader.app.ui.design.AppProgressBar
import com.novelreader.app.ui.design.GhostButton
import com.novelreader.app.ui.design.MutedText
import com.novelreader.app.ui.design.SoftIconButton
import com.novelreader.app.ui.design.Space
import com.novelreader.app.ui.design.palette
import com.novelreader.app.ui.files.ImagePickerHost
import com.novelreader.app.ui.library.BookCategoriesSheet
import com.novelreader.app.ui.library.BookCover
import com.novelreader.app.ui.library.CategoryNameDialog
import com.novelreader.app.ui.library.LibraryViewModel

/**
 * Book detail: a large cover (shared element with the library card), real statistics (read progress, word
 * count, time spent, bookmarks, notes) and the primary "continue reading" action. All numbers come from the
 * database / the EPUB itself; nothing here is a placeholder.
 */
@Composable
fun BookDetailScreen(
    vm: LibraryViewModel,
    bookId: Long,
    source: String,
    onBack: () -> Unit,
    onRead: (Long) -> Unit,
) {
    val books by vm.allBooks.collectAsState()
    val loaded by vm.loaded.collectAsState()
    val bookmarks by vm.allBookmarks.collectAsState()
    val notes by vm.allNotes.collectAsState()
    val book = books.firstOrNull { it.id == bookId }

    // The book vanished (removed from the library or deleted): leave the detail screen.
    LaunchedEffect(book == null, loaded) { if (book == null && loaded) onBack() }
    if (book == null) return

    val p = palette
    var confirmDelete by remember { mutableStateOf(false) }
    var pickCover by remember { mutableStateOf(false) }
    var showCategories by remember { mutableStateOf(false) }
    var newCategory by remember { mutableStateOf(false) }
    val categories by vm.categories.collectAsState()
    val links by vm.categoryLinks.collectAsState()
    val words by produceState<Long?>(initialValue = book.wordCount, book.id) {
        value = book.wordCount ?: vm.textStats(book)?.words
    }
    val started = book.lastReadAt != null || book.progress > 0.0

    Box(
        Modifier
            .fillMaxSize()
            .drawBehind {
                drawRect(
                    Brush.radialGradient(
                        listOf(p.accent.copy(alpha = if (p.dark) 0.30f else 0.18f), Color.Transparent),
                        center = Offset(size.width * 0.5f, size.height * 0.22f),
                        radius = size.width * 0.95f,
                    )
                )
            }
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = Space.gutter)
                .padding(bottom = Space.xl),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(Modifier.fillMaxWidth().padding(top = Space.m), verticalAlignment = Alignment.CenterVertically) {
                SoftIconButton(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back), onBack)
                Spacer(Modifier.weight(1f))
                SoftIconButton(
                    if (book.favorite) AppIcons.Heart else AppIcons.HeartOutline,
                    stringResource(if (book.favorite) R.string.favorite_remove else R.string.favorite_add),
                    { vm.setFavorite(book.id, !book.favorite) },
                    selected = book.favorite,
                )
            }
            Spacer(Modifier.height(Space.l))
            Box {
                BookCover(
                    book.title, vm.coverFile(book),
                    Modifier.width(210.dp).aspectRatio(2f / 3f).sharedCover("cover-$source-${book.id}"),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
                    elevation = 24.dp,
                )
                // Pick a cover of your own from the phone (gallery, file manager or storage browser).
                SoftIconButton(
                    AppIcons.AddPhoto, stringResource(R.string.cover_change), { pickCover = true },
                    modifier = Modifier.align(Alignment.BottomEnd).padding(10.dp),
                    size = 42.dp,
                )
            }
            Spacer(Modifier.height(Space.xl))
            Text(
                book.title, style = MaterialTheme.typography.displaySmall, color = p.text,
                textAlign = TextAlign.Center, maxLines = 3, overflow = TextOverflow.Ellipsis,
            )
            book.author?.let {
                Text(it, style = MaterialTheme.typography.bodyLarge, color = p.textMuted, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 4.dp))
            }
            MutedText(com.novelreader.app.ui.library.bookInfoLine(book), Modifier.padding(top = 4.dp))
            Spacer(Modifier.height(Space.xl))

            AppCard(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth().padding(vertical = Space.l)) {
                    Stat(Localized.percent((book.progress * 100).toInt()), stringResource(R.string.stat_read), Modifier.weight(1f))
                    StatDivider()
                    if (book.pageCount != null) {
                        Stat(Localized.number(book.pageCount), stringResource(R.string.fmt_pages), Modifier.weight(1f))
                    } else {
                        Stat(words?.let { Localized.number(it) } ?: "…", stringResource(R.string.stat_words), Modifier.weight(1f))
                    }
                    StatDivider()
                    Stat(readingTimeText(book.readingMillis), stringResource(R.string.stat_time), Modifier.weight(1f))
                }
            }
            Spacer(Modifier.height(Space.m))
            AppCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(Space.l)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(
                            stringResource(R.string.book_progress, Localized.percent((book.progress * 100).toInt())),
                            style = MaterialTheme.typography.labelLarge, color = p.text,
                        )
                    }
                    Spacer(Modifier.height(Space.s))
                    AppProgressBar(book.progress.toFloat())
                    Spacer(Modifier.height(Space.m))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        MutedText(
                            book.lastReadAt?.let {
                                stringResource(
                                    R.string.last_read,
                                    DateUtils.getRelativeTimeSpanString(it, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS).toString(),
                                )
                            } ?: stringResource(R.string.not_read_yet),
                        )
                        MutedText(
                            stringResource(R.string.detail_marks, Localized.number(bookmarks.count { it.bookId == book.id }), Localized.number(notes.count { it.bookId == book.id })),
                        )
                    }
                }
            }
            Spacer(Modifier.height(Space.xl))
            AccentButton(
                stringResource(if (started) R.string.continue_reading else R.string.start_reading),
                { onRead(book.id) }, Modifier.fillMaxWidth(), icon = AppIcons.Play, height = 56.dp,
            )
            Spacer(Modifier.height(Space.m))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Space.m)) {
                GhostButton(stringResource(R.string.book_categories), { showCategories = true }, Modifier.weight(1f), icon = AppIcons.Label)
                if (book.customCoverPath != null) {
                    GhostButton(stringResource(R.string.cover_reset), { vm.clearCustomCover(book.id) }, Modifier.weight(1f))
                } else {
                    GhostButton(stringResource(R.string.cover_change), { pickCover = true }, Modifier.weight(1f), icon = AppIcons.AddPhoto)
                }
            }
            Spacer(Modifier.height(Space.s))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Space.m)) {
                GhostButton(stringResource(R.string.remove_from_library), { vm.removeFromLibrary(book.id) }, Modifier.weight(1f))
                GhostButton(stringResource(R.string.delete_with_data), { confirmDelete = true }, Modifier.weight(1f), destructive = true)
            }
            MutedText(stringResource(R.string.book_actions_hint), Modifier.padding(top = Space.m))
        }
    }

    ImagePickerHost(
        visible = pickCover,
        onDismiss = { pickCover = false },
        onPicked = { vm.setCustomCover(book.id, it); pickCover = false },
    )
    if (showCategories) {
        BookCategoriesSheet(
            book = book, categories = categories, links = links,
            onToggle = { cid, member -> vm.setBookInCategory(book.id, cid, member) },
            onNew = { newCategory = true },
            onDismiss = { showCategories = false },
        )
    }
    if (newCategory) {
        CategoryNameDialog(
            title = stringResource(R.string.category_new),
            initial = "",
            confirmLabel = stringResource(R.string.category_create),
            onDismiss = { newCategory = false },
            onConfirm = { name ->
                newCategory = false
                vm.createCategory(name) { id -> vm.setBookInCategory(book.id, id, true) }
            },
        )
    }
    if (confirmDelete) {
        AppDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(stringResource(R.string.delete_with_data)) },
            text = { Text(stringResource(R.string.delete_with_data_message, book.title)) },
            confirmButton = {
                TextButton(onClick = { vm.deleteCompletely(book.id); confirmDelete = false }) {
                    Text(stringResource(R.string.delete), color = p.danger)
                }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text(stringResource(R.string.cancel)) } },
        )
    }
}

@Composable
private fun Stat(value: String, label: String, modifier: Modifier = Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.headlineSmall, color = palette.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(label, style = MaterialTheme.typography.labelMedium, color = palette.textMuted, maxLines = 1)
    }
}

@Composable
private fun RowScope.StatDivider() {
    Box(Modifier.width(1.dp).height(36.dp).background(palette.outline).align(Alignment.CenterVertically))
}

@Composable
private fun readingTimeText(ms: Long): String {
    val min = ms / 60_000
    return when {
        min >= 60 -> stringResource(R.string.bi_h_m, (min / 60).toInt(), (min % 60).toInt())
        min >= 1 -> stringResource(R.string.bi_m, min.toInt())
        ms > 0 -> stringResource(R.string.bi_lt_min)
        else -> "—"
    }
}

@Suppress("unused")
private fun BookEntity.hasStarted(): Boolean = lastReadAt != null || progress > 0.0
