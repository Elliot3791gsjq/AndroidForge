package com.novelreader.app.formats.comic

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.runtime.collectAsState
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.novelreader.app.R
import com.novelreader.app.data.ReaderSettings
import com.novelreader.app.graph
import com.novelreader.app.ui.design.AppTheme
import com.novelreader.app.ui.formats.ComicReaderScreen
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/** Hosts the CBZ / CBR reader (own engine, own settings). The EPUB reader is untouched. */
class ComicReaderActivity : AppCompatActivity() {

    private lateinit var vm: ComicReaderViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val bookId = intent.getLongExtra(EXTRA_BOOK_ID, -1L)
        if (bookId < 0) { finish(); return }
        vm = ViewModelProvider(this, ComicReaderViewModel.factory(application, bookId, intent.getStringExtra(EXTRA_LOCATOR)))[ComicReaderViewModel::class.java]
        WindowCompat.setDecorFitsSystemWindows(window, false)

        setContent {
            val appSettings = graph.settings.readerSettings.collectAsState(ReaderSettings()).value
            AppTheme(settings = appSettings, syncSystemChrome = false) {
                ComicReaderScreen(vm = vm, onBack = { finish() })
            }
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    vm.chromeVisible.collectLatest { visible ->
                        val c = WindowInsetsControllerCompat(window, window.decorView)
                        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                        if (visible) c.show(WindowInsetsCompat.Type.systemBars()) else c.hide(WindowInsetsCompat.Type.systemBars())
                    }
                }
                launch {
                    vm.settings.collectLatest { s ->
                        if (s?.keepScreenOn == true) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    }
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        vm.onForeground()
    }

    override fun onStop() {
        vm.onBackground(getString(R.string.fmt_page_label, com.novelreader.app.ui.Localized.number(vm.page.value + 1)))
        super.onStop()
    }

    companion object {
        private const val EXTRA_BOOK_ID = "book_id"
        private const val EXTRA_LOCATOR = "locator"

        fun intent(context: Context, bookId: Long, locatorJson: String? = null): Intent =
            Intent(context, ComicReaderActivity::class.java).putExtra(EXTRA_BOOK_ID, bookId).apply {
                if (locatorJson != null) putExtra(EXTRA_LOCATOR, locatorJson)
            }
    }
}
