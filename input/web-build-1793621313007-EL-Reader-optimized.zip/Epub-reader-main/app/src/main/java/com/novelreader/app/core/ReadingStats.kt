package com.novelreader.app.core

import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.time.temporal.TemporalAdjusters

/**
 * Pure maths behind the "Reading stats" screen (no Android classes, so it is unit-tested on the JVM).
 *
 * Input is the list of recorded reading *sittings* (one per foreground stretch of one book) and the books' stored
 * totals. Sittings that cross a day / month boundary are split at local midnight, so a late-night reader never
 * gets time credited to the wrong day. Everything is computed on this device's own data - nothing is estimated.
 */
enum class StatsPeriod { WEEK, MONTH, YEAR, ALL }

/** One recorded sitting. Progress values are whole-book progression 0..1 at the start / end of the sitting. */
data class StatSession(
    val bookId: Long,
    val startAt: Long,
    val durationMs: Long,
    val startProgress: Double,
    val endProgress: Double,
) {
    val endAt: Long get() = startAt + durationMs
}

/** A book with its all-time reading total (used for the part of the total that predates sitting records). */
data class StatBook(val id: Long, val totalReadingMs: Long)

enum class BarUnit { DAY, MONTH }

/** One bar of the chart: the period slice beginning at [startMillis]. */
data class StatBar(val startMillis: Long, val millis: Long, val isCurrent: Boolean)

data class BookStat(val bookId: Long, val millis: Long, val sittings: Int)

enum class Trend { MORE, LESS, SAME, NONE }

data class StatsResult(
    val period: StatsPeriod,
    val rangeStart: Long,
    val rangeEnd: Long,
    val totalMillis: Long,
    /** Time in the equivalent previous period (last week / month / year); null for "All time". */
    val previousMillis: Long?,
    val trend: Trend,
    val booksReadFrom: Int,
    val booksFinished: Int,
    val dayStreak: Int,
    val sittings: Int,
    /** Whole-book progress gained per hour of reading, in percent; null when there is too little data. */
    val pacePercentPerHour: Double?,
    val barUnit: BarUnit,
    val bars: List<StatBar>,
    /** Every known book, most read first (books with no time in the period have millis == 0). */
    val byBook: List<BookStat>,
)

object ReadingStats {

    /** A book counts as finished from this progression on (the last page rarely reports exactly 1.0). */
    const val FINISHED_PROGRESS = 0.985

    /** Pace is only meaningful after this much reading in the period. */
    const val MIN_PACE_MS = 60_000L

    /**
     * A sitting that moved faster than this (percent of the book per hour) was a jump (progress bar, chapter list,
     * search result), not reading; it is left out of the pace so one jump cannot show "3500 %/h".
     * Even a very fast reader on a short book stays far below it.
     */
    const val MAX_PLAUSIBLE_PACE = 400.0

    fun compute(
        period: StatsPeriod,
        sessions: List<StatSession>,
        books: List<StatBook>,
        now: Long,
        zone: ZoneId = ZoneId.systemDefault(),
        firstDayOfWeek: DayOfWeek = DayOfWeek.SUNDAY,
    ): StatsResult {
        val valid = sessions.filter { it.durationMs > 0 }
        val today = Instant.ofEpochMilli(now).atZone(zone).toLocalDate()
        val (from, to) = range(period, today, zone, firstDayOfWeek, valid)
        val prev = previousRange(period, today, zone, firstDayOfWeek)

        // Per-session overlap with the period.
        var total = 0L
        var progressGain = 0.0
        var paceMillis = 0L
        var sittings = 0
        val millisByBook = HashMap<Long, Long>()
        val sittingsByBook = HashMap<Long, Int>()
        for (s in valid) {
            val ov = overlap(s, from, to)
            if (ov <= 0) continue
            total += ov
            sittings++
            millisByBook[s.bookId] = (millisByBook[s.bookId] ?: 0L) + ov
            sittingsByBook[s.bookId] = (sittingsByBook[s.bookId] ?: 0) + 1
            val gain = (s.endProgress - s.startProgress).coerceAtLeast(0.0)
            val sittingPace = gain * 100.0 / (s.durationMs / 3_600_000.0)
            if (sittingPace <= MAX_PLAUSIBLE_PACE) {
                progressGain += gain * ov / s.durationMs
                paceMillis += ov
            }
        }

        // "All time" also counts reading recorded before sittings existed (no date, so no bar and no sitting).
        if (period == StatsPeriod.ALL) {
            for (b in books) {
                val dated = millisByBook[b.id] ?: 0L
                if (b.totalReadingMs > dated) {
                    total += b.totalReadingMs - dated
                    millisByBook[b.id] = b.totalReadingMs
                }
            }
        }

        val previous = prev?.let { (pf, pt) -> valid.sumOf { overlap(it, pf, pt) } }
        val trend = when {
            previous == null -> Trend.NONE
            total == 0L && previous == 0L -> Trend.NONE
            total > previous -> Trend.MORE
            total < previous -> Trend.LESS
            else -> Trend.SAME
        }

        val pace = if (paceMillis >= MIN_PACE_MS) progressGain * 100.0 / (paceMillis / 3_600_000.0) else null

        val (unit, bars) = buildBars(period, today, zone, firstDayOfWeek, valid, from)
        val byBook = (books.map { it.id } + millisByBook.keys).distinct()
            .map { id -> BookStat(id, millisByBook[id] ?: 0L, sittingsByBook[id] ?: 0) }
            .sortedWith(compareByDescending<BookStat> { it.millis }.thenBy { it.bookId })

        return StatsResult(
            period = period,
            rangeStart = from,
            rangeEnd = to,
            totalMillis = total,
            previousMillis = previous,
            trend = trend,
            booksReadFrom = millisByBook.count { it.value > 0 },
            booksFinished = finishedBooks(valid, from, to),
            dayStreak = streak(valid, today, zone, from),
            sittings = sittings,
            pacePercentPerHour = pace,
            barUnit = unit,
            bars = bars,
            byBook = byBook,
        )
    }

    // ---- ranges ----

    /** [start, end) of the period in epoch millis. "All time" starts at the first sitting. */
    fun range(
        period: StatsPeriod, today: LocalDate, zone: ZoneId, firstDayOfWeek: DayOfWeek, sessions: List<StatSession> = emptyList(),
    ): Pair<Long, Long> = when (period) {
        StatsPeriod.WEEK -> {
            val start = today.with(TemporalAdjusters.previousOrSame(firstDayOfWeek))
            ms(start, zone) to ms(start.plusDays(7), zone)
        }
        StatsPeriod.MONTH -> {
            val start = today.withDayOfMonth(1)
            ms(start, zone) to ms(start.plusMonths(1), zone)
        }
        StatsPeriod.YEAR -> {
            val start = today.withDayOfYear(1)
            ms(start, zone) to ms(start.plusYears(1), zone)
        }
        StatsPeriod.ALL -> (sessions.minOfOrNull { it.startAt } ?: ms(today, zone)) to Long.MAX_VALUE
    }

    private fun previousRange(period: StatsPeriod, today: LocalDate, zone: ZoneId, firstDayOfWeek: DayOfWeek): Pair<Long, Long>? = when (period) {
        StatsPeriod.WEEK -> {
            val start = today.with(TemporalAdjusters.previousOrSame(firstDayOfWeek))
            ms(start.minusDays(7), zone) to ms(start, zone)
        }
        StatsPeriod.MONTH -> {
            val start = today.withDayOfMonth(1)
            ms(start.minusMonths(1), zone) to ms(start, zone)
        }
        StatsPeriod.YEAR -> {
            val start = today.withDayOfYear(1)
            ms(start.minusYears(1), zone) to ms(start, zone)
        }
        StatsPeriod.ALL -> null
    }

    private fun ms(d: LocalDate, zone: ZoneId): Long = d.atStartOfDay(zone).toInstant().toEpochMilli()

    private fun overlap(s: StatSession, from: Long, to: Long): Long = (minOf(s.endAt, to) - maxOf(s.startAt, from)).coerceAtLeast(0L)

    // ---- chart ----

    private fun buildBars(
        period: StatsPeriod, today: LocalDate, zone: ZoneId, firstDayOfWeek: DayOfWeek, sessions: List<StatSession>, from: Long,
    ): Pair<BarUnit, List<StatBar>> {
        fun dayBars(first: LocalDate, count: Int): List<StatBar> = (0 until count).map { i ->
            val d = first.plusDays(i.toLong())
            val a = ms(d, zone)
            val b = ms(d.plusDays(1), zone)
            StatBar(a, sessions.sumOf { overlap(it, a, b) }, d == today)
        }
        fun monthBars(first: YearMonth, count: Int): List<StatBar> = (0 until count).map { i ->
            val m = first.plusMonths(i.toLong())
            val a = ms(m.atDay(1), zone)
            val b = ms(m.plusMonths(1).atDay(1), zone)
            StatBar(a, sessions.sumOf { overlap(it, a, b) }, m == YearMonth.from(today))
        }
        return when (period) {
            StatsPeriod.WEEK -> BarUnit.DAY to dayBars(today.with(TemporalAdjusters.previousOrSame(firstDayOfWeek)), 7)
            StatsPeriod.MONTH -> BarUnit.DAY to dayBars(today.withDayOfMonth(1), today.lengthOfMonth())
            StatsPeriod.YEAR -> BarUnit.MONTH to monthBars(YearMonth.of(today.year, 1), 12)
            StatsPeriod.ALL -> {
                val current = YearMonth.from(today)
                val earliest = sessions.minOfOrNull { Instant.ofEpochMilli(it.startAt).atZone(zone).let { z -> YearMonth.of(z.year, z.month) } } ?: current
                val span = (java.time.temporal.ChronoUnit.MONTHS.between(earliest, current).toInt() + 1).coerceIn(6, 12)
                BarUnit.MONTH to monthBars(current.minusMonths((span - 1).toLong()), span)
            }
        }
    }

    // ---- derived numbers ----

    /**
     * Books whose *finishing* sitting (the first one that ran from before the end to the end) ended in the period.
     * Books that were already finished before sittings were recorded are not counted - their date is unknown.
     */
    private fun finishedBooks(sessions: List<StatSession>, from: Long, to: Long): Int =
        sessions.groupBy { it.bookId }.count { (_, list) ->
            val finishing = list.filter { it.startProgress < FINISHED_PROGRESS && it.endProgress >= FINISHED_PROGRESS }.minByOrNull { it.startAt }
            finishing != null && finishing.endAt in from until to
        }

    /**
     * Consecutive reading days ending today (or yesterday, while today is still unread), never reaching back past
     * the start of the period - so the tile changes with the selected period like every other number.
     */
    private fun streak(sessions: List<StatSession>, today: LocalDate, zone: ZoneId, from: Long): Int {
        val days = HashSet<LocalDate>()
        for (s in sessions) {
            var d = Instant.ofEpochMilli(s.startAt).atZone(zone).toLocalDate()
            val last = Instant.ofEpochMilli(s.endAt - 1).atZone(zone).toLocalDate()
            while (!d.isAfter(last)) { days += d; d = d.plusDays(1) }
        }
        val earliest = Instant.ofEpochMilli(from).atZone(zone).toLocalDate()
        var d = if (today in days) today else today.minusDays(1)
        var n = 0
        while (d in days && !d.isBefore(earliest)) { n++; d = d.minusDays(1) }
        return n
    }
}
