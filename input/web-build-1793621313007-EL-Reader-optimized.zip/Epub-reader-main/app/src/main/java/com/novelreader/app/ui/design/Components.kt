package com.novelreader.app.ui.design

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.selection.toggleable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

// ---------------------------------------------------------------------------------------------------------------
// Interaction helpers
// ---------------------------------------------------------------------------------------------------------------

/** Subtle press feedback: the element shrinks a little while pressed. */
@Composable
fun Modifier.pressScale(source: MutableInteractionSource, to: Float = 0.96f): Modifier {
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) to else 1f, motion.fast(), label = "pressScale")
    return this.graphicsLayer {
        scaleX = scale
        scaleY = scale
    }
}

/** Click (and optional long-click) with the press-scale feedback instead of a ripple. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Modifier.appClickable(
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null,
    enabled: Boolean = true,
    role: Role? = Role.Button,
    scaleTo: Float = 0.96f,
): Modifier {
    val source = remember { MutableInteractionSource() }
    return this
        .pressScale(source, scaleTo)
        .combinedClickable(
            interactionSource = source,
            indication = null,
            enabled = enabled,
            role = role,
            onLongClick = onLongClick,
            onClick = onClick,
        )
}

// ---------------------------------------------------------------------------------------------------------------
// Backdrop, headers, text
// ---------------------------------------------------------------------------------------------------------------

/** Screen background: the base colour with a soft accent glow in the top corner for depth. */
@Composable
fun AppBackdrop(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val p = palette
    Box(
        modifier
            .fillMaxSize()
            .background(p.bg)
            .drawBehind {
                val glow = p.accent.copy(alpha = if (p.dark) 0.20f else 0.11f)
                drawRect(
                    Brush.radialGradient(
                        colors = listOf(glow, Color.Transparent),
                        center = Offset(size.width * 0.88f, -size.height * 0.03f),
                        radius = size.width * 0.95f,
                    )
                )
            }
    ) { content() }
}

@Composable
fun ScreenHeader(
    title: String,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    horizontalPadding: Dp = Space.gutter,
    actions: @Composable RowScope.() -> Unit = {},
) {
    Row(
        modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.statusBars)
            .padding(start = horizontalPadding, end = if (horizontalPadding > 4.dp) horizontalPadding - 4.dp else 0.dp, top = Space.m, bottom = Space.s),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.displayMedium, color = palette.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (subtitle != null) {
                Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = palette.textMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(Space.s), verticalAlignment = Alignment.CenterVertically, content = actions)
    }
}

/** Small accent label that introduces a block of content. */
@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(
        text.uppercase(),
        style = MaterialTheme.typography.labelMedium,
        color = palette.accentText,
        modifier = modifier.padding(top = Space.l, bottom = Space.s),
    )
}

@Composable
fun MutedText(text: String, modifier: Modifier = Modifier, maxLines: Int = Int.MAX_VALUE) {
    Text(text, style = MaterialTheme.typography.bodySmall, color = palette.textMuted, modifier = modifier, maxLines = maxLines, overflow = TextOverflow.Ellipsis)
}

// ---------------------------------------------------------------------------------------------------------------
// Buttons & chips
// ---------------------------------------------------------------------------------------------------------------

@Composable
fun SoftIconButton(
    icon: ImageVector,
    contentDescription: String?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    selected: Boolean = false,
    tint: Color? = null,
    size: Dp = 44.dp,
    filled: Boolean = true,
) {
    val p = palette
    val bg by animateColorAsState(
        when {
            selected -> p.accentSoft
            filled -> p.surfaceHigh
            else -> Color.Transparent
        }, motion.fast(), label = "iconBg",
    )
    val fg by animateColorAsState(tint ?: if (selected) p.onAccentSoft else p.text, motion.fast(), label = "iconFg")
    Box(
        modifier
            .size(size)
            .appClickable(onClick)
            .clip(CircleShape)
            .background(bg),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = contentDescription, tint = fg, modifier = Modifier.size(22.dp))
    }
}

@Composable
fun AccentButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    enabled: Boolean = true,
    height: Dp = 52.dp,
) {
    val p = palette
    val dim by animateFloatAsState(if (enabled) 1f else 0.4f, motion.fast(), label = "btnAlpha")
    val brush = Brush.verticalGradient(listOf(lerp(p.accent, Color.White, if (p.dark) 0.14f else 0.10f), p.accent))
    Row(
        modifier
            .height(height)
            .graphicsLayer { alpha = dim }
            .shadow(
                elevation = if (enabled) 12.dp else 0.dp,
                shape = CircleShape,
                ambientColor = p.accent.copy(alpha = 0.45f),
                spotColor = p.accent.copy(alpha = 0.6f),
            )
            .appClickable(onClick, enabled = enabled)
            .clip(CircleShape)
            .background(brush)
            .padding(horizontal = 26.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, tint = p.onAccent, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(text, style = MaterialTheme.typography.titleSmall, color = p.onAccent, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun GhostButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    enabled: Boolean = true,
    destructive: Boolean = false,
    height: Dp = 48.dp,
) {
    val p = palette
    val fg = if (destructive) p.danger else p.text
    val dim by animateFloatAsState(if (enabled) 1f else 0.4f, motion.fast(), label = "ghostAlpha")
    Row(
        modifier
            .height(height)
            .graphicsLayer { alpha = dim }
            .appClickable(onClick, enabled = enabled)
            .clip(CircleShape)
            .background(p.surfaceHigh)
            .border(1.dp, p.outline, CircleShape)
            .padding(horizontal = 22.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, tint = fg, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(text, style = MaterialTheme.typography.labelLarge, color = fg, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun AppChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    leadingIcon: ImageVector? = null,
) {
    val p = palette
    val bg by animateColorAsState(if (selected) p.accent else p.surfaceHigh, motion.fast(), label = "chipBg")
    val fg by animateColorAsState(if (selected) p.onAccent else p.textMuted, motion.fast(), label = "chipFg")
    Row(
        modifier
            .height(36.dp)
            .graphicsLayer { alpha = if (enabled) 1f else 0.4f }
            .appClickable(onClick, enabled = enabled, role = Role.Tab)
            .clip(AppShapes.chip)
            .background(bg)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
    ) {
        if (leadingIcon != null) {
            Icon(leadingIcon, contentDescription = null, tint = fg, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
        }
        Text(label, style = MaterialTheme.typography.labelLarge, color = fg, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun AppSwitch(checked: Boolean, onCheckedChange: ((Boolean) -> Unit)?, modifier: Modifier = Modifier, enabled: Boolean = true) {
    val p = palette
    val track by animateColorAsState(if (checked) p.accent else p.surfaceHighest, motion.fast(), label = "swTrack")
    val knob by animateColorAsState(if (checked) p.onAccent else p.textMuted, motion.fast(), label = "swKnob")
    val x by animateDpAsState(if (checked) 24.dp else 4.dp, motion.fast(), label = "swX")
    val base = modifier
        .size(width = 52.dp, height = 30.dp)
        .graphicsLayer { alpha = if (enabled) 1f else 0.4f }
        .clip(CircleShape)
        .background(track)
    Box(
        if (onCheckedChange != null) base.toggleable(checked, enabled = enabled, role = Role.Switch, onValueChange = onCheckedChange) else base,
        contentAlignment = Alignment.CenterStart,
    ) {
        Box(Modifier.offset(x = x).size(22.dp).clip(CircleShape).background(knob))
    }
}

// ---------------------------------------------------------------------------------------------------------------
// Containers
// ---------------------------------------------------------------------------------------------------------------

@Composable
fun AppCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    onLongClick: (() -> Unit)? = null,
    shape: androidx.compose.ui.graphics.Shape = AppShapes.card,
    containerColor: Color? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val p = palette
    val base = if (onClick != null) modifier.appClickable(onClick, onLongClick = onLongClick, scaleTo = 0.98f) else modifier
    Column(
        base
            .clip(shape)
            .background(containerColor ?: p.surface)
            .border(1.dp, p.outline, shape),
        content = content,
    )
}

/** A titled group of settings rows inside one card. */
@Composable
fun SettingsGroup(title: String?, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.fillMaxWidth()) {
        if (title != null) SectionLabel(title, Modifier.padding(horizontal = 4.dp))
        AppCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(horizontal = Space.l, vertical = Space.s), content = content)
        }
    }
}

@Composable
fun SettingRow(
    title: String,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    icon: ImageVector? = null,
    onClick: (() -> Unit)? = null,
    trailing: @Composable (() -> Unit)? = null,
) {
    val p = palette
    val base = if (onClick != null) modifier.appClickable(onClick, scaleTo = 0.985f, role = Role.Button) else modifier
    Row(
        base.fillMaxWidth().padding(vertical = Space.m),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Box(Modifier.size(36.dp).clip(CircleShape).background(p.accentSoft), contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = null, tint = p.onAccentSoft, modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.width(Space.m))
        }
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, color = p.text)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = p.textMuted)
        }
        if (trailing != null) {
            Spacer(Modifier.width(Space.m))
            trailing()
        }
    }
}

@Composable
fun SheetHandle(modifier: Modifier = Modifier) {
    Box(modifier.size(width = 40.dp, height = 4.dp).clip(CircleShape).background(palette.textMuted.copy(alpha = 0.45f)))
}

@Composable
fun ColorDot(color: Color, selected: Boolean, modifier: Modifier = Modifier, size: Dp = 34.dp, onClick: (() -> Unit)? = null) {
    val p = palette
    val ring by animateColorAsState(if (selected) p.accent else p.outline, motion.fast(), label = "dotRing")
    val base = if (onClick != null) modifier.appClickable(onClick, role = Role.RadioButton) else modifier
    Box(
        base
            .size(size)
            .clip(CircleShape)
            .background(color)
            .border(if (selected) 3.dp else 1.dp, ring, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        if (selected) {
            Icon(
                Icons.Default.Check, contentDescription = null,
                tint = Color(com.novelreader.app.core.ColorMath.bestTextOn(color.toArgb())),
                modifier = Modifier.size(size / 2),
            )
        }
    }
}

/** Pill-shaped segmented control with a sliding indicator. */
@Composable
fun SegmentedControl(options: List<String>, selectedIndex: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    val p = palette
    val n = options.size.coerceAtLeast(1)
    BoxWithConstraints(
        modifier
            .fillMaxWidth()
            .height(48.dp)
            .clip(CircleShape)
            .background(p.surface)
            .border(1.dp, p.outline, CircleShape)
            .padding(4.dp),
    ) {
        val itemWidth = maxWidth / n
        val x by animateDpAsState(itemWidth * selectedIndex.coerceIn(0, n - 1), motion.medium(), label = "segX")
        Box(
            Modifier
                .offset(x = x)
                .width(itemWidth)
                .fillMaxHeight()
                .clip(CircleShape)
                .background(p.accent)
        )
        Row(Modifier.fillMaxSize()) {
            options.forEachIndexed { i, label ->
                val selected = i == selectedIndex
                val fg by animateColorAsState(if (selected) p.onAccent else p.textMuted, motion.fast(), label = "segFg")
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clip(CircleShape)
                        .appClickable({ onSelect(i) }, role = Role.Tab, scaleTo = 0.98f),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(label, style = MaterialTheme.typography.labelLarge, color = fg, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

class NavItem(val label: String, val icon: ImageVector)

/** Floating pill navigation: the selected destination expands to show its label. */
@Composable
fun FloatingNavBar(items: List<NavItem>, selectedIndex: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    val p = palette
    Row(
        modifier
            .widthIn(max = 460.dp)
            .fillMaxWidth()
            .shadow(20.dp, CircleShape, ambientColor = Color.Black, spotColor = Color.Black)
            .clip(CircleShape)
            .background(p.surfaceHigh)
            .border(1.dp, p.outline, CircleShape)
            .padding(8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        items.forEachIndexed { i, item ->
            val selected = i == selectedIndex
            val bg by animateColorAsState(if (selected) p.accentSoft else Color.Transparent, motion.medium(), label = "navBg")
            val fg by animateColorAsState(if (selected) p.onAccentSoft else p.textMuted, motion.medium(), label = "navFg")
            Row(
                Modifier
                    .height(48.dp)
                    .appClickable({ onSelect(i) }, role = Role.Tab, scaleTo = 0.94f)
                    .clip(CircleShape)
                    .background(bg)
                    .padding(horizontal = if (selected) 18.dp else 14.dp)
                    .animateContentSize(motion.medium()),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(item.icon, contentDescription = item.label, tint = fg, modifier = Modifier.size(22.dp))
                if (selected) {
                    Spacer(Modifier.width(8.dp))
                    Text(item.label, style = MaterialTheme.typography.labelLarge, color = fg, maxLines = 1)
                }
            }
        }
    }
}

@Composable
fun AppProgressBar(progress: Float, modifier: Modifier = Modifier, height: Dp = 6.dp) {
    val p = palette
    val f by animateFloatAsState(progress.coerceIn(0f, 1f), motion.slow(), label = "progress")
    Box(modifier.fillMaxWidth().height(height).clip(CircleShape).background(p.surfaceHighest)) {
        Box(Modifier.fillMaxHeight().fillMaxWidth(f).clip(CircleShape).background(p.accent))
    }
}

@Composable
fun AppSlider(
    value: Float,
    onValueChange: (Float) -> Unit,
    valueRange: ClosedFloatingPointRange<Float>,
    modifier: Modifier = Modifier,
    onValueChangeFinished: (() -> Unit)? = null,
    steps: Int = 0,
) {
    val p = palette
    Slider(
        value = value,
        onValueChange = onValueChange,
        valueRange = valueRange,
        steps = steps,
        onValueChangeFinished = onValueChangeFinished,
        modifier = modifier,
        colors = SliderDefaults.colors(
            thumbColor = p.accent,
            activeTrackColor = p.accent,
            inactiveTrackColor = p.surfaceHighest,
            activeTickColor = p.onAccent.copy(alpha = 0.4f),
            inactiveTickColor = p.textMuted.copy(alpha = 0.4f),
        ),
    )
}

@Composable
fun AppTextField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    placeholder: String = "",
    leadingIcon: ImageVector? = null,
    trailing: @Composable (() -> Unit)? = null,
    singleLine: Boolean = true,
    keyboardOptions: androidx.compose.foundation.text.KeyboardOptions = androidx.compose.foundation.text.KeyboardOptions.Default,
    keyboardActions: androidx.compose.foundation.text.KeyboardActions = androidx.compose.foundation.text.KeyboardActions.Default,
    minHeight: Dp = 48.dp,
) {
    val p = palette
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    val border by animateColorAsState(if (focused) p.accent else p.outline, motion.fast(), label = "fieldBorder")
    BasicTextField(
        value = value,
        onValueChange = onValueChange,
        singleLine = singleLine,
        interactionSource = source,
        textStyle = MaterialTheme.typography.bodyMedium.copy(color = p.text),
        cursorBrush = SolidColor(p.accent),
        keyboardOptions = keyboardOptions,
        keyboardActions = keyboardActions,
        modifier = modifier,
        decorationBox = { inner ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .heightIn(min = minHeight)
                    .clip(AppShapes.field)
                    .background(p.surface)
                    .border(if (focused) 1.5.dp else 1.dp, border, AppShapes.field)
                    .padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (leadingIcon != null) {
                    Icon(leadingIcon, contentDescription = null, tint = p.textMuted, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(10.dp))
                }
                Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                    if (value.isEmpty() && placeholder.isNotEmpty()) {
                        Text(placeholder, style = MaterialTheme.typography.bodyMedium, color = p.textMuted, maxLines = 1)
                    }
                    inner()
                }
                if (trailing != null) trailing()
            }
        },
    )
}

// ---------------------------------------------------------------------------------------------------------------
// Dialogs & sheets
// ---------------------------------------------------------------------------------------------------------------

/** Dialog drawn with the app's own surface, shape and buttons (replaces the stock Material alert dialog). */
@Composable
fun AppDialog(
    onDismissRequest: () -> Unit,
    confirmButton: @Composable () -> Unit,
    modifier: Modifier = Modifier,
    dismissButton: (@Composable () -> Unit)? = null,
    icon: (@Composable () -> Unit)? = null,
    title: (@Composable () -> Unit)? = null,
    text: (@Composable () -> Unit)? = null,
) {
    val p = palette
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    Dialog(onDismissRequest = onDismissRequest, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        AnimatedVisibility(
            visible = shown,
            enter = fadeIn(motion.medium()) + scaleIn(motion.medium(), initialScale = 0.92f),
            exit = fadeOut(motion.fast()),
        ) {
            Column(
                modifier
                    .padding(horizontal = 24.dp)
                    .widthIn(max = 420.dp)
                    .shadow(24.dp, AppShapes.cardLarge, ambientColor = Color.Black, spotColor = Color.Black)
                    .clip(AppShapes.cardLarge)
                    .background(p.surfaceHigh)
                    .border(1.dp, p.outline, AppShapes.cardLarge)
                    .padding(start = 24.dp, end = 16.dp, top = 24.dp, bottom = 12.dp),
            ) {
                if (icon != null) Box(Modifier.padding(bottom = 12.dp)) { icon() }
                if (title != null) {
                    androidx.compose.runtime.CompositionLocalProvider(
                        androidx.compose.material3.LocalContentColor provides p.text,
                        androidx.compose.material3.LocalTextStyle provides MaterialTheme.typography.headlineSmall,
                    ) { Box(Modifier.padding(end = 8.dp, bottom = 12.dp)) { title() } }
                }
                if (text != null) {
                    androidx.compose.runtime.CompositionLocalProvider(
                        androidx.compose.material3.LocalContentColor provides p.textMuted,
                        androidx.compose.material3.LocalTextStyle provides MaterialTheme.typography.bodyMedium,
                    ) { Box(Modifier.padding(end = 8.dp, bottom = 12.dp)) { text() } }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                    if (dismissButton != null) {
                        dismissButton()
                        Spacer(Modifier.width(4.dp))
                    }
                    confirmButton()
                }
            }
        }
    }
}

/** Bottom sheet with the app's surface, large top corners and a drag handle. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppSheet(onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    val p = palette
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = p.surface,
        contentColor = p.text,
        tonalElevation = 0.dp,
        scrimColor = Color.Black.copy(alpha = 0.55f),
        shape = AppShapes.sheet,
        dragHandle = { SheetHandle(Modifier.padding(vertical = 12.dp)) },
        content = content,
    )
}

/** Centered icon + title + hint (+ action) for empty lists. */
@Composable
fun EmptyState(
    icon: ImageVector,
    title: String,
    body: String,
    modifier: Modifier = Modifier,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
) {
    val p = palette
    Column(
        modifier.fillMaxWidth().padding(horizontal = 40.dp, vertical = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.size(96.dp).clip(CircleShape).background(p.accentSoft), contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = null, tint = p.onAccentSoft, modifier = Modifier.size(44.dp))
        }
        Spacer(Modifier.height(Space.xl))
        Text(title, style = MaterialTheme.typography.headlineSmall, color = p.text, textAlign = TextAlign.Center)
        Spacer(Modifier.height(Space.s))
        Text(body, style = MaterialTheme.typography.bodyMedium, color = p.textMuted, textAlign = TextAlign.Center)
        if (actionLabel != null && onAction != null) {
            Spacer(Modifier.height(Space.xl))
            AccentButton(actionLabel, onAction)
        }
    }
}

/** Popup menu drawn with the app's surface and outline. */
@Composable
fun AppDropdownMenu(expanded: Boolean, onDismiss: () -> Unit, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val p = palette
    DropdownMenu(
        expanded = expanded,
        onDismissRequest = onDismiss,
        modifier = modifier,
        shape = AppShapes.card,
        containerColor = p.surfaceHigh,
        tonalElevation = 0.dp,
        shadowElevation = 16.dp,
        border = BorderStroke(1.dp, p.outline),
        content = content,
    )
}

@Composable
fun AppMenuItem(
    text: String,
    onClick: () -> Unit,
    selected: Boolean = false,
    destructive: Boolean = false,
    trailing: (@Composable () -> Unit)? = null,
) {
    val p = palette
    DropdownMenuItem(
        text = {
            Text(
                text,
                style = MaterialTheme.typography.bodyMedium,
                color = when {
                    destructive -> p.danger
                    selected -> p.accentText
                    else -> p.text
                },
            )
        },
        onClick = onClick,
        trailingIcon = trailing,
    )
}
