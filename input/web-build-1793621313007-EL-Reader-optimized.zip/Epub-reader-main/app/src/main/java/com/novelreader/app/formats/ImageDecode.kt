package com.novelreader.app.formats

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.IOException
import java.io.InputStream

/** Memory-safe bitmap decoding for comic pages and covers. */
object ImageDecode {

    /** Pictures with more pixels than this are refused (decompression-bomb guard; 100 MP). */
    const val MAX_SOURCE_PIXELS = 100_000_000L

    class Size(val width: Int, val height: Int)

    /** A decoded picture together with the size of the original and the sub-sampling that was applied. */
    class Decoded(val bitmap: Bitmap, val srcWidth: Int, val srcHeight: Int, val sample: Int)

    /** Pixel size of the picture without decoding it; null when it is not a readable image. */
    fun bounds(open: () -> InputStream): Size? = try {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        open().use { BitmapFactory.decodeStream(it, null, o) }
        if (o.outWidth > 0 && o.outHeight > 0) Size(o.outWidth, o.outHeight) else null
    } catch (_: IOException) {
        null
    }

    /** Largest power-of-two sample size that keeps the result at least [reqW] x [reqH] pixels. */
    fun sampleSize(srcW: Int, srcH: Int, reqW: Int, reqH: Int): Int {
        var sample = 1
        if (reqW <= 0 || reqH <= 0) return 1
        while (srcW / (sample * 2) >= reqW && srcH / (sample * 2) >= reqH) sample *= 2
        return sample
    }

    /**
     * Decodes the picture so that it is about [reqW] x [reqH] or larger (never upscaled beyond the original) and at most
     * [maxPixels] pixels. Returns null for a non-image, an oversized picture or when memory runs out.
     */
    fun decode(open: () -> InputStream, reqW: Int, reqH: Int, maxPixels: Long = 24_000_000L): Bitmap? =
        decodeWithInfo(open, reqW, reqH, maxPixels)?.bitmap

    fun decodeWithInfo(open: () -> InputStream, reqW: Int, reqH: Int, maxPixels: Long = 24_000_000L): Decoded? {
        val size = bounds(open) ?: return null
        if (size.width.toLong() * size.height > MAX_SOURCE_PIXELS) return null
        var sample = sampleSize(size.width, size.height, reqW, reqH)
        // Also respect the pixel budget.
        while ((size.width.toLong() / sample) * (size.height.toLong() / sample) > maxPixels) sample *= 2
        repeat(3) {
            try {
                val o = BitmapFactory.Options().apply {
                    inSampleSize = sample
                    inPreferredConfig = Bitmap.Config.ARGB_8888
                }
                val bmp = open().use { BitmapFactory.decodeStream(it, null, o) } ?: return null
                return Decoded(bmp, size.width, size.height, sample)
            } catch (_: OutOfMemoryError) {
                sample *= 2
            } catch (_: IOException) {
                return null
            }
        }
        return null
    }
}
