package com.novelreader.app.reader

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Pure geometry of the page turn (no Android types, unit tested).
 *
 * The curl is a sheet lifted at its free edge and rolled over a cylinder whose axis is vertical and sits at
 * [Plan.fold]. Everything is expressed in "spine space": `u` is the distance from the bound (spine) edge, so
 * `u = 0` is attached to the spine and `u = width` is the free edge the reader's finger holds. The view maps
 * spine space to the screen (left or right exit) when it draws.
 *
 *     flat      : u <= fold                    -> stays where it is
 *     roll      : fold < u <= fold + PI*radius -> wraps half a cylinder (front face, then the back face on top)
 *     flipped   : u > fold + PI*radius         -> lies flat again, back face up, mirrored, on top of the flat part
 */
object CurlGeometry {

    /** The free edge travels this far past the spine so the whole sheet has left the screen when progress = 1. */
    private const val TRAVEL = 2.04f

    /** Radius is ramped in over the first part of the lift, so progress 0 is exactly the flat page. */
    private const val RAMP = 0.12f

    /** Where the free edge is for a given turn progress (0 = flat, 1 = gone). */
    fun edgeFor(progress: Float, width: Float): Float = width - progress.coerceIn(0f, 1f) * TRAVEL * width

    /** Turn progress of a drag that moved the held edge [dragPx] towards the spine. */
    fun progressForDrag(dragPx: Float, width: Float): Float =
        if (width <= 0f) 0f else (dragPx / (TRAVEL * width)).coerceIn(0f, 1f)

    class Plan(
        /** Spine-space position where the sheet starts to wrap the cylinder. */
        val fold: Float,
        val radius: Float,
        /** Last spine-space point that is part of the roll (<= width). */
        val rollEnd: Float,
        /** Wrap angle reached at [rollEnd], 0..PI. */
        val thetaMax: Float,
        /** Spine-space start of the flipped flat part, or null when the roll has not got that far. */
        val flippedStart: Float?,
        /** Where the free edge ends up on screen (spine space). */
        val edge: Float,
        /** Spine-space x of the rightmost point of the roll (the shadow on the next page starts here). */
        val rim: Float,
        val width: Float,
    ) {
        val isFlat: Boolean get() = fold >= width
    }

    fun plan(edgeU: Float, width: Float, baseRadius: Float): Plan {
        val edge = edgeU.coerceAtMost(width)
        val lift = ((width - edge) / width).coerceIn(0f, 1f)
        val ramp = (lift / RAMP).coerceIn(0f, 1f)
        val radius = baseRadius * ramp * ramp * (3f - 2f * ramp)
        val fold = (edge + width - PI.toFloat() * radius) / 2f
        val full = PI.toFloat() * radius
        val rollEnd = min(width, fold + full)
        val theta = if (radius <= 0f) 0f else min(PI.toFloat(), (rollEnd - fold) / radius)
        val flippedStart = if (width > fold + full) fold + full else null
        val rim = fold + radius * sin(min(theta, (PI / 2).toFloat()))
        return Plan(fold, radius, rollEnd, theta, flippedStart, edge, rim, width)
    }

    /** Result of mapping one source column. */
    class Mapped(val x: Float, val theta: Float, val back: Boolean)

    /** Where the source column [u] ends up. [theta] is the wrap angle (0 flat .. PI flipped). */
    fun map(u: Float, p: Plan): Mapped {
        val fullRoll = PI.toFloat() * p.radius
        return when {
            u <= p.fold -> Mapped(u, 0f, false)
            p.radius <= 0f -> Mapped(2f * p.fold - u, PI.toFloat(), true)
            u <= p.fold + fullRoll -> {
                val th = (u - p.fold) / p.radius
                Mapped(p.fold + p.radius * sin(th), th, th > (PI / 2).toFloat())
            }
            else -> Mapped(p.fold - (u - p.fold - fullRoll), PI.toFloat(), true)
        }
    }

    /**
     * How strongly a surface at wrap angle [theta] is darkened (0..1): faces the viewer = 0, edge-on = 1.
     * The front face is seen for theta < PI/2, the back face above it.
     */
    fun darkness(theta: Float): Float = 1f - abs(cos(theta))

    /** Distance the cast shadow on the next page reaches. */
    fun shadowReach(width: Float, soft: Boolean): Float = width * (if (soft) 0.16f else 0.11f)

    // ---- gestures --------------------------------------------------------------------------------------------

    /**
     * Decides whether a released drag completes the turn.
     * @param dragPx how far the finger moved towards the exit side
     * @param velocity finger speed towards the exit side in px/s (negative = moving back)
     */
    fun shouldComplete(dragPx: Float, width: Float, velocity: Float, densityDpi: Float): Boolean {
        val flick = 500f * densityDpi / 160f
        if (velocity > flick) return dragPx > 0f
        if (velocity < -flick) return false
        return dragPx > width * 0.28f
    }

    /** Duration of the turn animation for a speed setting of 1 (slow) .. 10 (fast). */
    fun durationFor(speed: Int): Long = (760 - (speed.coerceIn(1, 10) - 1) * 66).toLong()
}
