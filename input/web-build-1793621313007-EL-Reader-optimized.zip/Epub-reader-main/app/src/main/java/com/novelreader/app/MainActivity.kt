package com.novelreader.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.remember
import androidx.core.content.IntentCompat
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import com.novelreader.app.formats.ReaderRouter
import kotlinx.coroutines.launch
import com.novelreader.app.ui.design.AppTheme
import com.novelreader.app.ui.library.LibraryEvent
import com.novelreader.app.ui.home.AppRoot
import com.novelreader.app.ui.library.LibraryViewModel
import com.novelreader.app.core.PickKind
import com.novelreader.app.graph
import com.novelreader.app.ui.files.PickFromStorage

/**
 * Library screen and the entry point for "Open with" / "Share" of EPUB files from other apps.
 * External files are copied to private storage first (the temporary read grant of a content:// URI can vanish),
 * added to the library like any other book, and opened directly in the reader.
 */
class MainActivity : AppCompatActivity() {

    private val vm: LibraryViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        setContent {
            val appSettings = vm.settings.collectAsState().value
            val snackbar = remember { SnackbarHostState() }
            // Both menu entries open the in-app file manager (real storage, multi-select); it reports file:// or
            // content:// URIs, which are imported one by one.
            val pickBooks = rememberLauncherForActivityResult(PickFromStorage()) { vm.importPicked(it) }
            val pickFolder = rememberLauncherForActivityResult(PickFromStorage()) { vm.importPicked(it) }

            LaunchedEffect(Unit) {
                vm.events.collect { e ->
                    when (e) {
                        is LibraryEvent.OpenBook -> openBook(e.bookId)
                        is LibraryEvent.Message -> {
                            val args = listOfNotNull(e.arg, e.arg2, e.arg3).toTypedArray<Any>()
                            snackbar.showSnackbar(if (args.isEmpty()) getString(e.resId) else getString(e.resId, *args))
                        }
                    }
                }
            }

            AppTheme(settings = appSettings, syncSystemChrome = true) {
                AppRoot(
                    vm = vm,
                    onOpenBook = { openBook(it) },
                    onOpenAt = { id, locator -> openBook(id, locator) },
                    onPickBooks = { pickBooks.launch(PickKind.BOOKS) },
                    onPickFolder = { pickFolder.launch(PickKind.FOLDER) },
                    snackbar = snackbar,
                )
            }
        }

        // Only the first creation handles the launching intent; rotations must not re-import it.
        if (savedInstanceState == null) handleIncoming(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncoming(intent)
    }

    /** Opens a book in the reader of its format (EPUB, PDF, text/Word document or comic). */
    private fun openBook(id: Long, locatorJson: String? = null) {
        lifecycleScope.launch {
            val book = graph.library.get(id) ?: return@launch
            startActivity(ReaderRouter.intent(this@MainActivity, book, locatorJson))
        }
    }

    private fun handleIncoming(intent: Intent?) {
        val uri = incomingUri(intent) ?: return
        // Consume it so a later recreation does not process the same file again.
        intent?.data = null
        intent?.removeExtra(Intent.EXTRA_STREAM)
        vm.openExternal(uri)
    }

    private fun incomingUri(intent: Intent?): Uri? = when (intent?.action) {
        Intent.ACTION_VIEW -> intent.data
        Intent.ACTION_SEND -> IntentCompat.getParcelableExtra(intent, Intent.EXTRA_STREAM, Uri::class.java)
            ?: intent.clipData?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.uri
        else -> null
    }.also { uri ->
        if (uri == null && (intent?.action == Intent.ACTION_VIEW || intent?.action == Intent.ACTION_SEND)) {
            Toast.makeText(this, R.string.import_err_no_access, Toast.LENGTH_LONG).show()
        }
    }
}
