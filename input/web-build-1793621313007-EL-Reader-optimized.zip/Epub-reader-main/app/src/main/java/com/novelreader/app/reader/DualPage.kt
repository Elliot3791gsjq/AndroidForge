package com.novelreader.app.reader

/**
 * Dual-Page Mode: two pages side by side.
 *
 * The reading engine (Readium CSS) only lets a *user* column count take effect when the viewport is at least ~60em
 * wide, which no phone reaches - not even in landscape - so the preference alone does nothing on a phone. The reader
 * therefore also sends the column count as a reading-system property (see ReaderActivity), which has no such gate.
 * That property is fixed for the lifetime of a navigator, so a change of [active] reopens the reader at the same page.
 */
object DualPage {
    /**
     * @param dualPage the user's switch
     * @param portraitToo the user also wants two pages in portrait (very narrow columns on a phone, so it is opt-in)
     * @param scrolling continuous scrolling has no pages to put side by side
     * @param landscape the screen is wider than tall
     */
    fun active(dualPage: Boolean, portraitToo: Boolean, scrolling: Boolean, landscape: Boolean): Boolean =
        dualPage && !scrolling && (landscape || portraitToo)
}
