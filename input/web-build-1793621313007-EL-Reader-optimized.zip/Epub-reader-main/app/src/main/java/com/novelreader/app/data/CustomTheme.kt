package com.novelreader.app.data

import org.json.JSONArray
import org.json.JSONObject

/**
 * A user-made app theme. One accent is shared by both brightness modes; background, surface and text are chosen
 * per mode (null surface/text = derived automatically from the background). Whatever is chosen, the palette
 * builder guarantees readable contrast, so a custom theme can never be saved in an unreadable state.
 */
data class CustomTheme(
    val id: String,
    val name: String,
    val accent: Int,
    val darkBg: Int,
    val darkSurface: Int? = null,
    val darkText: Int? = null,
    val lightBg: Int,
    val lightSurface: Int? = null,
    val lightText: Int? = null,
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("name", name).put("accent", accent)
        .put("dbg", darkBg).put("dsf", darkSurface ?: JSONObject.NULL).put("dtx", darkText ?: JSONObject.NULL)
        .put("lbg", lightBg).put("lsf", lightSurface ?: JSONObject.NULL).put("ltx", lightText ?: JSONObject.NULL)

    companion object {
        const val ID_PREFIX = "c_"

        fun newId(): String = ID_PREFIX + java.lang.Long.toString(System.currentTimeMillis(), 36)

        private fun JSONObject.optIntOrNull(key: String): Int? = if (isNull(key) || !has(key)) null else getInt(key)

        fun fromJson(o: JSONObject): CustomTheme? = try {
            CustomTheme(
                id = o.getString("id"),
                name = o.optString("name", "Custom"),
                accent = o.getInt("accent"),
                darkBg = o.getInt("dbg"),
                darkSurface = o.optIntOrNull("dsf"),
                darkText = o.optIntOrNull("dtx"),
                lightBg = o.getInt("lbg"),
                lightSurface = o.optIntOrNull("lsf"),
                lightText = o.optIntOrNull("ltx"),
            )
        } catch (_: Exception) {
            null
        }

        fun listToJson(list: List<CustomTheme>): String =
            JSONArray().also { a -> list.forEach { a.put(it.toJson()) } }.toString()

        fun listFromJson(json: String?): List<CustomTheme> {
            if (json.isNullOrBlank()) return emptyList()
            return try {
                val a = JSONArray(json)
                (0 until a.length()).mapNotNull { fromJson(a.getJSONObject(it)) }
            } catch (_: Exception) {
                emptyList()
            }
        }
    }
}
