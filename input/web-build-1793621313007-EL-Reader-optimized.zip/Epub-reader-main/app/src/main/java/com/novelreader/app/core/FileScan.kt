package com.novelreader.app.core

import java.io.File
import java.util.Locale

/** What the in-app storage browser is asked to pick. */
enum class PickKind(val extensions: Set<String>) {
    /** Any number of books (EPUB, PDF, TXT, DOCX, CBZ, CBR), free browsing. */
    BOOKS(com.novelreader.app.formats.BookFormat.allExtensions),

    /** One folder; every supported book inside it (and its sub-folders) is returned. */
    FOLDER(com.novelreader.app.formats.BookFormat.allExtensions),
    FONTS(setOf("ttf", "otf")),
    IMAGE(setOf("jpg", "jpeg", "png", "webp", "gif", "bmp", "heic", "heif", "avif")),
}

/**
 * Pure file-system helpers behind the storage browser (plain java.io, no Android classes, unit-tested).
 */
object FileScan {

    data class Entry(val file: File, val name: String, val isDir: Boolean, val size: Long, val modified: Long)

    /** True when [name] has one of [extensions] (case-insensitive, compared without the dot). */
    fun hasExtension(name: String, extensions: Set<String>): Boolean {
        val dot = name.lastIndexOf('.')
        if (dot < 0 || dot == name.length - 1) return false
        return name.substring(dot + 1).lowercase(Locale.ROOT) in extensions
    }

    /**
     * Case-insensitive "natural" order: digit runs compare by value, so "Book 2" sorts before "Book 10".
     * Used for both folders and files in the browser.
     */
    val naturalOrder: Comparator<String> = Comparator { a, b -> compareNatural(a, b) }

    fun compareNatural(a: String, b: String): Int {
        var i = 0
        var j = 0
        while (i < a.length && j < b.length) {
            val ca = a[i]
            val cb = b[j]
            if (ca.isDigit() && cb.isDigit()) {
                var ie = i
                while (ie < a.length && a[ie].isDigit()) ie++
                var je = j
                while (je < b.length && b[je].isDigit()) je++
                val na = a.substring(i, ie).trimStart('0')
                val nb = b.substring(j, je).trimStart('0')
                if (na.length != nb.length) return na.length - nb.length
                val c = na.compareTo(nb)
                if (c != 0) return c
                i = ie
                j = je
            } else {
                val c = ca.lowercaseChar().compareTo(cb.lowercaseChar())
                if (c != 0) return c
                i++
                j++
            }
        }
        val rest = (a.length - i) - (b.length - j)
        return if (rest != 0) rest else a.compareTo(b)
    }

    /**
     * Sub-folders and files with one of [extensions] directly inside [dir]; folders first, each group in natural order.
     * Hidden entries (leading dot) are skipped. Returns null when the folder cannot be read (no permission / gone).
     */
    fun list(dir: File, extensions: Set<String>): List<Entry>? {
        val children = try {
            dir.listFiles()
        } catch (_: SecurityException) {
            null
        } ?: return null
        val folders = ArrayList<Entry>()
        val files = ArrayList<Entry>()
        for (f in children) {
            val name = f.name
            if (name.startsWith(".")) continue
            if (f.isDirectory) {
                folders += Entry(f, name, true, 0L, f.lastModified())
            } else if (hasExtension(name, extensions)) {
                files += Entry(f, name, false, f.length(), f.lastModified())
            }
        }
        val byName = Comparator<Entry> { x, y -> naturalOrder.compare(x.name, y.name) }
        folders.sortWith(byName)
        files.sortWith(byName)
        return folders + files
    }

    /**
     * Every file with one of [extensions] under [root] (recursive, breadth-first so shallow files come first).
     * Hidden folders are skipped, symbolic-link loops are detected via canonical paths, and the walk stops after
     * [maxResults] files or [maxFolders] folders, or as soon as [cancelled] returns true.
     */
    fun scan(
        root: File,
        extensions: Set<String>,
        maxResults: Int = 20_000,
        maxFolders: Int = 50_000,
        cancelled: () -> Boolean = { false },
    ): List<File> {
        val found = ArrayList<File>()
        val seen = HashSet<String>()
        val queue = ArrayDeque<File>()
        queue.add(root)
        var folders = 0
        while (queue.isNotEmpty() && found.size < maxResults && folders < maxFolders) {
            if (cancelled()) break
            val dir = queue.removeFirst()
            val canonical = try { dir.canonicalPath } catch (_: Exception) { dir.absolutePath }
            if (!seen.add(canonical)) continue
            folders++
            val children = try { dir.listFiles() } catch (_: SecurityException) { null } ?: continue
            val subs = ArrayList<File>()
            val here = ArrayList<File>()
            for (f in children) {
                if (f.name.startsWith(".")) continue
                if (f.isDirectory) subs += f
                else if (hasExtension(f.name, extensions)) here += f
            }
            here.sortWith { x, y -> naturalOrder.compare(x.name, y.name) }
            for (f in here) {
                if (found.size >= maxResults) break
                found += f
            }
            subs.sortWith { x, y -> naturalOrder.compare(x.name, y.name) }
            queue.addAll(subs)
        }
        return found
    }

    /** "1.4 MB" style size (decimal units, as file managers show them). */
    fun formatSize(bytes: Long): String {
        if (bytes < 1000) return "$bytes B"
        val units = arrayOf("KB", "MB", "GB", "TB")
        var v = bytes / 1000.0
        var u = 0
        while (v >= 1000 && u < units.lastIndex) { v /= 1000; u++ }
        return String.format(Locale.US, if (v >= 100) "%.0f %s" else "%.1f %s", v, units[u])
    }
}
