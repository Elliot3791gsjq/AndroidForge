package com.novelreader.app.ui.design

import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import com.novelreader.app.core.ColorMath
import com.novelreader.app.data.CustomTheme
import com.novelreader.app.data.ReaderSettings
import com.novelreader.app.data.UiMode

/**
 * The complete colour vocabulary of the app UI as plain ARGB Ints (so the maths can be unit-tested on the JVM).
 * Every screen reads these tokens through [AppPalette]; nothing in the UI hard-codes a colour.
 *
 * Legibility is a property of the builder, not of the user's input: whatever accent/background a theme starts
 * from, [PaletteFactory] pushes text, muted text and accent-as-text until they pass WCAG contrast against the
 * surfaces they are drawn on. That is why the app never needs a "this colour is hard to read" refusal.
 */
data class ArgbPalette(
    val dark: Boolean,
    val bg: Int,
    val surface: Int,
    val surfaceHigh: Int,
    val surfaceHighest: Int,
    val outline: Int,
    val text: Int,
    val textMuted: Int,
    /** Fill colour of buttons / indicators (needs 3:1 against the background). */
    val accent: Int,
    /** Accent when it is used as text or a thin icon on a surface (needs 4.5:1). */
    val accentText: Int,
    val onAccent: Int,
    val accentSoft: Int,
    val onAccentSoft: Int,
    val danger: Int,
)

/** [ArgbPalette] as Compose colours. */
@Immutable
data class AppPalette(
    val dark: Boolean,
    val bg: Color,
    val surface: Color,
    val surfaceHigh: Color,
    val surfaceHighest: Color,
    val outline: Color,
    val text: Color,
    val textMuted: Color,
    val accent: Color,
    val accentText: Color,
    val onAccent: Color,
    val accentSoft: Color,
    val onAccentSoft: Color,
    val danger: Color,
)

fun ArgbPalette.toAppPalette() = AppPalette(
    dark = dark, bg = Color(bg), surface = Color(surface), surfaceHigh = Color(surfaceHigh),
    surfaceHighest = Color(surfaceHighest), outline = Color(outline), text = Color(text),
    textMuted = Color(textMuted), accent = Color(accent), accentText = Color(accentText),
    onAccent = Color(onAccent), accentSoft = Color(accentSoft), onAccentSoft = Color(onAccentSoft),
    danger = Color(danger),
)

/** One ready-made theme: an accent and hand-picked background/text for each brightness. */
data class PresetSpec(
    val id: String,
    val accentDark: Int,
    val accentLight: Int,
    val darkBg: Int,
    val darkText: Int,
    val lightBg: Int,
    val lightText: Int,
)

object Presets {
    const val EMBER = "ember"
    const val OCEAN = "ocean"
    const val VIOLET = "violet"
    const val FOREST = "forest"
    const val CRIMSON = "crimson"
    const val TEAL = "teal"
    const val MINIMAL = "minimal"
    const val PAPER = "paper"

    val all = listOf(
        PresetSpec(EMBER, 0xFFFF5A1F.toInt(), 0xFFE8501A.toInt(), 0xFF0B0908.toInt(), 0xFFFFF7F4.toInt(), 0xFFFBF6F2.toInt(), 0xFF291810.toInt()),
        PresetSpec(OCEAN, 0xFF4DA3FF.toInt(), 0xFF1F6FD6.toInt(), 0xFF070B14.toInt(), 0xFFEAF1FF.toInt(), 0xFFF3F7FD.toInt(), 0xFF0E1B33.toInt()),
        PresetSpec(VIOLET, 0xFFA97BFF.toInt(), 0xFF7B45E0.toInt(), 0xFF0C0914.toInt(), 0xFFF2ECFF.toInt(), 0xFFF8F4FE.toInt(), 0xFF24143D.toInt()),
        PresetSpec(FOREST, 0xFF5FD38A.toInt(), 0xFF1E9B55.toInt(), 0xFF08100B.toInt(), 0xFFEAF7EE.toInt(), 0xFFF2F8F3.toInt(), 0xFF10241A.toInt()),
        PresetSpec(CRIMSON, 0xFFFF4B5C.toInt(), 0xFFD6283C.toInt(), 0xFF121011.toInt(), 0xFFFBF0F0.toInt(), 0xFFFBF3F3.toInt(), 0xFF2B1214.toInt()),
        PresetSpec(TEAL, 0xFF2DD4BF.toInt(), 0xFF0F9E8E.toInt(), 0xFF06100F.toInt(), 0xFFE6F7F5.toInt(), 0xFFF0F8F7.toInt(), 0xFF0B2420.toInt()),
        PresetSpec(MINIMAL, 0xFFE6E6E6.toInt(), 0xFF1A1A1A.toInt(), 0xFF0F0F10.toInt(), 0xFFF4F4F4.toInt(), 0xFFFFFFFF.toInt(), 0xFF141414.toInt()),
        PresetSpec(PAPER, 0xFFD98B3F.toInt(), 0xFFB4531F.toInt(), 0xFF17120D.toInt(), 0xFFF3E8D6.toInt(), 0xFFF6EFE4.toInt(), 0xFF3A2A1A.toInt()),
    )

    fun byId(id: String?): PresetSpec = all.firstOrNull { it.id == id } ?: all.first()
    fun isPreset(id: String?): Boolean = all.any { it.id == id }
}

object PaletteFactory {

    private const val TEXT_RATIO = 7.0
    private const val MUTED_RATIO = 4.5
    private const val ACCENT_TEXT_RATIO = 4.5
    private const val ACCENT_FILL_RATIO = 3.0

    /**
     * Builds the full palette from the few colours a theme actually defines.
     * [text] / [surface] null = derived from the background.
     *
     * Order matters: the text colour is settled against the page first; every surface (derived or user-chosen) is then
     * pulled back towards the page until that text is readable on it; finally text, muted text and accent-as-text are
     * pushed - in the page's text polarity - until they pass on the page AND on every surface. Mid-tone pages cannot
     * reach 7:1 at all (the physical maximum is about 4.6:1); there the strongest possible colour is used.
     */
    fun build(accent: Int, bg: Int, text: Int?, surface: Int?, dark: Boolean): ArgbPalette {
        val opaque = 0xFF shl 24
        val bgOpaque = bg or opaque
        val polarity = ColorMath.bestTextOn(bgOpaque)
        val baseText = text?.let { it or opaque } ?: ColorMath.mix(polarity, accent, 0.06f)
        val pageText = ColorMath.ensureContrast(baseText, bgOpaque, TEXT_RATIO)
        val surfaceFloor = minOf(MUTED_RATIO, ColorMath.contrastRatio(pageText, bgOpaque))

        fun readable(c: Int): Int {
            var s = c
            var n = 0
            while (ColorMath.contrastRatio(pageText, s) < surfaceFloor && n < 40) {
                s = ColorMath.mix(s, bgOpaque, 0.15f)
                n++
            }
            return s
        }

        // Tint used to mix the surface ladder: mostly text colour with a trace of the accent.
        val tint = ColorMath.mix(baseText, accent, 0.14f)
        val custom = surface?.let { it or opaque }
        val base = custom ?: bgOpaque
        val raw1 = custom ?: ColorMath.mix(bgOpaque, tint, if (dark) 0.085f else 0.05f)
        val raw2 = if (custom != null) ColorMath.mix(raw1, tint, if (dark) 0.07f else 0.045f)
        else ColorMath.mix(base, tint, if (dark) 0.15f else 0.095f)
        val raw3 = if (custom != null) ColorMath.mix(raw1, tint, if (dark) 0.14f else 0.09f)
        else ColorMath.mix(base, tint, if (dark) 0.22f else 0.15f)
        val s1 = readable(raw1)
        val surfaceHigh = readable(raw2)
        val surfaceHighest = readable(raw3)

        val finalText = ColorMath.ensureContrastOnAll(pageText, polarity, TEXT_RATIO, bgOpaque, s1, surfaceHigh, surfaceHighest)
        val mutedSeed = ColorMath.mix(bgOpaque, finalText, 0.64f)
        val muted = ColorMath.ensureContrastOnAll(mutedSeed, polarity, MUTED_RATIO, bgOpaque, s1, surfaceHigh, surfaceHighest)

        val accentFill = ColorMath.ensureContrast(accent or opaque, bgOpaque, ACCENT_FILL_RATIO)
        val accentText = ColorMath.ensureContrastOnAll(accentFill, polarity, ACCENT_TEXT_RATIO, bgOpaque, s1, surfaceHigh, surfaceHighest)
        val onAccent = ColorMath.bestTextOn(accentFill)

        val accentSoft = ColorMath.mix(s1, accentFill, if (dark) 0.30f else 0.20f)
        val onAccentSoft = ColorMath.ensureContrast(accentText, accentSoft, ACCENT_TEXT_RATIO)

        val outline = ColorMath.mix(bgOpaque, finalText, if (dark) 0.17f else 0.16f)
        val danger = ColorMath.ensureContrast(if (dark) 0xFFFF6B6B.toInt() else 0xFFC62828.toInt(), surfaceHigh, ACCENT_TEXT_RATIO)

        return ArgbPalette(
            dark = dark, bg = bgOpaque, surface = s1, surfaceHigh = surfaceHigh, surfaceHighest = surfaceHighest,
            outline = outline, text = finalText, textMuted = muted, accent = accentFill, accentText = accentText,
            onAccent = onAccent, accentSoft = accentSoft, onAccentSoft = onAccentSoft, danger = danger,
        )
    }

    fun build(preset: PresetSpec, dark: Boolean): ArgbPalette =
        if (dark) build(preset.accentDark, preset.darkBg, preset.darkText, null, true)
        else build(preset.accentLight, preset.lightBg, preset.lightText, null, false)

    fun build(theme: CustomTheme, dark: Boolean): ArgbPalette =
        if (dark) build(theme.accent, theme.darkBg, theme.darkText, theme.darkSurface, true)
        else build(theme.accent, theme.lightBg, theme.lightText, theme.lightSurface, false)

    /** Whether the UI should be dark for [mode] given the system setting. */
    fun isDark(mode: UiMode, systemDark: Boolean): Boolean = when (mode) {
        UiMode.SYSTEM -> systemDark
        UiMode.DARK -> true
        UiMode.LIGHT -> false
    }

    /** The palette for the saved settings: a custom theme if the id matches one, else a preset (unknown id = Ember). */
    fun resolve(settings: ReaderSettings, systemDark: Boolean): ArgbPalette {
        val dark = isDark(settings.uiMode, systemDark)
        val custom = settings.customThemes.firstOrNull { it.id == settings.colorThemeId }
        return if (custom != null) build(custom, dark) else build(Presets.byId(settings.colorThemeId), dark)
    }
}
