package com.novelreader.app.core

import java.io.File
import java.util.zip.ZipFile

/**
 * Real character / word counts of an EPUB, taken from its own XHTML content files (nothing is estimated).
 * Markup, scripts and styles are removed first; the common HTML entities are decoded.
 * Words are whitespace-separated tokens, so for scripts written without spaces (e.g. Chinese/Japanese) the word
 * count is only a rough figure - the character count stays exact.
 */
object TextStats {
    data class Result(val characters: Long, val words: Long)

    private val scriptStyle = Regex("(?is)<(script|style)[^>]*>.*?</\\1>")
    private val tag = Regex("(?s)<[^>]*>")
    private val entity = Regex("&(#x?[0-9a-fA-F]+|[a-zA-Z]+);")
    private val spaces = Regex("\\s+")

    fun compute(epub: File): Result? = try {
        var chars = 0L
        var words = 0L
        ZipFile(epub).use { zip ->
            val entries = zip.entries()
            while (entries.hasMoreElements()) {
                val e = entries.nextElement()
                if (e.isDirectory) continue
                val name = e.name.lowercase()
                if (!(name.endsWith(".xhtml") || name.endsWith(".html") || name.endsWith(".htm"))) continue
                val raw = zip.getInputStream(e).use { it.readBytes().toString(Charsets.UTF_8) }
                val text = plainText(raw)
                chars += text.count { !it.isWhitespace() }
                if (text.isNotBlank()) words += text.trim().split(spaces).size
            }
        }
        Result(chars, words)
    } catch (_: Throwable) {
        null
    }

    internal fun plainText(html: String): String {
        val noScript = scriptStyle.replace(html, " ")
        val noTags = tag.replace(noScript, " ")
        return entity.replace(noTags) { m ->
            val v = m.groupValues[1]
            when {
                v.startsWith("#x") || v.startsWith("#X") -> v.drop(2).toIntOrNull(16)?.let { String(Character.toChars(it)) } ?: " "
                v.startsWith("#") -> v.drop(1).toIntOrNull()?.let { String(Character.toChars(it)) } ?: " "
                v == "amp" -> "&"
                v == "lt" -> "<"
                v == "gt" -> ">"
                v == "quot" -> "\""
                v == "apos" -> "'"
                v == "nbsp" -> " "
                else -> " "
            }
        }
    }
}
