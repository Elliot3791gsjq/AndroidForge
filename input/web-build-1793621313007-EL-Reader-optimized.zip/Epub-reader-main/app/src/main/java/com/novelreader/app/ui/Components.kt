package com.novelreader.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.absoluteOffset
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.novelreader.app.R
import com.novelreader.app.core.ColorMath
import com.novelreader.app.ui.design.AppChip
import com.novelreader.app.ui.design.AppDialog
import com.novelreader.app.ui.design.AppShapes
import com.novelreader.app.ui.design.AppSlider
import com.novelreader.app.ui.design.AppTextField
import com.novelreader.app.ui.design.ColorDot
import com.novelreader.app.ui.design.SectionLabel
import com.novelreader.app.ui.design.SoftIconButton
import com.novelreader.app.ui.design.palette
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.filterNotNull
import kotlin.math.roundToInt

/** Section heading inside settings panels. */
@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    SectionLabel(text, modifier)
}

/**
 * A slider with - / + buttons and a live value readout. Dragging applies the value live (debounced so the
 * navigator is not flooded) and the final value is committed on release.
 */
@OptIn(FlowPreview::class)
@Composable
fun StepperSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    step: Float,
    valueText: (Float) -> String,
    onCommit: (Float) -> Unit,
    modifier: Modifier = Modifier,
) {
    var drag by remember { mutableStateOf<Float?>(null) }
    val latest by rememberUpdatedState(onCommit)
    LaunchedEffect(Unit) {
        snapshotFlow { drag }.filterNotNull().debounce(120).collect { latest(it) }
    }
    val shown = drag ?: value
    fun snap(v: Float): Float {
        val s = ((v - range.start) / step).roundToInt() * step + range.start
        return s.coerceIn(range.start, range.endInclusive)
    }
    val p = palette
    Column(modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(label, style = MaterialTheme.typography.bodyMedium, color = p.text)
            Box(Modifier.clip(CircleShape).background(p.accentSoft).padding(horizontal = 12.dp, vertical = 4.dp)) {
                Text(valueText(shown), style = MaterialTheme.typography.labelLarge, color = p.onAccentSoft)
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            SoftIconButton(AppIcons.Remove, stringResource(R.string.decrease), { latest(snap(shown - step)) }, size = 36.dp)
            AppSlider(
                value = shown,
                onValueChange = { drag = snap(it) },
                onValueChangeFinished = { drag?.let { d -> latest(d) }; drag = null },
                valueRange = range,
                modifier = Modifier.weight(1f).padding(horizontal = 4.dp),
            )
            SoftIconButton(Icons.Default.Add, stringResource(R.string.increase), { latest(snap(shown + step)) }, size = 36.dp)
        }
    }
}

/** Row of colour swatches; [selected] gets a check mark. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SwatchRow(
    colors: List<Int>,
    selected: Int?,
    onPick: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    FlowRow(modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        colors.forEach { c ->
            ColorDot(Color(c), selected == c, size = 38.dp, onClick = { onPick(c) })
        }
    }
}

/** Chip group for a small enum-like choice; wraps onto more lines when needed. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun <T> ChoiceChips(
    options: List<Pair<T, String>>,
    selected: T,
    onSelect: (T) -> Unit,
    modifier: Modifier = Modifier,
) {
    FlowRow(modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (value, label) ->
            AppChip(label = label, selected = value == selected, onClick = { onSelect(value) })
        }
    }
}

/**
 * A custom slider whose track is painted with [brush] (hue rainbow, saturation ramp, ...).
 *
 * The value is set the moment the finger goes down and follows it while dragging; the round handle is centred under
 * the finger over the whole track, including the two ends (the handle travels from its half-width to
 * `width - half-width`, so the touch position is mapped over that same travel).
 */
@Composable
private fun GradientTrackSlider(
    fraction: Float,
    onFraction: (Float) -> Unit,
    brush: Brush,
    description: String,
    modifier: Modifier = Modifier,
) {
    var width by remember { mutableFloatStateOf(1f) }
    val thumb = 28.dp
    val thumbPx = with(androidx.compose.ui.platform.LocalDensity.current) { thumb.toPx() }
    val latest by rememberUpdatedState(onFraction)
    fun toFraction(x: Float): Float {
        val travel = (width - thumbPx).coerceAtLeast(1f)
        return ((x - thumbPx / 2f) / travel).coerceIn(0f, 1f)
    }
    Box(
        modifier
            .fillMaxWidth()
            .height(thumb)
            .onSizeChanged { width = it.width.toFloat().coerceAtLeast(1f) }
            .semantics {
                contentDescription = description
                stateDescription = "${(fraction.coerceIn(0f, 1f) * 100).roundToInt()}%"
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    latest(toFraction(down.position.x))
                    down.consume()
                    // Follow the finger through every event, including the final lift, so the value ends exactly
                    // where the finger was released.
                    while (true) {
                        val change = awaitPointerEvent().changes.firstOrNull { it.id == down.id } ?: break
                        latest(toFraction(change.position.x))
                        change.consume()
                        if (!change.pressed) break
                    }
                }
            },
        contentAlignment = Alignment.CenterStart,
    ) {
        Box(Modifier.fillMaxWidth().height(12.dp).clip(CircleShape).background(brush))
        Box(
            Modifier
                .absoluteOffset { IntOffset((fraction.coerceIn(0f, 1f) * (width - thumbPx)).roundToInt(), 0) }
                .size(thumb)
                .shadow(4.dp, CircleShape)
                .clip(CircleShape)
                .background(Color.White)
                .border(3.dp, Color(0x33000000), CircleShape)
        )
    }
}

/**
 * Colour picker dialog: hue / saturation / brightness sliders with gradient tracks, a HEX field and a live
 * preview. There is deliberately no "colour too similar" refusal - the app's palette builders keep whatever
 * is chosen legible by themselves. [preview] can draw the colour in context (e.g. a sample page).
 */
@Composable
fun ColorPickerDialog(
    title: String,
    initial: Int,
    onDismiss: () -> Unit,
    onConfirm: (Int) -> Unit,
    preview: (@Composable (Int) -> Unit)? = null,
) {
    val initialHsv = remember(initial) { ColorMath.argbToHsv(initial) }
    var hue by remember { mutableFloatStateOf(initialHsv[0]) }
    var sat by remember { mutableFloatStateOf(initialHsv[1]) }
    var value by remember { mutableFloatStateOf(initialHsv[2]) }
    val color = ColorMath.hsvToArgb(hue, sat, value)
    var hex by remember { mutableStateOf(ColorMath.toHex(initial)) }
    var hexError by remember { mutableStateOf(false) }
    val p = palette

    fun sync() { hex = ColorMath.toHex(ColorMath.hsvToArgb(hue, sat, value)); hexError = false }

    AppDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(64.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(color))
                        .border(1.dp, p.outline, RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center,
                ) { if (preview != null) preview(color) }
                Text(stringResource(R.string.picker_hue), style = MaterialTheme.typography.labelMedium)
                GradientTrackSlider(
                    hue / 360f, { hue = it * 360f; sync() },
                    Brush.horizontalGradient((0..6).map { Color(ColorMath.hsvToArgb(it * 60f, 1f, 1f)) }),
                    description = stringResource(R.string.picker_hue),
                )
                Text(stringResource(R.string.picker_saturation), style = MaterialTheme.typography.labelMedium)
                GradientTrackSlider(
                    sat, { sat = it; sync() },
                    Brush.horizontalGradient(listOf(Color(ColorMath.hsvToArgb(hue, 0f, value)), Color(ColorMath.hsvToArgb(hue, 1f, value)))),
                    description = stringResource(R.string.picker_saturation),
                )
                Text(stringResource(R.string.picker_brightness), style = MaterialTheme.typography.labelMedium)
                GradientTrackSlider(
                    value, { value = it; sync() },
                    Brush.horizontalGradient(listOf(Color.Black, Color(ColorMath.hsvToArgb(hue, sat, 1f)))),
                    description = stringResource(R.string.picker_brightness),
                )
                AppTextField(
                    value = hex,
                    onValueChange = { text ->
                        hex = text
                        val parsed = ColorMath.parseHex(text)
                        hexError = parsed == null
                        if (parsed != null) {
                            val hsv = ColorMath.argbToHsv(parsed)
                            hue = hsv[0]; sat = hsv[1]; value = hsv[2]
                        }
                    },
                    placeholder = "HEX  #RRGGBB",
                )
                if (hexError) Text(stringResource(R.string.picker_hex_invalid), color = p.danger, style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(ColorMath.parseHex(hex) ?: color) }, enabled = !hexError) { Text(stringResource(R.string.apply)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}
