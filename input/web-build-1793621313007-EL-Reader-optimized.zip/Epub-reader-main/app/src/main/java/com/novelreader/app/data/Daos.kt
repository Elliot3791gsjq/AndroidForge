package com.novelreader.app.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface BookDao {
    @Query("SELECT * FROM books WHERE inLibrary = 1")
    fun observeLibrary(): Flow<List<BookEntity>>

    @Query("SELECT * FROM books WHERE id = :id")
    suspend fun getById(id: Long): BookEntity?

    @Query("SELECT * FROM books WHERE sha256 = :sha")
    suspend fun getBySha(sha: String): BookEntity?

    @Insert
    suspend fun insert(book: BookEntity): Long

    @Query("UPDATE books SET inLibrary = :inLibrary WHERE id = :id")
    suspend fun setInLibrary(id: Long, inLibrary: Boolean)

    @Query(
        "UPDATE books SET progress = :progress, lastLocatorJson = :locatorJson, lastReadAt = :readAt WHERE id = :id"
    )
    suspend fun updatePosition(id: Long, progress: Double, locatorJson: String, readAt: Long)

    @Query("UPDATE books SET readingMillis = readingMillis + :delta WHERE id = :id")
    suspend fun addReadingTime(id: Long, delta: Long)

    @Query("UPDATE books SET charCount = :chars, wordCount = :words WHERE id = :id")
    suspend fun setTextStats(id: Long, chars: Long, words: Long)

    @Query("UPDATE books SET favorite = :favorite WHERE id = :id")
    suspend fun setFavorite(id: Long, favorite: Boolean)

    @Query("UPDATE books SET customCoverPath = :path WHERE id = :id")
    suspend fun setCustomCover(id: Long, path: String?)

    /** Every book, including hidden ones (reading stats still count their sittings). */
    @Query("SELECT * FROM books")
    fun observeAll(): Flow<List<BookEntity>>

    @Query("UPDATE books SET lastReadAt = :readAt WHERE id = :id")
    suspend fun touch(id: Long, readAt: Long)

    @Query("DELETE FROM books WHERE id = :id")
    suspend fun deleteById(id: Long)
}

/** A bookmark joined with its book, for the library-wide Bookmarks screen. */
data class GlobalBookmark(
    val id: Long, val bookId: Long, val bookTitle: String, val locatorJson: String,
    val title: String?, val note: String?, val chapterTitle: String?, val progress: Double, val createdAt: Long,
)

/** A note (annotation carrying text) joined with its book, for the library-wide Notes screen. */
data class GlobalNote(
    val id: Long, val bookId: Long, val bookTitle: String, val locatorJson: String,
    val text: String, val note: String?, val color: Int, val style: String, val chapterTitle: String?, val createdAt: Long,
)

@Dao
interface HighlightDao {
    @Query(
        "SELECT h.id AS id, h.bookId AS bookId, k.title AS bookTitle, h.locatorJson AS locatorJson, h.text AS text, " +
            "h.note AS note, h.color AS color, h.style AS style, h.chapterTitle AS chapterTitle, h.createdAt AS createdAt " +
            "FROM highlights h INNER JOIN books k ON k.id = h.bookId " +
            "WHERE h.note IS NOT NULL AND TRIM(h.note) != '' ORDER BY h.createdAt DESC"
    )
    fun observeAllNotes(): Flow<List<GlobalNote>>

    @Query("SELECT * FROM highlights WHERE bookId = :bookId ORDER BY createdAt DESC")
    fun observe(bookId: Long): Flow<List<HighlightEntity>>

    @Query("SELECT * FROM highlights WHERE id = :id")
    suspend fun getById(id: Long): HighlightEntity?

    @Insert
    suspend fun insert(h: HighlightEntity): Long

    @Update
    suspend fun update(h: HighlightEntity)

    @Delete
    suspend fun delete(h: HighlightEntity)

    @Query("DELETE FROM highlights WHERE id = :id")
    suspend fun deleteById(id: Long)
}

@Dao
interface BookmarkDao {
    @Query(
        "SELECT b.id AS id, b.bookId AS bookId, k.title AS bookTitle, b.locatorJson AS locatorJson, b.title AS title, " +
            "b.note AS note, b.chapterTitle AS chapterTitle, b.progress AS progress, b.createdAt AS createdAt " +
            "FROM bookmarks b INNER JOIN books k ON k.id = b.bookId ORDER BY b.createdAt DESC"
    )
    fun observeAll(): Flow<List<GlobalBookmark>>

    @Query("SELECT * FROM bookmarks WHERE bookId = :bookId ORDER BY progress ASC, createdAt ASC")
    fun observe(bookId: Long): Flow<List<BookmarkEntity>>

    @Insert
    suspend fun insert(b: BookmarkEntity): Long

    @Update
    suspend fun update(b: BookmarkEntity)

    @Query("DELETE FROM bookmarks WHERE id = :id")
    suspend fun deleteById(id: Long)
}

@Dao
interface HistoryDao {
    @Query("SELECT * FROM history WHERE bookId = :bookId ORDER BY createdAt DESC LIMIT :limit")
    fun observeRecent(bookId: Long, limit: Int): Flow<List<HistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(h: HistoryEntity): Long

    @Query("SELECT * FROM history WHERE bookId = :bookId ORDER BY createdAt DESC LIMIT 1")
    suspend fun latest(bookId: Long): HistoryEntity?

    /** Keeps only the newest [keep] rows for a book. */
    @Query(
        "DELETE FROM history WHERE bookId = :bookId AND id NOT IN " +
            "(SELECT id FROM history WHERE bookId = :bookId ORDER BY createdAt DESC LIMIT :keep)"
    )
    suspend fun trim(bookId: Long, keep: Int)
}

@Dao
interface CategoryDao {
    @Query("SELECT * FROM categories ORDER BY createdAt ASC, id ASC")
    fun observeAll(): Flow<List<CategoryEntity>>

    @Query("SELECT * FROM book_categories")
    fun observeLinks(): Flow<List<BookCategoryEntity>>

    @Insert
    suspend fun insert(c: CategoryEntity): Long

    @Query("UPDATE categories SET name = :name WHERE id = :id")
    suspend fun rename(id: Long, name: String)

    @Query("DELETE FROM categories WHERE id = :id")
    suspend fun delete(id: Long)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun link(link: BookCategoryEntity)

    @Query("DELETE FROM book_categories WHERE bookId = :bookId AND categoryId = :categoryId")
    suspend fun unlink(bookId: Long, categoryId: Long)
}

@Dao
interface ReadingSessionDao {
    @Insert
    suspend fun insert(s: ReadingSessionEntity): Long

    @Query("SELECT * FROM reading_sessions ORDER BY startAt ASC")
    fun observeAll(): Flow<List<ReadingSessionEntity>>
}
