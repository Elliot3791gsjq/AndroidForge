package com.novelreader.app.reader

import android.app.SearchManager
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import java.net.URLEncoder

/** Where the selected text can be sent from the selection menu's "More" list, in display order. */
enum class ExternalService(
    /** Installed-app route: ACTION_SEND text/plain to this package. null = no known app, web only. */
    val appPackage: String?,
    /** Web route. [webPrefill] true = the URL accepts the text as a query parameter. */
    val webUrl: (String) -> String,
    val webPrefill: Boolean,
) {
    GOOGLE_TRANSLATE(TranslateLauncher.TRANSLATE_PACKAGE, { "https://translate.google.com/?sl=auto&text=${enc(it)}&op=translate" }, true),
    WEB_SEARCH(null, { "https://www.google.com/search?q=${enc(it)}" }, true),
    GEMINI("com.google.android.apps.bard", { "https://gemini.google.com/app" }, false),
    CHATGPT("com.openai.chatgpt", { "https://chatgpt.com/?q=${enc(it)}" }, true),
    PERPLEXITY("ai.perplexity.app.android", { "https://www.perplexity.ai/search?q=${enc(it)}" }, true),
    CLAUDE("com.anthropic.claude", { "https://claude.ai/new?q=${enc(it)}" }, true),
    GROK("ai.x.grok", { "https://grok.com/?q=${enc(it)}" }, true),
    DEEPSEEK("com.deepseek.chat", { "https://chat.deepseek.com/" }, false),
    KIMI("com.moonshot.kimichat", { "https://www.kimi.com/" }, false);

    companion object {
        /** Query strings in URLs are capped; longer selections are sent whole only to installed apps. */
        const val URL_TEXT_LIMIT = 1_500
        private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    }
}

sealed interface ServiceOutcome {
    /** Opened an installed app with the text. */
    data object OpenedApp : ServiceOutcome
    /** Opened the website; the text was put in the URL. */
    data object OpenedWeb : ServiceOutcome
    /** Opened the website, which cannot be pre-filled: the text was copied so the user can paste it. */
    data object OpenedWebCopied : ServiceOutcome
    data class OpenedWebTruncated(val limit: Int) : ServiceOutcome
    data object Failed : ServiceOutcome
}

/**
 * Hands the selected text to another service using only standard Android mechanisms: an explicit ACTION_SEND to the
 * service's app when it is installed, otherwise its official website through ACTION_VIEW. The app never talks to
 * these services itself (it has no INTERNET permission). The caller shows the privacy notice before calling.
 */
object ExternalServices {

    fun send(context: Context, service: ExternalService, text: String): ServiceOutcome {
        if (service == ExternalService.GOOGLE_TRANSLATE) error("Google Translate has its own dialog (TranslateLauncher)")
        val pkg = service.appPackage
        if (pkg != null) {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                setPackage(pkg)
                putExtra(Intent.EXTRA_TEXT, text)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try {
                context.startActivity(intent)
                return ServiceOutcome.OpenedApp
            } catch (_: ActivityNotFoundException) { /* not installed -> website */ }
        }
        if (service == ExternalService.WEB_SEARCH) {
            // Prefer the system web-search handler (the user's default search app or browser).
            val search = Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, text.take(ExternalService.URL_TEXT_LIMIT))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try { context.startActivity(search); return ServiceOutcome.OpenedWeb } catch (_: ActivityNotFoundException) { }
        }
        val truncated = service.webPrefill && text.length > ExternalService.URL_TEXT_LIMIT
        val payload = if (truncated) text.take(ExternalService.URL_TEXT_LIMIT) else text
        if (!service.webPrefill) copy(context, text)
        return try {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(service.webUrl(payload))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            when {
                !service.webPrefill -> ServiceOutcome.OpenedWebCopied
                truncated -> ServiceOutcome.OpenedWebTruncated(ExternalService.URL_TEXT_LIMIT)
                else -> ServiceOutcome.OpenedWeb
            }
        } catch (_: ActivityNotFoundException) {
            ServiceOutcome.Failed
        }
    }

    private fun copy(context: Context, text: String) {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("Novel Reader", text))
    }
}
