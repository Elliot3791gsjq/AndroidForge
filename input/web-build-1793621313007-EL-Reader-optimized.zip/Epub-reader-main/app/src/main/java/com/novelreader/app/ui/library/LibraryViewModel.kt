package com.novelreader.app.ui.library

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.novelreader.app.R
import com.novelreader.app.core.ReadingStats
import com.novelreader.app.core.StatBook
import com.novelreader.app.core.StatSession
import com.novelreader.app.core.StatsPeriod
import com.novelreader.app.core.StatsResult
import com.novelreader.app.core.TextNormalizer
import com.novelreader.app.data.BookCategoryEntity
import com.novelreader.app.data.BookEntity
import com.novelreader.app.data.CategoryEntity
import com.novelreader.app.data.ImportError
import com.novelreader.app.data.ImportResult
import com.novelreader.app.data.LibrarySort
import com.novelreader.app.data.ReaderSettings
import com.novelreader.app.data.GlobalBookmark
import com.novelreader.app.data.GlobalNote
import com.novelreader.app.graph
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** Library filter chips. */
enum class LibraryFilter { ALL, READING, UNREAD, FINISHED, FAVORITES }

/** A book counts as finished from this progress on (the last page rarely reports exactly 1.0). */
const val FINISHED_PROGRESS = 0.985

sealed interface LibraryEvent {
    data class OpenBook(val bookId: Long) : LibraryEvent
    data class Message(val resId: Int, val arg: String? = null, val arg2: String? = null, val arg3: String? = null) : LibraryEvent
}

/** What the Reading stats screen shows: the computed numbers plus the books they refer to. */
data class StatsUi(val result: StatsResult, val books: Map<Long, BookEntity>)

/** Progress of a multi-book import ("Adding books… 3 of 40"). */
data class ImportProgress(val done: Int, val total: Int)

class LibraryViewModel(app: Application) : AndroidViewModel(app) {

    private val graph = app.graph

    private val query = MutableStateFlow("")
    private val filter = MutableStateFlow(LibraryFilter.ALL)
    val filterState: StateFlow<LibraryFilter> = filter.asStateFlow()
    val queryText: StateFlow<String> = query.asStateFlow()

    val sort: StateFlow<LibrarySort> = graph.settings.librarySort
        .stateIn(viewModelScope, SharingStarted.Eagerly, LibrarySort.LAST_READ)
    val grid: StateFlow<Boolean> = graph.settings.libraryGrid
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)

    val settings: StateFlow<ReaderSettings> = graph.settings.readerSettings
        .stateIn(viewModelScope, SharingStarted.Eagerly, ReaderSettings())
    val allBookmarks: StateFlow<List<GlobalBookmark>> = graph.annotations.allBookmarks()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val allNotes: StateFlow<List<GlobalNote>> = graph.annotations.allNotes()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    fun updateSettings(transform: (ReaderSettings) -> ReaderSettings) {
        viewModelScope.launch { graph.settings.update(transform) }
    }

    private val _importing = MutableStateFlow(false)
    val importing: StateFlow<Boolean> = _importing.asStateFlow()

    private val _loaded = MutableStateFlow(false)
    val loaded: StateFlow<Boolean> = _loaded.asStateFlow()

    private val _events = MutableSharedFlow<LibraryEvent>(extraBufferCapacity = 8)
    val events: SharedFlow<LibraryEvent> = _events.asSharedFlow()

    /** All library books (unfiltered) - used to tell "empty library" apart from "no search results". */
    val total: StateFlow<Int> = graph.library.observeLibrary()
        .let { flow -> combine(flow, _loaded) { list, _ -> list.size } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, 0)

    /** Every book in the library, unfiltered (detail screen lookups, filter counts). */
    val allBooks: StateFlow<List<BookEntity>> = graph.library.observeLibrary()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    /** The book to offer in the "continue reading" card: the most recently read one that is not finished. */
    val continueBook: StateFlow<BookEntity?> = allBooks
        .map { list -> list.filter { it.lastReadAt != null && it.progress < FINISHED_PROGRESS }.maxByOrNull { it.lastReadAt ?: 0L } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    private val categoryFilter = MutableStateFlow<Long?>(null)
    val categoryFilterState: StateFlow<Long?> = categoryFilter.asStateFlow()

    val categories: StateFlow<List<CategoryEntity>> = graph.library.observeCategories()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val categoryLinks: StateFlow<List<BookCategoryEntity>> = graph.library.observeCategoryLinks()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // ---- Reading stats ----
    private val statsPeriod = MutableStateFlow(StatsPeriod.WEEK)
    val statsPeriodState: StateFlow<StatsPeriod> = statsPeriod.asStateFlow()
    fun setStatsPeriod(p: StatsPeriod) { statsPeriod.value = p }

    /** Ticks every minute so "this week" rolls over by itself while the screen stays open. */
    private val clock = flow { while (true) { emit(System.currentTimeMillis()); delay(60_000) } }

    /** Recomputed from the stored sittings whenever the period, the data or the minute changes. */
    val stats: StateFlow<StatsUi?> = combine(statsPeriod, graph.library.observeSessions(), graph.library.observeAllBooks(), clock) { period, sessions, books, now ->
        val result = ReadingStats.compute(
            period = period,
            sessions = sessions.map { StatSession(it.bookId, it.startAt, it.durationMs, it.startProgress, it.endProgress) },
            books = books.map { StatBook(it.id, it.readingMillis) },
            now = now,
            zone = java.time.ZoneId.systemDefault(),
            firstDayOfWeek = java.time.temporal.WeekFields.of(java.util.Locale.getDefault()).firstDayOfWeek,
        )
        StatsUi(result, books.associateBy { it.id })
    }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    private data class Criteria(val query: String, val sort: LibrarySort, val filter: LibraryFilter, val category: Long?)

    private val criteria = combine(query, sort, filter, categoryFilter) { q, s, f, c -> Criteria(q, s, f, c) }

    /** Filtered + sorted books for display. */
    val books: StateFlow<List<BookEntity>> =
        combine(graph.library.observeLibrary(), criteria, categoryLinks) { list, c, links ->
            _loaded.value = true
            val inCategory = c.category?.let { id -> links.filter { it.categoryId == id }.map { it.bookId }.toSet() }
            list.filter { TextNormalizer.containsNormalized(it.title, c.query) || TextNormalizer.containsNormalized(it.author, c.query) }
                .filter { inCategory == null || it.id in inCategory }
                .filter { matches(it, c.filter) }
                .let { sorted(it, c.sort) }
        }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private fun matches(b: BookEntity, f: LibraryFilter): Boolean = when (f) {
        LibraryFilter.ALL -> true
        LibraryFilter.READING -> b.lastReadAt != null && b.progress < FINISHED_PROGRESS
        LibraryFilter.UNREAD -> b.lastReadAt == null && b.progress <= 0.0
        LibraryFilter.FINISHED -> b.progress >= FINISHED_PROGRESS
        LibraryFilter.FAVORITES -> b.favorite
    }

    private fun sorted(list: List<BookEntity>, s: LibrarySort): List<BookEntity> = when (s) {
        LibrarySort.LAST_READ -> list.sortedWith(
            compareByDescending<BookEntity> { it.lastReadAt ?: Long.MIN_VALUE }.thenByDescending { it.addedAt }
        )
        LibrarySort.TITLE -> list.sortedBy { TextNormalizer.normalize(it.title) }
        LibrarySort.ADDED -> list.sortedByDescending { it.addedAt }
    }

    fun setQuery(q: String) { query.value = q }
    /** Status chips and category chips form one single-choice row: picking one clears the other kind. */
    fun setFilter(f: LibraryFilter) { filter.value = f; categoryFilter.value = null }
    fun setCategoryFilter(id: Long) { categoryFilter.value = id; filter.value = LibraryFilter.ALL }

    /** Creates a category (an existing one with the same name is reused) and returns its id through [onCreated]. */
    fun createCategory(name: String, onCreated: (Long) -> Unit = {}) {
        viewModelScope.launch {
            val clean = name.trim()
            val same = categories.value.firstOrNull { it.name.equals(clean, ignoreCase = true) }
            val id = same?.id ?: graph.library.createCategory(clean) ?: return@launch
            onCreated(id)
        }
    }
    fun renameCategory(id: Long, name: String) { viewModelScope.launch { graph.library.renameCategory(id, name) } }
    fun deleteCategory(id: Long) {
        viewModelScope.launch {
            if (categoryFilter.value == id) { categoryFilter.value = null; filter.value = LibraryFilter.ALL }
            graph.library.deleteCategory(id)
        }
    }
    fun setBookInCategory(bookId: Long, categoryId: Long, member: Boolean) {
        viewModelScope.launch { graph.library.setBookInCategory(bookId, categoryId, member) }
    }

    /** Replaces the user's own cover of a book with an image from the phone. */
    fun setCustomCover(bookId: Long, uri: Uri) {
        viewModelScope.launch {
            val ok = graph.library.setCustomCover(bookId, uri)
            _events.tryEmit(LibraryEvent.Message(if (ok) R.string.cover_set_ok else R.string.cover_set_fail))
        }
    }
    fun clearCustomCover(bookId: Long) { viewModelScope.launch { graph.library.clearCustomCover(bookId) } }
    fun setFavorite(id: Long, favorite: Boolean) { viewModelScope.launch { graph.library.setFavorite(id, favorite) } }

    /** Character/word counts of a book's text (cached in the DB after the first computation). */
    suspend fun textStats(book: BookEntity) = graph.library.textStats(book)
    fun setSort(s: LibrarySort) { viewModelScope.launch { graph.settings.setLibrarySort(s) } }
    fun setGrid(g: Boolean) { viewModelScope.launch { graph.settings.setLibraryGrid(g) } }

    private val _importProgress = MutableStateFlow<ImportProgress?>(null)
    val importProgress: StateFlow<ImportProgress?> = _importProgress.asStateFlow()

    /** URIs returned by the storage browser / system pickers (file:// or content://) as strings. */
    fun importPicked(uriStrings: List<String>) = importUris(uriStrings.map { Uri.parse(it) })

    /**
     * Books picked by the user (any number): each is copied into private storage, validated and added to the
     * library. One summary message is shown at the end; a failure of one file never stops the others.
     */
    fun importUris(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            _importing.value = true
            var added = 0
            var existing = 0
            var failed = 0
            var lastError: ImportError? = null
            try {
                uris.forEachIndexed { i, uri ->
                    _importProgress.value = ImportProgress(i, uris.size)
                    when (val r = graph.library.importFromUri(uri, addToLibrary = true)) {
                        is ImportResult.Success -> if (r.alreadyPresent) existing++ else added++
                        is ImportResult.Failure -> { failed++; lastError = r.error }
                    }
                }
            } finally {
                _importing.value = false
                _importProgress.value = null
            }
            val err = lastError
            when {
                uris.size == 1 && failed == 1 && err != null -> _events.tryEmit(LibraryEvent.Message(errorRes(err)))
                uris.size == 1 && existing == 1 -> _events.tryEmit(LibraryEvent.Message(R.string.import_exists))
                failed == 0 && existing == 0 -> _events.tryEmit(LibraryEvent.Message(R.string.import_ok, added.toString()))
                else -> _events.tryEmit(LibraryEvent.Message(R.string.import_summary, added.toString(), existing.toString(), failed.toString()))
            }
        }
    }

    /**
     * A file handed over by another app ("Open with" / "Share"). It is copied privately (so access cannot be
     * revoked), added to the library like any other book, and opened right away. A book that is already in the
     * library is simply opened.
     */
    fun openExternal(uri: Uri) {
        viewModelScope.launch {
            _importing.value = true
            try {
                when (val r = graph.library.importFromUri(uri, addToLibrary = true)) {
                    is ImportResult.Success -> _events.tryEmit(LibraryEvent.OpenBook(r.bookId))
                    is ImportResult.Failure -> _events.tryEmit(LibraryEvent.Message(errorRes(r.error)))
                }
            } finally {
                _importing.value = false
            }
        }
    }

    /** Hides the book from the library but keeps the private copy, highlights, bookmarks and position. */
    fun removeFromLibrary(id: Long) { viewModelScope.launch { graph.library.removeFromLibrary(id) } }

    /** Deletes the private copy and every annotation. The user's original file is never touched. */
    fun deleteCompletely(id: Long) { viewModelScope.launch { graph.library.deleteCompletely(id) } }

    fun coverFile(book: BookEntity) = graph.library.coverFile(book)

    private fun errorRes(e: ImportError): Int = when (e) {
        ImportError.NO_ACCESS -> R.string.import_err_no_access
        ImportError.NOT_EPUB -> R.string.import_err_not_epub
        ImportError.NOT_SUPPORTED -> R.string.import_err_not_supported
        ImportError.CORRUPT -> R.string.import_err_corrupt
        ImportError.ENCRYPTED -> R.string.import_err_encrypted
        ImportError.UNSUPPORTED -> R.string.import_err_unsupported
        ImportError.IO -> R.string.import_err_io
        ImportError.TOO_LARGE -> R.string.import_err_too_large
    }
}
