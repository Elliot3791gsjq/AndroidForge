package com.novelreader.app.formats.doc

import java.nio.ByteBuffer
import java.nio.CharBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction

/** Text encodings EL Reader can read. [charset] is the JVM/Android charset name. */
enum class TextEncoding(val charset: String, val label: String) {
    UTF8("UTF-8", "UTF-8"),
    UTF16LE("UTF-16LE", "UTF-16 LE"),
    UTF16BE("UTF-16BE", "UTF-16 BE"),
    WIN1256("windows-1256", "Windows-1256 (Arabic / Persian)"),
    WIN1252("windows-1252", "Windows-1252 (Western European)"),
    WIN1251("windows-1251", "Windows-1251 (Cyrillic)"),
    GB18030("GB18030", "GB18030 (Chinese)"),
    BIG5("Big5", "Big5 (Traditional Chinese)"),
    SJIS("Shift_JIS", "Shift_JIS (Japanese)"),
    EUCKR("EUC-KR", "EUC-KR (Korean)");

    fun available(): Boolean = try { Charset.isSupported(charset) } catch (_: Exception) { false }
}

/** Result of decoding a text file: the text and the encoding that produced it. */
class DecodedText(
    val text: String,
    val encoding: TextEncoding,
    val hadBom: Boolean,
    /** What automatic detection picks for these bytes; differs from [encoding] only when the reader forced one. */
    val auto: TextEncoding = encoding,
)

/**
 * Detects the encoding of a plain-text file and decodes it. Order: byte-order mark, then valid UTF-8, then UTF-16
 * without a mark, then a script-plausibility score over the legacy code pages (Persian/Arabic first, then
 * Cyrillic, CJK, Western). A manual choice always wins. Pure JVM (unit-tested).
 */
object TextDecoder {

    fun decode(bytes: ByteArray, forced: TextEncoding? = null): DecodedText {
        // A byte-order mark is authoritative even over a manual choice of a different Unicode form.
        val bom = bomOf(bytes)
        if (bom != null && (forced == null || forced.charset.startsWith("UTF"))) {
            val (enc, skip) = bom
            return DecodedText(String(bytes, skip, bytes.size - skip, Charset.forName(enc.charset)), enc, true)
        }
        if (forced != null) return DecodedText(decodeLenient(bytes, forced), forced, false, detect(bytes))

        utf16WithoutMark(bytes)?.let { enc -> return DecodedText(String(bytes, Charset.forName(enc.charset)), enc, false) }
        if (isValidUtf8(bytes)) return DecodedText(String(bytes, Charsets.UTF_8), TextEncoding.UTF8, false)
        val best = bestLegacy(bytes)
        return DecodedText(decodeLenient(bytes, best), best, false)
    }

    private fun bomOf(b: ByteArray): Pair<TextEncoding, Int>? = when {
        b.size >= 3 && b[0] == 0xEF.toByte() && b[1] == 0xBB.toByte() && b[2] == 0xBF.toByte() -> TextEncoding.UTF8 to 3
        b.size >= 2 && b[0] == 0xFF.toByte() && b[1] == 0xFE.toByte() -> TextEncoding.UTF16LE to 2
        b.size >= 2 && b[0] == 0xFE.toByte() && b[1] == 0xFF.toByte() -> TextEncoding.UTF16BE to 2
        else -> null
    }

    /** Strict UTF-8 check over the whole file (a legacy-encoded text almost never passes). */
    fun isValidUtf8(bytes: ByteArray): Boolean {
        var i = 0
        var multi = 0
        val n = bytes.size
        while (i < n) {
            val b = bytes[i].toInt() and 0xFF
            val extra = when {
                b < 0x80 -> 0
                b in 0xC2..0xDF -> 1
                b in 0xE0..0xEF -> 2
                b in 0xF0..0xF4 -> 3
                else -> return false
            }
            if (extra > 0) {
                val avail = n - i - 1
                for (k in 1..minOf(extra, avail)) if ((bytes[i + k].toInt() and 0xC0) != 0x80) return false
                if (avail >= 1) {
                    // reject overlongs / surrogates / > U+10FFFF
                    val b1 = bytes[i + 1].toInt() and 0xFF
                    if (b == 0xE0 && b1 < 0xA0) return false
                    if (b == 0xED && b1 > 0x9F) return false
                    if (b == 0xF0 && b1 < 0x90) return false
                    if (b == 0xF4 && b1 > 0x8F) return false
                }
                // A file cut in the middle of its last character is still UTF-8. A lone lead byte at the very end
                // could just as well be one Latin-1 letter, so that needs some multi-byte text before it as evidence.
                if (avail < extra) return avail >= 1 || multi >= 3
                multi++
            }
            i += extra + 1
        }
        return true
    }

    /** UTF-16 text without a mark has NUL bytes on one parity only. */
    private fun utf16WithoutMark(b: ByteArray): TextEncoding? {
        val n = minOf(b.size, 64 * 1024) / 2 * 2
        if (n < 8) return null
        var even = 0
        var odd = 0
        var i = 0
        while (i < n) {
            if (b[i].toInt() == 0) even++
            if (b[i + 1].toInt() == 0) odd++
            i += 2
        }
        val pairs = n / 2
        return when {
            odd >= pairs / 4 && even <= odd / 20 -> TextEncoding.UTF16LE   // high byte (odd index) is zero: little-endian Latin
            even >= pairs / 4 && odd <= even / 20 -> TextEncoding.UTF16BE
            else -> null
        }
    }

    /** The encoding automatic detection would choose (same order as [decode] without a manual choice). */
    fun detect(bytes: ByteArray): TextEncoding =
        bomOf(bytes)?.first ?: utf16WithoutMark(bytes) ?: if (isValidUtf8(bytes)) TextEncoding.UTF8 else bestLegacy(bytes)

    private fun decodeLenient(bytes: ByteArray, enc: TextEncoding): String {
        val cs = try { Charset.forName(enc.charset) } catch (_: Exception) { Charsets.UTF_8 }
        return String(bytes, cs)
    }

    private fun decodeStrict(bytes: ByteArray, len: Int, cs: Charset): String? = try {
        cs.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT)
            .decode(ByteBuffer.wrap(bytes, 0, len)).toString()
    } catch (_: CharacterCodingException) { null }

    /**
     * Picks the legacy code page for text that is not valid UTF-8. Mostly ASCII means Western (windows-1252). Otherwise
     * the double-byte candidates are tried first, each only accepted when the decoded text really is that language
     * (hangul share, kana share, share of the most common Chinese characters), then Persian/Arabic (windows-1256) is
     * told apart from Russian (windows-1251) by letter frequencies. Verified on real-language samples (unit tests).
     */
    private fun bestLegacy(bytes: ByteArray): TextEncoding {
        val len = minOf(bytes.size, 256 * 1024)
        var high = 0
        var nonSpace = 0
        for (i in 0 until len) {
            val b = bytes[i].toInt() and 0xFF
            if (b > 0x20) nonSpace++
            if (b >= 0x80) high++
        }
        if (high < nonSpace * 0.15) return TextEncoding.WIN1252

        var best: TextEncoding? = null
        var bestScore = 0.0
        fun offer(enc: TextEncoding, score: Double) { if (score > bestScore) { bestScore = score; best = enc } }

        decodeLoose(bytes, len, TextEncoding.EUCKR)?.let { s -> if (share(s) { it in '\uAC00'..'\uD7AF' } >= 0.9) offer(TextEncoding.EUCKR, 0.95) }
        decodeLoose(bytes, len, TextEncoding.SJIS)?.let { s ->
            val kana = share(s) { it in '\u3040'..'\u30FF' }
            if (kana >= 0.15) offer(TextEncoding.SJIS, 0.5 + kana)
        }
        decodeLoose(bytes, len, TextEncoding.GB18030)?.let { s -> val c = share(s) { it in ZH_SIMPLIFIED }; if (c >= 0.18) offer(TextEncoding.GB18030, c) }
        decodeLoose(bytes, len, TextEncoding.BIG5)?.let { s -> val c = share(s) { it in ZH_TRADITIONAL }; if (c >= 0.18) offer(TextEncoding.BIG5, c) }
        best?.let { return it }

        val fa = decodeLoose(bytes, len, TextEncoding.WIN1256)?.let { meanLogProb(it, PERSIAN_ARABIC, FLOOR) } ?: -99.0
        val ru = decodeLoose(bytes, len, TextEncoding.WIN1251)?.let { meanLogProb(it, RUSSIAN, FLOOR) } ?: -99.0
        return when {
            fa >= ru && fa > -6.0 -> TextEncoding.WIN1256
            ru > fa && ru > -6.0 -> TextEncoding.WIN1251
            else -> TextEncoding.WIN1252
        }
    }

    /** Strict decoding that tolerates a sample cut in the middle of a multi-byte character (up to 3 trailing bytes). */
    private fun decodeLoose(bytes: ByteArray, len: Int, enc: TextEncoding): String? {
        if (!enc.available()) return null
        val cs = Charset.forName(enc.charset)
        for (cut in 0..3) {
            val l = len - cut
            if (l <= 0) break
            decodeStrict(bytes, l, cs)?.let { return it }
        }
        return null
    }

    private inline fun share(s: String, pred: (Char) -> Boolean): Double {
        var letters = 0
        var hits = 0
        for (c in s) if (Character.isLetter(c)) { letters++; if (pred(c)) hits++ }
        return if (letters == 0) 0.0 else hits.toDouble() / letters
    }

    private fun meanLogProb(s: String, table: Map<Char, Double>, floor: Double): Double {
        var letters = 0
        var sum = 0.0
        // Plain ASCII letters (markup, names, English words) say nothing about the code page: only the others count.
        for (c in s) if (c.code >= 0x80 && Character.isLetter(c)) { letters++; sum += table[c] ?: floor }
        return if (letters == 0) -99.0 else sum / letters
    }

    private const val FLOOR = -9.0

    private fun logTable(freq: Map<Char, Double>, withCaps: Boolean): Map<Char, Double> {
        val total = freq.values.sum()
        val out = HashMap<Char, Double>()
        for ((k, v) in freq) {
            out[k] = Math.log(v / total)
            if (withCaps && k.uppercaseChar() != k) out[k.uppercaseChar()] = Math.log(v / total * 0.05)
        }
        return out
    }

    private val RUSSIAN: Map<Char, Double> = logTable(
        "оеаинтсрвлкмдпуяыьгзбчйхжшюцщэфъё".toList().zip(
            listOf(10.97, 8.45, 8.01, 7.35, 6.70, 6.26, 5.47, 4.73, 4.54, 4.34, 3.49, 3.21, 2.98, 2.81, 2.62, 2.01, 1.90, 1.74, 1.69, 1.65, 1.59, 1.45, 1.21, 0.97, 0.94, 0.72, 0.64, 0.48, 0.36, 0.33, 0.27, 0.04, 0.04)
        ).toMap(),
        withCaps = true,
    )

    private val PERSIAN_ARABIC: Map<Char, Double> = run {
        val f = HashMap<Char, Double>()
        val pairs = listOf(
            'ا' to 13.5, 'ی' to 9.0, 'ي' to 9.0, 'ى' to 0.3, 'ن' to 6.5, 'و' to 6.0, 'ر' to 5.5, 'د' to 4.5, 'م' to 4.5, 'ه' to 4.5,
            'ة' to 0.5, 'ت' to 4.0, 'ب' to 3.5, 'س' to 3.0, 'ک' to 3.0, 'ك' to 3.0, 'ل' to 3.0, 'ش' to 2.0, 'ز' to 1.5, 'ف' to 1.3,
            'ق' to 1.3, 'گ' to 1.2, 'ع' to 1.5, 'خ' to 1.2, 'ح' to 1.0, 'ج' to 1.0, 'پ' to 1.0, 'چ' to 0.7, 'ص' to 0.7, 'ط' to 0.5,
            'ث' to 0.2, 'ذ' to 0.2, 'ض' to 0.3, 'ظ' to 0.1, 'غ' to 0.4, 'ژ' to 0.1, 'ئ' to 0.4, 'ؤ' to 0.1, 'ء' to 0.1, 'أ' to 0.2,
            'إ' to 0.05, 'آ' to 0.8,
        )
        for ((c, v) in pairs) f[c] = (f[c] ?: 0.0) + v
        logTable(f, withCaps = false)
    }

    private val ZH_SIMPLIFIED: Set<Char> = (
        "的一是不了人我在有他这中大来上国个到说们为子和你地出道也时年得就那要下以生会自着去之过家学对可她里后小么心多天而能好都然没日于起还发成事只作当想看文无开手十用主行方又如前所本见经头面公同三已老从动两长知民样现分将外但身些与高意进把法此实回二理美点月明其种声全工"
        ).toSet()

    private val ZH_TRADITIONAL: Set<Char> = (
        "的一是不了人我在有他這中大來上國個到說們為子和你地出道也時年得就那要下以生會自著去之過家學對可她裡後小麼心多天而能好都然沒日於起還發成事只作當想看文無開手十用主行方又如前所本見經頭面公同三已老從動兩長知民樣現分將外但身些與高意進把法此實回二理美點月明其種聲全工"
        ).toSet()
}

/** How the lines of a plain-text file become paragraphs. */
enum class ParagraphMode { AUTO, EVERY_LINE, JOIN_WRAPPED }

/** Splits decoded text into paragraphs (pure, unit-tested). */
object TextParagraphs {

    /** Calls [sink] for every paragraph, in order, without building a list of lines (files can be many MB). */
    fun split(text: String, mode: ParagraphMode, sink: (String) -> Unit) {
        val join = when (mode) {
            ParagraphMode.EVERY_LINE -> false
            ParagraphMode.JOIN_WRAPPED -> true
            ParagraphMode.AUTO -> looksHardWrapped(text)
        }
        val cur = StringBuilder()
        fun flush() { if (cur.isNotEmpty()) { sink(cur.toString()); cur.setLength(0) } }
        forEachLine(text) { start, end ->
            if (!join) {
                // One paragraph per non-blank line (blank lines only separate and are dropped).
                var e = end
                while (e > start && text[e - 1].isWhitespace()) e--
                if (e > start) sink(text.substring(start, e))
            } else {
                var s = start
                var e = end
                while (s < e && text[s].isWhitespace()) s++
                while (e > s && text[e - 1].isWhitespace()) e--
                if (s == e) flush() else {
                    if (cur.isNotEmpty()) cur.append(' ')
                    cur.append(text, s, e)
                }
            }
        }
        if (join) flush()
    }

    fun split(text: String, mode: ParagraphMode): List<String> = ArrayList<String>().also { out -> split(text, mode) { out += it } }

    /** Lines of [text] split on \n, \r\n and lone \r, as index ranges (end exclusive). */
    inline fun forEachLine(text: String, block: (Int, Int) -> Unit) {
        var i = 0
        val n = text.length
        var start = 0
        while (i < n) {
            val c = text[i]
            if (c == '\n' || c == '\r') {
                block(start, i)
                if (c == '\r' && i + 1 < n && text[i + 1] == '\n') i++
                start = i + 1
            }
            i++
        }
        if (start < n) block(start, n)
    }

    /**
     * Hard-wrapped plain text (Project Gutenberg style): blank lines separate paragraphs, and most paragraphs span
     * several lines of similar, limited length. Web-novel style text (one long line per paragraph) is not.
     */
    fun looksHardWrapped(text: String): Boolean {
        var nonEmpty = 0
        var blanks = 0
        var shortLines = 0
        var maxLen = 0
        var seen = 0
        // A sample of the start is enough and keeps this cheap on big files.
        forEachLine(text) { s, e ->
            if (seen < 4000) {
                seen++
                var end = e
                while (end > s && text[end - 1].isWhitespace()) end--
                val len = end - s
                if (len == 0) blanks++ else {
                    nonEmpty++
                    if (len <= 100) shortLines++
                    if (len > maxLen) maxLen = len
                }
            }
        }
        if (nonEmpty < 20 || blanks == 0) return false
        val linesPerParagraph = nonEmpty.toDouble() / (blanks + 1)
        return shortLines >= nonEmpty * 0.85 && linesPerParagraph >= 2.0 && maxLen <= 140
    }
}

/** Direction hints from the text itself (pure). */
object TextDirection {
    /** True when strong right-to-left letters (Arabic, Persian, Hebrew...) outnumber strong left-to-right ones. */
    fun looksRtl(sample: String): Boolean {
        var rtl = 0
        var ltr = 0
        var i = 0
        val n = minOf(sample.length, 20_000)
        while (i < n) {
            val cp = sample.codePointAt(i)
            i += Character.charCount(cp)
            when (Character.getDirectionality(cp)) {
                Character.DIRECTIONALITY_RIGHT_TO_LEFT, Character.DIRECTIONALITY_RIGHT_TO_LEFT_ARABIC -> rtl++
                Character.DIRECTIONALITY_LEFT_TO_RIGHT -> ltr++
                else -> {}
            }
        }
        return rtl > ltr
    }
}
