package com.novelreader.app.ui.reader

import kotlinx.coroutines.delay
import com.novelreader.app.core.ReadingMath
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import com.novelreader.app.ui.design.AccentButton
import com.novelreader.app.ui.design.AppDropdownMenu
import com.novelreader.app.ui.design.AppMenuItem
import com.novelreader.app.ui.design.AppShapes
import com.novelreader.app.ui.design.AppSlider
import com.novelreader.app.ui.design.SoftIconButton
import com.novelreader.app.ui.design.appClickable
import com.novelreader.app.ui.design.motion
import com.novelreader.app.ui.design.palette
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.filled.MoreVert
import com.novelreader.app.ui.design.Button
import com.novelreader.app.ui.design.LinearProgressIndicator
import com.novelreader.app.ui.design.OutlinedButton
import com.novelreader.app.ui.design.Switch
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.withStyle
import com.novelreader.app.core.ColorMath
import com.novelreader.app.data.AutoScrollMode
import com.novelreader.app.data.ToolbarItems
import com.novelreader.app.data.effectiveBackground
import com.novelreader.app.reader.AutoReader
import com.novelreader.app.reader.ReaderDialog
import com.novelreader.app.reader.ReaderGroup
import com.novelreader.app.ui.ToolbarCatalog
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import com.novelreader.app.ui.AppIcons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.novelreader.app.R
import com.novelreader.app.reader.ReaderFailure
import com.novelreader.app.reader.ReaderInfo
import com.novelreader.app.reader.ReaderLoad
import com.novelreader.app.reader.ReaderTab
import com.novelreader.app.reader.ReaderViewModel
import com.novelreader.app.ui.Localized

/**
 * The Compose layer drawn above the Readium navigator. It only consumes touches on its own controls; everything
 * else falls through to the navigator (page turns, text selection, taps on highlights).
 *
 * Always reachable, even with the bars hidden or in fullscreen: the floating "Aa" button (opens the settings
 * and tools sheet). Tapping the middle of the page toggles the top/bottom bars.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReaderScreen(vm: ReaderViewModel, onBack: () -> Unit) {
    val load by vm.load.collectAsState()
    when (val l = load) {
        ReaderLoad.Loading -> Box(Modifier.fillMaxSize().background(palette.bg), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = palette.accent)
        }
        is ReaderLoad.Failed -> ReaderError(l.reason, onBack)
        is ReaderLoad.Ready -> ReaderContent(vm, l.book.title, onBack)
    }
}

@Composable
private fun ReaderError(reason: ReaderFailure, onBack: () -> Unit) {
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            Modifier.fillMaxSize().padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(stringResource(R.string.reader_error_title), style = MaterialTheme.typography.titleLarge)
            Text(
                stringResource(
                    when (reason) {
                        ReaderFailure.BOOK_NOT_FOUND -> R.string.err_book_not_found
                        ReaderFailure.FILE_MISSING -> R.string.err_file_missing
                        ReaderFailure.NOT_EPUB -> R.string.err_not_epub
                        ReaderFailure.ENCRYPTED -> R.string.err_encrypted
                        ReaderFailure.CORRUPT -> R.string.err_corrupt
                        ReaderFailure.UNSUPPORTED -> R.string.err_unsupported
                    }
                ),
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(vertical = 16.dp),
            )
            AccentButton(stringResource(R.string.back), onBack)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ReaderContent(vm: ReaderViewModel, title: String, onBack: () -> Unit) {
    val chrome by vm.chromeVisible.collectAsState()
    val info by vm.info.collectAsState()
    val inLibrary by vm.inLibrary.collectAsState()
    val settingsOpen by vm.settingsOpen.collectAsState()
    val tab by vm.tab.collectAsState()
    val markers by vm.chapterMarkers.collectAsState()
    val dialog by vm.dialog.collectAsState()
    val search by vm.search.collectAsState()
    val settings by vm.settings.collectAsState()
    val autoRunning by vm.autoRunning.collectAsState()

    // Colour for text/icons that sit directly on the page: whichever of black/white reads better on the page colour.
    val onPage = Color(ColorMath.bestTextOn(settings.effectiveBackground()))
    val searchOpen = settingsOpen && tab == ReaderTab.SEARCH
    val barsVisible = chrome && !autoRunning && !searchOpen

    Box(Modifier.fillMaxSize()) {
        // ---- Top bar: short and fully transparent ----
        AnimatedVisibility(
            visible = barsVisible,
            modifier = Modifier.align(Alignment.TopCenter),
            enter = fadeIn(tween(180)) + slideInVertically(tween(220)) { -it / 2 },
            exit = fadeOut(tween(140)) + slideOutVertically(tween(180)) { -it / 2 },
        ) {
            ReaderTopBar(vm, title, inLibrary, settings.dualPage, settings.dualPagePortrait, onBack)
        }

        // ---- Search: opens at the very top, replacing the top bar so nothing is covered ----
        AnimatedVisibility(
            visible = searchOpen,
            modifier = Modifier.align(Alignment.TopCenter),
            enter = fadeIn(tween(160)) + slideInVertically(tween(220)) { -it },
            exit = fadeOut(tween(120)) + slideOutVertically(tween(160)) { -it },
        ) {
            SearchTopPanel(vm, onClose = { vm.setSettingsOpen(false) })
        }

        // ---- Bottom: slim progress + icon toolbar ----
        AnimatedVisibility(
            visible = barsVisible,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = fadeIn(tween(180)) + slideInVertically(tween(220)) { it / 2 },
            exit = fadeOut(tween(140)) + slideOutVertically(tween(180)) { it / 2 },
        ) {
            Column(
                Modifier
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .padding(horizontal = 12.dp, vertical = 8.dp)
                    .shadow(20.dp, AppShapes.cardLarge, ambientColor = Color.Black, spotColor = Color.Black)
                    .clip(AppShapes.cardLarge)
                    .background(palette.surface.copy(alpha = 0.985f))
                    .border(1.dp, palette.outline, AppShapes.cardLarge),
            ) {
                ProgressBar(
                    info = info,
                    markers = markers,
                    onSeek = { vm.goToFraction(it) },
                    onPreviousChapter = { vm.previousChapter() },
                    onNextChapter = { vm.nextChapter() },
                    modifier = Modifier.padding(start = 10.dp, end = 10.dp, top = 10.dp),
                )
                ReaderToolbar(vm, hidden = settings.toolbarHidden, openTab = if (settingsOpen) tab else null)
            }
        }

        // ---- Search result stepper (when results exist and the search panel is closed) ----
        AnimatedVisibility(
            visible = barsVisible && search.hits.isNotEmpty() && !settingsOpen,
            modifier = Modifier.align(Alignment.BottomStart).windowInsetsPadding(WindowInsets.systemBars).padding(start = 12.dp, bottom = 132.dp),
            enter = fadeIn(), exit = fadeOut(),
        ) {
            Surface(shape = CircleShape, color = palette.surfaceHigh, contentColor = palette.text, shadowElevation = 8.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { vm.previousSearchHit() }) {
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = stringResource(R.string.previous_result))
                    }
                    Text(
                        stringResource(
                            R.string.result_x_of_y,
                            Localized.number((search.activeIndex + 1).coerceAtLeast(1)),
                            Localized.number(search.hits.size),
                        ),
                        style = MaterialTheme.typography.labelLarge,
                    )
                    IconButton(onClick = { vm.nextSearchHit() }) {
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = stringResource(R.string.next_result))
                    }
                    IconButton(onClick = { vm.clearSearch() }) {
                        Icon(Icons.Default.Close, contentDescription = stringResource(R.string.clear))
                    }
                }
            }
        }

        // ---- Automatic reading overlays ----
        if (autoRunning) {
            when (settings.autoScrollMode) {
                AutoScrollMode.ROLLING_BLIND_PIXEL, AutoScrollMode.ROLLING_BLIND_LINE ->
                    BlindOverlay(vm, Color(settings.effectiveBackground()), MaterialTheme.colorScheme.primary)
                AutoScrollMode.SPEED_READ -> RsvpOverlay(vm, settings.autoScrollSpeed)
                else -> Unit
            }
            if (settings.autoScrollMode != AutoScrollMode.SPEED_READ) {
                AutoStopPill(settings.autoScrollSpeed, onStop = { vm.stopAuto() }, modifier = Modifier.align(Alignment.BottomCenter))
            }
        }

        AnimatedVisibility(
            visible = settingsOpen && tab != ReaderTab.SEARCH,
            modifier = Modifier.fillMaxSize(),
            enter = fadeIn(motion.medium()) + slideInVertically(motion.medium()) { it / 3 },
            exit = fadeOut(motion.fast()) + slideOutVertically(motion.fast()) { it / 3 },
        ) {
            ReaderSheet(vm = vm, onDismiss = { vm.setSettingsOpen(false) })
        }
        ReaderDialogs(vm = vm, dialog = dialog)
    }
}

/** Round translucent button that stays legible over any page colour. */
@Composable
private fun GlassButton(icon: androidx.compose.ui.graphics.vector.ImageVector, description: String, onClick: () -> Unit) {
    val p = palette
    Box(
        Modifier
            .size(40.dp)
            .appClickable(onClick)
            .clip(CircleShape)
            .background(p.surface.copy(alpha = 0.95f))
            .border(1.dp, p.outline.copy(alpha = 0.7f), CircleShape),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, contentDescription = description, tint = p.text, modifier = Modifier.size(20.dp)) }
}

@Composable
private fun ReaderTopBar(
    vm: ReaderViewModel,
    title: String,
    inLibrary: Boolean,
    dualPage: Boolean,
    dualPagePortrait: Boolean,
    onBack: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    val p = palette
    Row(
        Modifier.fillMaxWidth().windowInsetsPadding(WindowInsets.statusBars).padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        GlassButton(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back), onBack)
        Box(
            Modifier
                .weight(1f)
                .height(40.dp)
                .clip(CircleShape)
                .background(p.surface.copy(alpha = 0.95f))
                .border(1.dp, p.outline.copy(alpha = 0.7f), CircleShape)
                .padding(horizontal = 16.dp),
            contentAlignment = Alignment.CenterStart,
        ) {
            Text(title, style = MaterialTheme.typography.titleSmall, color = p.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (!inLibrary) GlassButton(AppIcons.LibraryAdd, stringResource(R.string.add_to_library)) { vm.addToLibrary() }
        GlassButton(AppIcons.BookmarkAdd, stringResource(R.string.add_bookmark)) { vm.showDialog(ReaderDialog.AddBookmark) }
        Box {
            GlassButton(Icons.Default.MoreVert, stringResource(R.string.reader_more_options)) { menu = true }
            AppDropdownMenu(expanded = menu, onDismiss = { menu = false }) {
                AppMenuItem(
                    stringResource(R.string.opt_dual_page),
                    onClick = { vm.updateSettings { it.copy(dualPage = !it.dualPage) }; menu = false },
                    trailing = { Switch(checked = dualPage, onCheckedChange = null) },
                )
                if (dualPage) {
                    AppMenuItem(
                        stringResource(R.string.opt_dual_page_portrait),
                        onClick = { vm.updateSettings { it.copy(dualPagePortrait = !it.dualPagePortrait) }; menu = false },
                        trailing = { Switch(checked = dualPagePortrait, onCheckedChange = null) },
                    )
                }
                AppMenuItem(stringResource(R.string.opt_auto_scroll), onClick = { menu = false; vm.showDialog(ReaderDialog.AutoScroll) })
                AppMenuItem(stringResource(R.string.opt_book_info), onClick = { menu = false; vm.loadBookInfo(); vm.showDialog(ReaderDialog.BookInfo) })
                AppMenuItem(stringResource(R.string.opt_page_flip), onClick = { menu = false; vm.showDialog(ReaderDialog.PageFlip) })
            }
        }
    }
}

/** Icon-only toolbar. Every icon opens its own section; which icons show is a user setting. */
@Composable
private fun ReaderToolbar(vm: ReaderViewModel, hidden: Set<String>, openTab: ReaderTab?) {
    val shown = ToolbarCatalog.items.filter { it.id !in hidden }
    val activeGroup = openTab?.let { ReaderGroup.of(it) }
    Row(Modifier.fillMaxWidth().height(56.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
        shown.forEach { item ->
            val group = when (item.id) {
                ToolbarItems.CONTENTS -> ReaderGroup.CONTENTS
                ToolbarItems.SEARCH -> ReaderGroup.SEARCH
                ToolbarItems.BOOKMARKS -> ReaderGroup.BOOKMARKS
                ToolbarItems.NOTES -> ReaderGroup.NOTES
                ToolbarItems.APPEARANCE -> ReaderGroup.APPEARANCE
                else -> ReaderGroup.FONTS
            }
            val active = activeGroup == group
            SoftIconButton(
                icon = item.icon,
                contentDescription = stringResource(item.nameRes),
                onClick = { if (active) vm.setSettingsOpen(false) else { vm.openTab(group.tabs.first()); vm.setSettingsOpen(true) } },
                selected = active,
                filled = false,
                tint = if (active) null else palette.textMuted,
            )
        }
    }
}

/** Search panel pinned to the top of the screen (below the status bar). */
@Composable
private fun SearchTopPanel(vm: ReaderViewModel, onClose: () -> Unit) {
    BackHandler(onBack = onClose)
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        Surface(
            modifier = Modifier.fillMaxWidth().heightIn(max = maxHeight * 0.6f),
            color = palette.surface,
            contentColor = palette.text,
            tonalElevation = 0.dp,
            shadowElevation = 16.dp,
            shape = RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp),
        ) {
            Column(Modifier.windowInsetsPadding(WindowInsets.statusBars).padding(horizontal = 16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(stringResource(R.string.tab_search), style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                    IconButton(onClick = onClose) { Icon(Icons.Default.Close, contentDescription = stringResource(R.string.search_close)) }
                }
                SearchPanel(vm, onClose)
            }
        }
    }
}

/** Rolling Blind: text below the moving line stays hidden; the line reveals it as it goes. */
@Composable
private fun BlindOverlay(vm: ReaderViewModel, pageColor: Color, accent: Color) {
    val y = vm.blind.collectAsState()
    Canvas(Modifier.fillMaxSize()) {
        val top = (size.height * y.value).coerceIn(0f, size.height)
        drawRect(pageColor.copy(alpha = 0.96f), topLeft = Offset(0f, top), size = Size(size.width, size.height - top))
        drawLine(accent, Offset(0f, top), Offset(size.width, top), strokeWidth = 2.dp.toPx())
    }
}

/** Speed Read (RSVP): one word at a time with the "optimal recognition point" letter highlighted. */
@Composable
private fun RsvpOverlay(vm: ReaderViewModel, speedPct: Int) {
    val d by vm.rsvp.collectAsState()
    val paused by vm.rsvpPaused.collectAsState()
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.systemBars).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            val word = d.word
            val pivot = ((word.length - 1) / 2).coerceAtLeast(0)
            val accent = MaterialTheme.colorScheme.primary
            Text(
                text = androidx.compose.ui.text.buildAnnotatedString {
                    word.forEachIndexed { i, ch ->
                        if (i == pivot) withStyle(androidx.compose.ui.text.SpanStyle(color = accent)) { append(ch) } else append(ch)
                    }
                },
                style = MaterialTheme.typography.displayMedium,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().height(110.dp).wrapContentHeight(Alignment.CenterVertically),
            )
            if (d.total > 0) {
                LinearProgressIndicator(progress = { d.index.toFloat() / d.total }, modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp))
                Text(
                    stringResource(R.string.progress_pages, Localized.number(d.index + 1), Localized.number(d.total)) +
                        " · " + stringResource(R.string.rsvp_wpm, (AutoReader.RSVP_BASE_WPM * speedPct / 100).toInt()),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Row(Modifier.padding(top = 24.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = { vm.toggleRsvpPause() }) {
                    Text(stringResource(if (paused) R.string.auto_resume else R.string.auto_pause))
                }
                OutlinedButton(onClick = { vm.stopAuto() }) { Text(stringResource(R.string.auto_stop)) }
            }
        }
    }
}

@Composable
private fun AutoStopPill(speedPct: Int, onStop: () -> Unit, modifier: Modifier = Modifier) {
    Surface(
        onClick = onStop,
        shape = CircleShape,
        color = palette.accentSoft,
        contentColor = palette.onAccentSoft,
        shadowElevation = 10.dp,
        modifier = modifier.windowInsetsPadding(WindowInsets.systemBars).padding(bottom = 20.dp),
    ) {
        Row(Modifier.padding(horizontal = 20.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(AppIcons.Pause, contentDescription = null)
            Text(
                stringResource(R.string.auto_stop) + " · " + Localized.percent(speedPct),
                style = MaterialTheme.typography.labelLarge,
                modifier = Modifier.padding(start = 8.dp),
            )
        }
    }
}

/**
 * Progress line with previous/next chapter buttons.
 *
 * Smoothness: while dragging the thumb snaps to real page positions (so what is shown is exactly where the book
 * opens); on release the thumb stays at the chosen place until the navigator has reported the new page, then
 * glides to the reported value. It never jumps back to the old position first.
 */
@Composable
private fun ProgressBar(
    info: ReaderInfo,
    markers: List<Double>,
    onSeek: (Double) -> Unit,
    onPreviousChapter: () -> Unit,
    onNextChapter: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var drag by remember { mutableStateOf<Float?>(null) }
    var hold by remember { mutableStateOf<Float?>(null) }
    val total = info.totalPositions
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    val tickColor = palette.textMuted.copy(alpha = 0.5f)

    fun snapToPage(v: Float): Float =
        if (total > 1) ReadingMath.fractionFromIndex(ReadingMath.indexFromFraction(v.toDouble(), total), total).toFloat() else v

    // Release the held value once the navigator has been quiet for a moment, then glide to the reported place.
    LaunchedEffect(hold, info.fraction) {
        if (hold != null) { delay(650); hold = null }
    }
    val target = (drag ?: hold ?: info.fraction.toFloat()).coerceIn(0f, 1f)
    val animated by animateFloatAsState(
        targetValue = target,
        animationSpec = if (drag != null) snap() else tween(220, easing = FastOutSlowInEasing),
        label = "progress",
    )
    val shownFraction = drag ?: animated
    val shownPage = if (drag != null && total > 0) ReadingMath.indexFromFraction(shownFraction.toDouble(), total) + 1 else info.position

    Column(modifier.fillMaxWidth()) {
        info.chapterTitle?.let {
            Text(it, style = MaterialTheme.typography.labelMedium, color = palette.textMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Row(Modifier.fillMaxWidth().height(40.dp), verticalAlignment = Alignment.CenterVertically) {
            SoftIconButton(AppIcons.ChevronsLeft, stringResource(R.string.reader_prev_chapter), onPreviousChapter, size = 36.dp)
            Box(Modifier.weight(1f).height(36.dp).padding(horizontal = 4.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxWidth().padding(horizontal = 10.dp).height(12.dp)) {
                    markers.forEach { m ->
                        val f = if (rtl) 1.0 - m else m
                        val x = (size.width * f).toFloat()
                        drawLine(tickColor, Offset(x, 0f), Offset(x, size.height), strokeWidth = 2.dp.toPx())
                    }
                }
                AppSlider(
                    value = shownFraction,
                    onValueChange = { drag = snapToPage(it) },
                    valueRange = 0f..1f,
                    onValueChangeFinished = {
                        drag?.let { f -> hold = f; onSeek(f.toDouble()) }
                        drag = null
                    },
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            SoftIconButton(AppIcons.ChevronsRight, stringResource(R.string.reader_next_chapter), onNextChapter, size = 36.dp)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            val pct = Localized.percent((shownFraction * 100).toInt())
            Text(pct, style = MaterialTheme.typography.labelLarge, color = palette.accentText)
            if (total > 0) {
                Text(
                    stringResource(
                        R.string.progress_pages,
                        Localized.number(shownPage),
                        Localized.number(total),
                    ),
                    style = MaterialTheme.typography.labelMedium,
                    color = palette.textMuted,
                )
                Text(
                    stringResource(R.string.progress_remaining, Localized.number((total - shownPage).coerceAtLeast(0))),
                    style = MaterialTheme.typography.labelMedium,
                    color = palette.textMuted,
                )
            }
        }
    }
}
