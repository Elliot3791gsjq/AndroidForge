package com.novelreader.app.ui.stats

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.novelreader.app.R
import com.novelreader.app.core.BarUnit
import com.novelreader.app.core.BookStat
import com.novelreader.app.core.ReadingMath
import com.novelreader.app.core.StatsPeriod
import com.novelreader.app.core.StatsResult
import com.novelreader.app.core.Trend
import com.novelreader.app.data.BookEntity
import com.novelreader.app.ui.AppIcons
import com.novelreader.app.ui.Localized
import com.novelreader.app.ui.design.AppCard
import com.novelreader.app.ui.design.AppDropdownMenu
import com.novelreader.app.ui.design.AppMenuItem
import com.novelreader.app.ui.design.AppProgressBar
import com.novelreader.app.ui.design.AppShapes
import com.novelreader.app.ui.design.MutedText
import com.novelreader.app.ui.design.ScreenHeader
import com.novelreader.app.ui.design.SectionLabel
import com.novelreader.app.ui.design.Space
import com.novelreader.app.ui.design.appClickable
import com.novelreader.app.ui.design.bottomClearance
import com.novelreader.app.ui.design.motion
import com.novelreader.app.ui.design.palette
import com.novelreader.app.ui.library.BookCover
import com.novelreader.app.ui.library.LibraryViewModel
import com.novelreader.app.ui.library.StatsUi
import java.time.Instant
import java.time.ZoneId
import java.time.format.TextStyle as JTextStyle
import java.util.Locale

/**
 * "Reading stats": time spent reading, trend against the previous period, tiles (books read from / finished,
 * day streak, sittings, pace), a day-by-day chart and a per-book list. All numbers come from the sittings recorded
 * by the reader on this device ([com.novelreader.app.core.ReadingStats]); the period button recomputes everything.
 */
@Composable
fun StatsScreen(vm: LibraryViewModel, onOpenDetail: (Long) -> Unit) {
    val ui by vm.stats.collectAsState()
    val period by vm.statsPeriodState.collectAsState()
    var menu by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(
            title = stringResource(R.string.stats_title),
            actions = {
                Box {
                    PeriodButton(periodLabel(period)) { menu = true }
                    AppDropdownMenu(menu, { menu = false }) {
                        StatsPeriod.entries.forEach { sp ->
                            AppMenuItem(periodLabel(sp), { vm.setStatsPeriod(sp); menu = false }, selected = sp == period)
                        }
                    }
                }
            },
        )
        val data = ui
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = Space.gutter, end = Space.gutter, top = Space.s, bottom = bottomClearance()),
            verticalArrangement = Arrangement.spacedBy(Space.m),
        ) {
            if (data != null) {
                val r = data.result
                item(key = "time") { TimeCard(r, r.period) }
                item(key = "tiles") { Tiles(r) }
                item(key = "device") { MutedText(stringResource(R.string.stats_device_only), Modifier.padding(horizontal = Space.xs)) }
                item(key = "chart") { ChartCard(r) }
                item(key = "bybook-label") { SectionLabel(stringResource(R.string.stats_by_book), Modifier.padding(top = Space.xs, bottom = 0.dp)) }
                val rows = r.byBook.filter { s -> data.books[s.bookId]?.let { it.inLibrary || s.millis > 0 } == true }
                if (rows.isEmpty()) {
                    item(key = "nobooks") { MutedText(stringResource(R.string.stats_no_books), Modifier.padding(vertical = Space.l)) }
                }
                items(rows, key = { "b" + it.bookId }) { s ->
                    val book = data.books.getValue(s.bookId)
                    BookRow(book, s, vm.coverFile(book)) { onOpenDetail(book.id) }
                }
            }
        }
    }
}

@Composable
private fun periodLabel(p: StatsPeriod): String = stringResource(
    when (p) {
        StatsPeriod.WEEK -> R.string.stats_period_week
        StatsPeriod.MONTH -> R.string.stats_period_month
        StatsPeriod.YEAR -> R.string.stats_period_year
        StatsPeriod.ALL -> R.string.stats_period_all
    }
)

@Composable
private fun PeriodButton(label: String, onClick: () -> Unit) {
    val p = palette
    Row(
        Modifier
            .height(40.dp)
            .appClickable(onClick, role = Role.Button)
            .clip(AppShapes.pill)
            .background(p.surfaceHigh)
            .border(1.dp, p.outline, AppShapes.pill)
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, style = MaterialTheme.typography.labelLarge, color = p.text, maxLines = 1)
        Spacer(Modifier.width(4.dp))
        Icon(AppIcons.ExpandMore, contentDescription = null, tint = p.textMuted, modifier = Modifier.size(18.dp))
    }
}

// ---------------------------------------------------------------------------------------------------------------
// Time card
// ---------------------------------------------------------------------------------------------------------------

@Composable
private fun TimeCard(r: StatsResult, period: StatsPeriod) {
    val p = palette
    AppCard(Modifier.fillMaxWidth(), shape = AppShapes.cardLarge) {
        Column(Modifier.padding(Space.xl)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    stringResource(R.string.stats_time_spent).uppercase(),
                    style = MaterialTheme.typography.labelMedium, color = p.accentText,
                    modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.width(Space.s))
                Text(
                    periodLabel(period),
                    style = MaterialTheme.typography.labelMedium, color = p.onAccentSoft,
                    modifier = Modifier.clip(AppShapes.pill).background(p.accentSoft).padding(horizontal = 12.dp, vertical = 5.dp),
                    maxLines = 1,
                )
            }
            Spacer(Modifier.height(Space.s))
            Text(bigDuration(r.totalMillis), color = p.text, maxLines = 2)
            Spacer(Modifier.height(Space.xs))
            Row(verticalAlignment = Alignment.CenterVertically) {
                when (r.trend) {
                    Trend.MORE -> Icon(AppIcons.ExpandLess, null, tint = p.accentText, modifier = Modifier.size(18.dp))
                    Trend.LESS -> Icon(AppIcons.ExpandMore, null, tint = p.textMuted, modifier = Modifier.size(18.dp))
                    Trend.SAME -> Icon(AppIcons.Remove, null, tint = p.textMuted, modifier = Modifier.size(18.dp))
                    Trend.NONE -> Unit
                }
                if (r.trend != Trend.NONE) Spacer(Modifier.width(4.dp))
                Text(
                    trendText(r, period),
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (r.trend == Trend.MORE) p.accentText else p.textMuted,
                )
            }
        }
    }
}

@Composable
private fun trendText(r: StatsResult, period: StatsPeriod): String {
    if (period == StatsPeriod.ALL) return stringResource(R.string.stats_trend_all)
    val previous = stringResource(
        when (period) {
            StatsPeriod.WEEK -> R.string.stats_last_week
            StatsPeriod.MONTH -> R.string.stats_last_month
            else -> R.string.stats_last_year
        }
    )
    return when (r.trend) {
        Trend.MORE -> stringResource(R.string.stats_trend_more, previous)
        Trend.LESS -> stringResource(R.string.stats_trend_less, previous)
        Trend.SAME -> stringResource(R.string.stats_trend_same, previous)
        Trend.NONE -> stringResource(
            when (period) {
                StatsPeriod.WEEK -> R.string.stats_trend_none_week
                StatsPeriod.MONTH -> R.string.stats_trend_none_month
                else -> R.string.stats_trend_none_year
            }
        )
    }
}

/** The headline duration: big numbers with small unit words ("1 h 25 min"). */
@Composable
private fun bigDuration(ms: Long): androidx.compose.ui.text.AnnotatedString {
    val hUnit = stringResource(R.string.stats_unit_h)
    val mUnit = stringResource(R.string.stats_unit_min)
    val less = stringResource(R.string.stats_dur_less_than_min)
    val base = MaterialTheme.typography.displayMedium
    val number = SpanStyle(fontFamily = base.fontFamily, fontSize = 44.sp, fontWeight = base.fontWeight)
    val unit = SpanStyle(fontSize = 16.sp, color = palette.textMuted)
    val h = ms / 3_600_000L
    val m = (ms % 3_600_000L) / 60_000L
    return buildAnnotatedString {
        when {
            ms in 1 until 60_000L -> withStyle(number.copy(fontSize = 28.sp)) { append(less) }
            h > 0 -> {
                withStyle(number) { append(Localized.number(h)) }
                withStyle(unit) { append(" $hUnit ") }
                if (m > 0) {
                    withStyle(number) { append(Localized.number(m)) }
                    withStyle(unit) { append(" $mUnit") }
                }
            }
            else -> {
                withStyle(number) { append(Localized.number(m)) }
                withStyle(unit) { append(" $mUnit") }
            }
        }
    }
}

/** Plain duration for chips and rows: "25 min", "2 h", "1 h 5 min", "<1 min". */
@Composable
private fun durationText(ms: Long): String {
    val hUnit = stringResource(R.string.stats_unit_h)
    val mUnit = stringResource(R.string.stats_unit_min)
    val less = stringResource(R.string.stats_dur_less_than_min)
    val h = ms / 3_600_000L
    val m = (ms % 3_600_000L) / 60_000L
    return when {
        ms <= 0 -> "${Localized.number(0)} $mUnit"
        ms < 60_000L -> less
        h == 0L -> "${Localized.number(m)} $mUnit"
        m == 0L -> "${Localized.number(h)} $hUnit"
        else -> "${Localized.number(h)} $hUnit ${Localized.number(m)} $mUnit"
    }
}

// ---------------------------------------------------------------------------------------------------------------
// Tiles
// ---------------------------------------------------------------------------------------------------------------

@Composable
private fun Tiles(r: StatsResult) {
    Column(verticalArrangement = Arrangement.spacedBy(Space.m)) {
        Row(horizontalArrangement = Arrangement.spacedBy(Space.m)) {
            StatTile(stringResource(R.string.stats_tile_books_read), Localized.number(r.booksReadFrom), Modifier.weight(1f))
            StatTile(stringResource(R.string.stats_tile_books_finished), Localized.number(r.booksFinished), Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(Space.m)) {
            StatTile(stringResource(R.string.stats_tile_streak), Localized.number(r.dayStreak), Modifier.weight(1f))
            StatTile(stringResource(R.string.stats_tile_sittings), Localized.number(r.sittings), Modifier.weight(1f))
        }
        val pace = r.pacePercentPerHour
        StatTile(
            stringResource(R.string.stats_tile_pace),
            if (pace == null) stringResource(R.string.stats_dash) else Localized.decimal(pace, 1),
            Modifier.fillMaxWidth(),
            unit = if (pace == null) null else stringResource(R.string.stats_pace_unit),
        )
    }
}

@Composable
private fun StatTile(label: String, value: String, modifier: Modifier = Modifier, unit: String? = null) {
    val p = palette
    AppCard(modifier) {
        Column(Modifier.padding(Space.l)) {
            Text(label, style = MaterialTheme.typography.bodySmall, color = p.textMuted, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(Space.xs))
            Row(verticalAlignment = Alignment.Bottom) {
                Text(value, style = MaterialTheme.typography.headlineMedium, color = p.text, maxLines = 1)
                if (unit != null) {
                    Spacer(Modifier.width(6.dp))
                    Text(unit, style = MaterialTheme.typography.labelMedium, color = p.textMuted, modifier = Modifier.padding(bottom = 4.dp), maxLines = 1)
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------------------------
// Chart
// ---------------------------------------------------------------------------------------------------------------

@Composable
private fun ChartCard(r: StatsResult) {
    val p = palette
    val zone = remember { ZoneId.systemDefault() }
    val locale = Locale.getDefault()
    AppCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(Space.l)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    stringResource(if (r.barUnit == BarUnit.DAY) R.string.stats_day_by_day else R.string.stats_month_by_month),
                    style = MaterialTheme.typography.titleMedium, color = p.text, modifier = Modifier.weight(1f),
                )
                Text(
                    stringResource(chipRes(r.period), durationText(r.totalMillis)),
                    style = MaterialTheme.typography.labelMedium, color = p.onAccentSoft,
                    modifier = Modifier.clip(AppShapes.pill).background(p.accentSoft).padding(horizontal = 12.dp, vertical = 5.dp),
                    maxLines = 1,
                )
            }
            Spacer(Modifier.height(Space.l))
            Bars(r, zone, locale)
        }
    }
}

private fun chipRes(p: StatsPeriod) = when (p) {
    StatsPeriod.WEEK -> R.string.stats_chip_week
    StatsPeriod.MONTH -> R.string.stats_chip_month
    StatsPeriod.YEAR -> R.string.stats_chip_year
    StatsPeriod.ALL -> R.string.stats_chip_all
}

@Composable
private fun Bars(r: StatsResult, zone: ZoneId, locale: Locale) {
    val p = palette
    val chartHeight = 128.dp
    val bars = r.bars
    val peak = bars.maxOfOrNull { it.millis }?.coerceAtLeast(1L) ?: 1L
    val dense = bars.size > 12
    val showValues = !dense
    val gap = if (dense) 2.dp else 6.dp
    Column {
        Row(
            Modifier.fillMaxWidth().height(chartHeight + 20.dp),
            horizontalArrangement = Arrangement.spacedBy(gap),
            verticalAlignment = Alignment.Bottom,
        ) {
            bars.forEach { b ->
                key(b.startMillis) {
                    val frac by animateFloatAsState(b.millis.toFloat() / peak, motion.medium(), label = "bar")
                    Column(Modifier.weight(1f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                        if (showValues && b.millis > 0) {
                            Text(shortDuration(b.millis), style = MaterialTheme.typography.labelSmall, color = p.textMuted, maxLines = 1, softWrap = false,
                                modifier = Modifier.wrapContentWidth(unbounded = true))
                            Spacer(Modifier.height(2.dp))
                        }
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .height(maxOf(4.dp, chartHeight * frac))
                                .clip(RoundedCornerShape(if (dense) 3.dp else 8.dp))
                                .background(
                                    when {
                                        b.isCurrent -> p.accent
                                        b.millis > 0 -> p.accent.copy(alpha = 0.55f)
                                        else -> p.surfaceHighest
                                    }
                                )
                        )
                    }
                }
            }
        }
        Spacer(Modifier.height(Space.s))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(gap)) {
            bars.forEachIndexed { i, b ->
                Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                    val visible = !dense || i == 0 || (i + 1) % 5 == 0
                    if (visible) {
                        Text(
                            barLabel(r, b.startMillis, zone, locale),
                            style = MaterialTheme.typography.labelSmall,
                            color = if (b.isCurrent) p.accentText else p.textMuted,
                            maxLines = 1, softWrap = false, textAlign = TextAlign.Center,
                            modifier = Modifier.wrapContentWidth(unbounded = true),
                        )
                    }
                }
            }
        }
    }
}

private fun barLabel(r: StatsResult, startMillis: Long, zone: ZoneId, locale: Locale): String {
    val d = Instant.ofEpochMilli(startMillis).atZone(zone)
    return when {
        r.barUnit == BarUnit.DAY && r.bars.size <= 7 -> d.dayOfWeek.getDisplayName(JTextStyle.SHORT, locale)
        r.barUnit == BarUnit.DAY -> Localized.number(d.dayOfMonth)
        else -> d.month.getDisplayName(JTextStyle.NARROW, locale)
    }
}

/** Compact value above a bar: "25m" or "1.5h". */
@Composable
private fun shortDuration(ms: Long): String {
    val minutes = (ms / 60_000L).coerceAtLeast(1L)
    return if (minutes < 60) {
        stringResource(R.string.stats_short_min, Localized.number(minutes))
    } else {
        val hours = minutes / 60.0
        val text = if (minutes % 60 == 0L) Localized.number(minutes / 60) else Localized.decimal(hours, 1)
        stringResource(R.string.stats_short_h, text)
    }
}

// ---------------------------------------------------------------------------------------------------------------
// By book
// ---------------------------------------------------------------------------------------------------------------

@Composable
private fun BookRow(book: BookEntity, s: BookStat, cover: java.io.File?, onClick: () -> Unit) {
    val p = palette
    AppCard(Modifier.fillMaxWidth(), onClick = onClick) {
        Row(Modifier.padding(Space.m), verticalAlignment = Alignment.CenterVertically) {
            BookCover(book.title, cover, Modifier.width(52.dp).aspectRatio(2f / 3f), elevation = 4.dp)
            Spacer(Modifier.width(Space.m))
            Column(Modifier.weight(1f)) {
                Text(book.title, style = MaterialTheme.typography.titleSmall, color = p.text, maxLines = 2, overflow = TextOverflow.Ellipsis)
                book.author?.takeIf { it.isNotBlank() }?.let { MutedText(it, maxLines = 1) }
                Spacer(Modifier.height(Space.s))
                AppProgressBar(book.progress.toFloat(), height = 4.dp)
                Spacer(Modifier.height(Space.xs))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        stringResource(R.string.stats_through, Localized.percent(ReadingMath.percent(book.progress))),
                        style = MaterialTheme.typography.labelMedium, color = p.textMuted, modifier = Modifier.weight(1f), maxLines = 1,
                    )
                    Text(
                        if (s.millis > 0) durationText(s.millis) else stringResource(R.string.stats_not_read),
                        style = MaterialTheme.typography.labelMedium, color = if (s.millis > 0) p.accentText else p.textMuted, maxLines = 1,
                    )
                }
                if (s.sittings > 0) {
                    Text(
                        if (s.sittings == 1) stringResource(R.string.stats_sittings_one) else stringResource(R.string.stats_sittings_many, Localized.number(s.sittings)),
                        style = MaterialTheme.typography.labelMedium, color = p.textMuted, maxLines = 1,
                    )
                }
            }
        }
    }
}
