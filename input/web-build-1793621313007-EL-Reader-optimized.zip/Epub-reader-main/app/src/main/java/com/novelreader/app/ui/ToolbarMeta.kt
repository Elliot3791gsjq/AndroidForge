package com.novelreader.app.ui

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Search
import androidx.compose.ui.graphics.vector.ImageVector
import com.novelreader.app.R
import com.novelreader.app.data.ToolbarItems

/** Icon + label for every reader bottom-toolbar entry; shared by the reader and "Customize toolbar". */
data class ToolbarMeta(val id: String, val nameRes: Int, val icon: ImageVector)

object ToolbarCatalog {
    val items: List<ToolbarMeta> by lazy {
        listOf(
            ToolbarMeta(ToolbarItems.CONTENTS, R.string.toolbar_contents, Icons.AutoMirrored.Filled.List),
            ToolbarMeta(ToolbarItems.SEARCH, R.string.toolbar_search, Icons.Default.Search),
            ToolbarMeta(ToolbarItems.BOOKMARKS, R.string.toolbar_bookmarks, AppIcons.Bookmark),
            ToolbarMeta(ToolbarItems.NOTES, R.string.toolbar_notes, AppIcons.Notes),
            ToolbarMeta(ToolbarItems.APPEARANCE, R.string.toolbar_appearance, AppIcons.Palette),
            ToolbarMeta(ToolbarItems.FONTS, R.string.toolbar_fonts, AppIcons.TextFields),
        )
    }
}
