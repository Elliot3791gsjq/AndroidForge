package com.novelreader.app.ui.design

import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.navigationBars
import android.app.Activity
import android.graphics.drawable.ColorDrawable
import android.provider.Settings
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import com.novelreader.app.data.ReaderSettings

// ---------------------------------------------------------------------------------------------------------------
// Central design system: palette tokens, typography, shapes, spacing, motion. Material 3 is only the technical
// base (it supplies the components the app does not draw itself); every value comes from here.
// ---------------------------------------------------------------------------------------------------------------

val LocalPalette = compositionLocalOf { PaletteFactory.build(Presets.byId(Presets.EMBER), true).toAppPalette() }

/** The active palette, e.g. `palette.accent`. */
val palette: AppPalette
    @Composable @ReadOnlyComposable get() = LocalPalette.current

object Space {
    val xs = 4.dp
    val s = 8.dp
    val m = 12.dp
    val l = 16.dp
    val xl = 20.dp
    val xxl = 28.dp
    /** Horizontal gutter of every top-level screen. */
    val gutter = 20.dp
    /** Bottom padding that keeps scrolling content clear of the floating navigation bar. */
    val navClearance = 112.dp
}

/**
 * Bottom padding for scrolling lists under the floating navigation bar: the bar itself, the system navigation
 * inset (gesture pill or 3-button bar) and some breathing room, so the last item can always be scrolled fully into view.
 */
@Composable
fun bottomClearance(): androidx.compose.ui.unit.Dp =
    Space.navClearance + WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 32.dp

object AppShapes {
    val chip: Shape = RoundedCornerShape(14.dp)
    val field: Shape = RoundedCornerShape(16.dp)
    val card: Shape = RoundedCornerShape(22.dp)
    val cardLarge: Shape = RoundedCornerShape(28.dp)
    val cover: Shape = RoundedCornerShape(14.dp)
    val sheet: Shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    val pill: Shape = CircleShape

    val material = Shapes(
        extraSmall = RoundedCornerShape(8.dp),
        small = RoundedCornerShape(12.dp),
        medium = RoundedCornerShape(16.dp),
        large = RoundedCornerShape(22.dp),
        extraLarge = RoundedCornerShape(28.dp),
    )
}

/** Animation timing. All durations collapse to [snap] when the user asked for reduced motion. */
@Immutable
class Motion(val reduce: Boolean) {
    fun <T> fast(): FiniteAnimationSpec<T> = if (reduce) snap() else tween(140, easing = FastOutSlowInEasing)
    fun <T> medium(): FiniteAnimationSpec<T> = if (reduce) snap() else tween(260, easing = FastOutSlowInEasing)
    fun <T> slow(): FiniteAnimationSpec<T> = if (reduce) snap() else tween(420, easing = FastOutSlowInEasing)
    /** Colour change when the theme is switched. */
    fun <T> theme(): FiniteAnimationSpec<T> = if (reduce) snap() else tween(380, easing = FastOutSlowInEasing)
}

val LocalMotion = compositionLocalOf { Motion(false) }

val motion: Motion
    @Composable @ReadOnlyComposable get() = LocalMotion.current

/** True when the user's setting, or the system "remove animations" switch (animator scale 0), asks for no motion. */
@Composable
fun rememberReduceMotion(userSetting: Boolean): Boolean {
    val resolver = LocalContext.current.contentResolver
    val systemOff = remember {
        try {
            Settings.Global.getFloat(resolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
        } catch (_: Throwable) {
            false
        }
    }
    return userSetting || systemOff
}

// ---------------------------------------------------------------------------------------------------------------
// Typography
// ---------------------------------------------------------------------------------------------------------------

private val NoSpacing: TextUnit = 0.sp

/**
 * UI text is Vazirmatn (Persian + Latin). English headings use Lora for a literary feel; Persian headings stay in
 * Vazirmatn because Lora has no Arabic-script glyphs. Letter spacing is always 0 - any tracking breaks Persian
 * letter joining. Only the Regular weight of each font ships; heavier weights are synthesised by the text engine.
 */
@Composable
fun rememberAppTypography(): Typography {
    val context = LocalContext.current
    val lang = LocalConfiguration.current.locales.get(0)?.language
    val arabicScript = lang == "fa" || lang == "ar"
    return remember(context, arabicScript) {
        val assets = context.assets
        val ui = FontFamily(Font("fonts/Vazirmatn-Regular.ttf", assets, FontWeight.Normal))
        val display = if (arabicScript) ui else FontFamily(Font("fonts/Lora-Regular.ttf", assets, FontWeight.Normal))
        fun s(size: Int, line: Int, weight: FontWeight, family: FontFamily = ui) = TextStyle(
            fontFamily = family, fontWeight = weight, fontSize = size.sp, lineHeight = line.sp, letterSpacing = NoSpacing,
        )
        Typography(
            displayLarge = s(44, 52, FontWeight.SemiBold, display),
            displayMedium = s(34, 42, FontWeight.SemiBold, display),
            displaySmall = s(28, 36, FontWeight.SemiBold, display),
            headlineLarge = s(26, 34, FontWeight.SemiBold, display),
            headlineMedium = s(22, 30, FontWeight.SemiBold, display),
            headlineSmall = s(20, 28, FontWeight.SemiBold, display),
            titleLarge = s(20, 28, FontWeight.SemiBold),
            titleMedium = s(16, 24, FontWeight.SemiBold),
            titleSmall = s(14, 22, FontWeight.SemiBold),
            bodyLarge = s(16, 26, FontWeight.Normal),
            bodyMedium = s(14, 23, FontWeight.Normal),
            bodySmall = s(12, 19, FontWeight.Normal),
            labelLarge = s(14, 20, FontWeight.Medium),
            labelMedium = s(12, 17, FontWeight.Medium),
            labelSmall = s(11, 16, FontWeight.Medium),
        )
    }
}

// ---------------------------------------------------------------------------------------------------------------
// Material bridge + theme entry points
// ---------------------------------------------------------------------------------------------------------------

private fun AppPalette.toColorScheme(): ColorScheme {
    val base = if (dark) darkColorScheme() else lightColorScheme()
    return base.copy(
        // Material components paint text/icons with `primary`, so it must be the text-safe accent.
        primary = accentText,
        onPrimary = if (com.novelreader.app.core.ColorMath.contrastRatio(Color.White.toArgb(), accentText.toArgb()) >=
            com.novelreader.app.core.ColorMath.contrastRatio(Color.Black.toArgb(), accentText.toArgb())) Color.White else Color.Black,
        primaryContainer = accentSoft,
        onPrimaryContainer = onAccentSoft,
        secondary = accentText,
        onSecondary = onAccent,
        secondaryContainer = surfaceHighest,
        onSecondaryContainer = text,
        tertiary = accentText,
        onTertiary = onAccent,
        tertiaryContainer = accentSoft,
        onTertiaryContainer = onAccentSoft,
        background = bg,
        onBackground = text,
        surface = bg,
        onSurface = text,
        surfaceVariant = surfaceHigh,
        onSurfaceVariant = textMuted,
        surfaceTint = Color.Transparent,
        inverseSurface = text,
        inverseOnSurface = bg,
        inversePrimary = accent,
        error = danger,
        onError = bg,
        errorContainer = surfaceHigh,
        onErrorContainer = danger,
        outline = textMuted.copy(alpha = 0.55f),
        outlineVariant = outline,
        scrim = Color.Black,
        surfaceDim = bg,
        surfaceBright = surfaceHighest,
        surfaceContainerLowest = bg,
        surfaceContainerLow = surface,
        surfaceContainer = surface,
        surfaceContainerHigh = surfaceHigh,
        surfaceContainerHighest = surfaceHighest,
    )
}

/** Animates every token towards [target], so switching theme or brightness fades instead of jumping. */
@Composable
private fun animatedPalette(target: AppPalette, reduce: Boolean): AppPalette {
    val m = Motion(reduce)
    @Composable fun a(c: Color, label: String): Color =
        animateColorAsState(c, m.theme(), label = label).value
    return AppPalette(
        dark = target.dark,
        bg = a(target.bg, "bg"),
        surface = a(target.surface, "surface"),
        surfaceHigh = a(target.surfaceHigh, "surfaceHigh"),
        surfaceHighest = a(target.surfaceHighest, "surfaceHighest"),
        outline = a(target.outline, "outline"),
        text = a(target.text, "text"),
        textMuted = a(target.textMuted, "textMuted"),
        accent = a(target.accent, "accent"),
        accentText = a(target.accentText, "accentText"),
        onAccent = a(target.onAccent, "onAccent"),
        accentSoft = a(target.accentSoft, "accentSoft"),
        onAccentSoft = a(target.onAccentSoft, "onAccentSoft"),
        danger = a(target.danger, "danger"),
    )
}

/**
 * The app theme for the saved [settings]. [syncSystemChrome] also paints the window background and the status /
 * navigation bar icon style to match (used by the library activity; the reader manages its own bars).
 */
@Composable
fun AppTheme(settings: ReaderSettings, syncSystemChrome: Boolean = true, content: @Composable () -> Unit) {
    val systemDark = isSystemInDarkTheme()
    val target = remember(settings.uiMode, settings.colorThemeId, settings.customThemes, systemDark) {
        PaletteFactory.resolve(settings, systemDark).toAppPalette()
    }
    AppThemeFromPalette(target, settings.reduceMotion, syncSystemChrome, content = content)
}

/** Theme from an explicit palette; also used by the theme editor to preview a draft with the real components. */
@Composable
fun AppThemeFromPalette(
    target: AppPalette,
    reduceMotionSetting: Boolean,
    syncSystemChrome: Boolean = false,
    instantColors: Boolean = false,
    content: @Composable () -> Unit,
) {
    val reduce = rememberReduceMotion(reduceMotionSetting)
    val p = animatedPalette(target, reduce || instantColors)
    val scheme = remember(p) { p.toColorScheme() }
    val typography = rememberAppTypography()

    if (syncSystemChrome) {
        val view = LocalView.current
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            window.setBackgroundDrawable(ColorDrawable(p.bg.toArgb()))
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = !target.dark
            controller.isAppearanceLightNavigationBars = !target.dark
        }
    }

    CompositionLocalProvider(LocalPalette provides p, LocalMotion provides Motion(reduce)) {
        MaterialTheme(colorScheme = scheme, typography = typography, shapes = AppShapes.material) {
            // Text/icons without an explicit colour follow the palette (outside a Surface the default would be black).
            CompositionLocalProvider(androidx.compose.material3.LocalContentColor provides p.text) { content() }
        }
    }
}
