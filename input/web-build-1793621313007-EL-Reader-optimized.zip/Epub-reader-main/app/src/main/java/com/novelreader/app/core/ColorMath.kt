package com.novelreader.app.core

/**
 * Pure colour math on ARGB Ints (no android.graphics dependency).
 * Backs the palette builder, which pulls any colour towards a readable one instead of ever refusing a choice.
 */
object ColorMath {

    /** WCAG minimum for normal body text. */
    const val MIN_CONTRAST = 3.0

    private fun channel(c: Int): Double {
        val v = c / 255.0
        return if (v <= 0.03928) v / 12.92 else Math.pow((v + 0.055) / 1.055, 2.4)
    }

    /** Relative luminance (WCAG) of an opaque colour given as 0xAARRGGBB or 0xRRGGBB. */
    fun luminance(argb: Int): Double {
        val r = (argb shr 16) and 0xFF
        val g = (argb shr 8) and 0xFF
        val b = argb and 0xFF
        return 0.2126 * channel(r) + 0.7152 * channel(g) + 0.0722 * channel(b)
    }

    /** WCAG contrast ratio, 1.0 (identical) .. 21.0 (black on white). */
    fun contrastRatio(a: Int, b: Int): Double {
        val la = luminance(a)
        val lb = luminance(b)
        val hi = maxOf(la, lb)
        val lo = minOf(la, lb)
        return (hi + 0.05) / (lo + 0.05)
    }

    fun isReadable(text: Int, background: Int): Boolean = contrastRatio(text, background) >= MIN_CONTRAST

    /** Black or white, whichever reads better on [background]. */
    fun bestTextOn(background: Int): Int =
        if (contrastRatio(0xFFFFFFFF.toInt(), background) >= contrastRatio(0xFF000000.toInt(), background))
            0xFFFFFFFF.toInt() else 0xFF000000.toInt()

    /** Parses "#RRGGBB", "RRGGBB", "#AARRGGBB" -> opaque ARGB Int, or null if invalid. */
    fun parseHex(input: String): Int? {
        val s = input.trim().removePrefix("#")
        if (s.length != 6 && s.length != 8) return null
        if (!s.all { it in '0'..'9' || it in 'a'..'f' || it in 'A'..'F' }) return null
        val v = s.toLong(16)
        return if (s.length == 6) (0xFF000000L or v).toInt() else v.toInt()
    }

    /** "#RRGGBB" (alpha dropped). */
    fun toHex(argb: Int): String = "#%06X".format(argb and 0xFFFFFF)

    /** HSV (h 0..360, s/v 0..1) to opaque ARGB Int. */
    fun hsvToArgb(h: Float, s: Float, v: Float): Int {
        val hh = ((h % 360f) + 360f) % 360f
        val c = v * s
        val x = c * (1 - Math.abs((hh / 60f) % 2 - 1))
        val m = v - c
        val (r, g, b) = when {
            hh < 60 -> Triple(c, x, 0f)
            hh < 120 -> Triple(x, c, 0f)
            hh < 180 -> Triple(0f, c, x)
            hh < 240 -> Triple(0f, x, c)
            hh < 300 -> Triple(x, 0f, c)
            else -> Triple(c, 0f, x)
        }
        fun to255(f: Float) = Math.round((f + m) * 255f).coerceIn(0, 255)
        return (0xFF shl 24) or (to255(r) shl 16) or (to255(g) shl 8) or to255(b)
    }

    /** ARGB Int to HSV triple (h 0..360, s/v 0..1). */
    fun argbToHsv(argb: Int): FloatArray {
        val r = ((argb shr 16) and 0xFF) / 255f
        val g = ((argb shr 8) and 0xFF) / 255f
        val b = (argb and 0xFF) / 255f
        val max = maxOf(r, g, b)
        val min = minOf(r, g, b)
        val d = max - min
        val h = when {
            d == 0f -> 0f
            max == r -> 60f * (((g - b) / d) % 6f)
            max == g -> 60f * (((b - r) / d) + 2f)
            else -> 60f * (((r - g) / d) + 4f)
        }.let { if (it < 0f) it + 360f else it }
        val s = if (max == 0f) 0f else d / max
        return floatArrayOf(h, s, max)
    }

    /** Linear blend of two opaque colours in sRGB space; t = 0 -> [a], t = 1 -> [b]. */
    fun mix(a: Int, b: Int, t: Float): Int {
        val k = t.coerceIn(0f, 1f)
        fun ch(shift: Int): Int {
            val x = (a shr shift) and 0xFF
            val y = (b shr shift) and 0xFF
            return Math.round(x + (y - x) * k).coerceIn(0, 255)
        }
        return (0xFF shl 24) or (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
    }

    /**
     * Returns [fg] unchanged when it already reaches [minRatio] against [bg]; otherwise nudges it towards white
     * or black (whichever direction increases contrast) in small steps, so hue is kept as long as possible.
     * This is what guarantees legibility for any user-chosen colour without ever having to reject a choice.
     */
    fun ensureContrast(fg: Int, bg: Int, minRatio: Double): Int {
        if (contrastRatio(fg, bg) >= minRatio) return fg
        val target = bestTextOn(bg)
        var t = 0.04f
        while (t < 1f) {
            val c = mix(fg, target, t)
            if (contrastRatio(c, bg) >= minRatio) return c
            t += 0.04f
        }
        return target
    }

    /**
     * Like [ensureContrast] but for several backgrounds at once: nudges [fg] towards [target] (the text polarity of
     * the page, normally `bestTextOn(page)`) until it reaches [minRatio] on every one of [backgrounds]. When that is
     * impossible (mid-tone pages cap out near 4.6:1) it returns [target], the strongest option.
     */
    fun ensureContrastOnAll(fg: Int, target: Int, minRatio: Double, vararg backgrounds: Int): Int {
        if (backgrounds.all { contrastRatio(fg, it) >= minRatio }) return fg
        var t = 0.04f
        while (t < 1f) {
            val c = mix(fg, target, t)
            if (backgrounds.all { contrastRatio(c, it) >= minRatio }) return c
            t += 0.04f
        }
        return target
    }

    /** The best contrast any text colour can reach on [background] (21 on black/white, ~4.6 at mid-grey). */
    fun maxAchievableContrast(background: Int): Double {
        val l = luminance(background)
        return maxOf(1.05 / (l + 0.05), (l + 0.05) / 0.05)
    }

    /** True for colours that are visually dark (page / surface colours). */
    fun isDark(argb: Int): Boolean = luminance(argb) < 0.179
}
