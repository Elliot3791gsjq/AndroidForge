package com.novelreader.app.core

import java.io.File
import java.net.URLDecoder
import java.util.zip.ZipFile

/**
 * Finds every picture of an EPUB, in reading order, straight from the book's own XHTML (nothing is invented).
 * The reader uses the result for the "Images" list of the Chapters panel and to jump to the exact picture.
 *
 * Numbering rule (shared with the page script that scrolls to the picture): the n-th `<img>` or SVG `<image>`
 * element of a resource, in document order, is picture number n of that resource.
 */
object EpubImages {

    /**
     * @param resourceHref  the reading-order resource containing the picture (no fragment, percent-decoded)
     * @param resourceOrder index of that resource in the reading order
     * @param indexInResource n-th picture element inside that resource (0-based)
     * @param entry         path of the picture file inside the EPUB (decoded), or null for data:/web pictures
     * @param progression   0..1 place of the tag inside its resource (used as the first, approximate, jump)
     */
    data class Ref(
        val globalIndex: Int,
        val resourceHref: String,
        val resourceOrder: Int,
        val indexInResource: Int,
        val entry: String?,
        val alt: String?,
        val progression: Double,
    )

    private val tag = Regex("<(img|image)\\b[^>]*>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
    private val srcAttr = Regex("(?:\\bsrc|\\bxlink:href|\\bhref)\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)')", RegexOption.IGNORE_CASE)
    private val altAttr = Regex("\\balt\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)')", RegexOption.IGNORE_CASE)

    /** The pictures of one XHTML document. [firstGlobalIndex] numbers them across the whole book. */
    fun parse(html: String, resourceHref: String, resourceOrder: Int, firstGlobalIndex: Int): List<Ref> {
        val out = ArrayList<Ref>()
        val len = html.length.coerceAtLeast(1).toDouble()
        for ((i, m) in tag.findAll(html).withIndex()) {
            val raw = m.value
            val src = srcAttr.find(raw)?.let { it.groupValues[1].ifEmpty { it.groupValues[2] } }
            val alt = altAttr.find(raw)?.let { it.groupValues[1].ifEmpty { it.groupValues[2] } }?.trim()?.takeIf { it.isNotEmpty() }
            out += Ref(
                globalIndex = firstGlobalIndex + i,
                resourceHref = resourceHref,
                resourceOrder = resourceOrder,
                indexInResource = i,
                entry = src?.let { resolve(resourceHref, it) },
                alt = alt?.let(::decodeEntities),
                progression = (m.range.first / len).coerceIn(0.0, 1.0),
            )
        }
        return out
    }

    /**
     * Zip entry path of [src] as written in the document at [baseHref]: query/fragment removed, percent-decoded,
     * "." and ".." resolved. Returns null for data: URIs and web addresses.
     */
    fun resolve(baseHref: String, src: String): String? {
        val s = src.trim()
        if (s.isEmpty() || s.startsWith("data:", true) || s.contains("://") || s.startsWith("//")) return null
        val clean = decode(s.substringBefore('#').substringBefore('?'))
        val parts = ArrayList<String>()
        if (!clean.startsWith("/")) {
            parts.addAll(baseHref.split('/').dropLast(1).filter { it.isNotEmpty() })
        }
        for (seg in clean.split('/')) {
            when (seg) {
                "", "." -> {}
                ".." -> if (parts.isNotEmpty()) parts.removeAt(parts.lastIndex)
                else -> parts += seg
            }
        }
        return parts.joinToString("/").ifEmpty { null }
    }

    /** Percent-decoding that leaves "+" alone (it is a literal plus in a path, not a space). */
    fun decode(s: String): String =
        try { URLDecoder.decode(s.replace("+", "%2B"), "UTF-8") } catch (_: Exception) { s }

    private fun decodeEntities(s: String): String =
        s.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&#39;", "'").replace("&apos;", "'")

    /**
     * Reads the reading-order documents of [epub] and lists their pictures. [readingOrderHrefs] are the hrefs the
     * EPUB engine reports (fragment-free, possibly percent-encoded). Unreadable documents are skipped.
     */
    fun scan(epub: File, readingOrderHrefs: List<String>): List<Ref> {
        val out = ArrayList<Ref>()
        try {
            ZipFile(epub).use { zip ->
                readingOrderHrefs.forEachIndexed { order, hrefRaw ->
                    val href = decode(hrefRaw)
                    val entry = zip.getEntry(href) ?: zip.getEntry(hrefRaw) ?: return@forEachIndexed
                    val html = try {
                        zip.getInputStream(entry).use { it.readBytes() }.toString(Charsets.UTF_8)
                    } catch (_: Exception) {
                        return@forEachIndexed
                    }
                    out += parse(html, href, order, out.size)
                }
            }
        } catch (_: Exception) {
            // an unreadable archive simply has no list
        }
        return out
    }
}
