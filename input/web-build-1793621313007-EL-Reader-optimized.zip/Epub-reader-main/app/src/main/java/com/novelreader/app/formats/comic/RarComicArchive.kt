package com.novelreader.app.formats.comic

import com.github.junrar.Archive
import com.github.junrar.ArchiveOptions
import com.github.junrar.exception.RarException
import com.github.junrar.exception.UnsupportedRarEncryptedException
import com.github.junrar.exception.WrongPasswordException
import com.github.junrar.rarfile.FileHeader
import com.novelreader.app.formats.BookFormat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream

/**
 * CBR: RAR archives (RAR 1.4 up to 7, incl. RAR5) read with junrar (pure Java, Maven Central).
 *
 * RAR cannot be read page-by-page at random like ZIP (solid archives must be decoded in order), so the pages are
 * unpacked one by one into [cacheDir] by a background thread and become readable as soon as each one is done:
 *  - non-solid archive: the page the reader asks for is unpacked first, the rest follows in archive order;
 *  - solid archive: strictly in archive order (anything else would force junrar to replay the stream).
 *
 * Files are written as `<pageIndex>.img` - never under a name taken from the archive - so a hostile entry name
 * ("../../x") cannot write outside [cacheDir]. Per-page size, page count and free space are checked first.
 * A page that fails to unpack (CRC error, unsupported method) is marked damaged; the others stay readable.
 */
class RarComicArchive(private val file: File, private val cacheDir: File) : ComicArchive {

    override val format = BookFormat.CBR

    private val archive: Archive
    private val headers: List<FileHeader>      // page order
    private val archiveOrder: IntArray         // page indices in the order they appear inside the archive
    private val solid: Boolean
    override val info: ComicInfo?

    private val lock = Object()
    private val ready: BooleanArray
    private val damaged: BooleanArray
    private val requested = LinkedHashSet<Int>()
    private val count = MutableStateFlow(0)
    override val readyCount: StateFlow<Int> get() = count
    @Volatile override var failure: Throwable? = null
        private set
    @Volatile private var closed = false
    private var worker: Thread? = null

    init {
        cacheDir.mkdirs()
        val opened = try {
            Archive(file, ArchiveOptions.builder().maxDictionarySize(MAX_DICTIONARY).build())
        } catch (e: WrongPasswordException) {
            throw EncryptedComicException()
        } catch (e: UnsupportedRarEncryptedException) {
            throw EncryptedComicException()
        } catch (e: RarException) {
            throw IOException("damaged or unsupported RAR: ${e.message}", e)
        }
        archive = opened
        try {
            if (archive.isPasswordProtected) throw EncryptedComicException()

            // Archive-order list of candidate pages (header + its position inside the archive).
            class Cand(val header: FileHeader, val name: String, val pos: Int)
            val cands = ArrayList<Cand>()
            var infoHeader: FileHeader? = null
            var pos = 0
            for (h in archive.fileHeaders) {
                val name = h.fileName ?: continue
                if (h.isDirectory) continue
                if (ComicPages.isComicInfoName(name)) { infoHeader = h; continue }
                if (!ComicPages.isPageName(name)) continue
                if (h.isSplitAfter || h.isSplitBefore) continue     // multi-volume pieces are not supported
                if (h.fullUnpackSize > ComicPages.MAX_ENTRY_BYTES) continue
                cands += Cand(h, name, pos++)
                if (cands.size >= ComicPages.MAX_PAGES) break
            }
            if (cands.isEmpty()) throw EmptyComicException()
            cands.sortWith { a, b -> ComicPages.order.compare(a.name, b.name) }

            headers = cands.map { it.header }
            val n = cands.size
            val order = IntArray(n)
            // Page indices sorted by their position inside the archive.
            cands.indices.sortedBy { cands[it].pos }.forEachIndexed { i, pageIdx -> order[i] = pageIdx }
            archiveOrder = order
            solid = (archive.mainHeader?.isSolid == true) || archive.fileHeaders.any { it.isSolid }
            ready = BooleanArray(n)
            damaged = BooleanArray(n)

            val totalBytes = headers.sumOf { it.fullUnpackSize.coerceAtLeast(0L) }
            val free = cacheDir.usableSpace
            if (free in 1 until (totalBytes + MIN_FREE_MARGIN)) throw NoSpaceComicException()

            // junrar replays the files before an entry of a solid archive to reach it, so in a solid archive
            // ComicInfo.xml is only read up front when little data precedes it (otherwise opening would decode
            // the whole archive twice); a missing ComicInfo just means "no direction / title hint".
            val infoAt = infoHeader
            val replayBytes = if (infoAt == null || !solid) 0L
            else archive.fileHeaders.takeWhile { it !== infoAt }.sumOf { it.fullUnpackSize.coerceAtLeast(0L) }
            info = infoAt?.takeIf { it.fullUnpackSize in 1..1_000_000 && replayBytes <= INFO_REPLAY_LIMIT }?.let { h ->
                try {
                    val bos = java.io.ByteArrayOutputStream()
                    archive.extractFile(h, bos)
                    ComicPages.parseInfo(String(bos.toByteArray(), Charsets.UTF_8))
                } catch (_: Exception) { null }
            }
        } catch (t: Throwable) {
            try { archive.close() } catch (_: IOException) { }
            throw t
        }
        // Pages left from an earlier open (partial or complete) are reused.
        for (i in 0 until pageCount) {
            val f = pageFile(i)
            if (f.isFile && f.length() > 0) { ready[i] = true; count.value++ }
        }
        startWorker()
    }

    override val pageCount: Int get() = headers.size
    override fun pageName(index: Int): String = headers[index].fileName ?: ""
    override fun isReady(index: Int): Boolean = synchronized(lock) { ready.getOrElse(index) { false } }

    private fun pageFile(i: Int) = File(cacheDir, "$i.img")

    private fun startWorker() {
        if (count.value >= pageCount) { closeArchiveQuietly(); return }
        worker = Thread({ runWorker() }, "rar-unpack").apply { isDaemon = true; priority = Thread.NORM_PRIORITY - 1; start() }
    }

    private fun pickNext(): Int? = synchronized(lock) {
        if (!solid) {
            val it = requested.iterator()
            while (it.hasNext()) {
                val r = it.next(); it.remove()
                if (!ready[r] && !damaged[r]) return r
            }
        }
        for (p in archiveOrder) if (!ready[p] && !damaged[p]) return p
        null
    }

    private fun runWorker() {
        try {
            while (!closed) {
                val i = pickNext() ?: break
                unpack(i)
            }
        } catch (t: Throwable) {
            if (!closed) failure = t
        } finally {
            synchronized(lock) { lock.notifyAll() }
            closeArchiveQuietly()
        }
    }

    private fun unpack(i: Int) {
        val part = File(cacheDir, "$i.part")
        var ok = false
        try {
            FileOutputStream(part).use { fos ->
                archive.extractFile(headers[i], CappedOutputStream(fos, ComicPages.MAX_ENTRY_BYTES))
            }
            ok = part.length() > 0 && part.renameTo(pageFile(i))
        } catch (e: RarException) {
            // One broken page must not take the whole book down.
        } catch (e: TooLargeException) {
            // Inflates past the per-page cap (archive bomb): this page is skipped.
        } catch (e: IOException) {
            if (closed) return
            // Disk full / write error: fatal for everything that follows.
            part.delete()
            throw e
        } finally {
            if (!ok) part.delete()
        }
        synchronized(lock) {
            if (ok) { ready[i] = true; count.value = count.value + 1 } else damaged[i] = true
            lock.notifyAll()
        }
    }

    override fun openPage(index: Int): InputStream {
        if (index !in 0 until pageCount) throw IOException("no such page")
        synchronized(lock) {
            if (!solid && !ready[index]) { requested.add(index); lock.notifyAll() }
            while (!ready[index] && !damaged[index] && failure == null && !closed) lock.wait(250)
            if (damaged[index]) throw IOException("damaged page")
            if (!ready[index]) throw IOException(failure?.message ?: "archive closed")
        }
        return FileInputStream(pageFile(index))
    }

    private fun closeArchiveQuietly() {
        try { archive.close() } catch (_: Exception) { }
    }

    override fun close() {
        closed = true
        synchronized(lock) { lock.notifyAll() }
        // The worker closes the archive itself when it stops; with no worker running, close it here.
        if (worker?.isAlive != true) closeArchiveQuietly()
    }

    private class TooLargeException : RuntimeException("entry too large")

    private class CappedOutputStream(private val out: OutputStream, private var remaining: Long) : OutputStream() {
        override fun write(b: Int) { if (--remaining < 0) throw TooLargeException(); out.write(b) }
        override fun write(b: ByteArray, off: Int, len: Int) {
            remaining -= len
            if (remaining < 0) throw TooLargeException()
            out.write(b, off, len)
        }
        override fun flush() = out.flush()
        override fun close() = out.close()
    }

    companion object {
        /** RAR5 dictionaries can ask for 4 GB; a phone gets a sane budget (archives needing more fail cleanly). */
        const val MAX_DICTIONARY = 256L * 1024 * 1024
        private const val MIN_FREE_MARGIN = 64L * 1024 * 1024
        private const val INFO_REPLAY_LIMIT = 16L * 1024 * 1024
    }
}
