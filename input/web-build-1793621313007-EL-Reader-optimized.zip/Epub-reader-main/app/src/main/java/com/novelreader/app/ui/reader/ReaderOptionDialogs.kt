package com.novelreader.app.ui.reader

import android.text.format.Formatter
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import com.novelreader.app.ui.design.AlertDialog
import com.novelreader.app.ui.design.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import com.novelreader.app.ui.design.OutlinedButton
import com.novelreader.app.ui.design.OutlinedTextField
import com.novelreader.app.ui.design.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.novelreader.app.R
import com.novelreader.app.data.AutoScrollMode
import com.novelreader.app.data.PageFlipAnim
import com.novelreader.app.data.PageFlipMode
import com.novelreader.app.data.flipMode
import com.novelreader.app.data.withFlipMode
import com.novelreader.app.reader.AutoReader
import com.novelreader.app.reader.ExternalService
import com.novelreader.app.reader.ExternalServices
import com.novelreader.app.reader.ReaderViewModel
import com.novelreader.app.reader.ServiceOutcome
import com.novelreader.app.ui.Localized
import com.novelreader.app.ui.SectionTitle
import com.novelreader.app.ui.StepperSlider

// ---------------------------------------------------------------------------------------------------------
// Note on a selection
// ---------------------------------------------------------------------------------------------------------

@Composable
fun NoteDialog(text: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var note by remember { mutableStateOf("") }
    val context = LocalContext.current
    val empty = stringResource(R.string.note_empty)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.new_note)) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("“$text”", maxLines = 4, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                OutlinedTextField(
                    value = note, onValueChange = { note = it },
                    label = { Text(stringResource(R.string.note_text)) },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 110.dp),
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (note.isBlank()) Toast.makeText(context, empty, Toast.LENGTH_SHORT).show() else onSave(note.trim())
            }) { Text(stringResource(R.string.save)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}

// ---------------------------------------------------------------------------------------------------------
// "More": send the selected text elsewhere
// ---------------------------------------------------------------------------------------------------------

private fun ExternalService.labelRes(): Int = when (this) {
    ExternalService.GOOGLE_TRANSLATE -> R.string.svc_google_translate
    ExternalService.WEB_SEARCH -> R.string.svc_web_search
    ExternalService.GEMINI -> R.string.svc_gemini
    ExternalService.CHATGPT -> R.string.svc_chatgpt
    ExternalService.PERPLEXITY -> R.string.svc_perplexity
    ExternalService.CLAUDE -> R.string.svc_claude
    ExternalService.GROK -> R.string.svc_grok
    ExternalService.DEEPSEEK -> R.string.svc_deepseek
    ExternalService.KIMI -> R.string.svc_kimi
}

@Composable
fun ServicesDialog(text: String, onDismiss: () -> Unit, onTranslate: () -> Unit) {
    val context = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.more_title)) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(text, maxLines = 3, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(stringResource(R.string.more_privacy), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(vertical = 8.dp))
                ExternalService.entries.forEach { svc ->
                    HorizontalDivider()
                    Text(
                        stringResource(svc.labelRes()),
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.fillMaxWidth().clickable {
                            if (svc == ExternalService.GOOGLE_TRANSLATE) {
                                onTranslate()
                            } else {
                                val msg = when (val r = ExternalServices.send(context, svc, text)) {
                                    ServiceOutcome.OpenedApp, ServiceOutcome.OpenedWeb -> null
                                    ServiceOutcome.OpenedWebCopied -> context.getString(R.string.svc_copied_paste)
                                    is ServiceOutcome.OpenedWebTruncated -> context.getString(R.string.svc_truncated, r.limit)
                                    ServiceOutcome.Failed -> context.getString(R.string.svc_failed)
                                }
                                if (msg != null) Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                                onDismiss()
                            }
                        }.padding(vertical = 14.dp),
                    )
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}


// ---------------------------------------------------------------------------------------------------------
// Auto Scroll
// ---------------------------------------------------------------------------------------------------------

private fun AutoScrollMode.labelRes(): Int = when (this) {
    AutoScrollMode.ROLLING_BLIND_PIXEL -> R.string.auto_rb_pixel
    AutoScrollMode.ROLLING_BLIND_LINE -> R.string.auto_rb_line
    AutoScrollMode.SCROLL_PIXEL -> R.string.auto_scroll_pixel
    AutoScrollMode.SCROLL_LINE -> R.string.auto_scroll_line
    AutoScrollMode.SCROLL_PAGE -> R.string.auto_scroll_page
    AutoScrollMode.SPEED_READ -> R.string.auto_speed_read
}

@Composable
private fun RadioRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected = selected, onClick = onClick)
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(start = 4.dp))
    }
}

@Composable
fun AutoScrollDialog(vm: ReaderViewModel, onDismiss: () -> Unit) {
    val s by vm.settings.collectAsState()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.auto_title)) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                SectionTitle(stringResource(R.string.auto_mode))
                AutoScrollMode.entries.forEach { m ->
                    RadioRow(stringResource(m.labelRes()), s.autoScrollMode == m) { vm.updateSettings { it.copy(autoScrollMode = m) } }
                }
                if (s.autoScrollMode == AutoScrollMode.SPEED_READ) {
                    Text(stringResource(R.string.rsvp_hint), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                SectionTitle(stringResource(R.string.auto_speed))
                StepperSlider(
                    label = stringResource(R.string.auto_speed),
                    value = s.autoScrollSpeed.toFloat(),
                    range = 10f..300f,
                    step = 10f,
                    valueText = { Localized.percent(it.toInt()) },
                    onCommit = { v -> vm.updateSettings { it.copy(autoScrollSpeed = v.toInt()) } },
                )
                if (s.autoScrollMode == AutoScrollMode.SPEED_READ) {
                    Text(
                        stringResource(R.string.rsvp_wpm, (AutoReader.RSVP_BASE_WPM * s.autoScrollSpeed / 100).toInt()),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
            }
        },
        confirmButton = { TextButton(onClick = { vm.startAuto() }) { Text(stringResource(R.string.auto_start)) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}

// ---------------------------------------------------------------------------------------------------------
// Page flip settings
// ---------------------------------------------------------------------------------------------------------

private fun PageFlipMode.labelRes(): Int = when (this) {
    PageFlipMode.RIGHT_TO_LEFT -> R.string.flip_rtl
    PageFlipMode.LEFT_TO_RIGHT -> R.string.flip_ltr
    PageFlipMode.TOP_TO_BOTTOM_CONTINUOUS -> R.string.flip_ttb_cont
    PageFlipMode.TOP_TO_BOTTOM_SEPARATE -> R.string.flip_ttb_sep
}

private fun PageFlipAnim.labelRes(): Int = when (this) {
    PageFlipAnim.NONE -> R.string.anim_none
    PageFlipAnim.APPLE_CURL -> R.string.anim_apple
    PageFlipAnim.GOOGLE_CURL -> R.string.anim_google
    PageFlipAnim.FLIP_HORIZONTAL -> R.string.anim_flip_h
    PageFlipAnim.FLIP_VERTICAL -> R.string.anim_flip_v
    PageFlipAnim.FADE -> R.string.anim_fade
    PageFlipAnim.SHIFT_HORIZONTAL -> R.string.anim_shift
    PageFlipAnim.TWO_WAY_SLIDE -> R.string.anim_two_way
}

@Composable
fun PageFlipDialog(vm: ReaderViewModel, onDismiss: () -> Unit) {
    val s by vm.settings.collectAsState()
    val mode = s.flipMode()
    val defaultTag = stringResource(R.string.flip_default_tag)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.flip_title)) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                SectionTitle(stringResource(R.string.flip_direction))
                PageFlipMode.entries.forEach { m ->
                    val label = stringResource(m.labelRes()) + if (m == PageFlipMode.RIGHT_TO_LEFT) " ($defaultTag)" else ""
                    RadioRow(label, mode == m) { vm.setFlipMode(m) }
                }
                Text(stringResource(R.string.flip_dir_hint), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                SectionTitle(stringResource(R.string.flip_animation))
                PageFlipAnim.entries.forEach { a ->
                    RadioRow(stringResource(a.labelRes()), s.pageFlipAnim == a) { vm.updateSettings { it.copy(pageFlipAnim = a) } }
                }
                StepperSlider(
                    label = stringResource(R.string.flip_speed),
                    value = s.pageFlipSpeed.toFloat(),
                    range = 1f..10f,
                    step = 1f,
                    valueText = { "${it.toInt()}/10" },
                    onCommit = { v -> vm.updateSettings { it.copy(pageFlipSpeed = v.toInt()) } },
                )
                Text(stringResource(R.string.flip_anim_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.close_dialog)) } },
    )
}

// ---------------------------------------------------------------------------------------------------------
// Book information
// ---------------------------------------------------------------------------------------------------------

@Composable
fun BookInfoDialog(vm: ReaderViewModel, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val data by vm.bookInfo.collectAsState()
    val info by vm.info.collectAsState()
    val calculating = stringResource(R.string.bi_calculating)

    fun duration(ms: Long): String {
        val minutes = ms / 60_000
        return when {
            minutes < 1 -> context.getString(R.string.bi_lt_min)
            minutes < 60 -> context.getString(R.string.bi_m, minutes.toInt())
            else -> context.getString(R.string.bi_h_m, (minutes / 60).toInt(), (minutes % 60).toInt())
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.opt_book_info)) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                val d = data
                if (d == null) {
                    Text(calculating)
                } else {
                    InfoRow(stringResource(R.string.bi_filename), d.fileName)
                    InfoRow(stringResource(R.string.bi_location), stringResource(R.string.bi_location_private))
                    InfoRow(stringResource(R.string.bi_size), Formatter.formatFileSize(context, d.sizeBytes))
                    InfoRow(stringResource(R.string.bi_total_pages), if (info.totalPositions > 0) Localized.number(info.totalPositions) else "—")
                    InfoRow(stringResource(R.string.bi_current_page), if (info.totalPositions > 0) Localized.number(info.position) else "—")
                    InfoRow(stringResource(R.string.bi_total_chapters), Localized.number(d.totalChapters))
                    InfoRow(stringResource(R.string.bi_current_chapter), info.chapterTitle ?: "—")
                    InfoRow(stringResource(R.string.bi_reading_time), duration(d.readingMillis))
                    val words = d.words
                    InfoRow(
                        stringResource(R.string.bi_est_left),
                        if (words == null) calculating else duration((words * (1.0 - info.fraction) / 230.0 * 60_000).toLong()),
                    )
                    InfoRow(stringResource(R.string.bi_chars), d.characters?.let { Localized.number(it) } ?: calculating)
                    InfoRow(stringResource(R.string.bi_words), words?.let { Localized.number(it) } ?: calculating)
                    Text(stringResource(R.string.bi_pages_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(stringResource(R.string.bi_est_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    OutlinedButton(onClick = { vm.continueFromSaved(); onDismiss() }) { Text(stringResource(R.string.back_to_saved)) }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.close_dialog)) } },
    )
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(0.45f))
        Text(value, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(0.55f))
    }
}
