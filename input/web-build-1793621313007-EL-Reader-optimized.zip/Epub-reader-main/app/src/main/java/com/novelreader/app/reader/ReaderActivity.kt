package com.novelreader.app.reader

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.ActionMode
import android.view.Menu
import android.view.MenuItem
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.fragment.app.FragmentContainerView
import androidx.fragment.app.commitNow
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.novelreader.app.R
import com.novelreader.app.data.AnnotationStyle
import com.novelreader.app.data.PageFlipAnim
import com.novelreader.app.data.isVerticalScrolling
import com.novelreader.app.data.flipMode
import com.novelreader.app.data.PageFlipMode
import com.novelreader.app.ui.design.AppTheme
import com.novelreader.app.core.ColorMath
import com.novelreader.app.data.effectiveBackground
import com.novelreader.app.graph
import com.novelreader.app.ui.reader.ReaderBackground
import com.novelreader.app.ui.reader.ReaderScreen
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filterIsInstance
import org.readium.r2.navigator.preferences.ReadingProgression
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import org.json.JSONObject
import org.readium.r2.navigator.DecorableNavigator
import org.readium.r2.navigator.Decoration
import org.readium.r2.navigator.epub.EpubNavigatorFactory
import org.readium.r2.navigator.epub.EpubNavigatorFragment
import org.readium.r2.navigator.input.InputListener
import org.readium.r2.navigator.input.TapEvent
import org.readium.r2.navigator.util.DirectionalNavigationAdapter
import org.readium.r2.shared.publication.Locator
import org.readium.r2.shared.util.AbsoluteUrl

/**
 * Hosts the Readium EPUB navigator (the engine's WebView-based renderer lives inside the fragment) and layers
 * the native Compose reading UI on top of it: progress bar, settings panel, search, highlights, bookmarks...
 *
 * The activity is the only place that talks to the navigator; Compose and the [ReaderViewModel] talk to it
 * through [ReaderCommand]s, decorations and preferences.
 */
class ReaderActivity : AppCompatActivity(), EpubNavigatorFragment.Listener {

    private lateinit var vm: ReaderViewModel
    private lateinit var navContainer: FragmentContainerView
    private var navigator: EpubNavigatorFragment? = null
    private lateinit var swipeLayout: VerticalSwipeLayout
    private lateinit var pageTurner: PageTurner
    private lateinit var autoReader: AutoReader
    /** Decoded background picture (for the page-turn snapshot); the live backdrop is drawn by Compose. */
    private var backgroundBitmap: Bitmap? = null
    /** Whether two pages per screen were requested when this navigator was created (fixed for its lifetime). */
    private var appliedDual = false

    override fun onCreate(savedInstanceState: Bundle?) {
        // The real factory needs the opened Publication, which loads asynchronously. Until then a dummy factory
        // keeps the FragmentManager happy. Fragment state is intentionally not restored (null below): the
        // reading position is restored from the database, which also covers process death.
        supportFragmentManager.fragmentFactory = EpubNavigatorFragment.createDummyFactory()
        super.onCreate(null)

        val bookId = intent.getLongExtra(EXTRA_BOOK_ID, -1L)
        if (bookId < 0) { finish(); return }
        vm = ViewModelProvider(this, ReaderViewModel.factory(application, bookId, intent.getStringExtra(EXTRA_START_LOCATOR)))[ReaderViewModel::class.java]

        WindowCompat.setDecorFitsSystemWindows(window, false)

        navContainer = FragmentContainerView(this).apply { id = R.id.navigator_container }
        val composeView = ComposeView(this).apply {
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
            setContent {
                val settings = vm.settings.collectAsState().value
                AppTheme(settings = settings, syncSystemChrome = false) {
                    ReaderScreen(vm = vm, onBack = { finish() })
                }
            }
        }
        // Layer 0: solid colour + optional image, BEHIND the (transparent-capable) navigator.
        val backgroundView = ComposeView(this).apply {
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
            setContent {
                val settings = vm.settings.collectAsState().value
                ReaderBackground(settings, graph.backgrounds)
            }
        }
        swipeLayout = VerticalSwipeLayout(this).apply {
            addView(navContainer, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        // Draws the page that is being turned away (curl / slide / fade / swing) above the live reader.
        val turnView = PageTurnView(this)
        pageTurner = PageTurner(
            view = turnView,
            layers = listOf(swipeLayout),
            paintBase = { canvas, w, h ->
                val st = vm.settings.value
                BackgroundSnapshot.draw(canvas, w, h, st.effectiveBackground(), backgroundBitmap, st.backgroundImageMode, st.backgroundImageOpacity)
            },
            config = {
                val st = vm.settings.value
                PageTurner.Config(
                    style = st.pageFlipAnim,
                    speed = st.pageFlipSpeed,
                    rtl = navigator?.overflow?.value?.readingProgression == ReadingProgression.RTL,
                    paper = st.effectiveBackground(),
                    enabled = st.pageFlipAnim != PageFlipAnim.NONE && !st.isVerticalScrolling() && !vm.autoRunning.value && navigator != null,
                    dual = appliedDual,
                    // Only the page is on screen (no bars, panels, dialogs): a window screenshot is exactly the page.
                    pixelCopy = !vm.chromeVisible.value && !vm.settingsOpen.value && vm.dialog.value == null && !vm.autoRunning.value,
                )
            },
            target = object : PageTurner.Target {
                override fun go(forward: Boolean): Boolean {
                    val nav = navigator ?: return false
                    return if (forward) nav.goForward(animated = false) else nav.goBackward(animated = false)
                }
                override fun position(): Any? = navigator?.currentLocator?.value
                override fun restore(position: Any?) {
                    val loc = position as? Locator ?: return
                    navigator?.go(loc, animated = false)
                }
            },
            densityDpi = { resources.displayMetrics.densityDpi.toFloat() },
            liveTranslate = { navContainer.translationX = it },
            window = { window },
        )
        swipeLayout.dragListener = pageTurner.dragListener
        autoReader = AutoReader(
            vm = vm,
            nav = { navigator },
            density = { resources.displayMetrics.density },
            viewportHeightPx = { navContainer.height },
        )
        swipeLayout.onSwipe = { forward -> if (forward) vm.next() else vm.previous() }
        val root = FrameLayout(this).apply {
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            addView(backgroundView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            addView(swipeLayout, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            addView(turnView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            addView(composeView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        setContentView(root)

        // Keep book text clear of the status/navigation bars and any display cut-out (also in fullscreen).
        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            navContainer.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        observeSystemBars()

        lifecycleScope.launch {
            val ready = vm.load.filterIsInstance<ReaderLoad.Ready>().first()
            setupNavigator(ready)
        }
    }

    // ---------------------------------------------------------------------------------------------
    // Navigator setup
    // ---------------------------------------------------------------------------------------------

    private fun setupNavigator(ready: ReaderLoad.Ready) {
        val factory = EpubNavigatorFactory(ready.publication)
        appliedDual = dualNow(vm.settings.value)
        supportFragmentManager.fragmentFactory = factory.createFragmentFactory(
            initialLocator = ready.initialLocator,
            initialPreferences = ReaderPreferencesMapper.toEpubPreferences(vm.settings.value, ready.fontIds, isLandscape()),
            listener = this,
            paginationListener = object : EpubNavigatorFragment.PaginationListener {
                // A new resource finished loading: re-apply Bold (it lives in the page DOM, not in a decoration).
                override fun onPageLoaded() {
                    clearNavigatorBackground(navContainer)
                    navigator?.let { n -> lifecycleScope.launch { applyBold(n); applyBackgroundMode(n) } }
                }
            },
            configuration = EpubNavigatorFragment.Configuration(
                // Reading-system page colour = transparent (inline CSS variable, so even the very first paint of a
                // chapter is see-through). A user page colour, when sent, still wins and paints the page normally.
                // Dual-Page Mode also needs the reading-system column count: Readium CSS ignores the *user* column
                // count below ~60em of viewport width, i.e. on every phone (see DualPage).
                readiumCssRsProperties = org.readium.r2.navigator.epub.css.RsProperties(
                    backgroundColor = TransparentPage,
                    colCount = if (appliedDual) org.readium.r2.navigator.epub.css.ColCount.TWO else null,
                    colWidth = if (appliedDual) org.readium.r2.navigator.epub.css.Length.Px(100.0) else null,
                ),
                decorationTemplates = AnnotationDecor.templates(),
                selectionActionModeCallback = SelectionCallback(),
                // The activity already pads the navigator container for system bars / cut-outs (see onCreate).
                shouldApplyInsetsPadding = false,
            ),
        )
        supportFragmentManager.commitNow {
            replace(navContainer.id, EpubNavigatorFragment::class.java, Bundle(), NAV_TAG)
        }
        val nav = supportFragmentManager.findFragmentByTag(NAV_TAG) as EpubNavigatorFragment
        navigator = nav
        // Readium paints an opaque page colour on its ViewPager and a white base on every page WebView; both hide
        // the background layer behind the navigator. Keep them transparent (the layer draws the colour itself).
        clearNavigatorBackground(navContainer)
        navContainer.viewTreeObserver.addOnGlobalLayoutListener { clearNavigatorBackground(navContainer) }
        wire(nav)
    }

    /** Makes the navigator's ViewPager and every page WebView transparent (no-op for views that already are). */
    private fun clearNavigatorBackground(view: android.view.View) {
        // The pager class is matched by name: it is Readium-internal and its androidx base class is not on our classpath.
        // Matched by name (not class): the pager is Readium-internal, and a release build may repackage it.
        val cls = view.javaClass
        if (view is android.webkit.WebView || cls.name.startsWith("org.readium.") || cls.simpleName.startsWith("R2") || cls.simpleName.contains("ViewPager")) {
            val current = (view.background as? android.graphics.drawable.ColorDrawable)?.color
            if (current != android.graphics.Color.TRANSPARENT) view.setBackgroundColor(android.graphics.Color.TRANSPARENT)
        }
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) clearNavigatorBackground(view.getChildAt(i))
        }
    }

    private fun wire(nav: EpubNavigatorFragment) {
        // Keys (arrows, space) keep Readium's own handling; taps are handled below so edge taps can play the page turn.
        nav.addInputListener(DirectionalNavigationAdapter(nav, tapEdges = emptySet()))
        nav.addInputListener(object : InputListener {
            override fun onTap(event: TapEvent): Boolean {
                // Edge taps turn pages (the outer 30% of the width, at least 80 px, like the engine's default);
                // a tap in the middle - or past the first/last page - toggles the reading chrome.
                if (!nav.overflow.value.scroll) {
                    val width = nav.publicationView.width.toDouble()
                    val edge = maxOf(80.0, 0.3 * width)
                    val x = event.point.x
                    val rtl = nav.overflow.value.readingProgression == ReadingProgression.RTL
                    val turned = when {
                        x >= width - edge -> pageTurner.turn(forward = !rtl, onBlocked = { vm.toggleChrome() })
                        x <= edge -> pageTurner.turn(forward = rtl, onBlocked = { vm.toggleChrome() })
                        else -> false
                    }
                    if (turned) return true
                }
                // A tap on a picture opens it in the zoom viewer; anywhere else it toggles the reading chrome.
                val p = event.point
                lifecycleScope.launch {
                    val hit = runCatching { nav.evaluateJavascript(IMAGE_AT_JS.replace("__X__", p.x.toString()).replace("__Y__", p.y.toString())) }
                        .getOrNull().orEmpty().trim().removeSurrounding("\"").replace("\\/", "/")
                    val bar = hit.indexOf('|')
                    val index = if (bar > 0) hit.substring(0, bar).toIntOrNull() else null
                    if (index != null) vm.openImageFromPage(hit.substring(bar + 1), index) else vm.toggleChrome()
                }
                return true
            }
        })

        // Tapping an existing highlight opens its edit dialog.
        nav.addDecorationListener(HIGHLIGHT_GROUP, object : DecorableNavigator.Listener {
            override fun onDecorationActivated(event: DecorableNavigator.OnActivatedEvent): Boolean {
                val id = event.decoration.id.toString().removePrefix("hl-").toLongOrNull() ?: return false
                vm.openHighlight(id)
                return true
            }
        })

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    nav.currentLocator.collect { loc ->
                        vm.onLocatorChanged(loc)
                        pageTurner.onPageChanged()
                    }
                }

                launch {
                    vm.settings.map { it.backgroundImagePath != null }.distinctUntilChanged().collect {
                        applyBackgroundMode(nav)
                        delay(250)
                        clearNavigatorBackground(navContainer)
                        // Diagnostics (view tree + page colours in logcat) only for debuggable builds.
                        if ((applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0) diagnoseBackground(nav)
                    }
                }

                // The page-turn snapshot needs the decoded background picture (the live one is drawn by Compose).
                launch {
                    vm.settings.map { it.backgroundImagePath }.distinctUntilChanged().collect { path ->
                        backgroundBitmap = if (path == null) null else runCatching { graph.backgrounds.load(path) }.getOrNull()
                    }
                }

                // A finger drag drives the page turn whenever an animation style is chosen (paginated modes only).
                launch {
                    vm.settings.map { it.pageFlipAnim != PageFlipAnim.NONE && !it.isVerticalScrolling() }.distinctUntilChanged()
                        .collect { swipeLayout.horizontalDragEnabled = it }
                }

                // Single / dual page is fixed per navigator: when it changes, reopen at the same page.
                launch {
                    vm.settings.map { dualNow(it) }.distinctUntilChanged().collectLatest { want ->
                        if (want != appliedDual) {
                            delay(250)
                            vm.reopenForLayout()
                        }
                    }
                }

                // "Top to Bottom (Separate Pages)": vertical swipes become single page turns.
                launch { vm.settings.map { it.flipMode() == PageFlipMode.TOP_TO_BOTTOM_SEPARATE }.distinctUntilChanged().collect { swipeLayout.separatePages = it } }

                // Automatic reading modes (scroll / blind / speed read); restarted when mode or speed changes.
                launch {
                    combine(vm.autoRunning, vm.settings.map { it.autoScrollMode to it.autoScrollSpeed }.distinctUntilChanged()) { r, ms -> r to ms }
                        .collectLatest { (running, ms) -> if (running) autoReader.run(ms.first, ms.second) }
                }

                launch {
                    combine(vm.settings, vm.availableFontIds) { settings, fontIds ->
                        ReaderPreferencesMapper.toEpubPreferences(settings, fontIds, isLandscape())
                    }
                        .distinctUntilChanged()
                        .collect { nav.submitPreferences(it) }
                }

                launch {
                    vm.events.collect { event ->
                        when (event) {
                            is ReaderEvent.Message -> Toast.makeText(
                                this@ReaderActivity,
                                event.arg?.let { getString(event.resId, it) } ?: getString(event.resId),
                                Toast.LENGTH_LONG,
                            ).show()
                            ReaderEvent.Reopen -> reopen()
                        }
                    }
                }

                launch {
                    vm.highlights.collectLatest { list ->
                        nav.applyDecorations(AnnotationDecor.decorations(list), HIGHLIGHT_GROUP)
                        applyBold(nav)
                    }
                }

                launch {
                    vm.search.collectLatest { s ->
                        val decorations = s.hits.take(MAX_SEARCH_DECORATIONS).mapIndexed { i, hit ->
                            Decoration(
                                id = "sr-$i",
                                locator = hit.locator,
                                style = Decoration.Style.Highlight(
                                    tint = SEARCH_TINT,
                                    isActive = i == s.activeIndex,
                                ),
                            )
                        }
                        nav.applyDecorations(decorations, SEARCH_GROUP)
                    }
                }

                launch {
                    vm.commands.collect { cmd ->
                        when (cmd) {
                            is ReaderCommand.GoLocator -> nav.go(cmd.locator, animated = false)
                            is ReaderCommand.GoLink -> nav.go(cmd.link, animated = false)
                            ReaderCommand.Next -> pageTurner.turn(forward = true)
                            ReaderCommand.Previous -> pageTurner.turn(forward = false)
                            is ReaderCommand.GoImage -> lifecycleScope.launch { jumpToImage(nav, cmd) }
                        }
                    }
                }
            }
        }
    }

    /**
     * With a background image the page itself must be see-through, otherwise the image layer behind the navigator
     * is hidden. The preference asks for an alpha-0 colour; this additionally forces the page's CSS backgrounds to
     * transparent in case the engine drops the alpha channel.
     */
    /** Logs what paints the reader area (view backgrounds, page colours) so a missing background picture can be traced. */
    private suspend fun diagnoseBackground(nav: EpubNavigatorFragment) {
        delay(1800)
        val sb = StringBuilder()
        fun walk(v: View, depth: Int) {
            val bg = (v.background as? ColorDrawable)?.let { "#%08x".format(it.color) } ?: (v.background?.javaClass?.simpleName ?: "none")
            sb.append("  ".repeat(depth)).append(v.javaClass.name.substringAfterLast('.'))
                .append(" bg=").append(bg).append(" layer=").append(v.layerType)
                .append(" alpha=").append(v.alpha).append(" vis=").append(v.visibility).append('\n')
            if (v is ViewGroup) for (i in 0 until v.childCount) walk(v.getChildAt(i), depth + 1)
        }
        walk(swipeLayout, 0)
        Log.i("BgDiag", "image=${vm.settings.value.backgroundImagePath} opacity=${vm.settings.value.backgroundImageOpacity} views:\n$sb")
        val js = "(function(){var h=document.documentElement,b=document.body;return [getComputedStyle(h).backgroundColor,getComputedStyle(b).backgroundColor,h.getAttribute('style'),document.getElementById('nr-bg-style')?'style-injected':'no-style'].join(' | ');})()"
        val r = runCatching { nav.evaluateJavascript(js) }
        Log.i("BgDiag", "page: " + (r.getOrNull() ?: r.exceptionOrNull()?.toString()))
    }

    private suspend fun applyBackgroundMode(nav: EpubNavigatorFragment) {
        val on = vm.settings.value.backgroundImagePath != null
        runCatching { nav.evaluateJavascript(TRANSPARENT_JS.replace("__ON__", on.toString())) }
    }

    /**
     * Opens the picture's document, then scrolls the page to that exact picture. The page script numbers pictures
     * the same way as [com.novelreader.app.core.EpubImages] (n-th img / svg image element) and uses Readium's own
     * scroll helper, so paginated pages land on the right page. Retried while the document is still loading.
     */
    private suspend fun jumpToImage(nav: EpubNavigatorFragment, cmd: ReaderCommand.GoImage) {
        nav.go(cmd.link, animated = false)
        val js = IMAGE_JUMP_JS.replace("__N__", cmd.index.toString()).replace("__TAIL__", JSONObject.quote(cmd.hrefTail))
        repeat(40) {
            kotlinx.coroutines.delay(120)
            val r = runCatching { nav.evaluateJavascript(js) }.getOrNull().orEmpty()
            if (r.contains("ok")) return
        }
    }

    private suspend fun applyBold(nav: EpubNavigatorFragment) {
        runCatching { nav.evaluateJavascript(BoldInjector.script(vm.highlights.value)) }
    }

    // ---------------------------------------------------------------------------------------------
    // Fullscreen / system bars
    // ---------------------------------------------------------------------------------------------

    private fun observeSystemBars() {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                vm.settings.map { it.fullscreen to ColorMath.isDark(it.effectiveBackground()) }.distinctUntilChanged().collect { (fullscreen, darkPage) ->
                    if (fullscreen) controller.hide(WindowInsetsCompat.Type.systemBars())
                    else controller.show(WindowInsetsCompat.Type.systemBars())
                    controller.isAppearanceLightStatusBars = !darkPage
                    controller.isAppearanceLightNavigationBars = !darkPage
                }
            }
        }
    }

    // ---------------------------------------------------------------------------------------------
    // Navigator listener (hyperlinks)
    // ---------------------------------------------------------------------------------------------

    /** EPUB links to the web are never opened silently: the user is asked first. */
    override fun onExternalLinkActivated(url: AbsoluteUrl) {
        vm.showDialog(ReaderDialog.ExternalLink(url.toString()))
    }

    // ---------------------------------------------------------------------------------------------
    // Text selection toolbar
    // ---------------------------------------------------------------------------------------------

    private inner class SelectionCallback : ActionMode.Callback {
        override fun onCreateActionMode(mode: ActionMode, menu: Menu): Boolean {
            swipeLayout.selectionActive = true
            mode.menuInflater.inflate(R.menu.reader_selection, menu)
            return true
        }

        override fun onPrepareActionMode(mode: ActionMode, menu: Menu): Boolean = false

        override fun onActionItemClicked(mode: ActionMode, item: MenuItem): Boolean {
            val action = item.itemId
            lifecycleScope.launch {
                val nav = navigator
                val selection = nav?.currentSelection()
                mode.finish()
                if (action == R.id.action_notes) {
                    vm.openTab(ReaderTab.NOTES); vm.setSettingsOpen(true)
                    return@launch
                }
                if (nav == null || selection == null) return@launch
                val text = selection.locator.text.highlight?.trim().orEmpty()
                if (text.isEmpty()) return@launch
                val json = selection.locator.toJSON().toString()
                val chapter = vm.chapterTitleFor(selection.locator)
                when (action) {
                    R.id.action_copy -> copyToClipboard(text)
                    R.id.action_highlight -> vm.showDialog(ReaderDialog.NewHighlight(json, text, chapter))
                    R.id.action_bold -> vm.applyStyle(AnnotationStyle.BOLD, json, text, chapter)
                    R.id.action_underline -> vm.applyStyle(AnnotationStyle.UNDERLINE, json, text, chapter)
                    R.id.action_strike -> vm.applyStyle(AnnotationStyle.STRIKE, json, text, chapter)
                    R.id.action_reset_format -> vm.resetFormatting(json, text)
                    R.id.action_note -> vm.showDialog(ReaderDialog.NewNote(json, text, chapter))
                    R.id.action_more -> vm.showDialog(ReaderDialog.Services(text))
                }
                nav.clearSelection()
            }
            return true
        }

        override fun onDestroyActionMode(mode: ActionMode) { swipeLayout.selectionActive = false }
    }

    private fun copyToClipboard(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText(getString(R.string.app_name), text))
        Toast.makeText(this, R.string.copied, Toast.LENGTH_SHORT).show()
    }

    // ---------------------------------------------------------------------------------------------

    private fun isLandscape(): Boolean = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

    private fun dualNow(s: com.novelreader.app.data.ReaderSettings): Boolean =
        DualPage.active(s.dualPage, s.dualPagePortrait, s.isVerticalScrolling(), isLandscape())

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (::pageTurner.isInitialized) pageTurner.finishNow()
        // Rotating can switch dual pages on or off; the column count is fixed per navigator, so reopen.
        if (navigator != null && dualNow(vm.settings.value) != appliedDual) vm.reopenForLayout()
    }

    /** Restarts this reader for the same book (position was already saved by the view-model). */
    private fun reopen() {
        // The saved position wins over any one-off "open at this place" request the first launch carried.
        val again = Intent(intent).addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION).also { it.removeExtra(EXTRA_START_LOCATOR) }
        finish()
        startActivity(again)
        @Suppress("DEPRECATION")
        overridePendingTransition(0, 0)
    }

    override fun onStart() {
        super.onStart()
        vm.onForeground()
    }

    override fun onStop() {
        if (::pageTurner.isInitialized) pageTurner.finishNow()
        vm.stopAuto()
        vm.onBackground()
        vm.flushPosition()
        super.onStop()
    }

    override fun onDestroy() {
        if (::pageTurner.isInitialized) pageTurner.release()
        super.onDestroy()
    }

    companion object {
        private const val EXTRA_BOOK_ID = "book_id"
        private const val NAV_TAG = "EpubNavigatorFragment"
        const val HIGHLIGHT_GROUP = AnnotationDecor.GROUP
        /**
         * The page CSS of Readium paints html with `:root[style*="--USER__backgroundColor"] { ... !important }`
         * (specificity 0,2,0), which a plain `html { background: transparent !important }` cannot beat. Two chained
         * `:not(#id)` raise the specificity above it, so the page really is see-through; the book's own body
         * background is cleared too. Removed again when the image is switched off.
         */
        private const val TRANSPARENT_JS = """(function(on){var id='nr-bg-style';var st=document.getElementById(id);if(!on){if(st){st.remove();}return true;}if(!st){st=document.createElement('style');st.id=id;(document.head||document.documentElement).appendChild(st);}st.textContent='html:not(#nr-a):not(#nr-b),html:not(#nr-a):not(#nr-b) body:not(#nr-a):not(#nr-b){background:transparent !important;background-color:transparent !important;background-image:none !important}';return true;})(__ON__)"""

        /** CSS colour "transparent" for Readium's reading-system background property (alpha-aware, unlike Color.Int). */
        private object TransparentPage : org.readium.r2.navigator.epub.css.Color {
            override fun toCss(): String = "transparent"
        }
        /** "n|page-url" for the picture under the point (device px), or "" - n counts img / svg image elements like EpubImages. */
        private const val IMAGE_AT_JS = """(function(px,py){try{var r=window.devicePixelRatio||1;var el=document.elementFromPoint(px/r,py/r);while(el&&el.tagName&&!/^(img|image)$/i.test(el.tagName)){if(/^svg$/i.test(el.tagName)){var inner=el.querySelector('image');if(inner){el=inner;break;}}el=el.parentElement;}if(!el){return '';}var els=document.querySelectorAll('img, image');var i=Array.prototype.indexOf.call(els,el);return i<0?'':(i+'|'+decodeURIComponent(location.href));}catch(e){return '';}})(__X__,__Y__)"""
        private const val IMAGE_JUMP_JS = """(function(n,tail){try{var d=decodeURIComponent(location.href);if(d.indexOf(tail)<0){return 'wait';}var els=document.querySelectorAll('img, image');var el=els[n];if(!el){return 'none';}if(!el.id){el.id='nr-img-'+n;}var done=false;if(window.readium&&window.readium.scrollToId){done=window.readium.scrollToId(el.id);}if(!done){el.scrollIntoView({block:'center',inline:'center'});}return 'ok';}catch(e){return 'err '+e;}})(__N__,__TAIL__)"""
        const val SEARCH_GROUP = "search-results"
        private const val SEARCH_TINT = 0xFFFF9800.toInt()
        private const val MAX_SEARCH_DECORATIONS = 200

        private const val EXTRA_START_LOCATOR = "start_locator"

        /** [startLocatorJson] (a Readium Locator) opens the book at that exact place instead of the saved position. */
        fun intent(context: Context, bookId: Long, startLocatorJson: String? = null): Intent =
            Intent(context, ReaderActivity::class.java).putExtra(EXTRA_BOOK_ID, bookId)
                .also { if (startLocatorJson != null) it.putExtra(EXTRA_START_LOCATOR, startLocatorJson) }
    }
}
