package com.novelreader.app.formats

import java.io.File
import java.io.IOException
import java.util.Locale
import java.util.zip.ZipException
import java.util.zip.ZipFile

/** Outcome of looking at the bytes of a file. */
sealed interface Detection {
    data class Found(val format: BookFormat) : Detection

    /** Not one of the supported types (spreadsheet, 7z, random binary, ...). */
    data object Unknown : Detection

    /** The signature says [format] but the container cannot be read (truncated download, broken zip, ...). */
    data class Damaged(val format: BookFormat) : Detection
}

/**
 * Decides what a file really is from its CONTENT; the display name and MIME type are only tie-breakers
 * (plain text has no signature, so it needs a hint). Pure java.io / java.util.zip, unit-tested with real files.
 *
 *  - "%PDF-" in the first KB            -> PDF
 *  - "Rar!\x1A\x07"                     -> CBR
 *  - ZIP: META-INF/container.xml        -> EPUB
 *         word/document.xml             -> DOCX
 *         other Office files (xl/, ppt/) -> unsupported
 *         otherwise, if it holds images -> CBZ (so a ".cbr" that is really a ZIP opens as CBZ)
 *  - no signature, readable text, text-like extension/MIME -> TXT
 */
object FormatDetector {

    val imageExtensions: Set<String> = setOf("jpg", "jpeg", "png", "webp", "gif", "bmp")

    private const val SAMPLE = 16 * 1024

    fun detect(file: File, displayName: String?, mime: String? = null): Detection {
        val head = try {
            file.inputStream().use { ins ->
                val buf = ByteArray(SAMPLE)
                var n = 0
                while (n < buf.size) {
                    val r = ins.read(buf, n, buf.size - n)
                    if (r < 0) break
                    n += r
                }
                buf.copyOf(n)
            }
        } catch (_: IOException) {
            return Detection.Unknown
        }
        if (head.isEmpty()) return Detection.Unknown
        val hint = BookFormat.fromExtension(displayName) ?: BookFormat.fromMime(mime)

        if (hasPdfHeader(head)) return Detection.Found(BookFormat.PDF)
        if (hasRarSignature(head)) return Detection.Found(BookFormat.CBR)
        if (hasZipSignature(head)) return detectZip(file, hint)
        if (isOtherArchive(head)) return Detection.Unknown

        val textHint = hint == BookFormat.TXT || mime?.lowercase(Locale.ROOT)?.startsWith("text/") == true
        if (textHint && looksLikeText(head, head.size)) return Detection.Found(BookFormat.TXT)
        return Detection.Unknown
    }

    // ---- signatures ----

    fun hasPdfHeader(head: ByteArray): Boolean {
        // The PDF spec allows junk before "%PDF-" as long as it is within the first 1024 bytes.
        val limit = minOf(head.size - 5, 1024)
        for (i in 0..limit) {
            if (head[i] == '%'.code.toByte() && head[i + 1] == 'P'.code.toByte() && head[i + 2] == 'D'.code.toByte() &&
                head[i + 3] == 'F'.code.toByte() && head[i + 4] == '-'.code.toByte()
            ) return true
        }
        return false
    }

    /** RAR 1.5-4 ("Rar!\x1A\x07\x00") and RAR 5 ("Rar!\x1A\x07\x01\x00"). */
    fun hasRarSignature(head: ByteArray): Boolean =
        head.size >= 7 && head[0] == 0x52.toByte() && head[1] == 0x61.toByte() && head[2] == 0x72.toByte() &&
            head[3] == 0x21.toByte() && head[4] == 0x1A.toByte() && head[5] == 0x07.toByte()

    fun hasZipSignature(head: ByteArray): Boolean =
        head.size >= 4 && head[0] == 0x50.toByte() && head[1] == 0x4B.toByte() &&
            (head[2] == 0x03.toByte() && head[3] == 0x04.toByte() || head[2] == 0x05.toByte() && head[3] == 0x06.toByte())

    private fun isOtherArchive(head: ByteArray): Boolean =
        // 7-Zip, gzip, bzip2, xz
        head.size >= 6 && (
            head[0] == 0x37.toByte() && head[1] == 0x7A.toByte() && head[2] == 0xBC.toByte() && head[3] == 0xAF.toByte() ||
                head[0] == 0x1F.toByte() && head[1] == 0x8B.toByte() ||
                head[0] == 0x42.toByte() && head[1] == 0x5A.toByte() && head[2] == 0x68.toByte() ||
                head[0] == 0xFD.toByte() && head[1] == 0x37.toByte() && head[2] == 0x7A.toByte()
            )

    private fun detectZip(file: File, hint: BookFormat?): Detection {
        val damagedAs = hint?.takeIf { it == BookFormat.EPUB || it == BookFormat.DOCX || it == BookFormat.CBZ } ?: BookFormat.CBZ
        try {
            ZipFile(file).use { zip ->
                var hasContainer = false
                var hasDocx = false
                var hasOtherOffice = false
                var images = 0
                var count = 0
                val en = zip.entries()
                while (en.hasMoreElements()) {
                    val e = en.nextElement()
                    if (++count > 500_000) break
                    if (e.isDirectory) continue
                    val n = e.name
                    when {
                        n == "META-INF/container.xml" -> hasContainer = true
                        n == "word/document.xml" -> hasDocx = true
                        n.startsWith("xl/") || n.startsWith("ppt/") -> hasOtherOffice = true
                        else -> {
                            val ext = BookFormat.extensionOf(n)
                            if (ext != null && ext in imageExtensions && !isJunkEntry(n)) images++
                        }
                    }
                }
                if (!hasContainer) {
                    // Some generators only write the "mimetype" entry.
                    zip.getEntry("mimetype")?.let { m ->
                        val txt = zip.getInputStream(m).use { ins ->
                            val b = ByteArray(64)
                            var n = 0
                            while (n < b.size) { val r = ins.read(b, n, b.size - n); if (r < 0) break; n += r }
                            String(b, 0, n, Charsets.US_ASCII)
                        }.trim()
                        if (txt == "application/epub+zip") hasContainer = true
                    }
                }
                return when {
                    hasContainer -> Detection.Found(BookFormat.EPUB)
                    hasDocx -> Detection.Found(BookFormat.DOCX)
                    hasOtherOffice -> Detection.Unknown
                    images > 0 -> Detection.Found(BookFormat.CBZ)
                    else -> Detection.Unknown
                }
            }
        } catch (_: ZipException) {
            return Detection.Damaged(damagedAs)
        } catch (_: IOException) {
            return Detection.Damaged(damagedAs)
        }
    }

    /** macOS resource forks, thumbnails and hidden files that archives often carry next to the real pages. */
    fun isJunkEntry(name: String): Boolean {
        val n = name.replace('\\', '/')
        if (n.startsWith("__MACOSX/") || n.contains("/__MACOSX/")) return true
        val base = n.substringAfterLast('/')
        return base.startsWith(".") || base.startsWith("._") || base.equals("Thumbs.db", ignoreCase = true)
    }

    // ---- plain text ----

    /** True when [sample] (first [len] bytes) is plausibly text: BOM, valid UTF-16 pattern, or few control bytes. */
    fun looksLikeText(sample: ByteArray, len: Int): Boolean {
        if (len == 0) return false
        if (len >= 3 && sample[0] == 0xEF.toByte() && sample[1] == 0xBB.toByte() && sample[2] == 0xBF.toByte()) return true
        if (len >= 2 && (sample[0] == 0xFF.toByte() && sample[1] == 0xFE.toByte() || sample[0] == 0xFE.toByte() && sample[1] == 0xFF.toByte())) return true
        var nulEven = 0
        var nulOdd = 0
        var control = 0
        for (i in 0 until len) {
            val b = sample[i].toInt() and 0xFF
            if (b == 0) { if (i % 2 == 0) nulEven++ else nulOdd++ }
            else if (b < 0x20 && b != 0x09 && b != 0x0A && b != 0x0D && b != 0x0C && b != 0x1B) control++
        }
        val nul = nulEven + nulOdd
        if (nul > 0) {
            // UTF-16 without BOM: NULs sit (almost) only on one parity.
            val pairs = len / 2
            if (pairs < 4) return false
            val hi = maxOf(nulEven, nulOdd)
            val lo = minOf(nulEven, nulOdd)
            return hi >= pairs / 5 && lo <= hi / 20 && control == 0
        }
        return control * 100 <= len // at most 1 % odd control bytes
    }
}
