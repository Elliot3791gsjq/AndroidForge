package com.novelreader.app.reader

import com.novelreader.app.R
import com.novelreader.app.data.AutoScrollMode
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import org.json.JSONTokener
import org.readium.r2.navigator.epub.EpubNavigatorFragment

/**
 * Runs the automatic reading modes against the real navigator:
 *  - Scroll by Pixel: a requestAnimationFrame loop inside the page scrolls it smoothly (needs scroll mode).
 *  - Scroll by Line: scrolls one real text line (computed from the page's CSS) per tick (needs scroll mode).
 *  - Scroll by Page: turns the page on a timer (any mode).
 *  - Rolling Blind (pixel / line): a reveal line, drawn by the app over the page, moves down; at the bottom the
 *    next page is opened.
 *  - Speed Read (RSVP): shows the words of the current chapter one at a time.
 * [run] suspends until cancelled or the book ends; the caller restarts it when mode/speed changes.
 */
class AutoReader(
    private val vm: ReaderViewModel,
    private val nav: () -> EpubNavigatorFragment?,
    private val density: () -> Float,
    private val viewportHeightPx: () -> Int,
) {
    // Speed Read keeps its place across restarts (e.g. when the speed slider moves) while in the same chapter.
    private var rsvpHref: String? = null
    private var rsvpWords: List<String> = emptyList()
    private var rsvpIndex = 0

    suspend fun run(mode: AutoScrollMode, speedPct: Int) {
        val n = nav() ?: return
        try {
            when (mode) {
                AutoScrollMode.SCROLL_PIXEL -> pixelScroll(n, speedPct)
                AutoScrollMode.SCROLL_LINE -> lineScroll(n, speedPct)
                AutoScrollMode.SCROLL_PAGE -> pageLoop(n, speedPct)
                AutoScrollMode.ROLLING_BLIND_PIXEL -> blind(n, speedPct, byLine = false)
                AutoScrollMode.ROLLING_BLIND_LINE -> blind(n, speedPct, byLine = true)
                AutoScrollMode.SPEED_READ -> speedRead(n, speedPct)
            }
        } finally {
            withContext(NonCancellable) { runCatching { n.evaluateJavascript(STOP_JS) } }
        }
    }

    private fun finish() {
        vm.stopAuto()
        vm.postMessage(R.string.auto_end_of_book)
    }

    private suspend fun evalBool(n: EpubNavigatorFragment, js: String): Boolean =
        runCatching { n.evaluateJavascript(js) }.getOrNull()?.trim() == "true"

    private suspend fun evalDouble(n: EpubNavigatorFragment, js: String): Double? =
        runCatching { n.evaluateJavascript(js) }.getOrNull()?.trim()?.toDoubleOrNull()

    // ---- Scroll by Pixel -------------------------------------------------------------------------------

    private suspend fun pixelScroll(n: EpubNavigatorFragment, pct: Int) {
        val pxPerSec = BASE_PX_PER_SEC * pct / 100.0
        while (currentCoroutineContext().isActive) {
            runCatching { n.evaluateJavascript(startJs(pxPerSec)) }
            delay(450)
            if (evalBool(n, "window.__nr ? window.__nr.atEnd() : false")) {
                runCatching { n.evaluateJavascript(STOP_JS) }
                if (!n.goForward(animated = false)) { finish(); return }
                delay(900)
            }
        }
    }

    // ---- Scroll by Line --------------------------------------------------------------------------------

    private suspend fun lineScroll(n: EpubNavigatorFragment, pct: Int) {
        val period = (BASE_LINE_MS * 100L / pct.coerceAtLeast(1)).coerceAtLeast(120L)
        while (currentCoroutineContext().isActive) {
            delay(period)
            val atEnd = evalBool(n, LINE_STEP_JS)
            if (atEnd) {
                if (!n.goForward(animated = false)) { finish(); return }
                delay(700)
            }
        }
    }

    // ---- Scroll by Page --------------------------------------------------------------------------------

    private suspend fun pageLoop(n: EpubNavigatorFragment, pct: Int) {
        val period = (BASE_PAGE_MS * 100L / pct.coerceAtLeast(1)).coerceAtLeast(800L)
        while (currentCoroutineContext().isActive) {
            delay(period)
            if (!n.goForward(animated = false)) { finish(); return }
        }
    }

    // ---- Rolling Blind ---------------------------------------------------------------------------------

    private suspend fun blind(n: EpubNavigatorFragment, pct: Int, byLine: Boolean) {
        val height = viewportHeightPx().toFloat().coerceAtLeast(1f)
        var y = 0f
        vm.setBlind(0f)
        if (byLine) {
            // One real text line per step; the line height comes from the page's own CSS (CSS px = dp).
            val lineDp = evalDouble(n, LINE_HEIGHT_JS) ?: 28.0
            val linePx = (lineDp * density()).toFloat().coerceAtLeast(8f)
            val period = (BASE_LINE_MS * 100L / pct.coerceAtLeast(1)).coerceAtLeast(120L)
            while (currentCoroutineContext().isActive) {
                delay(period)
                y += linePx
                if (y >= height) {
                    if (!n.goForward(animated = false)) { finish(); return }
                    y = 0f; delay(500)
                }
                vm.setBlind((y / height).coerceIn(0f, 1f))
            }
        } else {
            val pxPerSec = (BASE_PX_PER_SEC * density() * pct / 100.0).toFloat()
            var last = System.nanoTime()
            while (currentCoroutineContext().isActive) {
                delay(16)
                val now = System.nanoTime()
                y += pxPerSec * (now - last) / 1_000_000_000f
                last = now
                if (y >= height) {
                    if (!n.goForward(animated = false)) { finish(); return }
                    y = 0f; delay(500); last = System.nanoTime()
                }
                vm.setBlind((y / height).coerceIn(0f, 1f))
            }
        }
    }

    // ---- Speed Read (RSVP) -----------------------------------------------------------------------------

    private suspend fun speedRead(n: EpubNavigatorFragment, pct: Int) {
        val wpm = (RSVP_BASE_WPM * pct / 100.0).coerceIn(60.0, 1500.0)
        val baseMs = 60_000.0 / wpm
        while (currentCoroutineContext().isActive) {
            val locator = n.currentLocator.value
            val href = locator.href.toString()
            if (rsvpHref != href || rsvpWords.isEmpty()) {
                val text = pageText(n)
                rsvpWords = text.split(WHITESPACE).filter { it.isNotBlank() }
                rsvpHref = href
                rsvpIndex = ((locator.locations.progression ?: 0.0) * rsvpWords.size).toInt().coerceIn(0, (rsvpWords.size - 1).coerceAtLeast(0))
                if (rsvpWords.isEmpty()) {
                    vm.postMessage(R.string.rsvp_no_text)
                    val next = vm.nextResourceLink(href)
                    if (next == null) { finish(); return }
                    n.go(next, animated = false); delay(1200); continue
                }
            }
            while (rsvpIndex < rsvpWords.size && currentCoroutineContext().isActive) {
                if (vm.rsvpPaused.value) {
                    vm.setRsvp(RsvpDisplay(rsvpWords[rsvpIndex], rsvpIndex, rsvpWords.size, paused = true))
                    delay(120); continue
                }
                val w = rsvpWords[rsvpIndex]
                vm.setRsvp(RsvpDisplay(w, rsvpIndex, rsvpWords.size))
                var factor = 1.0
                if (w.endsWith('.') || w.endsWith('!') || w.endsWith('?') || w.endsWith('؟') || w.endsWith('…')) factor = 1.7
                else if (w.endsWith(',') || w.endsWith(';') || w.endsWith('،') || w.endsWith('؛') || w.endsWith(':')) factor = 1.3
                if (w.length > 10) factor *= 1.2
                delay((baseMs * factor).toLong().coerceAtLeast(30))
                rsvpIndex++
            }
            if (!currentCoroutineContext().isActive) return
            val next = vm.nextResourceLink(href)
            if (next == null) { finish(); return }
            rsvpWords = emptyList(); rsvpHref = null
            n.go(next, animated = false)
            delay(1200)
        }
    }

    private suspend fun pageText(n: EpubNavigatorFragment): String {
        val raw = runCatching { n.evaluateJavascript("document.body ? document.body.innerText : ''") }.getOrNull() ?: return ""
        return try { JSONTokener(raw).nextValue() as? String ?: "" } catch (_: Exception) { "" }
    }

    companion object {
        private val WHITESPACE = Regex("\\s+")
        /** Speeds at 100 %: ~40 px/s, one line per 2 s, one page per 40 s, 300 words/min. */
        const val BASE_PX_PER_SEC = 40.0
        const val BASE_LINE_MS = 2_000L
        const val BASE_PAGE_MS = 40_000L
        const val RSVP_BASE_WPM = 300.0

        private const val STOP_JS = "if (window.__nr) { window.__nr.stop(); } true"

        private const val LINE_HEIGHT_JS = """(function(){var cs=getComputedStyle(document.body);var lh=parseFloat(cs.lineHeight);if(!lh||isNaN(lh)){lh=(parseFloat(cs.fontSize)||16)*1.5;}return Math.round(lh);})()"""

        private const val LINE_STEP_JS = """(function(){var cs=getComputedStyle(document.body);var lh=parseFloat(cs.lineHeight);if(!lh||isNaN(lh)){lh=(parseFloat(cs.fontSize)||16)*1.5;}window.scrollBy({top:lh,behavior:'smooth'});return Math.ceil(window.scrollY+window.innerHeight)>=document.documentElement.scrollHeight-2;})()"""

        fun startJs(pxPerSec: Double): String = """
            (function(v){
              var w = window;
              if (!w.__nr) {
                w.__nr = { v: 0, l: 0, run: false, rem: 0 };
                w.__nr.atEnd = function () { return Math.ceil(w.scrollY + w.innerHeight) >= document.documentElement.scrollHeight - 2; };
                var step = function (ts) {
                  var s = w.__nr;
                  if (!s.run) { s.l = 0; return; }
                  if (s.l) {
                    s.rem += (ts - s.l) / 1000 * s.v;
                    var d = Math.floor(s.rem);
                    if (d >= 1) { w.scrollBy(0, d); s.rem -= d; }
                  }
                  s.l = ts;
                  requestAnimationFrame(step);
                };
                w.__nr.start = function (speed) {
                  var s = w.__nr; s.v = speed;
                  if (!s.run) { s.run = true; s.l = 0; requestAnimationFrame(step); }
                };
                w.__nr.stop = function () { w.__nr.run = false; };
              }
              w.__nr.start(v);
              return true;
            })($pxPerSec)
        """.trimIndent()
    }
}
