package com.novelreader.app.ui.library

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.novelreader.app.ui.design.AppShapes
import java.io.File

/**
 * A book cover with depth: the real cover image when the EPUB has one, otherwise a generated gradient with the
 * title (the UI never depends on a cover existing). The shadow gives it the "floating" look.
 */
@Composable
fun BookCover(
    title: String,
    file: File?,
    modifier: Modifier = Modifier,
    shape: Shape = AppShapes.cover,
    elevation: Dp = 10.dp,
) {
    Box(
        modifier
            .shadow(elevation, shape, ambientColor = Color.Black, spotColor = Color.Black)
            .clip(shape)
            .background(placeholderBrush(title)),
        contentAlignment = Alignment.Center,
    ) {
        if (file != null) {
            AsyncImage(model = file, contentDescription = title, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        } else {
            Box(Modifier.fillMaxSize().padding(14.dp), contentAlignment = Alignment.BottomStart) {
                Box(
                    Modifier
                        .align(Alignment.Center)
                        .fillMaxSize(0.55f)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.13f))
                )
                Text(
                    title.trim(),
                    style = MaterialTheme.typography.titleSmall,
                    color = Color.White,
                    maxLines = 4,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Start,
                )
            }
        }
    }
}

private fun placeholderBrush(seed: String): Brush {
    val h = ((seed.hashCode().toLong() and 0x7fffffff) % 360).toFloat()
    return Brush.linearGradient(listOf(Color.hsv(h, 0.55f, 0.62f), Color.hsv((h + 28f) % 360f, 0.7f, 0.26f)))
}

/** Small pill with the file type ("PDF", "CBZ"...) drawn over a cover corner; EPUB is the default and gets none. */
@Composable
fun FormatBadge(format: String, modifier: Modifier = Modifier) {
    if (format == "EPUB") return
    Box(
        modifier
            .clip(androidx.compose.foundation.shape.RoundedCornerShape(6.dp))
            .background(Color.Black.copy(alpha = 0.62f))
            .padding(horizontal = 6.dp, vertical = 2.dp),
    ) {
        Text(format, color = Color.White, style = MaterialTheme.typography.labelSmall)
    }
}

/** "PDF · 12.4 MB · 240 pages": what kind of file it is, how big, and its page count where it has one. */
@Composable
fun bookInfoLine(book: com.novelreader.app.data.BookEntity): String {
    val pages = book.pageCount?.let { androidx.compose.ui.res.stringResource(com.novelreader.app.R.string.fmt_pages_count, com.novelreader.app.ui.Localized.number(it)) }
    return androidx.compose.runtime.remember(book.format, book.sizeBytes, book.pageCount, pages) {
        listOfNotNull(book.format, com.novelreader.app.core.FileScan.formatSize(book.sizeBytes), pages).joinToString(" · ")
    }
}
