package com.novelreader.app.formats.pdf

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.novelreader.app.data.AnnotationStyle
import com.novelreader.app.data.HighlightEntity
import com.novelreader.app.formats.FormatLocator
import com.novelreader.app.formats.FormatReaderViewModel
import com.novelreader.app.formats.PdfHighlightRects
import com.novelreader.app.formats.PdfSettings
import com.novelreader.app.formats.PdfSettingsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException

enum class PdfFailure { MISSING, ENCRYPTED, CORRUPT }

sealed interface PdfLoad {
    data object Loading : PdfLoad
    data class Failed(val reason: PdfFailure) : PdfLoad
    data class Ready(val title: String, val pageCount: Int) : PdfLoad
}

/** "Show this place": [y] is the fraction of the page height that should sit near the top of the screen. */
data class PdfJump(val page: Int, val y: Float = 0f)

/** One search match: the rectangles it covers on [page] (page space, points). */
class PdfHit(val page: Int, val rects: List<FloatArray>)

/** A saved highlight / underline / note, parsed for drawing. */
class PdfHighlightItem(val entity: HighlightEntity, val page: Int, val rects: List<FloatArray>)

/** State of the PDF reader: the open document, caches, position, rotation, search, selection and annotations. */
class PdfReaderViewModel(app: Application, bookId: Long, private val startLocator: String?) : FormatReaderViewModel(app, bookId) {

    private val _load = MutableStateFlow<PdfLoad>(PdfLoad.Loading)
    val load: StateFlow<PdfLoad> = _load.asStateFlow()

    private val _settings = MutableStateFlow<PdfSettings?>(null)
    val settings: StateFlow<PdfSettings?> = _settings.asStateFlow()
    private var settingsRepo: PdfSettingsRepository? = null

    var engine: PdfEngine? = null
        private set
    var cache: PdfBitmapCache? = null
        private set
    var thumbs: PdfBitmapCache? = null
        private set

    private val _pageCount = MutableStateFlow(0)
    val pageCount: StateFlow<Int> = _pageCount.asStateFlow()

    private val _page = MutableStateFlow(0)
    /** Zero-based page at the top of the screen. */
    val page: StateFlow<Int> = _page.asStateFlow()
    private var yFrac = 0f

    private val _rotation = MutableStateFlow(0)
    /** View rotation in degrees (0/90/180/270), remembered per book. */
    val rotation: StateFlow<Int> = _rotation.asStateFlow()

    private val _sizes = MutableStateFlow(0)
    /** Ticks whenever more page sizes are known. */
    val sizes: StateFlow<Int> = _sizes.asStateFlow()

    private val _commands = MutableSharedFlow<PdfJump>(extraBufferCapacity = 4)
    val commands: SharedFlow<PdfJump> = _commands.asSharedFlow()

    /** Where the reader starts (restored position). */
    var startJump: PdfJump = PdfJump(0, 0f)
        private set

    val textSupported: Boolean get() = engine?.textSupported == true

    init {
        viewModelScope.launch { open() }
    }

    private suspend fun open() {
        val b = graph.library.get(bookId)
        if (b == null) { _load.value = PdfLoad.Failed(PdfFailure.MISSING); return }
        val file = graph.library.bookFile(b)
        if (!file.isFile) { _load.value = PdfLoad.Failed(PdfFailure.MISSING); return }
        val repo = graph.formatSettings.pdf()
        settingsRepo = repo
        viewModelScope.launch { repo.flow.collect { _settings.value = it } }

        val result: Any = withContext(Dispatchers.IO) {
            try {
                PdfEngine.open(file)
            } catch (e: SecurityException) {
                PdfFailure.ENCRYPTED
            } catch (e: IOException) {
                PdfFailure.CORRUPT
            } catch (e: Exception) {
                PdfFailure.CORRUPT
            }
        }
        val opened = result as? PdfEngine
        if (opened == null) { _load.value = PdfLoad.Failed(result as PdfFailure); return }
        engine = opened
        val budget = (Runtime.getRuntime().maxMemory() / 6).toInt().coerceIn(24 shl 20, 96 shl 20)
        cache = PdfBitmapCache(opened, budget)
        thumbs = PdfBitmapCache(opened, 12 shl 20)
        _pageCount.value = opened.pageCount

        val loc = startLocator ?: b.lastLocatorJson
        val pdf = FormatLocator.parse(loc) as? FormatLocator.Pdf
        if (pdf != null) {
            _rotation.value = pdf.rotation
            startJump = PdfJump(pdf.page.coerceIn(0, opened.pageCount - 1), pdf.y.toFloat())
        } else {
            // A jump target that is not a reading position: a highlight (note list) opens at its page.
            PdfHighlightRects.parse(loc)?.let { hl ->
                val page = hl.page.coerceIn(0, opened.pageCount - 1)
                val h = opened.sizeOrGuess(page).h
                val top = hl.rects.minOfOrNull { it[1] } ?: 0f
                startJump = PdfJump(page, ((top - 40f) / h).coerceIn(0f, 1f))
            }
        }
        _page.value = startJump.page
        yFrac = startJump.y
        _load.value = PdfLoad.Ready(b.title, opened.pageCount)

        viewModelScope.launch { opened.sizeVersion.collect { _sizes.value = it } }
        viewModelScope.launch(Dispatchers.Default) { opened.scanSizes() }
    }

    fun updateSettings(transform: (PdfSettings) -> PdfSettings) {
        val repo = settingsRepo ?: return
        viewModelScope.launch { repo.update(transform) }
    }

    // ---- position ----

    /** The reader reports the page at the top of the screen and how far into it the top edge is. */
    fun onViewport(page: Int, y: Float) {
        val n = _pageCount.value
        if (n <= 0) return
        val p = page.coerceIn(0, n - 1)
        _page.value = p
        yFrac = y.coerceIn(0f, 1f)
        reportPosition(PdfGeometry.progress(p, n), FormatLocator.Pdf(p, yFrac.toDouble(), _rotation.value).toJson())
    }

    fun goTo(page: Int, y: Float = 0f) {
        val n = _pageCount.value
        if (n <= 0) return
        _commands.tryEmit(PdfJump(page.coerceIn(0, n - 1), y.coerceIn(0f, 1f)))
    }

    fun rotateBy(delta: Int) {
        _rotation.value = PdfGeometry.normalizeRotation(_rotation.value + delta)
        val n = _pageCount.value
        if (n > 0) reportPosition(PdfGeometry.progress(_page.value, n), FormatLocator.Pdf(_page.value, yFrac.toDouble(), _rotation.value).toJson())
        goTo(_page.value, yFrac)
    }

    fun addBookmarkHere(label: String) {
        val p = _page.value
        addBookmark(FormatLocator.Pdf(p, yFrac.toDouble(), _rotation.value).toJson(), null, label, PdfGeometry.progress(p, _pageCount.value))
    }

    // ---- search (Android 15+) ----

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()
    private val _hits = MutableStateFlow<List<PdfHit>>(emptyList())
    val hits: StateFlow<List<PdfHit>> = _hits.asStateFlow()
    private val _activeHit = MutableStateFlow(-1)
    /** Index into [hits] of the match being shown, -1 for none. */
    val activeHit: StateFlow<Int> = _activeHit.asStateFlow()
    private val _searchProgress = MutableStateFlow(1f)
    /** 0..1 while searching, 1 when finished (or idle). */
    val searchProgress: StateFlow<Float> = _searchProgress.asStateFlow()
    private var searchJob: Job? = null

    fun search(text: String) {
        searchJob?.cancel()
        val q = text.trim()
        _query.value = q
        _hits.value = emptyList()
        _activeHit.value = -1
        val e = engine ?: return
        if (q.isEmpty() || !e.textSupported) { _searchProgress.value = 1f; return }
        _searchProgress.value = 0f
        val from = _page.value
        searchJob = viewModelScope.launch {
            val found = ArrayList<PdfHit>()
            val n = e.pageCount
            for (p in 0 until n) {
                val matches = e.search(p, q)
                if (matches.isNotEmpty()) {
                    matches.forEach { rects -> if (found.size < MAX_HITS) found += PdfHit(p, rects) }
                    _hits.value = ArrayList(found)
                    if (_activeHit.value < 0 && p >= from) { _activeHit.value = found.indexOfFirst { it.page >= from }; showHit(_activeHit.value) }
                }
                if (found.size >= MAX_HITS) break
                if (p % 8 == 7) _searchProgress.value = (p + 1f) / n
            }
            _searchProgress.value = 1f
            if (_activeHit.value < 0 && found.isNotEmpty()) { _activeHit.value = 0; showHit(0) }
        }
    }

    fun clearSearch() {
        searchJob?.cancel()
        _query.value = ""
        _hits.value = emptyList()
        _activeHit.value = -1
        _searchProgress.value = 1f
    }

    fun stepHit(delta: Int) {
        val n = _hits.value.size
        if (n == 0) return
        val i = ((_activeHit.value.coerceAtLeast(0) + delta) % n + n) % n
        _activeHit.value = i
        showHit(i)
    }

    fun openHit(i: Int) {
        if (i !in _hits.value.indices) return
        _activeHit.value = i
        showHit(i)
    }

    private fun showHit(i: Int) {
        val hit = _hits.value.getOrNull(i) ?: return
        _commands.tryEmit(PdfJump(hit.page, yOf(hit.page, hit.rects)))
    }

    /** Fraction of the displayed page above the top of [rects] (a little context is kept above the match). */
    private fun yOf(page: Int, rects: List<FloatArray>): Float {
        val e = engine ?: return 0f
        val s = e.sizeOrGuess(page)
        val rot = _rotation.value
        val top = rects.minOfOrNull { PdfGeometry.rectToDisplay(it[0], it[1], it[2], it[3], s.w, s.h, rot)[1] } ?: return 0f
        val disp = PdfGeometry.displaySize(s.w, s.h, rot)
        return ((top - 60f) / disp.h).coerceIn(0f, 1f)
    }

    // ---- selection (Android 15+) ----

    private val _selection = MutableStateFlow<PdfTextSelection?>(null)
    val selection: StateFlow<PdfTextSelection?> = _selection.asStateFlow()
    private var selStart: FloatArray? = null    // page-space points of the two selection ends
    private var selEnd: FloatArray? = null
    private var selJob: Job? = null

    /** Long press: selects the word at the page-space point. */
    fun selectWordAt(page: Int, x: Float, y: Float) {
        val e = engine ?: return
        if (!e.textSupported) return
        selJob?.cancel()
        selJob = viewModelScope.launch {
            val sel = e.selectText(page, x, y, x, y)
            if (sel == null) { clearSelection(); return@launch }
            setSelection(sel)
        }
    }

    private fun setSelection(sel: PdfTextSelection) {
        val first = sel.rects.firstOrNull()
        val last = sel.rects.lastOrNull()
        if (first != null && last != null) {
            selStart = floatArrayOf(first[0] + 1f, (first[1] + first[3]) / 2f)
            selEnd = floatArrayOf(last[2] - 1f, (last[1] + last[3]) / 2f)
        }
        _selection.value = sel
    }

    /** A handle was dragged to a page-space point; [startHandle] says which end moved. */
    fun moveSelectionHandle(startHandle: Boolean, x: Float, y: Float) {
        val cur = _selection.value ?: return
        val e = engine ?: return
        if (startHandle) selStart = floatArrayOf(x, y) else selEnd = floatArrayOf(x, y)
        val a = selStart ?: return
        val b = selEnd ?: return
        val forward = a[1] < b[1] || (a[1] == b[1] && a[0] <= b[0])
        val s = if (forward) a else b
        val t = if (forward) b else a
        selJob?.cancel()
        selJob = viewModelScope.launch {
            val sel = e.selectText(cur.page, s[0], s[1], t[0], t[1]) ?: return@launch
            _selection.value = sel
        }
    }

    fun clearSelection() {
        selJob?.cancel()
        _selection.value = null
        selStart = null
        selEnd = null
    }

    /** Where the two selection handles are, in page space, once a selection exists. */
    fun selectionEnds(): Pair<FloatArray, FloatArray>? {
        val sel = _selection.value ?: return null
        val first = sel.rects.firstOrNull() ?: return null
        val last = sel.rects.lastOrNull() ?: return null
        return floatArrayOf(first[0], first[3]) to floatArrayOf(last[2], last[3])
    }

    // ---- highlights, underlines, notes ----

    val highlights: StateFlow<List<PdfHighlightItem>> = graph.annotations.highlights(bookId)
        .map { list -> list.mapNotNull { h -> PdfHighlightRects.parse(h.locatorJson)?.let { PdfHighlightItem(h, it.page, it.rects) } } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    fun annotateSelection(style: AnnotationStyle, color: Int, note: String?, pageLabel: String) {
        val sel = _selection.value ?: return
        val json = PdfHighlightRects(sel.page, sel.rects).toJson()
        viewModelScope.launch {
            graph.annotations.addHighlight(bookId, json, sel.text, color, pageLabel, style, note)
        }
        clearSelection()
    }

    fun updateHighlight(h: HighlightEntity) { viewModelScope.launch { graph.annotations.updateHighlight(h) } }
    fun deleteHighlight(id: Long) { viewModelScope.launch { graph.annotations.deleteHighlight(id) } }

    suspend fun thumb(page: Int): android.graphics.Bitmap? = thumbs?.get(page, 0, THUMB_WIDTH)

    override fun onCleared() {
        super.onCleared()
        searchJob?.cancel()
        cache?.clear()
        thumbs?.clear()
        engine?.close()
    }

    companion object {
        const val THUMB_WIDTH = 200
        private const val MAX_HITS = 2000

        fun factory(app: Application, bookId: Long, startLocator: String?) = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T = PdfReaderViewModel(app, bookId, startLocator) as T
        }
    }
}
