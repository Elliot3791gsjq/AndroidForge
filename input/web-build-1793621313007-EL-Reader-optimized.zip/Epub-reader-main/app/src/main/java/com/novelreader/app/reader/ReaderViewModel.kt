package com.novelreader.app.reader

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.novelreader.app.R
import com.novelreader.app.core.ReadingMath
import com.novelreader.app.data.BgImageResult
import com.novelreader.app.data.BgImageMode
import com.novelreader.app.data.BookmarkEntity
import com.novelreader.app.data.CustomFont
import com.novelreader.app.data.FontImportError
import com.novelreader.app.data.FontImportResult
import com.novelreader.app.data.HighlightEntity
import com.novelreader.app.data.HistoryEntity
import com.novelreader.app.data.AnnotationStyle
import com.novelreader.app.data.AutoScrollMode
import com.novelreader.app.data.PageFlipMode
import com.novelreader.app.data.ReaderSettings
import com.novelreader.app.data.isVerticalScrolling
import com.novelreader.app.data.withFlipMode
import com.novelreader.app.graph
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import android.net.Uri
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.distinctUntilChanged
import org.json.JSONObject
import org.readium.r2.shared.publication.Link
import org.readium.r2.shared.publication.Locator
import org.readium.r2.shared.publication.Publication
import org.readium.r2.shared.publication.services.positions
import org.readium.r2.shared.publication.services.search.search
import org.readium.r2.shared.util.getOrElse

/**
 * Owns everything about one open book except the navigator fragment itself (which lives in the activity):
 * the Readium [Publication], table of contents, positions, progress, search, annotations and persistence.
 */
@OptIn(FlowPreview::class)
class ReaderViewModel(app: Application, private val bookId: Long, private val startLocatorJson: String? = null) : AndroidViewModel(app) {

    private val graph = app.graph

    private val _load = MutableStateFlow<ReaderLoad>(ReaderLoad.Loading)
    val load: StateFlow<ReaderLoad> = _load.asStateFlow()

    val settings: StateFlow<ReaderSettings> = graph.settings.readerSettings
        .stateIn(viewModelScope, SharingStarted.Eagerly, ReaderSettings())

    // ---- Imported fonts ----
    /** Live registry (changes immediately on import/delete). */
    val customFonts: StateFlow<List<CustomFont>> = graph.fonts.fonts
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    private val fontIdsAtOpen = MutableStateFlow<Set<String>>(emptySet())

    /** Imported fonts that exist now AND were declared when this publication was opened. */
    val availableFontIds: StateFlow<Set<String>> = combine(customFonts, fontIdsAtOpen) { live, atOpen ->
        live.map { it.id }.toSet().intersect(atOpen)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())

    private val _events = MutableSharedFlow<ReaderEvent>(extraBufferCapacity = 8)
    val events: SharedFlow<ReaderEvent> = _events.asSharedFlow()

    // ---- Table of contents / positions ----
    private val _toc = MutableStateFlow<List<TocItem>>(emptyList())
    val toc: StateFlow<List<TocItem>> = _toc.asStateFlow()
    private var flatToc: List<TocItem> = emptyList()
    private var tocStartIndex: IntArray = IntArray(0)

    /** Sorted position indices where a chapter begins (TOC entries, or reading-order documents when there is no TOC). */
    private var chapterStarts: IntArray = IntArray(0)

    private var positions: List<Locator> = emptyList()
    private val _chapterMarkers = MutableStateFlow<List<Double>>(emptyList())
    val chapterMarkers: StateFlow<List<Double>> = _chapterMarkers.asStateFlow()

    // ---- Live reading info ----
    private val _info = MutableStateFlow(ReaderInfo())
    val info: StateFlow<ReaderInfo> = _info.asStateFlow()
    private var latestLocator: Locator? = null
    private val saveTrigger = MutableSharedFlow<Locator>(extraBufferCapacity = 1)
    private var lastHistoryChapter: String? = null

    // ---- Chrome / dialogs / commands ----
    private val _chromeVisible = MutableStateFlow(true)
    val chromeVisible: StateFlow<Boolean> = _chromeVisible.asStateFlow()

    private val _settingsOpen = MutableStateFlow(false)
    val settingsOpen: StateFlow<Boolean> = _settingsOpen.asStateFlow()

    private val _tab = MutableStateFlow(ReaderTab.TEXT)
    val tab: StateFlow<ReaderTab> = _tab.asStateFlow()

    private val _dialog = MutableStateFlow<ReaderDialog?>(null)
    val dialog: StateFlow<ReaderDialog?> = _dialog.asStateFlow()

    private val _commands = MutableSharedFlow<ReaderCommand>(extraBufferCapacity = 8)
    val commands: SharedFlow<ReaderCommand> = _commands.asSharedFlow()

    // ---- Annotations ----
    val highlights: StateFlow<List<HighlightEntity>> = graph.annotations.highlights(bookId)
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val bookmarks: StateFlow<List<BookmarkEntity>> = graph.annotations.bookmarks(bookId)
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val history: StateFlow<List<HistoryEntity>> = graph.annotations.history(bookId)
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val _inLibrary = MutableStateFlow(true)
    val inLibrary: StateFlow<Boolean> = _inLibrary.asStateFlow()

    // ---- Auto scroll / speed read ----
    private val _autoRunning = MutableStateFlow(false)
    val autoRunning: StateFlow<Boolean> = _autoRunning.asStateFlow()
    private val _rsvp = MutableStateFlow(RsvpDisplay())
    val rsvp: StateFlow<RsvpDisplay> = _rsvp.asStateFlow()
    /** Position (0..1 of the screen height) of the Rolling Blind line. */
    private val _blind = MutableStateFlow(0f)
    val blind: StateFlow<Float> = _blind.asStateFlow()
    private val _rsvpPaused = MutableStateFlow(false)
    val rsvpPaused: StateFlow<Boolean> = _rsvpPaused.asStateFlow()

    // ---- Book information ----
    private val _bookInfo = MutableStateFlow<BookInfoData?>(null)
    val bookInfo: StateFlow<BookInfoData?> = _bookInfo.asStateFlow()
    private var sessionStartedAt = 0L
    /** Whole-book progression when the current sitting began; -1 until the navigator has reported a position. */
    private var sessionStartProgress = -1.0

    // ---- Search ----
    private val _search = MutableStateFlow(SearchState())
    val search: StateFlow<SearchState> = _search.asStateFlow()
    private var searchJob: Job? = null

    init {
        viewModelScope.launch { open() }
        viewModelScope.launch {
            saveTrigger.debounce(1_500).collect { persist(it) }
        }
    }

    // =====================================================================================
    // Opening
    // =====================================================================================

    private suspend fun open() {
        val book = graph.library.get(bookId)
        if (book == null) {
            _load.value = ReaderLoad.Failed(ReaderFailure.BOOK_NOT_FOUND, null); return
        }
        _inLibrary.value = book.inLibrary
        val file = graph.library.bookFile(book)
        if (!file.exists()) {
            _load.value = ReaderLoad.Failed(ReaderFailure.FILE_MISSING, null); return
        }
        val fonts = graph.settings.currentCustomFonts()
        // Only the fonts the user selected are declared in the page CSS (any number can be imported).
        val chosen = graph.settings.readerSettings.first().let { setOfNotNull(it.faFontId, it.latinFontId) }
            .intersect(fonts.map { it.id }.toSet())
        when (val r = graph.engine.open(file, fonts, graph.fonts.directory, chosen)) {
            is EngineResult.Failed -> _load.value = ReaderLoad.Failed(
                when (r.reason) {
                    EpubFailure.NOT_EPUB -> ReaderFailure.NOT_EPUB
                    EpubFailure.ENCRYPTED -> ReaderFailure.ENCRYPTED
                    EpubFailure.CORRUPT -> ReaderFailure.CORRUPT
                    EpubFailure.UNSUPPORTED -> ReaderFailure.UNSUPPORTED
                },
                r.detail,
            )
            is EngineResult.Ok -> {
                val pub = r.value
                buildToc(pub)
                // Positions power the progress bar; computed once, off the UI path (suspend).
                positions = try { pub.positions() } catch (t: Throwable) {
                    if (t is kotlinx.coroutines.CancellationException) throw t
                    emptyList()
                }
                computeChapterMarkers()
                val initial = (startLocatorJson ?: book.lastLocatorJson)?.let { json ->
                    try { Locator.fromJSON(JSONObject(json)) } catch (_: Throwable) { null }
                }
                initial?.let { onLocatorChanged(it, persist = false) }
                graph.library.touch(bookId) // keeps "last read" ordering right even before the first page turn
                fontIdsAtOpen.value = chosen
                _load.value = ReaderLoad.Ready(book, pub, initial, chosen)
                watchFontSelection()
            }
        }
    }

    private fun buildToc(pub: Publication) {
        val untitled = getApplication<Application>().getString(R.string.untitled_chapter)
        fun map(links: List<Link>, depth: Int): List<TocItem> = links.map { l ->
            TocItem(
                title = l.title?.takeIf { it.isNotBlank() } ?: untitled,
                href = ReadingMath.stripFragment(l.url().toString()),
                link = l,
                depth = depth,
                children = map(l.children, depth + 1),
            )
        }
        val tree = map(pub.tableOfContents, 0)
        _toc.value = tree
        val flat = ArrayList<TocItem>()
        fun walk(items: List<TocItem>) { items.forEach { flat += it; walk(it.children) } }
        walk(tree)
        flatToc = flat
    }

    private fun computeChapterMarkers() {
        val posHrefs = positions.map { ReadingMath.stripFragment(it.href.toString()) }
        val firstIndex = HashMap<String, Int>()
        posHrefs.forEachIndexed { i, h -> firstIndex.putIfAbsent(h, i) }
        tocStartIndex = IntArray(flatToc.size) { firstIndex[flatToc[it].href] ?: -1 }
        _chapterMarkers.value = ReadingMath.chapterMarkers(posHrefs, flatToc.map { it.href })
        val fromToc = tocStartIndex.filter { it >= 0 }.distinct().sorted()
        chapterStarts = (fromToc.ifEmpty { firstIndex.values.distinct().sorted() }).toIntArray()
    }

    // =====================================================================================
    // Position tracking
    // =====================================================================================

    /** Called by the activity for every navigator location change. */
    fun onLocatorChanged(locator: Locator, persist: Boolean = true) {
        latestLocator = locator
        val total = positions.size
        val pos = locator.locations.position
        val fraction = ReadingMath.clamp01(
            locator.locations.totalProgression
                ?: if (total > 0 && pos != null) (pos - 1).toDouble() / total else 0.0
        )
        val tocIdx = currentTocIndex(pos)
        val chapter = if (tocIdx >= 0) flatToc[tocIdx].title else locator.title?.takeIf { it.isNotBlank() }
        _info.value = ReaderInfo(
            position = ReadingMath.currentPosition(pos, total),
            totalPositions = total,
            percent = ReadingMath.percent(fraction),
            fraction = fraction,
            chapterTitle = chapter,
            currentTocIndex = tocIdx,
        )
        if (sessionStartedAt > 0L && sessionStartProgress < 0) sessionStartProgress = fraction
        if (persist) {
            saveTrigger.tryEmit(locator)
            if (chapter != null && chapter != lastHistoryChapter) {
                lastHistoryChapter = chapter
                viewModelScope.launch {
                    graph.annotations.addHistory(bookId, locator.toJSON().toString(), chapter, fraction)
                }
            }
        }
    }

    private fun currentTocIndex(position: Int?): Int {
        if (flatToc.isEmpty() || position == null) return -1
        val p = position - 1
        var best = -1
        var bestStart = -1
        for (i in flatToc.indices) {
            val s = tocStartIndex.getOrElse(i) { -1 }
            if (s in 0..p && s >= bestStart) { best = i; bestStart = s }
        }
        return best
    }

    /** Writes the newest position immediately (called when the reader goes to the background / closes). */
    fun flushPosition() {
        val l = latestLocator ?: return
        viewModelScope.launch { persist(l) }
    }

    /** One page or two is fixed when the navigator is created: save the position, then have the activity reopen. */
    fun reopenForLayout() {
        viewModelScope.launch {
            latestLocator?.let { persist(it) }
            _events.tryEmit(ReaderEvent.Reopen)
        }
    }

    private suspend fun persist(locator: Locator) {
        val fraction = ReadingMath.clamp01(locator.locations.totalProgression ?: _info.value.fraction)
        graph.annotations.savePosition(bookId, fraction, locator.toJSON().toString())
    }

    // =====================================================================================
    // Chrome, dialogs, navigation
    // =====================================================================================

    fun setChromeVisible(v: Boolean) { _chromeVisible.value = v }
    fun toggleChrome() { _chromeVisible.value = !_chromeVisible.value }
    fun setSettingsOpen(v: Boolean) { _settingsOpen.value = v }
    fun openTab(tab: ReaderTab) { _tab.value = tab }
    fun showDialog(d: ReaderDialog?) { _dialog.value = d }

    fun go(locator: Locator) { _commands.tryEmit(ReaderCommand.GoLocator(locator)) }
    fun go(link: Link) { _commands.tryEmit(ReaderCommand.GoLink(link)) }
    fun next() { _commands.tryEmit(ReaderCommand.Next) }
    fun previous() { _commands.tryEmit(ReaderCommand.Previous) }

    /** Jumps to the start of approximate page [index] (0-based) from the progress bar. */
    fun goToPositionIndex(index: Int) {
        positions.getOrNull(index)?.let { go(it) }
    }

    fun goToFraction(fraction: Double) {
        val idx = ReadingMath.indexFromFraction(fraction, positions.size)
        if (idx >= 0) goToPositionIndex(idx)
    }

    fun goToLocatorJson(json: String) {
        try { Locator.fromJSON(JSONObject(json))?.let { go(it) } } catch (_: Throwable) { /* ignore corrupt row */ }
    }

    /** 0-based index of the position shown now. */
    private fun currentPositionIndex(): Int =
        ((latestLocator?.locations?.position ?: _info.value.position) - 1).coerceAtLeast(0)

    /** "Next chapter" button: start of the next chapter. */
    fun nextChapter() {
        val target = chapterStarts.firstOrNull { it > currentPositionIndex() }
        if (target == null) _events.tryEmit(ReaderEvent.Message(R.string.last_chapter)) else goToPositionIndex(target)
    }

    /** "Previous chapter" button: start of the chapter before the current one (the book start from the first chapter). */
    fun previousChapter() {
        val p = currentPositionIndex()
        val currentStart = chapterStarts.lastOrNull { it <= p } ?: 0
        if (currentStart == 0 && p == 0) { _events.tryEmit(ReaderEvent.Message(R.string.first_chapter)); return }
        goToPositionIndex(chapterStarts.lastOrNull { it < currentStart } ?: 0)
    }

    // ---- Images of the book ----
    private val _images = MutableStateFlow<List<ImageItem>?>(null)

    /** null while the list is still being built. */
    val images: StateFlow<List<ImageItem>?> = _images.asStateFlow()
    private var imagesJob: Job? = null
    private val thumbCache = object : android.util.LruCache<Int, android.graphics.Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: Int, value: android.graphics.Bitmap): Int = value.byteCount
    }

    /** Builds the Images list once (reads the book's XHTML in the background). */
    fun loadImages() {
        val ready = _load.value as? ReaderLoad.Ready ?: return
        if (imagesJob != null) return
        imagesJob = viewModelScope.launch {
            val file = graph.library.bookFile(ready.book)
            val order = ready.publication.readingOrder
            val hrefs = order.map { ReadingMath.stripFragment(it.url().toString()) }
            val refs = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) {
                com.novelreader.app.core.EpubImages.scan(file, hrefs)
            }
            val firstIndex = HashMap<String, Int>()
            positions.forEachIndexed { i, l ->
                firstIndex.putIfAbsent(com.novelreader.app.core.EpubImages.decode(ReadingMath.stripFragment(l.href.toString())), i)
            }
            _images.value = refs.map { r ->
                val chapterIdx = firstIndex[r.resourceHref]?.let { currentTocIndex(it + 1) } ?: -1
                ImageItem(r, order.getOrNull(r.resourceOrder), if (chapterIdx >= 0) flatToc[chapterIdx].title else null)
            }
        }
    }

    /** Small preview of [item] (decoded from the book file, cached). Null for SVG / web pictures. */
    suspend fun imageThumbnail(item: ImageItem, maxSide: Int): android.graphics.Bitmap? {
        thumbCache.get(item.ref.globalIndex)?.let { return it }
        val ready = _load.value as? ReaderLoad.Ready ?: return null
        val entry = item.ref.entry ?: return null
        val file = graph.library.bookFile(ready.book)
        val bmp = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            com.novelreader.app.reader.ImageThumbs.load(file, entry, maxSide)
        }
        if (bmp != null) thumbCache.put(item.ref.globalIndex, bmp)
        return bmp
    }

    /**
     * Opens the picture the reader tapped. [pageUrl] is the address of the page document and [index] the n-th picture
     * element of it (same numbering as [com.novelreader.app.core.EpubImages]). Shows the zoom viewer, or a message when
     * the picture cannot be shown (SVG, web or embedded picture).
     */
    fun openImageFromPage(pageUrl: String, index: Int) {
        viewModelScope.launch {
            loadImages()
            val list = kotlinx.coroutines.withTimeoutOrNull(15_000) { images.filterNotNull().first() }.orEmpty()
            val decoded = com.novelreader.app.core.EpubImages.decode(pageUrl)
            val item = list.filter { it.ref.indexInResource == index && decoded.contains(it.ref.resourceHref) }
                .maxByOrNull { it.ref.resourceHref.length }
            val ready = _load.value as? ReaderLoad.Ready
            val entry = item?.ref?.entry
            val bmp = if (ready == null || entry == null) null else kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                com.novelreader.app.reader.ImageThumbs.loadForZoom(graph.library.bookFile(ready.book), entry)
            }
            if (bmp == null) _events.tryEmit(ReaderEvent.Message(R.string.image_zoom_unavailable)) else _dialog.value = ReaderDialog.ImageZoom(bmp)
        }
    }

    /** Jumps to exactly where [item] sits in the book. */
    fun goToImage(item: ImageItem) {
        val link = item.link ?: return
        _commands.tryEmit(ReaderCommand.GoImage(link, item.ref.resourceHref, item.ref.indexInResource))
    }

    fun continueFromSaved() {
        val json = (_load.value as? ReaderLoad.Ready)?.book?.lastLocatorJson ?: return
        goToLocatorJson(json)
    }

    fun chapterTitleFor(locator: Locator): String? {
        val idx = currentTocIndex(locator.locations.position)
        return if (idx >= 0) flatToc[idx].title else locator.title?.takeIf { it.isNotBlank() }
    }

    // =====================================================================================
    // Settings
    // =====================================================================================

    fun updateSettings(transform: (ReaderSettings) -> ReaderSettings) {
        viewModelScope.launch { graph.settings.update(transform) }
    }

    // =====================================================================================
    // Fonts and background image
    // =====================================================================================

    /** Selects imported fonts for Persian (and other Arabic-script) text and for everything else. null = default. */
    fun selectFonts(faId: String?, latinId: String?) {
        updateSettings { it.copy(faFontId = faId, latinFontId = latinId) }
    }

    /**
     * Imports a TTF/OTF chosen in the system picker. A new font must be declared in the publication's resources, so
     * after a successful new import the position is saved and the reader is reopened (see [ReaderEvent.Reopen]).
     */
    fun importFont(uri: Uri) = importFonts(listOf(uri))

    /**
     * Bulk import (any number of files, e.g. everything picked with "Select all" in the file browser). One font =
     * selected for the scripts it covers; several = just added to the list (select them later, one by one).
     */
    fun importFonts(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            val results = graph.fonts.importMany(uris)
            val added = results.filterIsInstance<FontImportResult.Success>().filter { !it.alreadyPresent }.map { it.font }
            results.filterIsInstance<FontImportResult.Failure>().map { it.error }.distinct().forEach {
                _events.tryEmit(ReaderEvent.Message(fontErrorRes(it)))
            }
            val dup = results.count { it is FontImportResult.Success && it.alreadyPresent }
            finishFontImport(added)
            if (added.isEmpty() && dup > 0) _events.tryEmit(ReaderEvent.Message(R.string.font_already_imported))
        }
    }

    /** Installs one of the bundled suggested fonts (assets/fonts) and selects it. */
    fun useBundledFont(assetName: String) {
        viewModelScope.launch {
            when (val r = graph.fonts.importAsset(assetName)) {
                is FontImportResult.Failure -> _events.tryEmit(ReaderEvent.Message(fontErrorRes(r.error)))
                is FontImportResult.Success -> {
                    // Already imported earlier: just select it again.
                    val font = r.font
                    graph.settings.update {
                        it.copy(
                            faFontId = if (font.coversPersian) font.id else it.faFontId,
                            latinFontId = if (font.coversLatin) font.id else it.latinFontId,
                        )
                    }
                }
            }
        }
    }

    private suspend fun finishFontImport(added: List<CustomFont>) {
        if (added.isEmpty()) return
        if (added.size == 1) {
            val font = added.first()
            graph.settings.update {
                it.copy(
                    faFontId = if (font.coversPersian) font.id else it.faFontId,
                    latinFontId = if (font.coversLatin) font.id else it.latinFontId,
                )
            }
            if (!font.coversPersian) _events.tryEmit(ReaderEvent.Message(R.string.font_no_persian, font.displayName))
        } else {
            _events.tryEmit(ReaderEvent.Message(R.string.fonts_imported_count, added.size.toString()))
        }
    }

    /**
     * A font can only be drawn if its @font-face was declared when the publication was opened. When the user picks
     * a font that was not (any imported font, via the font list or right after an import), the position is saved
     * and the reader reopens once - then the font is there.
     */
    private fun watchFontSelection() {
        viewModelScope.launch {
            settings.map { setOfNotNull(it.faFontId, it.latinFontId) }.distinctUntilChanged().collect { wanted ->
                val live = customFonts.value.map { it.id }.toSet()
                val missing = wanted.filter { it in live && it !in fontIdsAtOpen.value }
                if (missing.isNotEmpty()) {
                    latestLocator?.let { persist(it) }
                    val name = customFonts.value.firstOrNull { it.id == missing.first() }?.displayName.orEmpty()
                    _events.tryEmit(ReaderEvent.Message(R.string.font_applying_reload, name))
                    _events.tryEmit(ReaderEvent.Reopen)
                }
            }
        }
    }

    fun deleteFonts(ids: Set<String>) {
        viewModelScope.launch {
            ids.forEach { graph.fonts.delete(it) }
            _events.tryEmit(ReaderEvent.Message(R.string.font_deleted))
        }
    }

    fun deleteFont(id: String) {
        viewModelScope.launch {
            graph.fonts.delete(id)
            _events.tryEmit(ReaderEvent.Message(R.string.font_deleted))
        }
    }

    fun resetFonts() {
        updateSettings { it.copy(faFontId = null, latinFontId = null, fontChoice = com.novelreader.app.data.FontChoice.ORIGINAL) }
    }

    private fun fontErrorRes(e: FontImportError): Int = when (e) {
        FontImportError.NO_ACCESS -> R.string.font_err_no_access
        FontImportError.EMPTY, FontImportError.NOT_A_FONT, FontImportError.CORRUPT -> R.string.font_err_invalid
        FontImportError.TOO_LARGE -> R.string.font_err_too_large
        FontImportError.COLLECTION -> R.string.font_err_collection
        FontImportError.WEB_FONT -> R.string.font_err_webfont
        FontImportError.LIMIT_REACHED, FontImportError.IO -> R.string.font_err_io
    }

    fun importBackground(uri: Uri) {
        viewModelScope.launch {
            val previous = settings.value.backgroundImagePath
            when (val r = graph.backgrounds.import(uri)) {
                is BgImageResult.Ok -> {
                    updateSettings { it.copy(backgroundImagePath = r.path) }
                    graph.backgrounds.delete(previous)
                }
                BgImageResult.Invalid -> _events.tryEmit(ReaderEvent.Message(R.string.bg_err_invalid))
                BgImageResult.TooLarge -> _events.tryEmit(ReaderEvent.Message(R.string.bg_err_too_large))
                BgImageResult.IoError -> _events.tryEmit(ReaderEvent.Message(R.string.bg_err_io))
            }
        }
    }

    fun removeBackgroundImage() {
        val previous = settings.value.backgroundImagePath
        updateSettings { it.copy(backgroundImagePath = null) }
        graph.backgrounds.delete(previous)
    }

    // =====================================================================================
    // Annotations
    // =====================================================================================

    fun createHighlight(json: String, text: String, color: Int, note: String?, chapter: String?) {
        viewModelScope.launch {
            val id = graph.annotations.addHighlight(bookId, json, text, color, chapter)
            if (!note.isNullOrBlank()) {
                graph.annotations.highlight(id)?.let { graph.annotations.updateHighlight(it.copy(note = note.trim())) }
            }
        }
    }

    fun updateHighlight(h: HighlightEntity) { viewModelScope.launch { graph.annotations.updateHighlight(h) } }
    fun deleteHighlight(id: Long) { viewModelScope.launch { graph.annotations.deleteHighlight(id) } }

    fun openHighlight(id: Long) {
        viewModelScope.launch {
            graph.annotations.highlight(id)?.let { _dialog.value = ReaderDialog.EditHighlight(it) }
        }
    }

    fun addBookmark(title: String?) {
        val l = latestLocator ?: return
        viewModelScope.launch {
            graph.annotations.addBookmark(
                bookId, l.toJSON().toString(), title, _info.value.chapterTitle, _info.value.fraction,
            )
        }
    }

    fun updateBookmark(b: BookmarkEntity) { viewModelScope.launch { graph.annotations.updateBookmark(b) } }
    fun deleteBookmark(id: Long) { viewModelScope.launch { graph.annotations.deleteBookmark(id) } }

    fun addToLibrary() {
        viewModelScope.launch {
            graph.library.addToLibrary(bookId)
            _inLibrary.value = true
        }
    }

    // =====================================================================================
    // In-book search (Readium search service over the real EPUB text)
    // =====================================================================================

    fun runSearch(rawQuery: String) {
        val query = rawQuery.trim()
        searchJob?.cancel()
        if (query.isEmpty()) { clearSearch(); return }
        val pub = (_load.value as? ReaderLoad.Ready)?.publication ?: return
        _search.value = SearchState(query = query, running = true)
        searchJob = viewModelScope.launch {
            val hits = ArrayList<SearchHit>()
            var truncated = false
            try {
                val iterator = pub.search(query)
                if (iterator == null) {
                    _search.value = SearchState(query = query, unsupported = true, done = true); return@launch
                }
                try {
                    var failed = false
                    loop@ while (true) {
                        val collection = iterator.next().getOrElse { failed = true; null }
                        if (failed) break
                        if (collection == null) break
                        for (loc in collection.locators) {
                            hits += SearchHit(
                                locator = loc,
                                before = loc.text.before.orEmpty(),
                                match = loc.text.highlight.orEmpty(),
                                after = loc.text.after.orEmpty(),
                                chapter = chapterTitleFor(loc),
                            )
                            if (hits.size >= MAX_SEARCH_HITS) { truncated = true; break@loop }
                        }
                        _search.value = _search.value.copy(hits = hits.toList())
                    }
                    _search.value = SearchState(
                        query = query, hits = hits.toList(), truncated = truncated, failed = failed && hits.isEmpty(),
                        activeIndex = -1, done = true,
                    )
                } finally {
                    iterator.close()
                }
            } catch (t: Throwable) {
                if (t is kotlinx.coroutines.CancellationException) throw t
                _search.value = SearchState(query = query, hits = hits.toList(), failed = true, done = true)
            }
        }
    }

    fun clearSearch() {
        searchJob?.cancel()
        _search.value = SearchState()
    }

    fun goToSearchHit(index: Int) {
        val hits = _search.value.hits
        if (index !in hits.indices) return
        _search.value = _search.value.copy(activeIndex = index)
        go(hits[index].locator)
    }

    fun nextSearchHit() {
        val s = _search.value
        if (s.hits.isEmpty()) return
        goToSearchHit((s.activeIndex + 1).mod(s.hits.size))
    }

    fun previousSearchHit() {
        val s = _search.value
        if (s.hits.isEmpty()) return
        goToSearchHit((s.activeIndex - 1).mod(s.hits.size))
    }

    // =====================================================================================
    // Reading time
    // =====================================================================================

    /** Called by the activity when it becomes visible / stops being visible. Only foreground time is counted. */
    fun onForeground() {
        sessionStartedAt = System.currentTimeMillis()
        // Known now when the navigator already reported a position, otherwise taken from the first report.
        sessionStartProgress = if (latestLocator != null) _info.value.fraction else -1.0
    }

    fun onBackground() {
        val started = sessionStartedAt
        if (started <= 0L) return
        sessionStartedAt = 0L
        val delta = System.currentTimeMillis() - started
        // A single unbroken stretch over 6 hours is almost certainly a forgotten open screen: not counted.
        if (delta in 1_000..MAX_SESSION_MS) {
            // Own scope: the view-model may be cleared right after onStop, which would cancel viewModelScope.
            val library = graph.library
            val id = bookId
            val end = _info.value.fraction
            val start = if (sessionStartProgress < 0) end else sessionStartProgress
            kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
                library.addReadingTime(id, delta)
                // One "sitting" for the Reading stats screen.
                library.recordSession(id, started, delta, start, end)
            }
        }
    }

    // =====================================================================================
    // Book information (real data only)
    // =====================================================================================

    fun loadBookInfo() {
        viewModelScope.launch {
            val book = graph.library.get(bookId) ?: return@launch
            _bookInfo.value = BookInfoData(
                fileName = book.fileName,
                sizeBytes = book.sizeBytes,
                totalChapters = flatToc.size,
                readingMillis = book.readingMillis + (if (sessionStartedAt > 0) System.currentTimeMillis() - sessionStartedAt else 0),
                characters = book.charCount,
                words = book.wordCount,
            )
            if (book.charCount == null || book.wordCount == null) {
                val stats = graph.library.textStats(book)
                _bookInfo.value = _bookInfo.value?.copy(characters = stats?.characters, words = stats?.words)
            }
        }
    }

    // =====================================================================================
    // Auto scroll / speed read state (the loops themselves run in the activity, next to the navigator)
    // =====================================================================================

    fun startAuto() {
        val s = settings.value
        val needsScroll = s.autoScrollMode == AutoScrollMode.SCROLL_PIXEL || s.autoScrollMode == AutoScrollMode.SCROLL_LINE
        if (needsScroll && !s.isVerticalScrolling()) {
            updateSettings { it.withFlipMode(PageFlipMode.TOP_TO_BOTTOM_CONTINUOUS) }
            _events.tryEmit(ReaderEvent.Message(R.string.auto_switched_scroll))
        }
        _blind.value = 0f
        _rsvpPaused.value = false
        _rsvp.value = RsvpDisplay()
        _autoRunning.value = true
        _chromeVisible.value = false
        showDialog(null)
        setSettingsOpen(false)
    }

    fun stopAuto() {
        _autoRunning.value = false
        _rsvp.value = RsvpDisplay()
        _rsvpPaused.value = false
    }

    fun setBlind(v: Float) { _blind.value = v }
    fun setRsvp(d: RsvpDisplay) { _rsvp.value = d }
    fun toggleRsvpPause() { _rsvpPaused.value = !_rsvpPaused.value }
    fun postMessage(resId: Int, arg: String? = null) { _events.tryEmit(ReaderEvent.Message(resId, arg)) }

    /** Next reading-order link after [href], for Speed Read to continue into the following chapter. */
    fun nextResourceLink(href: String): Link? {
        val order = (_load.value as? ReaderLoad.Ready)?.publication?.readingOrder ?: return null
        val i = order.indexOfFirst { ReadingMath.stripFragment(it.url().toString()) == ReadingMath.stripFragment(href) }
        return if (i >= 0) order.getOrNull(i + 1) else null
    }

    // =====================================================================================
    // Page flip / options
    // =====================================================================================

    fun setFlipMode(m: PageFlipMode) { updateSettings { it.withFlipMode(m) } }

    // =====================================================================================
    // Selection formatting (highlight / bold / underline / strikethrough / note)
    // =====================================================================================

    fun applyStyle(style: AnnotationStyle, json: String, text: String, chapter: String?) {
        viewModelScope.launch {
            graph.annotations.addHighlight(bookId, json, text, AnnotationDecor.defaultColor(style), chapter, style)
            _events.tryEmit(ReaderEvent.Message(R.string.format_saved))
        }
    }

    fun createNote(json: String, text: String, chapter: String?, note: String) {
        viewModelScope.launch {
            graph.annotations.addHighlight(bookId, json, text, AnnotationDecor.defaultColor(AnnotationStyle.NOTE), chapter, AnnotationStyle.NOTE, note)
        }
    }

    /**
     * Removes formatting from the annotations overlapping the selection (same chapter, overlapping text, nearby
     * position). Formatting that carries a note keeps the note (it becomes a plain note); notes themselves stay.
     */
    fun resetFormatting(selectionJson: String, selectionText: String) {
        viewModelScope.launch {
            val sel = AnnotationDecor.parseLocator(selectionJson)
            if (sel == null) { _events.tryEmit(ReaderEvent.Message(R.string.format_reset_none)); return@launch }
            var changed = 0
            for (h in highlights.value) {
                val style = AnnotationDecor.styleOf(h)
                if (style == AnnotationStyle.NOTE) continue
                val loc = AnnotationDecor.parseLocator(h.locatorJson) ?: continue
                if (loc.href != sel.href) continue
                val a = loc.locations.progression
                val b = sel.locations.progression
                if (a != null && b != null && kotlin.math.abs(a - b) > 0.05) continue
                val t1 = h.text.trim()
                val t2 = selectionText.trim()
                if (t1.isEmpty() || t2.isEmpty() || !(t1.contains(t2) || t2.contains(t1))) continue
                if (h.note.isNullOrBlank()) graph.annotations.deleteHighlight(h.id)
                else graph.annotations.updateHighlight(h.copy(style = AnnotationStyle.NOTE.name))
                changed++
            }
            _events.tryEmit(
                if (changed > 0) ReaderEvent.Message(R.string.format_reset_done, changed.toString())
                else ReaderEvent.Message(R.string.format_reset_none)
            )
        }
    }

    override fun onCleared() {
        (_load.value as? ReaderLoad.Ready)?.publication?.close()
        super.onCleared()
    }

    companion object {
        const val MAX_SEARCH_HITS = 300
        private const val MAX_SESSION_MS = 6L * 60 * 60 * 1000

        fun factory(app: Application, bookId: Long, startLocatorJson: String? = null) = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T = ReaderViewModel(app, bookId, startLocatorJson) as T
        }
    }
}
