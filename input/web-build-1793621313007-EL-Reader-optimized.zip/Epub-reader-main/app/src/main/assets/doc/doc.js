/* EL Reader document view. The page is a flat list of blocks (<... data-i="n">); position, search hits,
   highlights and selections are all addressed as (block, character offset in the block's textContent). */
(function () {
  'use strict';
  function call(name) {
    var NR = window.NR;
    try { if (NR && NR[name]) NR[name].apply(NR, Array.prototype.slice.call(arguments, 1)); } catch (e) {}
  }

  var blocks = [];
  var started = false;
  var userMoved = false;
  var settleToken = 0;

  // ---------- helpers ----------
  function textNodes(el) {
    var w = document.createTreeWalker(el, NodeFilter.SHOW_TEXT, null), out = [], n;
    while ((n = w.nextNode())) out.push(n);
    return out;
  }

  function wrap(block, s, e, cls, id, k, color) {
    if (!block || e <= s) return;
    var pos = 0, nodes = textNodes(block);
    for (var i = 0; i < nodes.length; i++) {
      var n = nodes[i], len = n.data.length, a = pos, b = pos + len;
      pos = b;
      if (b <= s) continue;
      if (a >= e) break;
      var from = Math.max(s, a) - a, to = Math.min(e, b) - a, node = n;
      if (from > 0) node = node.splitText(from);
      if (to - from < node.data.length) node.splitText(to - from);
      var m = document.createElement('mark');
      m.className = cls;
      if (id != null) m.setAttribute('data-h', id);
      if (k != null) m.setAttribute('data-k', k);
      if (color) styleMark(m, cls, color);
      node.parentNode.insertBefore(m, node);
      m.appendChild(node);
    }
  }

  function styleMark(m, cls, c) {
    var rgb = c.join(',');
    if (cls === 'hl') m.style.background = 'rgba(' + rgb + ',.45)';
    else if (cls === 'nt') { m.style.background = 'rgba(' + rgb + ',.25)'; m.style.borderBottom = '2px dotted rgb(' + rgb + ')'; }
    else if (cls === 'ul' || cls === 'st') m.style.textDecorationColor = 'rgb(' + rgb + ')';
  }

  function clearMarks(sel) {
    var list = document.querySelectorAll(sel);
    var parents = new Set();
    for (var i = 0; i < list.length; i++) {
      var m = list[i], p = m.parentNode;
      if (!p) continue;
      while (m.firstChild) p.insertBefore(m.firstChild, m);
      p.removeChild(m);
      parents.add(p);
    }
    parents.forEach(function (p) { p.normalize(); });
  }

  // ---------- position ----------
  function topBlock() {
    var x = Math.min(window.innerWidth / 2, window.innerWidth - 2);
    for (var y = 1; y < 140; y += 7) {
      var el = document.elementFromPoint(x, y);
      var b = el && el.closest ? el.closest('[data-i]') : null;
      if (b) return b;
    }
    var lo = 0, hi = blocks.length - 1;
    while (lo < hi) {
      var mid = (lo + hi) >> 1;
      if (blocks[mid].getBoundingClientRect().bottom <= 0) lo = mid + 1; else hi = mid;
    }
    return blocks[lo] || null;
  }

  function capture() {
    var b = topBlock();
    if (!b) return null;
    var r = b.getBoundingClientRect();
    var f = r.height > 0 ? Math.min(1, Math.max(0, -r.top / r.height)) : 0;
    return { i: +b.getAttribute('data-i'), f: f };
  }

  var reportTimer = 0;
  function scheduleReport() {
    if (reportTimer) return;
    reportTimer = setTimeout(function () {
      reportTimer = 0;
      var c = capture();
      if (c) call('onPosition', c.i, c.f);
    }, 140);
  }

  /** Puts block [i] (plus fraction [f] of its height) [offset] pixels below the top edge. Heights of far-away blocks
      are estimates in big documents, so the scroll is corrected a few times while the layout settles. */
  function scrollToBlock(i, f, offset) {
    var el = blocks[i];
    if (!el) return;
    offset = offset || 0;
    var token = ++settleToken;
    userMoved = false;
    function go() {
      var r = el.getBoundingClientRect();
      var y = window.scrollY + r.top + (f || 0) * r.height - offset;
      window.scrollTo(0, Math.max(0, y));
    }
    go();
    var tries = [30, 90, 250, 600];
    tries.forEach(function (ms) {
      setTimeout(function () {
        if (token !== settleToken || userMoved) return;
        var r = el.getBoundingClientRect();
        var want = offset - (f || 0) * r.height;
        if (Math.abs(r.top - want) > 2) go();
      }, ms);
    });
  }

  ['touchstart', 'wheel', 'mousedown'].forEach(function (ev) {
    window.addEventListener(ev, function () { userMoved = true; }, { passive: true });
  });
  window.addEventListener('scroll', scheduleReport, { passive: true });
  window.addEventListener('resize', function () { setTimeout(updateEstimate, 100); });

  // ---------- style ----------
  function applyStyle(s) {
    var r = document.documentElement.style;
    function set(k, v) { if (v != null) r.setProperty(k, v); }
    set('--fs', s.fs + 'px');
    set('--lh', s.lh);
    set('--para', s.para + 'em');
    set('--mx', s.mx + 'px');
    set('--indent', s.indent + 'em');
    set('--fg', s.fg);
    set('--bg', s.bg);
    set('--link', s.link);
    set('--font', s.font);
    set('--weight', s.weight);
    set('--align', s.align === 'doc' ? 'start' : s.align);
    var c = document.body.classList;
    c.toggle('al-force', s.align !== 'doc');
    c.toggle('d-ltr', s.dir === 'ltr');
    c.toggle('d-rtl', s.dir === 'rtl');
    c.toggle('docfonts', !!s.docFonts);
    c.toggle('nodc', !s.docColors);
    document.documentElement.style.colorScheme = s.dark ? 'dark' : 'light';
  }

  /** Big documents (class "big", set by the host in the markup) skip the layout of off-screen blocks; the height
      assumed for them is the average of what is on screen, so far jumps land close to where they should. */
  function updateEstimate() {
    if (!document.body.classList.contains('big')) return;
    var x = Math.min(window.innerWidth / 2, window.innerWidth - 2), seen = [], sum = 0;
    for (var y = 8; y < window.innerHeight; y += 36) {
      var el = document.elementFromPoint(x, y), b = el && el.closest ? el.closest('#doc > .b') : null;
      if (b && seen.indexOf(b) < 0) { seen.push(b); sum += b.getBoundingClientRect().height; }
    }
    if (seen.length >= 3) document.documentElement.style.setProperty('--est', Math.max(24, Math.round(sum / seen.length)) + 'px');
  }

  function setStyle(s) {
    var keep = started ? capture() : null;
    applyStyle(s);
    if (keep) { void document.body.offsetHeight; updateEstimate(); scrollToBlock(keep.i, keep.f, 0); }
  }

  // ---------- highlights and search ----------
  function rgbOf(hex) {
    var h = (hex || '#ffeb3b').replace('#', '');
    return [parseInt(h.substr(0, 2), 16), parseInt(h.substr(2, 2), 16), parseInt(h.substr(4, 2), 16)];
  }

  function setHighlights(list) {
    clearMarks('mark.hl, mark.ul, mark.nt, mark.st');
    for (var i = 0; i < list.length; i++) {
      var h = list[i];
      wrap(blocks[h.b], h.s, h.e, h.k, h.id, null, rgbOf(h.c));
    }
  }

  var searchHits = [];
  function setSearch(hits, active) {
    clearMarks('mark.sr');
    searchHits = hits;
    for (var i = 0; i < hits.length; i++) wrap(blocks[hits[i][0]], hits[i][1], hits[i][2], 'sr', null, i, null);
    showHit(active, false);
  }

  function showHit(active, scroll) {
    var on = document.querySelectorAll('mark.sr.on');
    for (var i = 0; i < on.length; i++) on[i].classList.remove('on');
    if (active == null || active < 0) return;
    var ms = document.querySelectorAll('mark.sr[data-k="' + active + '"]');
    for (var j = 0; j < ms.length; j++) ms[j].classList.add('on');
    if (scroll === false || !ms.length) return;
    userMoved = true;                       // stop a pending position restore from pulling the page back
    settleToken++;
    var token = settleToken;
    // The match is put about a quarter of the screen below the top; heights of blocks that were not drawn yet are
    // estimates, so the position is checked again while the layout settles.
    function place(force) {
      if (token !== settleToken) return;
      var r = ms[0].getBoundingClientRect();
      var comfy = r.top > 80 && r.bottom < window.innerHeight - 140;
      if (force || !comfy) window.scrollTo(0, Math.max(0, window.scrollY + r.top - window.innerHeight * 0.25));
    }
    place(true);
    [60, 200, 500].forEach(function (ms2) { setTimeout(function () { place(false); }, ms2); });
  }

  function clearSearch() { clearMarks('mark.sr'); searchHits = []; }

  // ---------- selection ----------
  function rangesOf(r) {
    var out = [], n = blocks.length;
    if (!n) return out;
    var lo = 0, hi = n;
    while (lo < hi) {
      var mid = (lo + hi) >> 1, b = blocks[mid];
      if (r.comparePoint(b, b.childNodes.length) < 0) lo = mid + 1; else hi = mid;
    }
    for (var i = lo; i < n; i++) {
      var blk = blocks[i];
      if (r.comparePoint(blk, 0) > 0) break;
      var len = blk.textContent.length, s = 0, e = len;
      var pre = document.createRange();
      pre.selectNodeContents(blk);
      if (r.compareBoundaryPoints(Range.START_TO_START, pre) > 0) {
        pre.setEnd(r.startContainer, r.startOffset);
        s = pre.toString().length;
        pre.selectNodeContents(blk);
      }
      if (r.compareBoundaryPoints(Range.END_TO_END, pre) < 0) {
        var p2 = document.createRange();
        p2.selectNodeContents(blk);
        p2.setEnd(r.endContainer, r.endOffset);
        e = p2.toString().length;
      }
      if (e > s) out.push({ b: i, s: s, e: e });
    }
    return out;
  }

  function selectionPayload() {
    var sel = window.getSelection();
    if (!sel || sel.rangeCount === 0 || sel.isCollapsed) return null;
    var ranges = rangesOf(sel.getRangeAt(0));
    if (!ranges.length) return null;
    return { text: sel.toString(), ranges: ranges };
  }

  var selTimer = 0;
  document.addEventListener('selectionchange', function () {
    clearTimeout(selTimer);
    selTimer = setTimeout(function () {
      var p = selectionPayload();
      call('onSelection', p ? JSON.stringify(p) : '');
    }, 140);
  });

  function clearSelection() { var s = window.getSelection(); if (s) s.removeAllRanges(); }

  // ---------- taps ----------
  document.addEventListener('click', function (e) {
    var sel = window.getSelection();
    if (sel && !sel.isCollapsed) return;
    var t = e.target;
    var hl = t.closest ? t.closest('mark[data-h]') : null;
    if (hl) { call('onHighlightTap', +hl.getAttribute('data-h')); return; }
    var a = t.closest ? t.closest('a[data-href],a[data-a]') : null;
    if (a) {
      e.preventDefault();
      if (a.hasAttribute('data-href')) call('onLink', a.getAttribute('data-href'));
      else call('onAnchor', a.getAttribute('data-a'));
      return;
    }
    call('onTap', e.clientX / window.innerWidth, e.clientY / window.innerHeight);
  });

  // ---------- public ----------
  function init(cfg) {
    var list = document.querySelectorAll('[data-i]');
    blocks = new Array(list.length);
    for (var i = 0; i < list.length; i++) blocks[+list[i].getAttribute('data-i')] = list[i];
    applyStyle(cfg.style);
    if (cfg.highlights && cfg.highlights.length) setHighlights(cfg.highlights);
    started = true;
    document.body.style.visibility = 'visible';
    if (cfg.block != null) scrollToBlock(cfg.block, cfg.frac || 0, 0);
    setTimeout(updateEstimate, 60);
    call('onReady', blocks.length);
  }

  function pageScroll(dir) {
    userMoved = true;
    window.scrollBy({ top: dir * window.innerHeight * 0.88, behavior: 'smooth' });
  }

  window.DocApp = {
    init: init, setStyle: setStyle, scrollToBlock: scrollToBlock, setHighlights: setHighlights,
    setSearch: setSearch, showHit: showHit, clearSearch: clearSearch, clearSelection: clearSelection,
    pageScroll: pageScroll, position: capture, selection: selectionPayload,
    _blocks: function () { return blocks; },
  };

  // Hosts that load the page without a native bridge (tests) can still drive it; a native host calls DocApp.init itself.
  window.addEventListener('load', function () { call('onLoaded'); });
})();
