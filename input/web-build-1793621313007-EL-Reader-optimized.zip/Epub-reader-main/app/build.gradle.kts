import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.ksp)
}

// ---- Easily changeable identity (also see res/values/strings.xml -> app_name) ----
val appId = "com.novelreader.app"
val appVersionName = "0.1.0"
val appVersionCode = 1

android {
    namespace = "com.novelreader.app"
    compileSdk = 36

    defaultConfig {
        applicationId = appId
        minSdk = 26          // unchanged
        targetSdk = 35
        versionCode = appVersionCode
        versionName = appVersionName
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    // Release signing is read from environment variables so no secrets live in the repo.
    // See docs/BUILD.md. If the variables are absent, the release build is left unsigned.
    signingConfigs {
        // Stable DEBUG key (committed on purpose; it protects nothing). CI builds used to get a fresh random debug
        // key every run, which made each new APK fail to install over the previous one ("signature conflict") and
        // forced an uninstall - i.e. loss of the reader's data. With one fixed key, updates install over each other.
        getByName("debug") {
            storeFile = file("novelreader-debug.keystore")
            storePassword = "android"
            keyAlias = "novelreader-debug"
            keyPassword = "android"
        }
        val ksPath = System.getenv("NR_KEYSTORE_PATH")
        if (ksPath != null) {
            create("release") {
                storeFile = file(ksPath)
                storePassword = System.getenv("NR_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("NR_KEY_ALIAS")
                keyPassword = System.getenv("NR_KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        debug {
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            // Without release secrets the optimised build is signed with the same stable key as the debug build and
            // keeps the debug application id, so it installs over an existing install and keeps the library.
            val own = signingConfigs.findByName("release")
            if (own != null) {
                signingConfig = own
            } else {
                signingConfig = signingConfigs.getByName("debug")
                applicationIdSuffix = ".debug"
                versionNameSuffix = "-fast"
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        // Core library desugaring: required by the Readium Kotlin Toolkit (Gradle error reported by the user).
        isCoreLibraryDesugaringEnabled = true
    }
    buildFeatures {
        compose = true
    }
    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
    lint {
        // The CI only needs the APK; lint's release checks are not part of the build.
        checkReleaseBuilds = false
        abortOnError = false
    }
}

// Kotlin compiler options (the old android { kotlinOptions {} } DSL is removed in recent Kotlin Gradle plugins).
kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
        freeCompilerArgs.add("-opt-in=org.readium.r2.shared.ExperimentalReadiumApi")
    }
}

ksp {
    arg("room.schemaLocation", "$projectDir/schemas")
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.fragment.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.viewmodel.ktx)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.kotlinx.coroutines.android)

    implementation(libs.compose.ui)
    implementation(libs.compose.ui.graphics)
    implementation(libs.compose.foundation)
    implementation(libs.compose.ui.tooling.preview)
    implementation(libs.compose.material3)
    implementation(libs.compose.material.icons)

    implementation(libs.room.runtime)
    implementation(libs.room.ktx)
    ksp(libs.room.compiler)

    implementation(libs.datastore.preferences)
    implementation(libs.coil.compose)

    implementation(libs.readium.shared)
    implementation(libs.readium.streamer)
    implementation(libs.readium.navigator)

    // CBR (RAR) archives: pure-Java reader, RAR 1.4 - 7 incl. RAR5 (UnRAR licence terms, see THIRD_PARTY_NOTICES.md).
    implementation(libs.junrar)

    // Installs the baseline profile (src/main/baseline-prof.txt + the Compose libraries' own) when the APK is
    // sideloaded, so the first scrolls and animations run as precompiled code instead of interpreted bytecode.
    implementation("androidx.profileinstaller:profileinstaller:1.4.1")

    coreLibraryDesugaring(libs.desugar.jdk.libs)

    testImplementation(libs.junit)
    // The JVM unit-test classpath only has android.jar stubs of org.json; the real library lets JSON round-trips run.
    testImplementation("org.json:json:20240303")
    // The JVM has no XmlPullParser; the DOCX parser is fed this one in unit tests (Android supplies its own).
    testImplementation(libs.kxml2)
}
