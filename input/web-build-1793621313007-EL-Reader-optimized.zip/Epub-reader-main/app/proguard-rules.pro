# Readium uses reflection/serialization in a few places; keep its public surface.
-keep class org.readium.** { *; }
-dontwarn org.readium.**

# Room generated code is handled by Room's own consumer rules.

# JavaScript bridges used by the reader's WebViews (called by name from the page).
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod,Exceptions

# Optional / annotation-only dependencies referenced by libraries but absent at runtime.
-dontwarn javax.annotation.**
-dontwarn org.slf4j.**
-dontwarn org.jetbrains.annotations.**
-dontwarn com.google.errorprone.annotations.**
-dontwarn org.checkerframework.**
-dontwarn kotlinx.parcelize.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
-dontwarn android.support.**

# junrar (CBR): kept whole; it is small and reads archive headers through reflection-free but name-sensitive code paths.
-keep class com.github.junrar.** { *; }
-dontwarn com.github.junrar.**
