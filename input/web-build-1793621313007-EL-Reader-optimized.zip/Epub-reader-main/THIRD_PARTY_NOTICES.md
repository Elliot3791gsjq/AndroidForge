# Third-party notices

## libreadview (page-curl renderers)
Files in `app/src/main/java/com/novelreader/app/reader/curl/` (`IBookCurlRenderer`, `GoogleCurlRenderer`, `CurlRenderer`
and the geometry helpers) are adapted from https://github.com/Peyilo/libreadview

MIT License

Copyright (c) 2025 Peyilo

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the Software without restriction, including without limitation the
rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit
persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

## junrar (CBR / RAR archives)
CBR comics are read with junrar, https://github.com/junrar/junrar (Maven Central `com.github.junrar:junrar`).
It is a Java port of the UnRAR source and is used under the UnRAR licence: it can read and extract RAR archives, and
the code may not be used to develop a RAR (WinRAR) compatible archiver. EL Reader only reads archives.

## kxml2 (unit tests only)
`net.sf.kxml:kxml2` supplies an XML pull parser for the JVM unit tests of the DOCX reader. It is not shipped in the APK.
