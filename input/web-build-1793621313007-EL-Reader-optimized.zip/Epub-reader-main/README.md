# EL Reader (کتاب‌خوان رمان) — native Android EPUB reader

Kotlin · Jetpack Compose · Room · DataStore · Storage Access Framework · **Readium Kotlin Toolkit 3.2.0** (real EPUB engine, not a WebView-wrapped website).
Persian (RTL) and English UI, dark theme by default.

> **Status:** built by GitHub Actions on every push (Releases `build-N`: `EL-Reader.apk` = optimised, `NovelReader-debug.apk` = full)
> and walked through on an Android 14 emulator by an automated UI test (screenshots + pixel checks, Releases `ui-N`).
> **Not yet tried on a physical phone.** Exact results: [`docs/TEST_REPORT.md`](docs/TEST_REPORT.md);
> known gaps: [`docs/KNOWN_LIMITATIONS.md`](docs/KNOWN_LIMITATIONS.md).

## Build
JDK 17, Gradle 8.11.1, AGP 8.9.1, Kotlin 2.3.20, KSP 2.3.4, compileSdk 36. See [`docs/BUILD.md`](docs/BUILD.md).
The easiest way: push to GitHub — the *Build APK* workflow publishes both APKs as a Release. To re-run the emulator walkthrough:
Actions ▸ *Emulator UI test* ▸ Run workflow (tag = `build-N`, apk = `EL-Reader.apk` or `NovelReader-debug.apk`).

## Changing name / icon / package id
- App name: `app/src/main/res/values/strings.xml` and `values-en/strings.xml` → `app_name`
  (strings are generated from a table; if you edit the XML by hand, keep both languages in sync).
- Icon: `res/mipmap-*/ic_launcher_foreground.png` (+ `ic_launcher_monochrome.png`), adaptive XML in `res/mipmap-anydpi-v26`, background colour in `res/values/colors.xml`; source image in `docs/logo-source.png`.
- Package id: `appId` at the top of `app/build.gradle.kts` (+ `namespace` if you also move the Kotlin package).

## Install an APK
Download `EL-Reader.apk` from the newest `build-N` Release, open it on the phone and allow "install unknown apps" when asked.
Both APKs use the id `com.novelreader.app.debug` and the same signing key, so one installs over the other and keeps the data.

## Custom fonts
Imported TTF/OTF fonts are served to the EPUB through a composite Readium container + CSS `@font-face` injection
(the EPUB file itself is never modified). Design, risks and device test plan: [`docs/FONT_IMPORT.md`](docs/FONT_IMPORT.md).
