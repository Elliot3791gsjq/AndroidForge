# راهنمای ساخت (Build)

> هشدار صادقانه: این پروژه هنوز در هیچ محیطی کامپایل نشده است (محیط نگارنده SDK اندروید و دسترسی به Maven/Google نداشت).
> اولین ساخت ممکن است خطاهای کامپایل داشته باشد؛ احتمال‌های شناخته‌شده در `TEST_REPORT.md` بخش «ریسک‌های کامپایل» آمده است.

## پیش‌نیازها
- Android Studio (نسخهٔ جدیدی که AGP 8.7.x را پشتیبانی کند) یا JDK 17 + Android SDK (platform 35، build-tools)
- Gradle 8.9 یا بالاتر (پروژه Gradle Wrapper ندارد؛ پایین ببینید)
- دسترسی به `mavenCentral()` و `google()`؛ Readium از mavenCentral با گروه `org.readium.kotlin-toolkit` می‌آید.

## ساخت با Android Studio
1. `File ▸ Open` و پوشهٔ `NovelReader` را باز کنید. Studio خودش Gradle را همگام می‌کند.
2. اگر `gradlew` نبود: در پوشهٔ پروژه `gradle wrapper --gradle-version 8.10.2` را اجرا کنید (یا Studio آن را بسازد).
3. `Build ▸ Build APK(s)` یا اجرای مستقیم روی گوشی/شبیه‌ساز (minSdk 26).

## ساخت با خط فرمان
```
./gradlew :app:testDebugUnitTest     # تست‌های JVM (منطق خالص)
./gradlew :app:assembleDebug         # app/build/outputs/apk/debug/app-debug.apk
```

## نسخهٔ Release امضاشده
1. ساخت کلید (یک بار؛ کلید و رمز را امن نگه دارید، هرگز در مخزن نگذارید):
   ```
   keytool -genkeypair -v -keystore novelreader.jks -alias novelreader -keyalg RSA -keysize 2048 -validity 10000
   ```
2. تنظیم متغیرهای محیطی:
   ```
   export NR_KEYSTORE_PATH=/path/novelreader.jks
   export NR_KEYSTORE_PASSWORD=...
   export NR_KEY_ALIAS=novelreader
   export NR_KEY_PASSWORD=...
   ./gradlew :app:assembleRelease
   ```
3. خروجی: `app/build/outputs/apk/release/app-release.apk`. اگر متغیرها تنظیم نباشند، فایل **بدون امضا** تولید می‌شود و قابل نصب نیست.
4. Release با `minify`/`shrinkResources` ساخته می‌شود؛ قوانین در `app/proguard-rules.pro` هنوز **آزمایش‌نشده** است. اگر برنامه در Release کرش کرد
   (به‌ویژه Readium/Room/Coil)، موقتاً `isMinifyEnabled=false` کنید و قوانین keep را کامل کنید.

## تغییر نام، آیکون، شناسهٔ بسته
در `README.md` توضیح داده شده است.

## CI
`.github/workflows/build.yml` تست‌های واحد و `assembleDebug` را اجرا و APK را آپلود می‌کند (اجرا نشده).
