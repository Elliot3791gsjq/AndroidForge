# rem MavenCentral Publishing

./gradlew publishAllPublicationsToMavenCentralRepository -PenablePublishing